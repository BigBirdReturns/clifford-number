set -Eeuo pipefail
rm -rf "$OUT" "$QUAL" "$STAGE"
mkdir -p "$OUT"
HEAD_SHA="$PR_HEAD_SHA"
BASE_SHA="$PR_BASE_SHA"
test "$(git rev-parse HEAD)" = "$HEAD_SHA"
test "$BASE_SHA" = "$CANONICAL_MAIN"
test "$(git rev-parse HEAD^)" = "$CANONICAL_MAIN"
test "$(git rev-list --count "$CANONICAL_MAIN..HEAD")" -eq 1
printf '%s\n' "$WORKFLOW_PATH" "$CONTROLLER_PATH" | LC_ALL=C sort > "$OUT/expected-carrier-paths.txt"
git diff --name-only "$CANONICAL_MAIN" HEAD | LC_ALL=C sort > "$OUT/actual-carrier-paths.txt"
cmp "$OUT/expected-carrier-paths.txt" "$OUT/actual-carrier-paths.txt"
test "$(git diff --name-only --diff-filter=A "$CANONICAL_MAIN" HEAD | wc -l)" -eq 2
test -z "$(git diff --name-only --diff-filter=MDTCRUXB "$CANONICAL_MAIN" HEAD)"
git diff --check "$CANONICAL_MAIN" HEAD
git fetch --no-tags --force origin '+refs/heads/main:refs/remotes/origin/main'
test "$(git rev-parse origin/main)" = "$CANONICAL_MAIN"
test "$(git rev-parse "$CANONICAL_MAIN^{tree}")" = "$CANONICAL_MAIN_TREE"
test "$(git rev-parse "$SOURCE_PRODUCT^")" = "$CANONICAL_MAIN"
test "$(git rev-parse "$SOURCE_PRODUCT^{tree}")" = "$SOURCE_PRODUCT_TREE"
test "$(git rev-list --count "$CANONICAL_MAIN..$SOURCE_PRODUCT")" -eq 1
test -z "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH")"

cat > "$OUT/product-paths.txt" <<'PATHS'
.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/input-custody.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-decision.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-ledger.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/promoted-partial-field-matrix.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/remaining-open-field-census.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-summary.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/index.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/product-manifest.json
docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md
schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json
test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js
tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs
PATHS
LC_ALL=C sort "$OUT/product-paths.txt" -o "$OUT/product-paths.txt"
git diff --name-only "$CANONICAL_MAIN" "$SOURCE_PRODUCT" | LC_ALL=C sort > "$OUT/source-product-paths.txt"
cmp "$OUT/product-paths.txt" "$OUT/source-product-paths.txt"
test "$(git diff --name-only --diff-filter=A "$CANONICAL_MAIN" "$SOURCE_PRODUCT" | wc -l)" -eq 14
test -z "$(git diff --name-only --diff-filter=MDTCRUXB "$CANONICAL_MAIN" "$SOURCE_PRODUCT")"

mapfile -t PRODUCT_PATHS < "$OUT/product-paths.txt"
git show "$SOURCE_PRODUCT:$STANDING_WORKFLOW" > "$OUT/standing-workflow.yml"
test "$(stat -c %s "$OUT/standing-workflow.yml")" = "$STANDING_WORKFLOW_BYTES"
test "$(sha256sum "$OUT/standing-workflow.yml" | awk '{print $1}')" = "$STANDING_WORKFLOW_SHA256"
test "$(git hash-object "$OUT/standing-workflow.yml")" = "$STANDING_WORKFLOW_BLOB"

git worktree add --detach "$QUAL" "$CANONICAL_MAIN"
git -C "$QUAL" checkout "$SOURCE_PRODUCT" -- "${PRODUCT_PATHS[@]}"

QUAL="$QUAL" SCHEMA_PATH="$SCHEMA_PATH" TEST_PATH="$TEST_PATH" VALIDATOR_PATH="$VALIDATOR_PATH" DOCS_PATH="$DOCS_PATH" MANIFEST_PATH="$MANIFEST_PATH" python - <<'PY'
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ["QUAL"])
schema_path = root / os.environ["SCHEMA_PATH"]
test_path = root / os.environ["TEST_PATH"]
validator_path = root / os.environ["VALIDATOR_PATH"]
docs_path = root / os.environ["DOCS_PATH"]
manifest_path = root / os.environ["MANIFEST_PATH"]

def replace_exact(text: str, old: str, new: str, count: int = 1) -> str:
    actual = text.count(old)
    assert actual == count, (old, actual, count)
    return text.replace(old, new, count)

schema = json.loads(schema_path.read_text(encoding="utf-8"))
assert schema["properties"]["schema_version"]["const"] == "ssc-rd04-nd-row-state-reconciliation-schema@2"
schema["properties"]["schema_version"]["const"] = "ssc-rd04-nd-row-state-reconciliation-schema@3"
counts = schema["$defs"]["rowStateValue"]["properties"]["terminal_evidence_state_counts"]
assert counts["additionalProperties"] is False
assert counts["required"] == ["evidence_complete", "not_publicly_recovered"]
assert counts["properties"] == {
    "evidence_complete": {"const": 7},
    "not_publicly_recovered": {"const": 1},
}
counts["required"] = ["evidence_complete", "observed", "not_publicly_recovered"]
counts["properties"] = {
    "evidence_complete": {"const": 7},
    "observed": {"const": 0},
    "not_publicly_recovered": {"const": 1},
}
manifest_const = schema["$defs"]["productManifest"]["properties"]["schema_version"]
assert manifest_const["const"] == "ssc-rd04-nd-row-state-reconciliation-manifest@2"
manifest_const["const"] = "ssc-rd04-nd-row-state-reconciliation-manifest@3"
schema_path.write_text(json.dumps(schema, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

validator = validator_path.read_text(encoding="utf-8")
validator = replace_exact(
    validator,
    "const schemaManifestVersion=schema?.$defs?.productManifest?.properties?.schema_version?.const;\n",
    "const schemaManifestVersion=schema?.$defs?.productManifest?.properties?.schema_version?.const;\n"
    "  const schemaStateCounts=schema?.$defs?.rowStateValue?.properties?.terminal_evidence_state_counts;\n",
)
validator = replace_exact(
    validator,
    "assert(schemaRootVersion==='ssc-rd04-nd-row-state-reconciliation-schema@2','row-state product schema version mismatch');",
    "assert(schemaRootVersion==='ssc-rd04-nd-row-state-reconciliation-schema@3','row-state product schema version mismatch');",
)
validator = replace_exact(
    validator,
    "assert(schemaManifestVersion==='ssc-rd04-nd-row-state-reconciliation-manifest@2','row-state manifest schema version mismatch');",
    "assert(schemaManifestVersion==='ssc-rd04-nd-row-state-reconciliation-manifest@3','row-state manifest schema version mismatch');\n"
    "  assert(schemaStateCounts?.additionalProperties===false,'row-state evidence-count schema is not closed');\n"
    "  assert(same(schemaStateCounts?.required,['evidence_complete','observed','not_publicly_recovered']),'row-state evidence-count schema required keys mismatch');\n"
    "  assert(schemaStateCounts?.properties?.evidence_complete?.const===7&&schemaStateCounts?.properties?.observed?.const===0&&schemaStateCounts?.properties?.not_publicly_recovered?.const===1,'row-state evidence-count schema constants mismatch');",
)
validator = replace_exact(
    validator,
    "assert(m.decision.candidate_id===schemaCandidate,'row-state decision does not conform to candidate schema');",
    "assert(m.decision.candidate_id===schemaCandidate,'row-state decision does not conform to candidate schema');\n"
    "  const decisionStateCounts=m.decision?.proposed_row_state_cell?.value?.terminal_evidence_state_counts;\n"
    "  assert(same(decisionStateCounts,{evidence_complete:7,observed:0,not_publicly_recovered:1}),'row-state decision evidence-count object mismatch');",
)
validator = replace_exact(
    validator,
    "assert(m.manifest.schema_version==='ssc-rd04-nd-row-state-reconciliation-manifest@2','manifest schema mismatch');",
    "assert(m.manifest.schema_version==='ssc-rd04-nd-row-state-reconciliation-manifest@3','manifest schema mismatch');",
)
validator_path.write_text(validator, encoding="utf-8")

test_text = test_path.read_text(encoding="utf-8")
test_text = replace_exact(
    test_text,
    "test('closed product contract rejects 45 adversarial mutations',()=>{",
    "test('closed product contract rejects 48 adversarial mutations',()=>{",
)
test_text = replace_exact(
    test_text,
    "    ['decision value extra key',mutateJson(rel.decision,o=>{o.proposed_row_state_cell.value.unreviewed=true;})],\n",
    "    ['decision value extra key',mutateJson(rel.decision,o=>{o.proposed_row_state_cell.value.unreviewed=true;})],\n"
    "    ['decision observed evidence count drift',mutateJson(rel.decision,o=>{o.proposed_row_state_cell.value.terminal_evidence_state_counts.observed=1;})],\n",
)
test_text = replace_exact(
    test_text,
    "    ['schema manifest version regression',mutateSchema(s=>{s.$defs.productManifest.properties.schema_version.const='ssc-rd04-nd-row-state-reconciliation-manifest@1';})],\n",
    "    ['schema manifest version regression',mutateSchema(s=>{s.$defs.productManifest.properties.schema_version.const='ssc-rd04-nd-row-state-reconciliation-manifest@1';})],\n"
    "    ['schema observed evidence count omitted',mutateSchema(s=>{const c=s.$defs.rowStateValue.properties.terminal_evidence_state_counts;c.required=c.required.filter(k=>k!=='observed');delete c.properties.observed;})],\n"
    "    ['schema observed evidence count drift',mutateSchema(s=>{s.$defs.rowStateValue.properties.terminal_evidence_state_counts.properties.observed.const=1;})],\n",
)
test_text = replace_exact(test_text, "  assert.equal(mutations.length,45);", "  assert.equal(mutations.length,48);")
test_path.write_text(test_text, encoding="utf-8")

docs = docs_path.read_text(encoding="utf-8")
paragraph = (
    "\nThe closed contract is schema `ssc-rd04-nd-row-state-reconciliation-schema@3` "
    "with manifest `ssc-rd04-nd-row-state-reconciliation-manifest@3`. "
    "Its terminal evidence census is the exact three-key object "
    "`{ evidence_complete: 7, observed: 0, not_publicly_recovered: 1 }`. "
    "The schema requires all three keys, forbids additional keys, and the validator "
    "binds the committed decision to the same constants. The adversarial denominator is forty-eight.\n"
)
assert "schema@3" not in docs
docs_path.write_text(docs.rstrip() + "\n" + paragraph, encoding="utf-8")

manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
assert manifest["schema_version"] == "ssc-rd04-nd-row-state-reconciliation-manifest@2"
manifest["schema_version"] = "ssc-rd04-nd-row-state-reconciliation-manifest@3"

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

rows = []
for rec in manifest["hashed_files"]:
    data = (root / rec["path"]).read_bytes()
    rec["bytes"] = len(data)
    rec["sha256"] = sha256(data)
    rec["git_blob"] = git_blob(data)
    rows.append(f'{rec["path"]}\0{rec["sha256"]}\0{rec["bytes"]}\n')
manifest["combined_sha256"] = sha256("".join(sorted(rows)).encode())
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
PY

printf '%s\n' \
  "$DOCS_PATH" \
  "$SCHEMA_PATH" \
  "$TEST_PATH" \
  "$VALIDATOR_PATH" \
  "$MANIFEST_PATH" | LC_ALL=C sort > "$OUT/expected-repaired-paths.txt"
: > "$OUT/actual-repaired-paths.txt"
for p in "${PRODUCT_PATHS[@]}"; do
  if ! cmp -s <(git show "$SOURCE_PRODUCT:$p") "$QUAL/$p"; then
    printf '%s\n' "$p" >> "$OUT/actual-repaired-paths.txt"
  fi
done
LC_ALL=C sort "$OUT/actual-repaired-paths.txt" -o "$OUT/actual-repaired-paths.txt"
cmp "$OUT/expected-repaired-paths.txt" "$OUT/actual-repaired-paths.txt"

git -C "$QUAL" config user.name 'rd04-schema-contract-repair'
git -C "$QUAL" config user.email 'rd04-schema-contract-repair@users.noreply.github.com'
git -C "$QUAL" add -- "${PRODUCT_PATHS[@]}"
git -C "$QUAL" diff --cached --name-only | LC_ALL=C sort > "$OUT/qualified-product-paths.txt"
cmp "$OUT/product-paths.txt" "$OUT/qualified-product-paths.txt"
test "$(git -C "$QUAL" diff --cached --name-only --diff-filter=A | wc -l)" -eq 14
test -z "$(git -C "$QUAL" diff --cached --name-only --diff-filter=MDTCRUXB)"
git -C "$QUAL" diff --cached --check
git -C "$QUAL" commit -m 'Close North Dakota row-state evidence-count schema'
PRODUCT_COMMIT="$(git -C "$QUAL" rev-parse HEAD)"
PRODUCT_TREE="$(git -C "$QUAL" rev-parse HEAD^{tree})"
test "$(git -C "$QUAL" rev-parse HEAD^)" = "$CANONICAL_MAIN"
printf '%s\n' "$PRODUCT_COMMIT" > "$OUT/product-commit.txt"
printf '%s\n' "$PRODUCT_TREE" > "$OUT/product-tree.txt"

for p in "${PRODUCT_PATHS[@]}"; do
  if ! grep -Fxq "$p" "$OUT/expected-repaired-paths.txt"; then
    test "$(git rev-parse "$SOURCE_PRODUCT:$p")" = "$(git -C "$QUAL" rev-parse "HEAD:$p")"
  fi
done
test "$(git -C "$QUAL" rev-parse "HEAD:$PRODUCT_ROOT/promoted-partial-field-matrix.json")" = '6ba11a6025021e9df8ac6535be8c42499654c233'
test "$(git -C "$QUAL" rev-parse "HEAD:$PRODUCT_ROOT/row-state-decision.json")" = '0a9e611061779854c510dd1a8c5a1a0d82822ac7'
test "$(git -C "$QUAL" rev-parse "HEAD:$STANDING_WORKFLOW")" = "$STANDING_WORKFLOW_BLOB"

(
  cd "$QUAL"
  node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs --check | tee "$OUT/builder-check.txt"
  node "$VALIDATOR_PATH" --out "$OUT/validator.json" | tee "$OUT/validator-stdout.txt"
  node --test "$TEST_PATH" | tee "$OUT/adversarial.log"
  grep -F "closed product contract rejects 48 adversarial mutations" "$OUT/adversarial.log" > /dev/null
  npm run release:check > "$OUT/release-check.log" 2>&1
  git reset --hard "$PRODUCT_COMMIT"
  git clean -fdx
  test -z "$(git status --porcelain)"
  node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs --check > "$OUT/post-release-builder-check.txt"
  node "$VALIDATOR_PATH" --out "$OUT/post-release-validator.json" > "$OUT/post-release-validator-stdout.txt"
  node --test "$TEST_PATH" > "$OUT/post-release-adversarial.log"
  cmp "$OUT/validator.json" "$OUT/post-release-validator.json"
  cmp "$OUT/builder-check.txt" "$OUT/post-release-builder-check.txt"
  grep -F "closed product contract rejects 48 adversarial mutations" "$OUT/post-release-adversarial.log" > /dev/null
)

NONWORKFLOW_PATHS=()
for p in "${PRODUCT_PATHS[@]}"; do
  if [ "$p" != "$STANDING_WORKFLOW" ]; then NONWORKFLOW_PATHS+=("$p"); fi
done
test "${#NONWORKFLOW_PATHS[@]}" -eq 13
git worktree add --detach "$STAGE" "$CANONICAL_MAIN"
git -C "$STAGE" checkout "$PRODUCT_COMMIT" -- "${NONWORKFLOW_PATHS[@]}"
mkdir -p "$STAGE/.tmp/rd04-nd-row-state-evidence-count-schema-repair"
cp "$OUT/standing-workflow.yml" "$STAGE/.tmp/rd04-nd-row-state-evidence-count-schema-repair/standing-workflow.yml"
git -C "$STAGE" config user.name 'rd04-schema-contract-stager'
git -C "$STAGE" config user.email 'rd04-schema-contract-stager@users.noreply.github.com'
git -C "$STAGE" add -- "${NONWORKFLOW_PATHS[@]}" .tmp/rd04-nd-row-state-evidence-count-schema-repair/standing-workflow.yml
test "$(git -C "$STAGE" diff --cached --name-only | wc -l)" -eq 14
test "$(git -C "$STAGE" diff --cached --name-only --diff-filter=A | wc -l)" -eq 14
test -z "$(git -C "$STAGE" diff --cached --name-only --diff-filter=MDTCRUXB)"
git -C "$STAGE" diff --cached --check
git -C "$STAGE" commit -m 'Stage qualified North Dakota evidence-count schema repair'
STAGE_COMMIT="$(git -C "$STAGE" rev-parse HEAD)"
STAGE_TREE="$(git -C "$STAGE" rev-parse HEAD^{tree})"
test "$(git -C "$STAGE" rev-parse HEAD^)" = "$CANONICAL_MAIN"
test -z "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH")"
git -C "$STAGE" push origin "$STAGE_COMMIT:refs/heads/$STAGING_BRANCH"
test "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH" | awk '{print $1}')" = "$STAGE_COMMIT"

QUAL="$QUAL" OUT="$OUT" PRODUCT_COMMIT="$PRODUCT_COMMIT" PRODUCT_TREE="$PRODUCT_TREE" STAGE_COMMIT="$STAGE_COMMIT" STAGE_TREE="$STAGE_TREE" python - <<'PY'
import hashlib
import json
import os
from pathlib import Path

root = Path(os.environ["QUAL"])
out = Path(os.environ["OUT"])
manifest = json.loads((root / os.environ["MANIFEST_PATH"]).read_text())
receipt = {
    "schema_version": "ssc-rd04-nd-row-state-evidence-count-schema-repair@1",
    "state": "qualified_evidence_count_schema_repair_staged",
    "canonical_parent": os.environ["CANONICAL_MAIN"],
    "canonical_parent_tree": os.environ["CANONICAL_MAIN_TREE"],
    "source_product": os.environ["SOURCE_PRODUCT"],
    "source_product_tree": os.environ["SOURCE_PRODUCT_TREE"],
    "product_commit_local": os.environ["PRODUCT_COMMIT"],
    "product_tree": os.environ["PRODUCT_TREE"],
    "stage_commit": os.environ["STAGE_COMMIT"],
    "stage_tree": os.environ["STAGE_TREE"],
    "staging_branch": os.environ["STAGING_BRANCH"],
    "repaired_paths": (out / "actual-repaired-paths.txt").read_text().splitlines(),
    "permanent_paths": 14,
    "added_paths": 14,
    "modified_paths": 0,
    "deleted_paths": 0,
    "manifest_schema_version": manifest["schema_version"],
    "manifest_combined_sha256": manifest["combined_sha256"],
    "matrix_git_blob": "6ba11a6025021e9df8ac6535be8c42499654c233",
    "decision_git_blob": "0a9e611061779854c510dd1a8c5a1a0d82822ac7",
    "standing_workflow_git_blob": os.environ["STANDING_WORKFLOW_BLOB"],
    "schema_contract": {
        "schema_version": "ssc-rd04-nd-row-state-reconciliation-schema@3",
        "manifest_schema_version": "ssc-rd04-nd-row-state-reconciliation-manifest@3",
        "terminal_evidence_state_counts": {
            "evidence_complete": 7,
            "observed": 0,
            "not_publicly_recovered": 1,
        },
        "additional_properties": False,
    },
    "qualification": {
        "builder": "passed",
        "validator": "passed",
        "adversarial_refusals": 48,
        "release_check": "passed",
        "post_release_replay": "passed",
    },
    "transition": {
        "substantive_field_terminalizations": 0,
        "matrix_updates": 1,
        "row_state_mutations": 1,
        "row_terminalizations": 1,
        "terminal_cells": [228, 229],
        "still_open_cells": [222, 221],
        "terminal_units": [10, 11],
        "class_closed": False,
    },
    "outside_human_dependency": False,
}
(out / "materialization-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
PY

(cd "$OUT" && find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS && sha256sum -c SHA256SUMS)
