#!/usr/bin/env bash
export TARGET_BRANCH='agent/ssc-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication-v1'
export EXPECTED_MAIN_ANCESTOR='a49b18304a69e9637cd854d38e80b67d4165cc6c'
export ARCHIVE_BYTES='39124'
export ARCHIVE_SHA256='672be321f243be0e3bc4867256fb68641f4319d43fd1fdc06271ff0ddcb85ccd'
export PRODUCT_PATHS='14'
export DATA_DIR='data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication'
export BUILDER='tools/build-status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.mjs'
export VALIDATOR='tools/validate-status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.mjs'
export TEST='test/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.test.js'
export SCHEMA='schemas/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.schema.json'
export WORKFLOW_PATH='.github/workflows/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.yml'
export BLOB_SPECS_JSON='[{"sha":"a36854c499b2904c6b563d61cfbe836c9cc5ef5b","bytes":1957,"sha256":"4dd2a2b553074649e8c3071725e5e1a8249a73d9114d849586acbab2bb4a2da5"},{"sha":"5e2ee4086054ca0117ad692819db633774ab3748","bytes":1957,"sha256":"6b57e36588e280279486d5f702feb539e6b270db05f97061faf464a5a6887496"},{"sha":"0f19030825ce6b4039bfd2e7e1e4dc3236112017","bytes":1957,"sha256":"760893d47658bb8d7261c88c072a2ac03b73921a75d6d668cf3332b7aa1dac3d"},{"sha":"dc87380d1d58b4d853644a4ff5f66a4ff97e3b2e","bytes":3695,"sha256":"4d0d79d3d9554030764989cc1edf7d223320e2fef0d91c398d922e2ca685bc7d"},{"sha":"fa06888c6dc607095a907d0ae99ce6b8a0b39f75","bytes":3695,"sha256":"c0ecb4ad02a8ce79bef41876f7a744e1fad0f839511820bc3aaa519b1b8cdcb5"},{"sha":"79f2e924d5a3ee5d27cd0ee44a6a0f5b0eb163b7","bytes":3695,"sha256":"4ba9c66cadb66552f93f64255acf8fc7bc9f41ffdab3f3766423fc3142032375"},{"sha":"be2956d6b6a79abf44ef4625dca72b170a301c04","bytes":3695,"sha256":"264635f3cc0cca4337e9175e21d7953c0c81cd8f3361bac0008660c3e4886a11"},{"sha":"4ad36971d73addf06c52c6de110a1e756006c63b","bytes":3695,"sha256":"d32e0c21405ce52383a0014fb6e5003d4e8a97c40b6d8ba564c5da7f69af0f1a"},{"sha":"6ac51160aef780f9b3379a7e35d95c24a1836052","bytes":3695,"sha256":"8febdf8eb9a604f6900c2504706e25cb6ce56c703baffa18ba888f96926ff38c"},{"sha":"23a92602261bdcc76b937a43f8064719ffac6206","bytes":3695,"sha256":"7e0553f3aceca85e7bbafe1a02fe0288b5bc5e8a3d912e4955a253c6afbb9d86"},{"sha":"b19ec042a5287a6bd5490dd54fbef0a149d378e7","bytes":3695,"sha256":"cdaa4ae363604ac15000672403da63e13ab436bbf94a320db020086c96756cc8"},{"sha":"a485c078e33dd42fab3ad470dc4ed948404a0f20","bytes":3693,"sha256":"4defc6d39b77b6727bcb2b7f20aabbc210bc95cdb91ce83e501dfd2f251e2336"}]'
export FILE_ENTRIES_JSON='[{"path":".github/workflows/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.yml","bytes":5904,"sha256":"b4a4071fd764059a83578555893014f0fa26f0f9a73afd49d0f62310dfb91391","git_blob_sha":"0b8d9ac1f475b7f4dad97b6fe776e0067611a561","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/authored-row-state-decisions.json","bytes":13166,"sha256":"c03b4ea204bfcbb0a7309bbec77e066b17cd7618a1e646821f9ffa5c0eec7579","git_blob_sha":"4f99abbc3deaa490599f2b72e24ba32e5067d37e","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/index.json","bytes":3140,"sha256":"9cd1c22828c533cf2dc81ebeb9dca74751487cd8b721c2ecfef18373ad7dab46","git_blob_sha":"babcaebc949f62271f3298ad76cd12ecd93e001b","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/predecessor-custody.json","bytes":2202,"sha256":"a0481db18cd8c5de6ea7b1285942c6bcbc2293f27f88426bbb8ea264b95a8ba7","git_blob_sha":"26e78a964313acb0c264d15e260dc51d79a56c5c","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/product-manifest.json","bytes":2345,"sha256":"b9b1d01c6a562d1a17df01aa490c09cec8fc3d229cfc16b70521bec31465adad","git_blob_sha":"3e314227828deb025bf0d246cc2d8139f3cc55dc","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/promoted-partial-field-matrix.json","bytes":447445,"sha256":"a23febb325b1ac2224ad357225ffa22166223c24c7296d09551eb181269821e1","git_blob_sha":"ab5f136d887aa6f21edc793e7394fee38b8ad6f6","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/remaining-open-field-census.json","bytes":80273,"sha256":"e9a5461a3487b8061397c35782689ce12250e889207442c58f098a90e689cf71","git_blob_sha":"89a6c85075299e9df00e387a21746a2747325d19","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/row-state-ledger.json","bytes":15246,"sha256":"986a19710d7a4eb1bde4cbe1ce84dd633debea410b0dce2e4000fd6970ec3047","git_blob_sha":"d715af3fcb75233d340c1d0ede0c4685c3e50aae","mode":"100644","type":"blob"},{"path":"data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/summary.json","bytes":3485,"sha256":"dd048aa6f25140ef6ce931524b4afdd0b84813450c5337e1573e8f9df72b2ee6","git_blob_sha":"14d34c2da3ef3bf1d40caf2f81a2af299ae1dd83","mode":"100644","type":"blob"},{"path":"docs/milestones/ssc-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.md","bytes":2093,"sha256":"000d3e0796da303d717545db456a280d969d1391796728e940eef2da3d0b5850","git_blob_sha":"9541b0fdf637c0c23f29963a24fc4eee113e13bb","mode":"100644","type":"blob"},{"path":"schemas/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.schema.json","bytes":11113,"sha256":"702cd96c906e969fc4ce305922a76a3c85c1cddb442f7a61a39e5e3a6bf87394","git_blob_sha":"bff912cf6e489de916502ef11d7995fac03170ff","mode":"100644","type":"blob"},{"path":"test/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.test.js","bytes":7981,"sha256":"91d7fbc9898578d9ebc24b8c7a826b1a9e38970b613e598a26fc11184bb699fe","git_blob_sha":"2946c5c81cfaca9ba7d73b1f4f27f817482cab9f","mode":"100644","type":"blob"},{"path":"tools/build-status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.mjs","bytes":23847,"sha256":"c1d446663b0f774a084125d4e0e34831f1af520447dff42e817bb00068a978e7","git_blob_sha":"43456eafc05bd85d66b39c9f649ed4197e2b1ad5","mode":"100644","type":"blob"},{"path":"tools/validate-status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.mjs","bytes":10790,"sha256":"2dd7cc6b0bf0c15088e6104aa06eecd2e88959cc40ee3a4955c61de76aa30df4","git_blob_sha":"d17d070a9ebb7c6a9ea4c8eded129e47160553c8","mode":"100644","type":"blob"}]'

set -Eeuo pipefail
RECEIPT=/tmp/rd04-mf7-row-state-materialization-v3
PACKAGE=/tmp/rd04-mf7-row-state-package-v3
WORKTREE=/tmp/rd04-mf7-row-state-worktree-v3
rm -rf "$RECEIPT" "$PACKAGE" "$WORKTREE"
mkdir -p "$RECEIPT" "$PACKAGE"
exec > >(tee "$RECEIPT/run.log") 2>&1

git fetch --no-tags origin main
MAIN_START=$(git rev-parse origin/main)
git merge-base --is-ancestor "$EXPECTED_MAIN_ANCESTOR" "$MAIN_START"
printf '%s\n' "$MAIN_START" > "$RECEIPT/main-start.txt"

TARGET_START=''
if git ls-remote --exit-code --heads origin "$TARGET_BRANCH" > /tmp/rd04-mf7-row-state-target-start-v3.txt 2>/dev/null; then
  TARGET_START=$(awk '{print $1}' /tmp/rd04-mf7-row-state-target-start-v3.txt)
fi
printf '%s\n' "$TARGET_START" > "$RECEIPT/target-start.txt"

python - <<'PY_BLOBS'
import base64, hashlib, json, os, tarfile, urllib.request
from pathlib import Path, PurePosixPath

receipt=Path('/tmp/rd04-mf7-row-state-materialization-v3')
package=Path('/tmp/rd04-mf7-row-state-package-v3')
specs=json.loads(os.environ['BLOB_SPECS_JSON'])
expected_entries=json.loads(os.environ['FILE_ENTRIES_JSON'])
token=os.environ['GH_TOKEN']; repo=os.environ['GH_REPOSITORY']
parts=[]; part_receipts=[]
for ordinal,spec in enumerate(specs):
    req=urllib.request.Request(
        f"https://api.github.com/repos/{repo}/git/blobs/{spec['sha']}",
        headers={'Authorization':f'Bearer {token}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28','User-Agent':'ssc-rd04-mf7-row-state-v3'},
    )
    with urllib.request.urlopen(req,timeout=90) as response:
        payload=json.load(response)
    if payload.get('encoding')!='base64': raise SystemExit(f"blob encoding drift {spec['sha']}")
    raw=base64.b64decode(''.join(payload['content'].split()),validate=True)
    git_sha=hashlib.sha1(f"blob {len(raw)}\\0".encode()+raw).hexdigest()
    if git_sha!=spec['sha']: raise SystemExit(f"blob identity drift {spec['sha']} != {git_sha}")
    if len(raw)!=spec['bytes'] or hashlib.sha256(raw).hexdigest()!=spec['sha256']:
        raise SystemExit(f"blob byte custody drift {spec['sha']}")
    parts.append(raw)
    part_receipts.append({'ordinal':ordinal,**spec})
archive_bytes=b''.join(parts)
if len(archive_bytes)!=int(os.environ['ARCHIVE_BYTES']): raise SystemExit('archive byte denominator drift')
if hashlib.sha256(archive_bytes).hexdigest()!=os.environ['ARCHIVE_SHA256']: raise SystemExit('archive digest drift')
archive_path=receipt/'product.tar.xz'; archive_path.write_bytes(archive_bytes)
observed={}
with tarfile.open(archive_path,'r:xz') as tf:
    for member in tf.getmembers():
        p=PurePosixPath(member.name)
        if p.is_absolute() or '..' in p.parts or member.issym() or member.islnk(): raise SystemExit(f'unsafe archive member {member.name}')
        if member.isfile(): observed[member.name]=member.mode & 0o777
    expected_paths={e['path'] for e in expected_entries}
    if set(observed)!=expected_paths: raise SystemExit(f"archive path drift {sorted(set(observed)^expected_paths)}")
    tf.extractall(package,filter='data')
for entry in expected_entries:
    path=package/entry['path']; body=path.read_bytes()
    expected_mode=int(entry['mode'],8)&0o777
    if observed[entry['path']]!=expected_mode: raise SystemExit(f"mode drift {entry['path']}")
    if len(body)!=entry['bytes'] or hashlib.sha256(body).hexdigest()!=entry['sha256']:
        raise SystemExit(f"file digest drift {entry['path']}")
    git_sha=hashlib.sha1(f"blob {len(body)}\\0".encode()+body).hexdigest()
    if git_sha!=entry['git_blob_sha']: raise SystemExit(f"file Git identity drift {entry['path']}")
paths=sorted(e['path'] for e in expected_entries)
(receipt/'permanent-paths.txt').write_text('\\n'.join(paths)+'\\n')
(receipt/'ordinary-paths.txt').write_text('\\n'.join(p for p in paths if p!=os.environ['WORKFLOW_PATH'])+'\\n')
(receipt/'archive-receipt.json').write_text(json.dumps({'parts':part_receipts,'archive_bytes':len(archive_bytes),'archive_sha256':hashlib.sha256(archive_bytes).hexdigest(),'file_count':len(paths),'files':expected_entries},indent=2)+'\\n')
print('binary_archive_reconstruction=pass blobs=12 paths=14')
PY_BLOBS

qualify() {
  local BASE_SHA=$1
  rm -rf "$WORKTREE"
  git worktree add --detach "$WORKTREE" "$BASE_SHA"
  cp -a "$PACKAGE"/. "$WORKTREE"/
  cd "$WORKTREE"
  mapfile -t STATUS < <(git status --porcelain=v1 --untracked-files=all)
  test "${#STATUS[@]}" -eq "$PRODUCT_PATHS"
  for row in "${STATUS[@]}"; do test "${row:0:2}" = '??'; done
  mapfile -t PATHS < <(printf '%s\n' "${STATUS[@]}" | sed 's/^?? //' | sort)
  diff -u "$RECEIPT/permanent-paths.txt" <(printf '%s\n' "${PATHS[@]}")
  ! grep -E '(^|/)(\.transport|carrier|materializer|trigger|archive|chunk|shard)(/|$)' "$RECEIPT/permanent-paths.txt"
  git add -- "${PATHS[@]}"
  git -c user.name='BigBirdReturns' -c user.email='219768509+BigBirdReturns@users.noreply.github.com' commit -m 'Terminalize RD-04 seven-state minimum-frontier rows'
  FULL_HEAD=$(git rev-parse HEAD); FULL_TREE=$(git rev-parse 'HEAD^{tree}')
  test "$(git rev-list --count "$BASE_SHA..$FULL_HEAD")" -eq 1
  test "$(git diff --name-only "$BASE_SHA" "$FULL_HEAD" | wc -l)" -eq 14
  test -z "$(git diff --name-only --diff-filter=MD "$BASE_SHA" "$FULL_HEAD")"
  node --check "$BUILDER"; node --check "$VALIDATOR"; node --check "$TEST"
  node "$BUILDER" --check; node "$VALIDATOR"
  python - <<'PY_SCHEMA'
import json
from pathlib import Path
import jsonschema
data=Path('data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication')
schema=json.loads(Path('schemas/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication.schema.json').read_text())
paths=sorted(data.glob('*.json'))
if len(paths)!=8: raise SystemExit(f'JSON denominator drift {len(paths)}')
validator=jsonschema.Draft202012Validator(schema)
for p in paths: validator.validate(json.loads(p.read_text()))
print('closed_schema_validation=pass objects=8')
PY_SCHEMA
  node "$TEST" | tee "$RECEIPT/adversarial.txt"
  grep -qx 'rd04_mf7_row_state_adversarial=pass mutations_refused=757' "$RECEIPT/adversarial.txt"
  node tools/validate-no-magic-human-gate.mjs
  npm run release:check
  git restore --staged --worktree .; git clean -fdx
  node "$BUILDER" --write; node "$BUILDER" --check; node "$VALIDATOR"
  node "$TEST" | grep -qx 'rd04_mf7_row_state_adversarial=pass mutations_refused=757'
  node tools/validate-no-magic-human-gate.mjs
  git diff --check; git diff --exit-code; test -z "$(git status --porcelain=v1 --untracked-files=all)"
  printf '%s\n' "$BASE_SHA" > "$RECEIPT/qualified-base.txt"
  printf '%s\n' "$FULL_HEAD" > "$RECEIPT/full-head.txt"
  printf '%s\n' "$FULL_TREE" > "$RECEIPT/full-tree.txt"

  git reset --hard "$BASE_SHA"; git clean -fdx
  cp -a "$PACKAGE"/. .
  rm -f "$WORKFLOW_PATH"
  mapfile -t OSTATUS < <(git status --porcelain=v1 --untracked-files=all)
  test "${#OSTATUS[@]}" -eq 13
  for row in "${OSTATUS[@]}"; do test "${row:0:2}" = '??'; done
  mapfile -t OPATHS < <(printf '%s\n' "${OSTATUS[@]}" | sed 's/^?? //' | sort)
  diff -u "$RECEIPT/ordinary-paths.txt" <(printf '%s\n' "${OPATHS[@]}")
  git add -- "${OPATHS[@]}"
  git -c user.name='BigBirdReturns' -c user.email='219768509+BigBirdReturns@users.noreply.github.com' commit -m 'Terminalize RD-04 seven-state minimum-frontier rows'
  ORD_HEAD=$(git rev-parse HEAD); ORD_TREE=$(git rev-parse 'HEAD^{tree}')
  node "$BUILDER" --check; node "$VALIDATOR"
  node "$TEST" | grep -qx 'rd04_mf7_row_state_adversarial=pass mutations_refused=757'
  node tools/validate-no-magic-human-gate.mjs
  npm run release:check
  git diff --check; git diff --exit-code; test -z "$(git status --porcelain=v1 --untracked-files=all)"
  printf '%s\n' "$ORD_HEAD" > "$RECEIPT/ordinary-head.txt"
  printf '%s\n' "$ORD_TREE" > "$RECEIPT/ordinary-tree.txt"
  cd "$GITHUB_WORKSPACE"; git worktree remove --force "$WORKTREE"
}

qualify "$MAIN_START"
git fetch --no-tags origin main
MAIN_NOW=$(git rev-parse origin/main)
if test "$MAIN_NOW" != "$MAIN_START"; then
  git diff --name-only "$MAIN_START" "$MAIN_NOW" > "$RECEIPT/main-delta.txt"
  python - "$RECEIPT/permanent-paths.txt" "$RECEIPT/main-delta.txt" <<'PY_OVERLAP'
import sys
from pathlib import Path
product=set(Path(sys.argv[1]).read_text().splitlines()); delta=set(Path(sys.argv[2]).read_text().splitlines())
overlap=sorted(product & delta)
if overlap: raise SystemExit(f'live-main overlap: {overlap}')
print(f'live_main_rebind_disjoint_paths={len(delta)}')
PY_OVERLAP
  qualify "$MAIN_NOW"
fi
FINAL_BASE=$(cat "$RECEIPT/qualified-base.txt"); ORD_HEAD=$(cat "$RECEIPT/ordinary-head.txt")
git fetch --no-tags origin main; test "$(git rev-parse origin/main)" = "$FINAL_BASE"
CURRENT_TARGET=''
if git ls-remote --exit-code --heads origin "$TARGET_BRANCH" > /tmp/rd04-mf7-target-now-v3.txt 2>/dev/null; then CURRENT_TARGET=$(awk '{print $1}' /tmp/rd04-mf7-target-now-v3.txt); fi
test "$CURRENT_TARGET" = "$TARGET_START"
if test -n "$TARGET_START"; then git push --force-with-lease="refs/heads/$TARGET_BRANCH:$TARGET_START" origin "$ORD_HEAD:refs/heads/$TARGET_BRANCH"; else git push origin "$ORD_HEAD:refs/heads/$TARGET_BRANCH"; fi
test "$(git ls-remote origin "refs/heads/$TARGET_BRANCH" | awk '{print $1}')" = "$ORD_HEAD"

OWNER=${GH_REPOSITORY%%/*}
EXISTING=$(gh api "repos/$GH_REPOSITORY/pulls?state=open&head=$OWNER:$TARGET_BRANCH" --jq '.[0].number // empty')
BODY=$(cat <<EOF_BODY
Tracks RD-04 Issue #1017 under Wave-03 Issue #1013.

Exact thirteen-path ordinary product qualified together with its read-only standing workflow; the workflow will be composed separately without byte changes.

\`\`\`text
canonical parent: $(cat "$RECEIPT/qualified-base.txt")
qualified full tree: $(cat "$RECEIPT/full-tree.txt")
ordinary product commit: $(cat "$RECEIPT/ordinary-head.txt")
ordinary product tree: $(cat "$RECEIPT/ordinary-tree.txt")
target rows: 7
terminal cells: 211 -> 218
terminal units: 3 -> 10
substantive field changes: 0
adversarial refusals: 757
class closed: false
\`\`\`
EOF_BODY
)
if test -n "$EXISTING"; then
  gh api --method PATCH "repos/$GH_REPOSITORY/pulls/$EXISTING" -f title='SSC RD Wave 03: terminalize seven minimum-frontier rows' -f body="$BODY" >/tmp/rd04-mf7-pr-v3.json
else
  gh api --method POST "repos/$GH_REPOSITORY/pulls" -f title='SSC RD Wave 03: terminalize seven minimum-frontier rows' -f head="$TARGET_BRANCH" -f base=main -f body="$BODY" -F draft=true >/tmp/rd04-mf7-pr-v3.json
fi
python - <<'PY_RECEIPT'
import json
from pathlib import Path
r=Path('/tmp/rd04-mf7-row-state-materialization-v3')
pr=json.load(open('/tmp/rd04-mf7-pr-v3.json'))
obj={'schema_version':'ssc-rd04-mf7-row-state-materialization@2','canonical_parent':(r/'qualified-base.txt').read_text().strip(),'full_head':(r/'full-head.txt').read_text().strip(),'full_tree':(r/'full-tree.txt').read_text().strip(),'ordinary_head':(r/'ordinary-head.txt').read_text().strip(),'ordinary_tree':(r/'ordinary-tree.txt').read_text().strip(),'permanent_pr':pr['number'],'archive_sha256':'672be321f243be0e3bc4867256fb68641f4319d43fd1fdc06271ff0ddcb85ccd','permanent_paths':14,'ordinary_paths':13,'target_rows':7,'terminal_cells_before':211,'terminal_cells_after':218,'terminal_units_before':3,'terminal_units_after':10,'adversarial_refusals':757,'class_closed':False,'outside_human_dependency':False}
(r/'receipt.json').write_text(json.dumps(obj,indent=2)+'\\n')
print(json.dumps(obj,indent=2))
PY_RECEIPT
