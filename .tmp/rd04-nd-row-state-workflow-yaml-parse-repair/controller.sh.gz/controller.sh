#!/usr/bin/env bash
set -Eeuo pipefail

: "${CANONICAL_MAIN:?}"
: "${CANONICAL_MAIN_TREE:?}"
: "${SOURCE_PRODUCT:?}"
: "${SOURCE_PRODUCT_TREE:?}"
: "${STAGING_BRANCH:?}"
: "${WORKFLOW_PATH:?}"
: "${CONTROLLER_PATH:?}"
: "${PRODUCT_ROOT:?}"
: "${STANDING_WORKFLOW:?}"
: "${VALIDATOR_PATH:?}"
: "${TEST_PATH:?}"
: "${MANIFEST_PATH:?}"
: "${OUT:?}"
: "${WORK:?}"
: "${STAGE:?}"
: "${PR_HEAD_SHA:?}"
: "${PR_BASE_SHA:?}"

rm -rf "$OUT" "$WORK" "$STAGE"
mkdir -p "$OUT"

HEAD_SHA="$(git rev-parse HEAD)"
test "$HEAD_SHA" = "$PR_HEAD_SHA"
test "$PR_BASE_SHA" = "$CANONICAL_MAIN"
test "$(git rev-parse HEAD^)" = "$CANONICAL_MAIN"
test "$(git rev-list --count "$CANONICAL_MAIN..HEAD")" -eq 1
test "$(git rev-parse "$CANONICAL_MAIN^{tree}")" = "$CANONICAL_MAIN_TREE"
git fetch --no-tags --force origin '+refs/heads/main:refs/remotes/origin/main'
test "$(git rev-parse origin/main)" = "$CANONICAL_MAIN"

printf '%s\n' "$WORKFLOW_PATH" "$CONTROLLER_PATH" | LC_ALL=C sort > "$OUT/expected-carrier-paths.txt"
git diff --name-only "$CANONICAL_MAIN" HEAD | LC_ALL=C sort > "$OUT/actual-carrier-paths.txt"
cmp "$OUT/expected-carrier-paths.txt" "$OUT/actual-carrier-paths.txt"
test "$(git diff --name-only --diff-filter=A "$CANONICAL_MAIN" HEAD | wc -l)" -eq 2
test -z "$(git diff --name-only --diff-filter=MDTCRUXB "$CANONICAL_MAIN" HEAD)"
git diff --check "$CANONICAL_MAIN" HEAD

test "$(git rev-parse "$SOURCE_PRODUCT^")" = "$CANONICAL_MAIN"
test "$(git rev-parse "$SOURCE_PRODUCT^{tree}")" = "$SOURCE_PRODUCT_TREE"
test "$(git rev-list --count "$CANONICAL_MAIN..$SOURCE_PRODUCT")" -eq 1

cat > "$OUT/product-paths.txt" <<'PATHS'
.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/input-custody.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-decision.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-ledger.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/promoted-partial-field-matrix.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/remaining-open-field-census.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-summary.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/index.json
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/product-manifest.json
docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md
schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json
test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js
tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs
PATHS
LC_ALL=C sort "$OUT/product-paths.txt" -o "$OUT/product-paths.txt"
test "$(wc -l < "$OUT/product-paths.txt")" -eq 14
git diff --name-only "$CANONICAL_MAIN" "$SOURCE_PRODUCT" | LC_ALL=C sort > "$OUT/source-product-paths.txt"
cmp "$OUT/product-paths.txt" "$OUT/source-product-paths.txt"
test "$(git diff --name-only --diff-filter=A "$CANONICAL_MAIN" "$SOURCE_PRODUCT" | wc -l)" -eq 14
test -z "$(git diff --name-only --diff-filter=MDTCRUXB "$CANONICAL_MAIN" "$SOURCE_PRODUCT")"

test -z "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH")"

mapfile -t PRODUCT_PATHS < "$OUT/product-paths.txt"
git worktree add --detach "$WORK" "$CANONICAL_MAIN"
git -C "$WORK" checkout "$SOURCE_PRODUCT" -- "${PRODUCT_PATHS[@]}"

python3 - "$WORK" "$STANDING_WORKFLOW" "$VALIDATOR_PATH" "$TEST_PATH" "$MANIFEST_PATH" <<'PY'
from __future__ import annotations
import hashlib
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
workflow_path, validator_path, test_path, manifest_path = sys.argv[2:]

def read(rel: str) -> str:
    return (root / rel).read_text(encoding='utf-8')

def write(rel: str, text: str) -> None:
    (root / rel).write_text(text, encoding='utf-8')

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

# Repair only the physical YAML line split identified by exact-head review.
workflow = read(workflow_path)
bad = "          printf '%s\n' \"$EXPECTED\" > \"$OUT/product-paths.txt\"\n"
good = "          printf '%s\\n' \"$EXPECTED\" > \"$OUT/product-paths.txt\"\n"
assert workflow.count(bad) == 1, workflow.count(bad)
assert good not in workflow
workflow = workflow.replace(bad, good)
write(workflow_path, workflow)

# Add a permanent physical-indentation guard to the exact validator.
validator = read(validator_path)
function_anchor = "function schemaTypeMatches(value,type){\n"
assert validator.count(function_anchor) == 1
function_insert = r'''function validateStandingWorkflow(text){
  const corrected=`          printf '%s\\n' "$EXPECTED" > "$OUT/product-paths.txt"`;
  const physicallySplit=`          printf '%s
' "$EXPECTED" > "$OUT/product-paths.txt"`;
  assert(text.split(corrected).length===2,'standing workflow corrected printf command mismatch');
  assert(!text.includes(physicallySplit),'standing workflow printf command is physically split');
  const lines=text.split(/\r?\n/);let blocks=0;
  for(let index=0;index<lines.length;index++){
    const match=lines[index].match(/^(\s*)run:\s*\|\s*$/);if(!match)continue;
    blocks++;const base=match[1].length;
    for(index+=1;index<lines.length;index++){
      const line=lines[index];if(line.trim()==='')continue;
      const indent=(line.match(/^ */)?.[0].length??0);
      if(indent<=base){index-=1;break;}
      assert(indent>=base+2,`standing workflow run block indentation mismatch line ${index+1}`);
    }
  }
  assert(blocks>=1,'standing workflow run block absent');
}
'''
validator = validator.replace(function_anchor, function_insert + function_anchor)
model_anchor = "  const schema=readJson(m.repoRoot,SCHEMA_PATH,m.overrides);\n"
assert validator.count(model_anchor) == 1
model_insert = model_anchor + "  validateStandingWorkflow(readBytes(m.repoRoot,EXPECTED_PERMANENT_PATHS[0],m.overrides).toString('utf8'));\n"
validator = validator.replace(model_anchor, model_insert)
write(validator_path, validator)

# Add a manifest-consistent regression that recreates the exact physical split.
test_source = read(test_path)
helper_anchor = "const expectRefusal=(label,overrides)=>assert.throws(()=>validateProduct(ROOT,overrides),undefined,label);\n"
assert test_source.count(helper_anchor) == 1
helper_insert = r'''const mutateWorkflow=fn=>{const current=bytes(rel.workflow).toString('utf8');const changed=Buffer.from(fn(current));const manifest=json(rel.manifest);const rec=manifest.hashed_files.find(r=>r.path===rel.workflow);rec.bytes=changed.length;rec.sha256=digest(changed);rec.git_blob=blob(changed);recomputeCombined(manifest);return new Map([[rel.workflow,changed],[rel.manifest,encode(manifest)]]);};
'''
test_source = test_source.replace(helper_anchor, helper_insert + helper_anchor)
mutation_anchor = "    ['workflow byte drift',new Map([[rel.workflow,Buffer.concat([bytes(rel.workflow),Buffer.from('\\n# altered\\n')])]])],\n"
assert test_source.count(mutation_anchor) == 1
mutation = r'''    ['workflow physical printf split with recomputed manifest',mutateWorkflow(text=>{
      const corrected=`          printf '%s\\n' "$EXPECTED" > "$OUT/product-paths.txt"`;
      const broken=`          printf '%s
' "$EXPECTED" > "$OUT/product-paths.txt"`;
      assert.equal(text.split(corrected).length,2);
      return text.replace(corrected,broken);
    })],
'''
test_source = test_source.replace(mutation_anchor, mutation + mutation_anchor)
assert test_source.count("rejects 46 adversarial mutations") == 1
test_source = test_source.replace("rejects 46 adversarial mutations", "rejects 47 adversarial mutations")
assert test_source.count("assert.equal(mutations.length,46);") == 1
test_source = test_source.replace("assert.equal(mutations.length,46);", "assert.equal(mutations.length,47);")
write(test_path, test_source)

# Recompute only the three changed hashed records and their dependent combined digest.
manifest_file = root / manifest_path
manifest = json.loads(manifest_file.read_text(encoding='utf-8'))
changed_paths = [workflow_path, validator_path, test_path]
for rel in changed_paths:
    data = (root / rel).read_bytes()
    rec = next(item for item in manifest['hashed_files'] if item['path'] == rel)
    rec.clear()
    rec.update({'path': rel, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': git_blob(data)})
rows = [f"{rec['path']}\0{rec['sha256']}\0{rec['bytes']}\n" for rec in manifest['hashed_files']]
manifest['combined_sha256'] = hashlib.sha256(''.join(sorted(rows)).encode()).hexdigest()
manifest_file.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
PY

cat > "$OUT/expected-repaired-paths.txt" <<'PATHS'
.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml
data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/product-manifest.json
test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js
tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs
PATHS
LC_ALL=C sort "$OUT/expected-repaired-paths.txt" -o "$OUT/expected-repaired-paths.txt"
git -C "$WORK" diff --name-only "$SOURCE_PRODUCT" -- "${PRODUCT_PATHS[@]}" | LC_ALL=C sort > "$OUT/actual-repaired-paths.txt"
cmp "$OUT/expected-repaired-paths.txt" "$OUT/actual-repaired-paths.txt"

git -C "$WORK" add -- "${PRODUCT_PATHS[@]}"
git -C "$WORK" diff --cached --name-only | LC_ALL=C sort > "$OUT/candidate-paths.txt"
cmp "$OUT/product-paths.txt" "$OUT/candidate-paths.txt"
test "$(git -C "$WORK" diff --cached --name-only --diff-filter=A | wc -l)" -eq 14
test -z "$(git -C "$WORK" diff --cached --name-only --diff-filter=MDTCRUXB)"
git -C "$WORK" diff --cached --check

# A real YAML parser must accept the repaired permanent workflow before product admission.
ruby -e 'require "yaml"; Psych.parse_file(ARGV.fetch(0))' "$WORK/$STANDING_WORKFLOW"

(
  cd "$WORK"
  node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs --check | tee "$OUT/builder-check.txt"
  node "$VALIDATOR_PATH" --out "$OUT/validator.json" | tee "$OUT/validator-stdout.txt"
  node --test "$TEST_PATH" | tee "$OUT/adversarial.log"
)
grep -F 'closed product contract rejects 47 adversarial mutations' "$OUT/adversarial.log" > /dev/null

git -C "$WORK" config user.name 'rd04-workflow-yaml-repair'
git -C "$WORK" config user.email 'rd04-workflow-yaml-repair@users.noreply.github.com'
git -C "$WORK" commit -m 'Repair North Dakota row-state workflow YAML parsing'
CANDIDATE="$(git -C "$WORK" rev-parse HEAD)"
CANDIDATE_TREE="$(git -C "$WORK" rev-parse HEAD^{tree})"
test "$(git -C "$WORK" rev-parse HEAD^)" = "$CANONICAL_MAIN"
test "$(git -C "$WORK" rev-list --count "$CANONICAL_MAIN..HEAD")" -eq 1
printf '%s\n' "$CANDIDATE" > "$OUT/product-commit.txt"
printf '%s\n' "$CANDIDATE_TREE" > "$OUT/product-tree.txt"

# Ten semantic/schema/build blobs must remain byte-identical to the reviewed source.
while IFS= read -r PRODUCT_PATH; do
  case "$PRODUCT_PATH" in
    "$STANDING_WORKFLOW"|"$MANIFEST_PATH"|"$TEST_PATH"|"$VALIDATOR_PATH") continue ;;
  esac
  test "$(git -C "$WORK" rev-parse "$CANDIDATE:$PRODUCT_PATH")" = "$(git rev-parse "$SOURCE_PRODUCT:$PRODUCT_PATH")"
done < "$OUT/product-paths.txt"

test "$(git -C "$WORK" rev-parse "$CANDIDATE:$PRODUCT_ROOT/promoted-partial-field-matrix.json")" = '6ba11a6025021e9df8ac6535be8c42499654c233'
test "$(git -C "$WORK" rev-parse "$CANDIDATE:$PRODUCT_ROOT/row-state-decision.json")" = '0a9e611061779854c510dd1a8c5a1a0d82822ac7'
test "$(git -C "$WORK" rev-parse "$CANDIDATE:$PRODUCT_ROOT/input-custody.json")" = 'c14472c0d31a51879742c8ab98049e1ac8c47b27'
test "$(git -C "$WORK" rev-parse "$CANDIDATE:schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json")" = 'd41112bb621656bd41fcbfaa605e6cedbfeb04ca'
test "$(git -C "$WORK" rev-parse "$CANDIDATE:tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs")" = '5bfd596e3c423119ef285e3c634e7d8087693bae'

(
  cd "$WORK"
  npm run release:check > "$OUT/release-check.log" 2>&1
  git reset --hard "$CANDIDATE"
  git clean -fdx
  test -z "$(git status --porcelain)"
  ruby -e 'require "yaml"; Psych.parse_file(ARGV.fetch(0))' "$STANDING_WORKFLOW"
  node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs --check > "$OUT/post-release-builder-check.txt"
  node "$VALIDATOR_PATH" --out "$OUT/post-release-validator.json" > "$OUT/post-release-validator-stdout.txt"
  node --test "$TEST_PATH" > "$OUT/post-release-adversarial.log"
  cmp "$OUT/validator.json" "$OUT/post-release-validator.json"
)
grep -F 'closed product contract rejects 47 adversarial mutations' "$OUT/post-release-adversarial.log" > /dev/null

# Stage only thirteen permanent nonworkflow objects plus one temporary workflow carrier.
TEMP_WORKFLOW='.tmp/rd04-nd-row-state-workflow-yaml-parse-repair/standing-workflow.yml'
git worktree add --detach "$STAGE" "$CANONICAL_MAIN"
NONWORKFLOW=()
while IFS= read -r PRODUCT_PATH; do
  [ "$PRODUCT_PATH" = "$STANDING_WORKFLOW" ] || NONWORKFLOW+=("$PRODUCT_PATH")
done < "$OUT/product-paths.txt"
git -C "$STAGE" checkout "$CANDIDATE" -- "${NONWORKFLOW[@]}"
mkdir -p "$STAGE/$(dirname "$TEMP_WORKFLOW")"
git -C "$WORK" show "$CANDIDATE:$STANDING_WORKFLOW" > "$STAGE/$TEMP_WORKFLOW"
git -C "$STAGE" add -- "${NONWORKFLOW[@]}" "$TEMP_WORKFLOW"
test "$(git -C "$STAGE" diff --cached --name-only | wc -l)" -eq 14
test "$(git -C "$STAGE" diff --cached --name-only --diff-filter=A | wc -l)" -eq 14
test -z "$(git -C "$STAGE" diff --cached --name-only --diff-filter=MDTCRUXB)"
git -C "$STAGE" diff --cached --check
git -C "$STAGE" config user.name 'rd04-workflow-yaml-stager'
git -C "$STAGE" config user.email 'rd04-workflow-yaml-stager@users.noreply.github.com'
git -C "$STAGE" commit -m 'Stage qualified North Dakota row-state YAML repair objects'
STAGE_COMMIT="$(git -C "$STAGE" rev-parse HEAD)"
STAGE_TREE="$(git -C "$STAGE" rev-parse HEAD^{tree})"
test "$(git -C "$STAGE" rev-parse HEAD^)" = "$CANONICAL_MAIN"

test -z "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH")"
git -C "$STAGE" push origin "$STAGE_COMMIT:refs/heads/$STAGING_BRANCH"
test "$(git ls-remote --heads origin "refs/heads/$STAGING_BRANCH" | awk '{print $1}')" = "$STAGE_COMMIT"

python3 - "$OUT/materialization-receipt.json" <<PY
import json
from pathlib import Path
receipt = {
  'schema_version': 'ssc-rd04-nd-row-state-workflow-yaml-parse-repair@1',
  'canonical_main': '$CANONICAL_MAIN',
  'canonical_main_tree': '$CANONICAL_MAIN_TREE',
  'source_product': '$SOURCE_PRODUCT',
  'source_product_tree': '$SOURCE_PRODUCT_TREE',
  'candidate_commit': '$CANDIDATE',
  'candidate_tree': '$CANDIDATE_TREE',
  'stage_commit': '$STAGE_COMMIT',
  'stage_tree': '$STAGE_TREE',
  'staging_branch': '$STAGING_BRANCH',
  'permanent_paths': 14,
  'repaired_paths': 4,
  'yaml_parser': 'ruby_psych',
  'yaml_parse_passed': True,
  'adversarial_refusals': 47,
  'release_check': 'passed',
  'semantic_blobs_changed': 0,
  'matrix_blob': '6ba11a6025021e9df8ac6535be8c42499654c233',
  'source_requests': 0,
  'route_executions': 0,
  'source_admissions': 0,
  'field_terminalizations': 0,
  'matrix_updates': 1,
  'row_state_mutations': 1,
  'row_terminalizations': 1,
  'class_closed': False,
  'outside_human_dependency': False,
}
Path('$OUT/materialization-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
PY

(
  cd "$OUT"
  find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS
  sha256sum -c SHA256SUMS
)
