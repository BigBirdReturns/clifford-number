#!/usr/bin/env python3
from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path.cwd()
VROOT = ROOT / os.environ["VALIDATION_ROOT"]
MATRIX = ROOT / os.environ["MATRIX_PATH"]

EXPECTED_PARENT = "bab9570ab043df7c5062e5a45a0717a82eed346b"
EXPECTED_PARENT_TREE = "74c43136c79700be7cacf9d983738743cec227b8"
EXPECTED_REPAIR_PRODUCT = "21d4f8433e49e8428d59fc37ad91b9ac77c835f5"
PROMOTION_MERGE = "4eaa66d7a0f025e0c4ec797e9925634a22d9e49e"
PROMOTION_PARENT = "77aef3313e85e1fddc68805a9f22252ff147b4e8"
PROMOTION_PRODUCT = "ec9ec9f6cfc3180adcf816ae91e4bbf14df0e4dd"
PROMOTION_TREE = "51c46f38071f7f5193ab7856a193095a86389356"
STALE_HEAD = "057f8cfc68b5d9aa4b7d0b2acbe95d89c4889632"
TERMINAL_STATE = "terminal_fixed_public_record_obligation_complete"
CURRENT_MATRIX_BYTES = 495400
CURRENT_MATRIX_SHA = "1878270c1c34d1a96b28eb0ee26eff5b1b3b6c8d74a56026c293544c7925d824"
CURRENT_MATRIX_BLOB = "c25a1ad8fdfe82f70f1ff71e61da6796be94c737"
CURRENT_ROW_SHA = "0f3ba29ee5c7354249f89c96fc38c21b55341fc9fdad9b5919ecdb9243c4929e"
CURRENT_ROW_STATE_SHA = "6a4c7d204c6c99a89f3c121065860806668c5da850f44c67fe42b4dc84b1b5c3"
PROPOSED_SHA = "61b09a85d2efd348d069349fb29e8ea5a742d559a5a1a8ab614b798793b87dde"
UNCHANGED_ROWS_SHA = "e9507cce90ced2d303b6d464968c4eeed630f2f058ba4302980c34f32f3e1105"

AUTH_KEYS = [
    "source_requests", "route_executions", "source_admissions",
    "field_terminalizations", "matrix_updates", "row_state_mutations",
    "row_terminalizations", "class_closed", "cumulative_ledger_effect",
    "publication_effect", "adoption_effect", "graph_effect",
    "outside_human_dependency",
]
FIELDS = ["canonical_state_identity", "operative_state_implementation_authority_and_version", "implementation_effective_date_or_typed_gap", "abawd_or_work_requirement_waiver_state_and_governing_period", "discretionary_exemption_authority_and_reported_state_practice", "fitness_for_work_or_eligibility_screening_rule", "verification_evidence_and_staff_discretion_surface", "source_identities_and_exact_custody"]
TERMINAL_UNIT_IDS = [
    "US-STATE-AR", "US-STATE-CA", "US-STATE-GA", "US-STATE-MD",
    "US-STATE-NC", "US-STATE-ND", "US-STATE-PA", "US-STATE-RI",
    "US-STATE-SD", "US-STATE-WA", "US-STATE-WV",
]
PATHS = [
    os.environ["WORKFLOW_PATH"],
    os.environ["VALIDATION_ROOT"] + "/current-row-custody.json",
    os.environ["VALIDATION_ROOT"] + "/row-state-validation.json",
    os.environ["VALIDATION_ROOT"] + "/validated-row-state-protocol.json",
    os.environ["VALIDATION_ROOT"] + "/summary.json",
    os.environ["VALIDATION_ROOT"] + "/product-manifest.json",
    os.environ["VALIDATOR_PATH"],
]

CUSTODY_KEYS = [
    "schema_version", "issue", "wave_id", "lane_id", "class_id",
    "canonical_parent", "canonical_parent_tree", "canonical_manifest_repair",
    "canonical_promotion", "matrix", "north_dakota", "authority_boundary",
]
VALIDATION_KEYS = [
    "schema_version", "issue", "wave_id", "lane_id", "class_id",
    "canonical_parent", "canonical_parent_tree", "source_validation_head",
    "review_correction", "validation_result", "proposed_row_state_cell",
    "proposed_row_state_cell_sha256", "projected_row", "projected_matrix",
    "projected_effects", "authority_boundary",
]
PROTOCOL_KEYS = [
    "schema_version", "issue", "wave_id", "lane_id", "class_id",
    "canonical_parent", "canonical_parent_tree", "source_validation_head",
    "unit_id", "current_row_sha256", "current_row_state_cell_sha256",
    "proposed_row_state_cell_sha256", "projected_row_state",
    "projected_row_sha256", "projected_matrix_sha256",
    "projected_matrix_scope", "final_product_identity_authorized",
    "validation_state", "canonical_validation_merge_required_before_promotion",
    "separate_promotion_product_authorized", "maximum_field_terminalizations",
    "maximum_matrix_updates", "maximum_row_state_mutations",
    "maximum_row_terminalizations", "class_closure_authorized",
    "promotion_executed_here", "projected_counts",
    "projected_current_result", "authority_boundary",
]
SUMMARY_KEYS = [
    "schema_version", "issue", "state", "canonical_parent",
    "canonical_parent_tree", "source_validation_head", "unit_id",
    "current_row_state", "projected_row_state", "current_terminal_fields",
    "current_open_fields", "projected_terminal_fields", "projected_open_fields",
    "projected_row_sha256", "projected_semantic_matrix_sha256",
    "final_product_identity_authorized", "validated_candidates",
    "rejected_candidates", "promotion_executed_here",
    "next_authorized_operation", "authority_boundary",
]
MANIFEST_KEYS = [
    "schema_version", "issue", "wave_id", "lane_id", "class_id",
    "canonical_parent", "canonical_parent_tree", "source_validation_head",
    "product_slug", "addition_only", "permanent_path_count",
    "permanent_paths", "qualification_workflow", "validator_script",
    "payload_digest_algorithm", "payload_files", "payload_combined_sha256",
    "semantic_counts", "authority_boundary",
]

def load(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))

def canon(value) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode()

def json_bytes(value) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def blob(data: bytes) -> str:
    return hashlib.sha1(
        b"blob " + str(len(data)).encode() + b"\0" + data
    ).hexdigest()

def exact_keys(value, expected, label):
    assert isinstance(value, dict), f"{label} must be an object"
    assert sorted(value) == sorted(expected), f"{label} key set mismatch"

def authority(value):
    exact_keys(value, AUTH_KEYS, "authority boundary")
    assert value["source_requests"] == 0
    assert value["route_executions"] == 0
    assert value["source_admissions"] == 0
    assert value["field_terminalizations"] == 0
    assert value["matrix_updates"] == 0
    assert value["row_state_mutations"] == 0
    assert value["row_terminalizations"] == 0
    assert value["class_closed"] is False
    assert value["cumulative_ledger_effect"] == "none"
    assert value["publication_effect"] == "none"
    assert value["adoption_effect"] == "none"
    assert value["graph_effect"] == "none"
    assert value["outside_human_dependency"] is False

def checkout_head() -> str:
    expected = os.environ.get("EXPECTED_CHECKOUT_HEAD")
    try:
        actual = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL
        ).strip()
    except Exception:
        actual = expected or "local-unbound"
    if expected:
        assert actual == expected
    return actual

def load_model():
    raw = MATRIX.read_bytes()
    return {
        "matrix_raw": raw,
        "matrix": json.loads(raw),
        "custody": load(VROOT / "current-row-custody.json"),
        "validation": load(VROOT / "row-state-validation.json"),
        "protocol": load(VROOT / "validated-row-state-protocol.json"),
        "summary": load(VROOT / "summary.json"),
        "manifest": load(VROOT / "product-manifest.json"),
    }

def project(matrix, proposed):
    projected = copy.deepcopy(matrix)
    after = next(
        row for row in projected["rows"] if row["unit_id"] == "US-STATE-ND"
    )
    after["row_state"] = TERMINAL_STATE
    after["terminal_fields"] = 9
    after["open_fields"] = 0
    after["cells"][8] = copy.deepcopy(proposed)

    projected["counts"].update({
        "evidence_complete_cells": 198,
        "still_open_cells": 221,
        "terminal_cells": 229,
        "row_terminal_state_cells_terminal": 11,
        "row_terminal_state_cells_open": 39,
        "terminal_units": 11,
        "postpromotion_nd_current_public_record_gap_row_state_candidate_cells": 1,
        "newly_terminalized_postpromotion_nd_current_public_record_gap_row_state_cells": 1,
    })

    projected["current_result"].update({
        "terminal_cells": "229/450",
        "still_open_cells": "221/450",
        "terminal_substantive_cells": 118,
        "still_open_substantive_cells": 182,
        "row_terminal_state_cells_terminal": 11,
        "row_terminal_state_cells_open": 39,
        "terminal_units": 11,
    })
    projected["current_result"]["terminal_unit_ids"] = [
        row["unit_id"]
        for row in projected["rows"]
        if row["row_state"] == TERMINAL_STATE
    ]
    return projected, after

def validate(model, check_files=True):
    raw = model["matrix_raw"]
    matrix = model["matrix"]
    custody = model["custody"]
    validation = model["validation"]
    protocol = model["protocol"]
    summary = model["summary"]
    manifest = model["manifest"]

    assert len(raw) == CURRENT_MATRIX_BYTES
    assert sha(raw) == CURRENT_MATRIX_SHA
    assert blob(raw) == CURRENT_MATRIX_BLOB
    assert matrix == json.loads(raw)

    current_counts = {
        "materialized_cells": 450,
        "terminal_cells": 228,
        "still_open_cells": 222,
        "terminal_substantive_cells": 118,
        "still_open_substantive_cells": 182,
        "evidence_complete_cells": 197,
        "observed_cells": 17,
        "not_publicly_recovered_cells": 14,
        "row_terminal_state_cells_terminal": 10,
        "row_terminal_state_cells_open": 40,
        "terminal_units": 10,
        "class_closed": False,
    }
    for key, expected in current_counts.items():
        assert matrix["counts"][key] == expected
    assert matrix["current_result"]["terminal_cells"] == "228/450"
    assert matrix["current_result"]["still_open_cells"] == "222/450"
    assert matrix["current_result"]["terminal_units"] == 10
    assert matrix["current_result"]["terminal_unit_ids"] == [
        "US-STATE-AR", "US-STATE-CA", "US-STATE-GA", "US-STATE-MD",
        "US-STATE-NC", "US-STATE-PA", "US-STATE-RI", "US-STATE-SD",
        "US-STATE-WA", "US-STATE-WV",
    ]

    nd = next(row for row in matrix["rows"] if row["unit_id"] == "US-STATE-ND")
    assert sha(canon(nd)) == CURRENT_ROW_SHA
    assert (nd["row_state"], nd["terminal_fields"], nd["open_fields"]) == (
        "still_open", 8, 1
    )
    assert [cell["field_id"] for cell in nd["cells"][:8]] == FIELDS
    assert all(cell["terminal"] for cell in nd["cells"][:8])
    assert [cell["state"] for cell in nd["cells"][:8]].count(
        "evidence_complete"
    ) == 7
    assert [cell["state"] for cell in nd["cells"][:8]].count(
        "not_publicly_recovered"
    ) == 1
    current = nd["cells"][8]
    assert current["field_id"] == "field_and_row_terminal_state"
    assert sha(canon(current)) == CURRENT_ROW_STATE_SHA
    assert current["state"] == "still_open"
    assert current["terminal"] is False

    exact_keys(custody, CUSTODY_KEYS, "custody")
    exact_keys(validation, VALIDATION_KEYS, "validation")
    exact_keys(protocol, PROTOCOL_KEYS, "protocol")
    exact_keys(summary, SUMMARY_KEYS, "summary")
    exact_keys(manifest, MANIFEST_KEYS, "manifest")
    for obj in [custody, validation, protocol, summary, manifest]:
        authority(obj["authority_boundary"])
        assert obj["canonical_parent"] == EXPECTED_PARENT
        assert obj["canonical_parent_tree"] == EXPECTED_PARENT_TREE

    assert custody["schema_version"] == (
        "ssc-rd04-nd-row-state-reconciliation-current-row-custody@2"
    )
    assert validation["schema_version"] == (
        "ssc-rd04-nd-row-state-reconciliation-validation@2"
    )
    assert protocol["schema_version"] == (
        "ssc-rd04-nd-row-state-reconciliation-validated-protocol@2"
    )
    assert summary["schema_version"] == (
        "ssc-rd04-nd-row-state-reconciliation-validation-summary@2"
    )
    assert manifest["schema_version"] == (
        "ssc-rd04-nd-row-state-reconciliation-validation-product-manifest@2"
    )

    assert custody["canonical_manifest_repair"] == {
        "merge_commit": EXPECTED_PARENT,
        "product_commit": EXPECTED_REPAIR_PRODUCT,
        "product_tree": EXPECTED_PARENT_TREE,
        "pull_request": 1785,
        "effect": "validation_parent_and_manifest_contract_only",
    }
    assert custody["canonical_promotion"]["merge_commit"] == PROMOTION_MERGE
    assert custody["canonical_promotion"]["product_commit"] == PROMOTION_PRODUCT
    assert custody["canonical_promotion"]["product_tree"] == PROMOTION_TREE
    assert custody["canonical_promotion"]["pull_request"] == 1776
    assert custody["matrix"]["path"] == os.environ["MATRIX_PATH"]
    assert custody["matrix"]["git_blob_sha"] == CURRENT_MATRIX_BLOB
    assert custody["matrix"]["bytes"] == CURRENT_MATRIX_BYTES
    assert custody["matrix"]["sha256"] == CURRENT_MATRIX_SHA
    assert custody["matrix"]["counts"] == matrix["counts"]
    assert custody["matrix"]["current_result"] == matrix["current_result"]
    assert custody["north_dakota"]["row_sha256"] == CURRENT_ROW_SHA
    assert custody["north_dakota"]["row_state_cell_sha256"] == CURRENT_ROW_STATE_SHA
    assert custody["north_dakota"]["all_eight_substantive_fields_terminal"] is True
    assert custody["north_dakota"]["remaining_open_field_ids"] == [
        "field_and_row_terminal_state"
    ]
    assert custody["north_dakota"]["substantive_field_ids"] == FIELDS
    assert custody["north_dakota"]["substantive_cell_states"] == {
        cell["field_id"]: cell["state"] for cell in nd["cells"][:8]
    }
    assert custody["north_dakota"]["substantive_cell_sha256s"] == {
        cell["field_id"]: sha(canon(cell)) for cell in nd["cells"][:8]
    }

    assert validation["source_validation_head"] == STALE_HEAD
    assert validation["review_correction"] == {
        "rejected_row_state": "terminal",
        "required_row_state": TERMINAL_STATE,
        "mechanism": (
            "bind_row_aggregate_to_the_same_canonical_terminal_enum_"
            "as_the_row_state_cell"
        ),
        "aggregate_reconciliation": (
            "update_current_result_counts_and_ordered_terminal_unit_ids"
        ),
    }
    assert validation["validation_result"] == {
        "state": "validated_exact_current_row_state",
        "all_eight_substantive_fields_terminal": True,
        "remaining_open_cell_count": 1,
        "remaining_open_field_id": "field_and_row_terminal_state",
        "row_state_transition_mechanically_admissible": True,
        "separate_promotion_product_authorized": True,
        "promotion_executed_here": False,
    }

    proposed = validation["proposed_row_state_cell"]
    exact_keys(
        proposed,
        [
            "field_ordinal", "field_id", "state", "terminal", "value",
            "evidence_source_ids", "typed_gap", "authority_effect",
        ],
        "proposed row-state cell",
    )
    assert proposed["field_ordinal"] == 9
    assert proposed["field_id"] == "field_and_row_terminal_state"
    assert proposed["state"] == "evidence_complete"
    assert proposed["terminal"] is True
    assert proposed["typed_gap"] is None
    assert proposed["evidence_source_ids"] == [
        "RD04-ND-ROW-STATE-RECONCILIATION-V2"
    ]
    assert proposed["authority_effect"] == (
        "row_level_fixed_public_record_obligation_terminal_only"
    )
    exact_keys(
        proposed["value"],
        [
            "terminal_classification", "row_scope", "completed_evidence_fields",
            "terminal_evidence_field_ids", "terminal_evidence_state_counts",
            "predecessor_row_canonical_sha256", "completion_rule",
            "class_effect", "cumulative_ledger_effect", "limitations",
            "prohibited_inferences",
        ],
        "proposed row-state value",
    )
    value = proposed["value"]
    assert value["terminal_classification"] == TERMINAL_STATE
    assert value["row_scope"] == "fixed_public_record_obligation_for_one_state"
    assert value["completed_evidence_fields"] == 8
    assert value["terminal_evidence_field_ids"] == FIELDS
    assert value["terminal_evidence_state_counts"] == {
        "evidence_complete": 7,
        "observed": 0,
        "not_publicly_recovered": 1,
    }
    assert value["predecessor_row_canonical_sha256"] == CURRENT_ROW_SHA
    assert value["completion_rule"] == (
        "all_eight_declared_state_evidence_fields_are_terminal_"
        "under_exact_source_or_typed_gap_custody"
    )
    assert value["class_effect"] == "none"
    assert value["cumulative_ledger_effect"] == "none"
    assert len(value["limitations"]) == 4
    assert len(value["prohibited_inferences"]) == 9
    assert (
        "do_not_close_rd04_c02_or_wave03_from_eleven_terminal_rows"
        in value["prohibited_inferences"]
    )
    assert sha(canon(proposed)) == PROPOSED_SHA
    assert validation["proposed_row_state_cell_sha256"] == PROPOSED_SHA

    projected, after = project(matrix, proposed)
    projected_raw = json_bytes(projected)
    projected_row_sha = sha(canon(after))
    projected_sha = sha(projected_raw)
    projected_blob = blob(projected_raw)
    unchanged_sha = sha(
        b"".join(
            canon(row) + b"\n"
            for row in matrix["rows"]
            if row["unit_id"] != "US-STATE-ND"
        )
    )
    assert unchanged_sha == UNCHANGED_ROWS_SHA
    assert after["row_state"] == TERMINAL_STATE
    assert after["terminal_fields"] == 9
    assert after["open_fields"] == 0
    assert after["cells"][8] == proposed
    assert projected["current_result"]["terminal_unit_ids"] == TERMINAL_UNIT_IDS
    assert projected["current_result"]["terminal_cells"] == "229/450"
    assert projected["current_result"]["still_open_cells"] == "221/450"
    assert projected["current_result"]["terminal_units"] == 11
    assert all(
        left == right
        for left, right in zip(
            [
                row for row in matrix["rows"]
                if row["unit_id"] != "US-STATE-ND"
            ],
            [
                row for row in projected["rows"]
                if row["unit_id"] != "US-STATE-ND"
            ],
        )
    )

    assert validation["projected_row"] == {
        "row_sha256": projected_row_sha,
        "row_state": TERMINAL_STATE,
        "terminal_fields": 9,
        "open_fields": 0,
    }
    projected_meta = validation["projected_matrix"]
    exact_keys(
        projected_meta,
        [
            "scope", "final_product_identity_authorized", "bytes", "sha256",
            "git_blob_sha", "counts", "current_result", "changed_units",
            "changed_cells", "unchanged_non_target_rows",
            "unchanged_non_target_rows_sha256",
        ],
        "projected matrix",
    )
    assert projected_meta["scope"] == (
        "semantic_state_before_later_product_provenance_metadata"
    )
    assert projected_meta["final_product_identity_authorized"] is False
    assert projected_meta["bytes"] == len(projected_raw)
    assert projected_meta["sha256"] == projected_sha
    assert projected_meta["git_blob_sha"] == projected_blob
    assert projected_meta["counts"] == projected["counts"]
    assert projected_meta["current_result"] == projected["current_result"]
    assert projected_meta["changed_units"] == 1
    assert projected_meta["changed_cells"] == 1
    assert projected_meta["unchanged_non_target_rows"] == 49
    assert projected_meta["unchanged_non_target_rows_sha256"] == UNCHANGED_ROWS_SHA
    assert validation["projected_effects"] == {
        "field_terminalizations": 0,
        "matrix_updates": 1,
        "row_state_mutations": 1,
        "row_terminalizations": 1,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "outside_human_dependency": False,
    }

    assert protocol["source_validation_head"] == STALE_HEAD
    assert protocol["unit_id"] == "US-STATE-ND"
    assert protocol["current_row_sha256"] == CURRENT_ROW_SHA
    assert protocol["current_row_state_cell_sha256"] == CURRENT_ROW_STATE_SHA
    assert protocol["proposed_row_state_cell_sha256"] == PROPOSED_SHA
    assert protocol["projected_row_state"] == TERMINAL_STATE
    assert protocol["projected_row_sha256"] == projected_row_sha
    assert protocol["projected_matrix_sha256"] == projected_sha
    assert protocol["projected_matrix_scope"] == (
        "semantic_state_before_later_product_provenance_metadata"
    )
    assert protocol["final_product_identity_authorized"] is False
    assert protocol["validation_state"] == "validated_exact_current_row_state"
    assert (
        protocol["canonical_validation_merge_required_before_promotion"]
        is True
    )
    assert protocol["separate_promotion_product_authorized"] is True
    assert protocol["maximum_field_terminalizations"] == 0
    assert protocol["maximum_matrix_updates"] == 1
    assert protocol["maximum_row_state_mutations"] == 1
    assert protocol["maximum_row_terminalizations"] == 1
    assert protocol["class_closure_authorized"] is False
    assert protocol["promotion_executed_here"] is False
    assert protocol["projected_counts"] == projected["counts"]
    assert protocol["projected_current_result"] == projected["current_result"]

    assert summary["source_validation_head"] == STALE_HEAD
    assert summary["state"] == (
        "validated_exact_current_row_state_requires_separate_promotion"
    )
    assert summary["unit_id"] == "US-STATE-ND"
    assert summary["current_row_state"] == "still_open"
    assert summary["projected_row_state"] == TERMINAL_STATE
    assert summary["current_terminal_fields"] == 8
    assert summary["current_open_fields"] == 1
    assert summary["projected_terminal_fields"] == 9
    assert summary["projected_open_fields"] == 0
    assert summary["projected_row_sha256"] == projected_row_sha
    assert summary["projected_semantic_matrix_sha256"] == projected_sha
    assert summary["final_product_identity_authorized"] is False
    assert summary["validated_candidates"] == 1
    assert summary["rejected_candidates"] == 0
    assert summary["promotion_executed_here"] is False
    assert summary["next_authorized_operation"] == (
        "construct_one_separate_row_state_promotion_product_"
        "after_this_validation_product_is_canonical"
    )

    assert manifest["source_validation_head"] == STALE_HEAD
    assert manifest["product_slug"] == (
        "status-sovereignty-rd-wave03-rd04-postpromotion-"
        "nd-row-state-reconciliation-validation-v2"
    )
    assert manifest["addition_only"] is True
    assert manifest["permanent_path_count"] == 7
    assert manifest["permanent_paths"] == PATHS
    assert len(set(manifest["permanent_paths"])) == 7
    assert manifest["qualification_workflow"] == {
        "path": os.environ["WORKFLOW_PATH"]
    }
    assert manifest["semantic_counts"] == {
        "validated_candidates": 1,
        "rejected_candidates": 0,
        "separate_promotion_product_authorized": True,
        "promotion_executed_here": False,
        "field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
        "row_terminalizations": 0,
        "projected_matrix_updates": 1,
        "projected_row_state_mutations": 1,
        "projected_row_terminalizations": 1,
        "adversarial_refusals": 44,
        "class_closed": False,
    }
    assert manifest["payload_digest_algorithm"] == (
        "sha256 over UTF-8 rows path NUL sha256 NUL bytes LF "
        "in lexicographic path order"
    )

    payload_names = [
        "current-row-custody.json",
        "row-state-validation.json",
        "validated-row-state-protocol.json",
        "summary.json",
    ]
    payload_objects = [custody, validation, protocol, summary]
    expected_records = []
    digest_rows = []
    for name, obj in zip(payload_names, payload_objects):
        path = os.environ["VALIDATION_ROOT"] + "/" + name
        data = json_bytes(obj)
        record = {
            "path": path,
            "bytes": len(data),
            "sha256": sha(data),
            "git_blob": blob(data),
        }
        expected_records.append(record)
        digest_rows.append(
            f"{path}\0{record['sha256']}\0{record['bytes']}\n"
        )
        if check_files:
            assert (ROOT / path).read_bytes() == data
    assert manifest["payload_files"] == expected_records
    assert len({record["path"] for record in expected_records}) == 4
    assert manifest["payload_combined_sha256"] == sha(
        "".join(sorted(digest_rows)).encode()
    )

    if check_files:
        script = (ROOT / os.environ["VALIDATOR_PATH"]).read_bytes()
        assert manifest["validator_script"] == {
            "path": os.environ["VALIDATOR_PATH"],
            "bytes": len(script),
            "sha256": sha(script),
            "git_blob": blob(script),
        }

    return {
        "schema_version": (
            "ssc-rd04-nd-row-state-reconciliation-hosted-validation@2"
        ),
        "state": (
            "validated_exact_current_row_state_requires_separate_promotion"
        ),
        "canonical_parent": EXPECTED_PARENT,
        "canonical_parent_tree": EXPECTED_PARENT_TREE,
        "source_validation_head": STALE_HEAD,
        "head": checkout_head(),
        "current_matrix_sha256": CURRENT_MATRIX_SHA,
        "current_row_sha256": CURRENT_ROW_SHA,
        "current_row_state_cell_sha256": CURRENT_ROW_STATE_SHA,
        "proposed_row_state_cell_sha256": PROPOSED_SHA,
        "projected_row_state": TERMINAL_STATE,
        "projected_row_sha256": projected_row_sha,
        "projected_semantic_matrix_bytes": len(projected_raw),
        "projected_semantic_matrix_sha256": projected_sha,
        "projected_semantic_matrix_git_blob": projected_blob,
        "validated_candidates": 1,
        "rejected_candidates": 0,
        "adversarial_refusals": 44,
        "promotion_executed_here": False,
        "final_product_identity_authorized": False,
        "projected_matrix_updates": 1,
        "projected_row_state_mutations": 1,
        "projected_row_terminalizations": 1,
        "field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
        "row_terminalizations": 0,
        "class_closed": False,
        "outside_human_dependency": False,
    }

def adversarial():
    base = load_model()
    tests = []

    def add(name, mutate):
        tests.append((name, mutate))

    add(
        "current terminal count",
        lambda m: m["matrix"]["counts"].__setitem__("terminal_cells", 229),
    )
    add(
        "current open count",
        lambda m: m["matrix"]["counts"].__setitem__("still_open_cells", 221),
    )
    add(
        "current-result terminal count",
        lambda m: m["matrix"]["current_result"].__setitem__(
            "terminal_cells", "229/450"
        ),
    )
    add(
        "current-result terminal units",
        lambda m: m["matrix"]["current_result"].__setitem__(
            "terminal_units", 11
        ),
    )
    add(
        "current-result terminal-unit order",
        lambda m: m["matrix"]["current_result"]["terminal_unit_ids"].reverse(),
    )
    add(
        "current row aggregate state",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        ).__setitem__("row_state", TERMINAL_STATE),
    )
    add(
        "current row terminal fields",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        ).__setitem__("terminal_fields", 9),
    )
    add(
        "current row open fields",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        ).__setitem__("open_fields", 0),
    )
    add(
        "current row-state cell state",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        )["cells"][8].__setitem__("state", "evidence_complete"),
    )
    add(
        "current row-state cell terminal",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        )["cells"][8].__setitem__("terminal", True),
    )
    add(
        "substantive terminal rollback",
        lambda m: next(
            row for row in m["matrix"]["rows"]
            if row["unit_id"] == "US-STATE-ND"
        )["cells"][0].__setitem__("terminal", False),
    )
    add(
        "custody undeclared key",
        lambda m: m["custody"].__setitem__("publication_claim", "claimed"),
    )
    add(
        "custody parent",
        lambda m: m["custody"].__setitem__(
            "canonical_parent", PROMOTION_MERGE
        ),
    )
    add(
        "custody tree",
        lambda m: m["custody"].__setitem__(
            "canonical_parent_tree", PROMOTION_TREE
        ),
    )
    add(
        "custody repair product",
        lambda m: m["custody"]["canonical_manifest_repair"].__setitem__(
            "product_commit", "0" * 40
        ),
    )
    add(
        "custody row digest",
        lambda m: m["custody"]["north_dakota"].__setitem__(
            "row_sha256", "0" * 64
        ),
    )
    add(
        "validation undeclared key",
        lambda m: m["validation"].__setitem__(
            "final_promotion_executed", True
        ),
    )
    add(
        "validation authorization",
        lambda m: m["validation"]["validation_result"].__setitem__(
            "separate_promotion_product_authorized", False
        ),
    )
    add(
        "validation execution",
        lambda m: m["validation"]["validation_result"].__setitem__(
            "promotion_executed_here", True
        ),
    )
    add(
        "proposed state",
        lambda m: m["validation"]["proposed_row_state_cell"].__setitem__(
            "state", "observed"
        ),
    )
    add(
        "proposed terminal",
        lambda m: m["validation"]["proposed_row_state_cell"].__setitem__(
            "terminal", False
        ),
    )
    add(
        "proposed terminal classification",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"].__setitem__(
            "terminal_classification", "terminal"
        ),
    )
    add(
        "proposed completed fields",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"].__setitem__(
            "completed_evidence_fields", 7
        ),
    )
    add(
        "proposed predecessor",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"].__setitem__(
            "predecessor_row_canonical_sha256", "0" * 64
        ),
    )
    add(
        "proposed limitations",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"][
            "limitations"
        ].pop(),
    )
    add(
        "proposed prohibited inference",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"][
            "prohibited_inferences"
        ].pop(),
    )
    add(
        "proposed source",
        lambda m: m["validation"]["proposed_row_state_cell"].__setitem__(
            "evidence_source_ids", []
        ),
    )
    add(
        "proposed value undeclared key",
        lambda m: m["validation"]["proposed_row_state_cell"]["value"].__setitem__(
            "national_prevalence", "claimed"
        ),
    )
    add(
        "review correction state",
        lambda m: m["validation"]["review_correction"].__setitem__(
            "required_row_state", "terminal"
        ),
    )
    add(
        "projected row state",
        lambda m: m["validation"]["projected_row"].__setitem__(
            "row_state", "terminal"
        ),
    )
    add(
        "projected row digest",
        lambda m: m["validation"]["projected_row"].__setitem__(
            "row_sha256", "0" * 64
        ),
    )
    add(
        "projected matrix bytes",
        lambda m: m["validation"]["projected_matrix"].__setitem__(
            "bytes", 0
        ),
    )
    add(
        "projected matrix digest",
        lambda m: m["validation"]["projected_matrix"].__setitem__(
            "sha256", "0" * 64
        ),
    )
    add(
        "projected current-result units",
        lambda m: m["validation"]["projected_matrix"][
            "current_result"
        ].__setitem__("terminal_units", 10),
    )
    add(
        "projected final identity",
        lambda m: m["validation"]["projected_matrix"].__setitem__(
            "final_product_identity_authorized", True
        ),
    )
    add(
        "protocol maximum matrix",
        lambda m: m["protocol"].__setitem__("maximum_matrix_updates", 2),
    )
    add(
        "protocol class closure",
        lambda m: m["protocol"].__setitem__(
            "class_closure_authorized", True
        ),
    )
    add(
        "protocol final identity",
        lambda m: m["protocol"].__setitem__(
            "final_product_identity_authorized", True
        ),
    )
    add(
        "summary projected state",
        lambda m: m["summary"].__setitem__(
            "projected_row_state", "terminal"
        ),
    )
    add(
        "summary execution",
        lambda m: m["summary"].__setitem__(
            "promotion_executed_here", True
        ),
    )
    add(
        "manifest parent",
        lambda m: m["manifest"].__setitem__(
            "canonical_parent", PROMOTION_MERGE
        ),
    )
    add(
        "manifest path omission",
        lambda m: m["manifest"]["permanent_paths"].pop(),
    )
    add(
        "manifest payload forgery",
        lambda m: m["manifest"]["payload_files"][0].__setitem__(
            "sha256", "0" * 64
        ),
    )
    add(
        "manifest authority",
        lambda m: m["manifest"]["authority_boundary"].__setitem__(
            "row_terminalizations", 1
        ),
    )

    assert len(tests) == 44
    refusals = []
    for name, mutate in tests:
        model = copy.deepcopy(base)
        mutate(model)
        try:
            validate(model, check_files=False)
        except Exception:
            refusals.append(name)
        else:
            raise AssertionError(f"mutation admitted: {name}")
    return {
        "schema_version": (
            "ssc-rd04-nd-row-state-reconciliation-adversarial@2"
        ),
        "state": "forty_four_typed_adversarial_refusals_complete",
        "refusals": len(refusals),
        "names": refusals,
    }

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--adversarial", action="store_true")
    args = parser.parse_args()
    result = adversarial() if args.adversarial else validate(load_model())
    print(json.dumps(result, indent=2, sort_keys=True))
