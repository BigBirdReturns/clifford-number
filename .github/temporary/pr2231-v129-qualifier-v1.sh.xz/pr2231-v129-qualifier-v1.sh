#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=e0c772e962078878a1e4b659a861581cb2957a73
product_tree=24a1487dac3e221601b905fd696b4888444a0032
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=b2aefcdc6a2ae6715c5ae9dd748c12310c57564f
test_blob=c76ea816162a2a47e1cbf3612322adc95cc60c4e
library_sha256=a1acebc33a13502813b5d5abdac5d37f504efb38cd46bda8813cde29f72c0db7
test_sha256=6508b93361da6bfb1fa12b2bd11f8ea34975d954e2f6e6629166e5bff68c2a22
review_comments=(3912324673 3912338942 3912338949 3917571264 3917571271)
review_commits=(
  e0c772e962078878a1e4b659a861581cb2957a73
  e0c772e962078878a1e4b659a861581cb2957a73
  e0c772e962078878a1e4b659a861581cb2957a73
  e0c772e962078878a1e4b659a861581cb2957a73
  e0c772e962078878a1e4b659a861581cb2957a73
)
review_original_commits=(
  73e4501c6da942ba326ecf146df1a71bbf953b25
  73e4501c6da942ba326ecf146df1a71bbf953b25
  73e4501c6da942ba326ecf146df1a71bbf953b25
  bd1523d86a562be91acdc175f73607dab0fcac09
  bd1523d86a562be91acdc175f73607dab0fcac09
)
expected_review_titles=(
  'Preserve a later phone-owned opener after the clean observation closer'
  'Compare embedded-email bounds in source coordinates'
  'Index token bounds before processing embedded emails'
  'Reject bare-host matches followed by scheme syntax'
  'Map normalized origins across composing code points'
)

out=/tmp/pr2231-v129-qualification-v2
work=/tmp/pr2231-v129-work-v2
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec > >(tee -a "$out/qualification.log") 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=read-only-v129-current-v128-qualification\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual" >&2
    exit 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,commit_id,path,line,start_line,side,in_reply_to_id,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
}

require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$product_parent" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count

gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit.json")" 1 product-parent-count

for i in "${!review_comments[@]}"; do
  id=${review_comments[$i]}
  review_commit=${review_commits[$i]}
  review_original_commit=${review_original_commits[$i]}
  title=${expected_review_titles[$i]}
  gh api "repos/$repo/pulls/comments/$id" > "$out/review-$id.json"
  require_equal "$(jq -r '.commit_id' "$out/review-$id.json")" "$review_commit" "review-$id-commit"
  require_equal "$(jq -r '.original_commit_id' "$out/review-$id.json")" "$review_original_commit" "review-$id-original-commit"
  require_equal "$(jq -r '.path' "$out/review-$id.json")" "$library_path" "review-$id-path"
  jq -er --arg title "$title" '.body | contains($title)' "$out/review-$id.json" >/dev/null
  printf '%s\t%s\n' "$id" "$(jq -r '.node_id' "$out/review-$id.json")" >> "$out/review-denominator.txt"
done

# Materialize the exact live V128 product over its exact main parent without fetching or moving refs.
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v128-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v128-industrial-exhaust.test.js"

cat > "$out/v129-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const wrapperCases = [
  ['ID: 123-45678/[62-16]-[03-6216-8041]', 'ID: 123-45678/[62-16]-[[contact omitted]]'],
  ['ID: 123-45678/[62-16]-{03-6216-8041}', 'ID: 123-45678/[62-16]-{[contact omitted]}'],
  ['ID: 123-45678/[62-16]-【03-6216-8041】', 'ID: 123-45678/[62-16]-【[contact omitted]】'],
  ['ＩＤ：１２３－４５６７８／［６２－１６］－［０３－６２１６－８０４１］', 'ＩＤ：１２３－４５６７８／［６２－１６］－［[contact omitted]］']
];

const shrinkingPrefix = 'ｶﾞ'.repeat(20);
const nfkcEmailUrl = `https://example.test/${shrinkingPrefix}alice@example.com/03-6216-8041`;
const scaleInput = `https://example.test/${'a@b.com/'.repeat(1000)}03-6216-8041`;
const malformedSchemeInput = 'Phone: 03-6216-8041.https://example.test/03-6216-8041';
const malformedSchemeExpected = 'Phone: [contact omitted].https://example.test/[contact omitted]';
const nfkcOriginPrefix = 'ｶﾞ'.repeat(15);
const nfkcOriginInput = `${nfkcOriginPrefix}:03-6216-8041=https://example.test/03-6216-8041`;
const nfkcOriginExpected = `${nfkcOriginPrefix}:[contact omitted]=https://example.test/03-6216-8041`;

const countNormalizeWork = input => {
  const originalNormalize = String.prototype.normalize;
  let normalizedCharacters = 0;
  let actual;
  try {
    String.prototype.normalize = function countedNormalize(form) {
      normalizedCharacters += String(this).length;
      return originalNormalize.call(this, form);
    };
    actual = redactContactData(input);
  } finally {
    String.prototype.normalize = originalNormalize;
  }
  return { actual, normalizedCharacters };
};

if (mode === 'predecessor') {
  for (const [input, expected] of wrapperCases) {
    assert.equal(redactContactData(input), expected);
  }
  assert.equal(redactContactData(nfkcEmailUrl), nfkcEmailUrl);
  const scale = countNormalizeWork(scaleInput);
  assert.equal(scale.actual, scaleInput);
  assert.ok(scale.normalizedCharacters < scaleInput.length * 30);

  const malformedSchemeActual = redactContactData(malformedSchemeInput);
  assert.equal(
    malformedSchemeActual,
    malformedSchemeInput,
    'V128 must reproduce bare-host custody minted by an interior approved-looking scheme'
  );
  const unsupportedSchemeInput = 'Phone: 03-6216-8041.mailto://example.test/03-6216-8041';
  const unsupportedSchemeActual = redactContactData(unsupportedSchemeInput);
  assert.equal(
    unsupportedSchemeActual,
    unsupportedSchemeInput,
    'V128 must reproduce bare-host custody minted by an interior unsupported scheme'
  );
  const ipv4PseudoSchemeInput = '192.0.2.1://03-6216-8041';
  assert.equal(
    redactContactData(ipv4PseudoSchemeInput),
    ipv4PseudoSchemeInput,
    'V128 must reproduce scheme-relative custody minted by an IPv4 pseudo-scheme'
  );
  const nfkcOriginActual = redactContactData(nfkcOriginInput);
  assert.equal(
    nfkcOriginActual,
    nfkcOriginInput,
    'V128 must reproduce backward URL custody across an NFKC contraction'
  );
  const kannadaPrefix = 'ೇ'.repeat(15);
  const kannadaInput = `${kannadaPrefix}:03-6216-8041=https://example.test/03-6216-8041`;
  assert.equal(
    redactContactData(kannadaInput),
    kannadaInput,
    'V128 must reproduce backward URL custody across Kannada cross-code-point composition'
  );
  console.log(JSON.stringify({
    mode,
    retainedV128WrapperRepairs: wrapperCases.length,
    retainedV128EmailCustody: true,
    malformedSchemeOutput: malformedSchemeActual,
    unsupportedSchemeOutput: unsupportedSchemeActual,
    ipv4PseudoSchemeOutput: redactContactData(ipv4PseudoSchemeInput),
    nfkcOriginOutput: nfkcOriginActual,
    scaleInputLength: scaleInput.length,
    normalizedCharacters: scale.normalizedCharacters
  }, null, 2));
  process.exit(0);
}

for (const [input, expected] of wrapperCases) assert.equal(redactContactData(input), expected);
for (const input of [
  'ID: 123-45678/[62-16]-[12345678]',
  'ID: 123-45678/[62-16-]-[03-6216-8041]',
  'ID: 123-45678/(62-16]-[03-6216-8041]',
  'ID: 123-45678/[62-16]]-[03-6216-8041]',
  'ID: 123-45678/[62-16/]-[03-6216-8041]'
]) assert.equal(redactContactData(input), input);

assert.equal(redactContactData(nfkcEmailUrl), nfkcEmailUrl);
assert.equal(
  redactContactData('alice@example.com=https://example.test/03-6216-8041'),
  '[contact omitted]=https://example.test/03-6216-8041'
);
assert.equal(
  redactContactData('mailto://alice@example.com/03-6216-8041'),
  'mailto://[contact omitted]/[contact omitted]'
);
assert.equal(
  redactContactData('https://alice@example.com/03-6216-8041'),
  'https://alice@example.com/03-6216-8041'
);
assert.equal(
  redactContactData(malformedSchemeInput),
  malformedSchemeExpected,
  'an interior malformed scheme must not promote the preceding phone-shaped domain prefix into URL custody'
);
assert.equal(
  redactContactData('Phone: 03-6216-8041.mailto://example.test/03-6216-8041'),
  'Phone: [contact omitted].mailto://example.test/[contact omitted]',
  'an unsupported interior scheme must not acquire bare-host custody'
);
assert.equal(
  redactContactData('192.0.2.1://03-6216-8041'),
  '192.0.2.1://[contact omitted]',
  'an IPv4 pseudo-scheme must not acquire scheme-relative custody from its interior slashes'
);
assert.equal(
  redactContactData(nfkcOriginInput),
  nfkcOriginExpected,
  'URL origin transport must account for whole-grapheme NFKC contraction before the source origin'
);
assert.equal(
  redactContactData('Phone: 03-6216-8041=https://example.test/03-6216-8041'),
  'Phone: [contact omitted]=https://example.test/03-6216-8041',
  'a genuine later HTTPS origin must retain its own numeric path without backward custody'
);
assert.equal(
  redactContactData('example.test:443/03-6216-8041'),
  'example.test:443/03-6216-8041',
  'a numeric port on a genuine bare host remains approved URL custody'
);

const scale = countNormalizeWork(scaleInput);
assert.equal(scale.actual, scaleInput);
assert.ok(
  scale.normalizedCharacters < scaleInput.length * 30,
  `embedded-email URL custody must use one indexed token census; normalized ${scale.normalizedCharacters} chars for ${scaleInput.length} source chars`
);
console.log(JSON.stringify({
  mode,
  wrapperRepairs: wrapperCases.length,
  semanticRepairs: 5,
  scaleInputLength: scaleInput.length,
  normalizedCharacters: scale.normalizedCharacters
}, null, 2));
NODE

node "$out/v129-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

cat > "$out/apply-v129.py" <<'PY'
from pathlib import Path
import sys

library = Path(sys.argv[1])
test = Path(sys.argv[2])
text = library.read_text()

def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected one anchor, found {count}')
    return source.replace(old, new, 1)

text = replace_once(text, r'''const LEGACY_UNSUPPORTED_URL_SCHEME_PATTERN = /(?:^|[<([{=:;,|])([\p{L}][\p{L}\p{N}+.-]*):\/\//iu;
const URL_TOKEN_LEADING_WRAPPER_PATTERN = /[\p{P}\p{S}]/u;
''', r'''const LEGACY_UNSUPPORTED_URL_SCHEME_PATTERN = /(?:^|[<([{=:;,|])([\p{L}][\p{L}\p{N}+.-]*):\/\//iu;
const LEGACY_URL_ORIGIN_DELIMITER_PATTERN = /[<([{=:;,|]/u;
const URL_TOKEN_LEADING_WRAPPER_PATTERN = /[\p{P}\p{S}]/u;

function malformedSchemeLikeUrlOrigin(value) {
  for (const match of value.matchAll(
    /([\p{L}][\p{L}\p{N}+.-]*|(?:\d{1,3}\.){3}\d{1,3}):\/\//giu
  )) {
    const origin = match[1];
    const start = match.index;
    const prior = previousCodePoint(value, start);
    const approvedLegacyScheme = /^https?$/iu.test(origin)
      && (start === 0 || LEGACY_URL_ORIGIN_DELIMITER_PATTERN.test(prior));
    if (approvedLegacyScheme) continue;
    return start;
  }
  return -1;
}
''', 'malformed scheme-like origin classifier')

text = replace_once(text, '''  if (leadingScheme) {
    const approved = /^https?$/iu.test(leadingScheme[1]);
    return {
      normalized,
      originStart: leadingOriginStart,
      approved,
      unsupported: !approved
    };
  }
  if (DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN.test(leadingOrigin)
''', '''  if (leadingScheme) {
    const approved = /^https?$/iu.test(leadingScheme[1]);
    return {
      normalized,
      originStart: leadingOriginStart,
      approved,
      unsupported: !approved
    };
  }
  const malformedSchemeLikeOrigin = malformedSchemeLikeUrlOrigin(normalized);
  if (malformedSchemeLikeOrigin >= 0) {
    return {
      normalized,
      originStart: malformedSchemeLikeOrigin,
      approved: false,
      unsupported: true
    };
  }
  if (DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN.test(leadingOrigin)
''', 'malformed scheme-like origin precedence')

text = replace_once(text, '''function sourceEndForNormalizedPrefix(source, normalizedLength) {
  let sourceEnd = 0;
  let normalizedEnd = 0;
  for (const character of source) {
    if (normalizedEnd >= normalizedLength) break;
    sourceEnd += character.length;
    normalizedEnd += character.normalize('NFKC').length;
  }
  return sourceEnd;
}
''', '''const NFKC_SOURCE_SEGMENTER = new Intl.Segmenter(
  'und',
  { granularity: 'grapheme' }
);

function sourceEndForNormalizedPrefix(source, normalizedLength) {
  let sourceEnd = 0;
  let normalizedEnd = 0;
  for (const { segment } of NFKC_SOURCE_SEGMENTER.segment(source)) {
    if (normalizedEnd >= normalizedLength) break;
    sourceEnd += segment.length;
    normalizedEnd += segment.normalize('NFKC').length;
  }
  return sourceEnd;
}
''', 'grapheme-segment NFKC source map')

library.write_text(text)

tests = test.read_text()
append = r'''

// PR2231 V129 malformed-scheme and whole-segment NFKC origin custody
for (const [name, input, expected] of [
  [
    'approved-looking interior scheme cannot be parsed as a bare-host TLD',
    'Phone: 03-6216-8041.https://example.test/03-6216-8041',
    'Phone: [contact omitted].https://example.test/[contact omitted]'
  ],
  [
    'unsupported interior scheme cannot be parsed as a bare-host TLD',
    'Phone: 03-6216-8041.mailto://example.test/03-6216-8041',
    'Phone: [contact omitted].mailto://example.test/[contact omitted]'
  ],
  [
    'bare-domain port custody remains approved',
    'example.test:443/03-6216-8041',
    'example.test:443/03-6216-8041'
  ],
  [
    'IPv4 port custody remains approved',
    '192.0.2.1:443/03-6216-8041',
    '192.0.2.1:443/03-6216-8041'
  ],
  [
    'bare-domain pseudo-scheme cannot retain a numeric path',
    'example.test://03-6216-8041',
    'example.test://[contact omitted]'
  ],
  [
    'IPv4 pseudo-scheme cannot retain a numeric path',
    '192.0.2.1://03-6216-8041',
    '192.0.2.1://[contact omitted]'
  ],
  [
    'candidate-relative HTTPS origin remains approved after an equals boundary',
    'Phone: 03-6216-8041=https://example.test/03-6216-8041',
    'Phone: [contact omitted]=https://example.test/03-6216-8041'
  ],
  [
    'candidate-relative scheme-relative origin remains approved after a semicolon boundary',
    'Phone: 03-6216-8041;//03-6216-8041',
    'Phone: [contact omitted];//03-6216-8041'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    `${name}: only an approved URL origin or numeric host port may acquire URL custody`
  );
}

for (const [name, contraction] of [
  ['halfwidth katakana voiced pair', 'ｶﾞ'],
  ['Kannada vowel-sign pair', '\u0CC6\u0CD5']
]) {
  const prefix = contraction.repeat(15);
  const input = `${prefix}:03-6216-8041=https://example.test/03-6216-8041`;
  assert.equal(
    redactContactData(input),
    `${prefix}:[contact omitted]=https://example.test/03-6216-8041`,
    `${name}: grapheme-segment NFKC mapping must not move a later URL origin backward across a phone`
  );
}
'''
if 'PR2231 V129 malformed-scheme and whole-segment NFKC origin custody' in tests:
    raise SystemExit('V129 tests already present')
test.write_text(tests + append)
PY

python3 "$out/apply-v129.py" "$work/product/$library_path" "$work/product/$test_path"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2

cp "$work/product/$library_path" "$out/v129-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v129-industrial-exhaust.test.js"
sha256sum "$out/v129-industrial-exhaust.mjs" "$out/v129-industrial-exhaust.test.js" \
  > "$out/v129-file-sha256.txt"
printf 'library_blob=%s\ntest_blob=%s\n' \
  "$(git hash-object "$out/v129-industrial-exhaust.mjs")" \
  "$(git hash-object "$out/v129-industrial-exhaust.test.js")" \
  > "$out/v129-file-blobs.txt"
git -C "$work/product" diff --numstat > "$out/v129-numstat.txt"
git -C "$work/product" diff -- "$library_path" "$test_path" > "$out/v129.patch"

node "$out/v129-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/successor-direct.json"

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

run_focused "$work/product" repaired-product
run_release "$work/product" repaired-product

# Restore generated state while retaining only the exact candidate files.
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v129-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

cp "$out/v129-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/transplant/$test_path"
run_focused "$work/transplant" frozen-main-transplant
run_release "$work/transplant" frozen-main-transplant

git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v129-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

# Construct one deterministic unpushed direct-child candidate over the frozen main lease.
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_message=$'fix: bind V129 source-indexed contact custody\n\nRetain V128 wrapper and embedded-email custody, reject malformed scheme-like origins, and map approved URL offsets through grapheme-segment NFKC source coordinates.'
candidate_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-02T22:10:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-02T22:10:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$(git hash-object "$out/v129-industrial-exhaust.mjs")
test_blob=$(git hash-object "$out/v129-industrial-exhaust.test.js")
EOF
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree" candidate-tree
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count

git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" \
  > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"

snapshot_state after
for item in product-pr controller-pr main-ref product-ref review-comments reviews issue-comments; do
  cmp "$out/$item.before.${item#*-}" "$out/$item.after.${item#*-}" 2>/dev/null || true
done
# Explicit comparisons avoid filename-extension ambiguity in the compact loop above.
cmp "$out/product-pr.before.json" "$out/product-pr.after.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.after.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.after.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"

cat > "$out/qualification-terminal.txt" <<EOF
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
EOF
cat "$out/qualification-terminal.txt"
