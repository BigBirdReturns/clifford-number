#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=bd1523d86a562be91acdc175f73607dab0fcac09
product_tree=8252807a4b840ba20d69cd478c8fdb53a851a826
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=cdf13a780f97f42c64bdac2e745da52be44850a1
test_blob=711003e4ce56e99cf51ceb0d8fd03df1e4473c31
library_sha256=7b36dcd6b8469f4332b18f070d2e554c85cff4b2f5c94e1b351286129e73dbf1
test_sha256=787c9891a4e4d59494979ced2498036178e7f18fdcaaf5b717183d566b22b291
review_comments=(3912324673 3912338942 3912338949 3917571264 3917571271)
review_commits=(
  73e4501c6da942ba326ecf146df1a71bbf953b25
  73e4501c6da942ba326ecf146df1a71bbf953b25
  73e4501c6da942ba326ecf146df1a71bbf953b25
  bd1523d86a562be91acdc175f73607dab0fcac09
  bd1523d86a562be91acdc175f73607dab0fcac09
)
expected_review_titles=(
  'Preserve a later phone-owned opener after the clean observation closer'
  'Compare embedded-email bounds in source coordinates'
  'Index token bounds before processing embedded emails'
  'Reject scheme syntax after a bare-host match'
  'Map URL origins using whole-prefix normalization'
)

out=/tmp/pr2231-v129-qualification-v1
work=/tmp/pr2231-v129-work-v1
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec > >(tee -a "$out/qualification.log") 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=read-only-v129-cumulative-qualification\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual" >&2
    exit 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,commit_id,path,line,start_line,side,in_reply_to_id,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
}

require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$product_parent" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count

gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit.json")" 1 product-parent-count

for i in "${!review_comments[@]}"; do
  id=${review_comments[$i]}
  review_commit=${review_commits[$i]}
  title=${expected_review_titles[$i]}
  gh api "repos/$repo/pulls/comments/$id" > "$out/review-$id.json"
  require_equal "$(jq -r '.commit_id' "$out/review-$id.json")" "$review_commit" "review-$id-commit"
  require_equal "$(jq -r '.path' "$out/review-$id.json")" "$library_path" "review-$id-path"
  jq -er --arg title "$title" '.body | contains($title)' "$out/review-$id.json" >/dev/null
  printf '%s\t%s\n' "$id" "$(jq -r '.node_id' "$out/review-$id.json")" >> "$out/review-denominator.txt"
done

# Materialize the exact V127 product over its exact main parent without fetching or moving refs.
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v127-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v127-industrial-exhaust.test.js"

cat > "$out/v129-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const wrapperCases = [
  ['ID: 123-45678/[62-16]-[03-6216-8041]', 'ID: 123-45678/[62-16]-[[contact omitted]]'],
  ['ID: 123-45678/[62-16]-{03-6216-8041}', 'ID: 123-45678/[62-16]-{[contact omitted]}'],
  ['ID: 123-45678/[62-16]-【03-6216-8041】', 'ID: 123-45678/[62-16]-【[contact omitted]】'],
  ['ＩＤ：１２３－４５６７８／［６２－１６］－［０３－６２１６－８０４１］', 'ＩＤ：１２３－４５６７８／［６２－１６］－［[contact omitted]］']
];

const shrinkingPrefix = 'ｶﾞ'.repeat(20);
const nfkcEmailUrl = `https://example.test/${shrinkingPrefix}alice@example.com/03-6216-8041`;
const scaleInput = `https://example.test/${'a@b.com/'.repeat(1000)}03-6216-8041`;
const malformedSchemeInput = 'Phone: 03-6216-8041.https://example.test/03-6216-8041';
const malformedSchemeExpected = 'Phone: [contact omitted].https://example.test/[contact omitted]';
const nfkcOriginPrefix = 'ｶﾞ'.repeat(15);
const nfkcOriginInput = `${nfkcOriginPrefix}:03-6216-8041=https://example.test/03-6216-8041`;
const nfkcOriginExpected = `${nfkcOriginPrefix}:[contact omitted]=https://example.test/03-6216-8041`;

const countNormalizeWork = input => {
  const originalNormalize = String.prototype.normalize;
  let normalizedCharacters = 0;
  let actual;
  try {
    String.prototype.normalize = function countedNormalize(form) {
      normalizedCharacters += String(this).length;
      return originalNormalize.call(this, form);
    };
    actual = redactContactData(input);
  } finally {
    String.prototype.normalize = originalNormalize;
  }
  return { actual, normalizedCharacters };
};

if (mode === 'predecessor') {
  for (const [input] of wrapperCases) assert.equal(redactContactData(input), input);
  const semantic = redactContactData(nfkcEmailUrl);
  assert.notEqual(semantic, nfkcEmailUrl);
  assert.ok((semantic.match(/\[contact omitted\]/gu) ?? []).length >= 1);
  const malformedSchemeActual = redactContactData(malformedSchemeInput);
  assert.equal(
    malformedSchemeActual,
    malformedSchemeInput,
    'the predecessor must reproduce bare-host custody minted by an interior malformed scheme'
  );
  const nfkcOriginActual = redactContactData(nfkcOriginInput);
  assert.equal(
    nfkcOriginActual,
    nfkcOriginInput,
    'the predecessor must reproduce backward URL custody across an NFKC contraction'
  );
  const scale = countNormalizeWork(scaleInput);
  assert.equal(scale.actual, scaleInput);
  assert.ok(scale.normalizedCharacters > scaleInput.length * 100);
  console.log(JSON.stringify({
    mode,
    wrapperFailures: wrapperCases.length,
    nfkcEmailOutput: semantic,
    malformedSchemeOutput: malformedSchemeActual,
    nfkcOriginOutput: nfkcOriginActual,
    scaleInputLength: scaleInput.length,
    normalizedCharacters: scale.normalizedCharacters
  }, null, 2));
  process.exit(0);
}

for (const [input, expected] of wrapperCases) assert.equal(redactContactData(input), expected);
for (const input of [
  'ID: 123-45678/[62-16]-[12345678]',
  'ID: 123-45678/[62-16-]-[03-6216-8041]',
  'ID: 123-45678/(62-16]-[03-6216-8041]',
  'ID: 123-45678/[62-16]]-[03-6216-8041]',
  'ID: 123-45678/[62-16/]-[03-6216-8041]'
]) assert.equal(redactContactData(input), input);

assert.equal(redactContactData(nfkcEmailUrl), nfkcEmailUrl);
assert.equal(
  redactContactData('alice@example.com=https://example.test/03-6216-8041'),
  '[contact omitted]=https://example.test/03-6216-8041'
);
assert.equal(
  redactContactData('mailto://alice@example.com/03-6216-8041'),
  'mailto://[contact omitted]/[contact omitted]'
);
assert.equal(
  redactContactData('https://alice@example.com/03-6216-8041'),
  'https://alice@example.com/03-6216-8041'
);
assert.equal(
  redactContactData(malformedSchemeInput),
  malformedSchemeExpected,
  'an interior malformed scheme must not promote the preceding phone-shaped domain prefix into URL custody'
);
assert.equal(
  redactContactData('Phone: 03-6216-8041.mailto://example.test/03-6216-8041'),
  'Phone: [contact omitted].mailto://example.test/[contact omitted]',
  'an unsupported interior scheme must not acquire bare-host custody'
);
assert.equal(
  redactContactData(nfkcOriginInput),
  nfkcOriginExpected,
  'URL origin transport must account for whole-grapheme NFKC contraction before the source origin'
);
assert.equal(
  redactContactData('Phone: 03-6216-8041=https://example.test/03-6216-8041'),
  'Phone: [contact omitted]=https://example.test/03-6216-8041',
  'a genuine later HTTPS origin must retain its own numeric path without backward custody'
);
assert.equal(
  redactContactData('example.test:443/03-6216-8041'),
  'example.test:443/03-6216-8041',
  'a numeric port on a genuine bare host remains approved URL custody'
);

const scale = countNormalizeWork(scaleInput);
assert.equal(scale.actual, scaleInput);
assert.ok(
  scale.normalizedCharacters < scaleInput.length * 30,
  `embedded-email URL custody must use one indexed token census; normalized ${scale.normalizedCharacters} chars for ${scaleInput.length} source chars`
);
console.log(JSON.stringify({
  mode,
  wrapperRepairs: wrapperCases.length,
  semanticRepairs: 5,
  scaleInputLength: scaleInput.length,
  normalizedCharacters: scale.normalizedCharacters
}, null, 2));
NODE

node "$out/v129-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

cat > "$out/apply-v129.py" <<'PY'
from pathlib import Path
import sys

library = Path(sys.argv[1])
test = Path(sys.argv[2])
text = library.read_text()

def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected one anchor, found {count}')
    return source.replace(old, new, 1)

text = replace_once(text, '''function emailMatchHasDirectUrlCustody(input, offset, length) {
  const tokenStart = nonWhitespaceTokenStart(input, offset);
  let tokenEnd = offset + length;
  while (tokenEnd < input.length && !/\\s/u.test(input[tokenEnd])) tokenEnd += 1;

  const origin = directUrlTokenOrigin(input.slice(tokenStart, tokenEnd));
  if (!origin.approved) return false;
  const relativeStart = offset - tokenStart;
  const relativeEnd = relativeStart + length;
  return relativeStart >= origin.originStart && relativeEnd <= origin.normalized.length;
}
''', '''function emailMatchHasDirectUrlCustody(
  input,
  offset,
  length,
  tokenBoundaryIndex = null
) {
  const tokenStart = nonWhitespaceTokenStart(
    input,
    offset,
    tokenBoundaryIndex
  );
  let tokenEnd;
  if (tokenBoundaryIndex) {
    tokenEnd = tokenBoundaryIndex.end(offset);
  } else {
    tokenEnd = offset + length;
    while (tokenEnd < input.length && !/\\s/u.test(input[tokenEnd])) tokenEnd += 1;
  }

  const emailEnd = offset + length;
  if (tokenBoundaryIndex) {
    const originStart = tokenBoundaryIndex.urlOriginStart(tokenStart);
    return tokenBoundaryIndex.urlState(tokenStart) === 1
      && originStart >= 0
      && offset >= originStart
      && emailEnd <= tokenEnd;
  }

  const token = input.slice(tokenStart, tokenEnd);
  const origin = directUrlTokenOrigin(token);
  if (!origin.approved) return false;
  const sourceOriginStart = tokenStart + sourceEndForNormalizedPrefix(
    token,
    origin.originStart
  );
  return offset >= sourceOriginStart && emailEnd <= tokenEnd;
}
''', 'email source coordinates and indexed custody')

text = replace_once(text, '''  const tokenStarts = new Uint32Array(value.length + 1);
  const previousEnds = new Uint32Array(value.length + 1);
  const urlTokenStates = new Int8Array(value.length + 1);
''', '''  const tokenStarts = new Uint32Array(value.length + 1);
  const previousEnds = new Uint32Array(value.length + 1);
  const tokenEnds = new Uint32Array(value.length + 1);
  const urlTokenStates = new Int8Array(value.length + 1);
''', 'token end index declaration')

text = replace_once(text, '''    if ((atEnd || whitespace) && tokenStart < index) {
      const origin = directUrlTokenOrigin(value.slice(tokenStart, index));
''', '''    if ((atEnd || whitespace) && tokenStart < index) {
      tokenEnds.fill(index, tokenStart, index + 1);
      const origin = directUrlTokenOrigin(value.slice(tokenStart, index));
''', 'token end index population')

text = replace_once(text, '''    previousEnd(end) {
      const boundedEnd = Math.min(Math.max(0, end), value.length);
      return previousEnds[boundedEnd];
    },
    urlState(start) {
''', '''    previousEnd(end) {
      const boundedEnd = Math.min(Math.max(0, end), value.length);
      return previousEnds[boundedEnd];
    },
    end(offset) {
      const boundedOffset = Math.min(Math.max(0, offset), value.length);
      return tokenEnds[boundedOffset] || boundedOffset;
    },
    urlState(start) {
''', 'token end index API')

text = replace_once(text, '''function consumeOwnedObservationClosers(separator, openers) {
''', '''function trailingExternalPhoneOpenersStart(value) {
  let cursor = value.length;
  let sawOpeningWrapper = false;

  while (cursor > 0) {
    const character = previousCodePoint(value, cursor);
    if (/\\s/u.test(character)) {
      cursor -= character.length;
      continue;
    }
    if (!OPENING_IDENTIFIER_WRAPPER_PATTERN.test(
      character.normalize('NFKC')
    )) break;
    sawOpeningWrapper = true;
    cursor -= character.length;
  }

  return sawOpeningWrapper ? cursor : value.length;
}

function consumeOwnedObservationClosers(separator, openers) {
''', 'later-phone external opener helper')

text = replace_once(text, '''    const closingState = consumeCleanOwnedObservationClosers(
      progressionBoundarySource,
      observationOpeners
    );
''', '''    const laterPhoneOpeningWrapperStart =
      trailingExternalPhoneOpenersStart(progressionBoundarySource);
    const cleanClosingBoundarySource = progressionBoundarySource.slice(
      0,
      laterPhoneOpeningWrapperStart
    );
    const closingState = consumeCleanOwnedObservationClosers(
      cleanClosingBoundarySource,
      observationOpeners
    );
''', 'observation closer versus later-phone opener partition')

text = replace_once(text, '''export function redactContactData(value) {
  const emailRedacted = String(value ?? '')
    .replace(
      /\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b/giu,
      (email, offset, input) => emailMatchHasDirectUrlCustody(
        input,
        offset,
        email.length
      ) ? email : '[contact omitted]'
    );
''', '''export function redactContactData(value) {
  const source = String(value ?? '');
  const emailTokenBoundaryIndex = createNonWhitespaceTokenBoundaryIndex(source);
  const emailRedacted = source.replace(
    /\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b/giu,
    (email, offset, input) => emailMatchHasDirectUrlCustody(
      input,
      offset,
      email.length,
      emailTokenBoundaryIndex
    ) ? email : '[contact omitted]'
  );
''', 'indexed email pass')

text = replace_once(text, r'''const DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN = /^(?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*$/iu;
const LEGACY_DIRECT_URL_ORIGIN_PATTERN = /(?:^|[<([{=:;,|])((?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*|\/\/[^\s]*)/iu;
''', r'''const DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN = /^(?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?!\.?:\/\/)(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?!\.?:\/\/)(?=\.?[:/?#]))[^\s]*$/iu;
const LEGACY_DIRECT_URL_ORIGIN_PATTERN = /(?:^|[<([{=:;,|])((?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?!\.?:\/\/)(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?!\.?:\/\/)(?=\.?[:/?#]))[^\s]*|\/\/[^\s]*)/iu;
''', 'bare host malformed-scheme guard')

text = replace_once(text, r'''  return /(?:www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*$/iu.test(
''', r'''  return /(?:www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?!\.?:\/\/)(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?!\.?:\/\/)(?=\.?[:/?#]))[^\s]*$/iu.test(
''', 'legacy host suffix malformed-scheme guard')

text = replace_once(text, '''function sourceEndForNormalizedPrefix(source, normalizedLength) {
  let sourceEnd = 0;
  let normalizedEnd = 0;
  for (const character of source) {
    if (normalizedEnd >= normalizedLength) break;
    sourceEnd += character.length;
    normalizedEnd += character.normalize('NFKC').length;
  }
  return sourceEnd;
}
''', '''const NFKC_SOURCE_SEGMENTER = new Intl.Segmenter(
  'und',
  { granularity: 'grapheme' }
);

function sourceEndForNormalizedPrefix(source, normalizedLength) {
  let sourceEnd = 0;
  let normalizedEnd = 0;
  for (const { segment } of NFKC_SOURCE_SEGMENTER.segment(source)) {
    if (normalizedEnd >= normalizedLength) break;
    sourceEnd += segment.length;
    normalizedEnd += segment.normalize('NFKC').length;
  }
  return sourceEnd;
}
''', 'grapheme-segment NFKC source map')

library.write_text(text)

tests = test.read_text()
append = r'''

// PR2231 V129 later-phone opener custody and indexed embedded-email URL bounds
for (const [name, input, expected] of [
  [
    'square-wrapped later phone retains its opener after a clean weak-range closer',
    'ID: 123-45678/[62-16]-[03-6216-8041]',
    'ID: 123-45678/[62-16]-[[contact omitted]]'
  ],
  [
    'brace-wrapped later phone retains its opener after a clean weak-range closer',
    'ID: 123-45678/[62-16]-{03-6216-8041}',
    'ID: 123-45678/[62-16]-{[contact omitted]}'
  ],
  [
    'corner-wrapped later phone retains its opener after a clean weak-range closer',
    'ID: 123-45678/[62-16]-【03-6216-8041】',
    'ID: 123-45678/[62-16]-【[contact omitted]】'
  ],
  [
    'fullwidth square-wrapped later phone retains its exact source wrapper',
    'ＩＤ：１２３－４５６７８／［６２－１６］－［０３－６２１６－８０４１］',
    'ＩＤ：１２３－４５６７８／［６２－１６］－［[contact omitted]］'
  ],
  [
    'wrapped bare tail gains no telephone authority after a clean weak range',
    'ID: 123-45678/[62-16]-[12345678]',
    'ID: 123-45678/[62-16]-[12345678]'
  ],
  [
    'dirty weak-range suffix cannot borrow a later phone wrapper',
    'ID: 123-45678/[62-16-]-[03-6216-8041]',
    'ID: 123-45678/[62-16-]-[03-6216-8041]'
  ],
  [
    'mismatched weak-range closer cannot borrow a later phone wrapper',
    'ID: 123-45678/(62-16]-[03-6216-8041]',
    'ID: 123-45678/(62-16]-[03-6216-8041]'
  ],
  [
    'surplus weak-range closer cannot borrow a later phone wrapper',
    'ID: 123-45678/[62-16]]-[03-6216-8041]',
    'ID: 123-45678/[62-16]]-[03-6216-8041]'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    `${name}: the clean observation closer must stop before the external opener owned by the validated later phone`
  );
}

{
  const shrinkingPrefix = 'ｶﾞ'.repeat(20);
  const input = `https://example.test/${shrinkingPrefix}alice@example.com/03-6216-8041`;
  assert.equal(
    redactContactData(input),
    input,
    'embedded-email URL custody must compare approved-origin and email bounds in original source coordinates'
  );
}

assert.equal(
  redactContactData('alice@example.com=https://example.test/03-6216-8041'),
  '[contact omitted]=https://example.test/03-6216-8041',
  'an email before the indexed URL origin must not inherit suffix URL custody'
);

{
  const repetitions = 1000;
  const input = `https://example.test/${'a@b.com/'.repeat(repetitions)}03-6216-8041`;
  const originalNormalize = String.prototype.normalize;
  let normalizedCharacters = 0;
  let actual;
  try {
    String.prototype.normalize = function countedNormalize(form) {
      normalizedCharacters += String(this).length;
      return originalNormalize.call(this, form);
    };
    actual = redactContactData(input);
  } finally {
    String.prototype.normalize = originalNormalize;
  }
  assert.equal(
    actual,
    input,
    'every embedded email and numeric path inside one approved URL token must retain exact source bytes'
  );
  assert.ok(
    normalizedCharacters < input.length * 30,
    `embedded-email callbacks must reuse one token-boundary and origin index; normalized ${normalizedCharacters} characters for ${input.length} source characters`
  );
}

// PR2231 V129 malformed-scheme and whole-segment NFKC origin custody
for (const [name, input, expected] of [
  [
    'approved-looking interior scheme cannot be parsed as a bare-host TLD',
    'Phone: 03-6216-8041.https://example.test/03-6216-8041',
    'Phone: [contact omitted].https://example.test/[contact omitted]'
  ],
  [
    'unsupported interior scheme cannot be parsed as a bare-host TLD',
    'Phone: 03-6216-8041.mailto://example.test/03-6216-8041',
    'Phone: [contact omitted].mailto://example.test/[contact omitted]'
  ],
  [
    'bare-domain port custody remains approved',
    'example.test:443/03-6216-8041',
    'example.test:443/03-6216-8041'
  ],
  [
    'IPv4 port custody remains approved',
    '192.0.2.1:443/03-6216-8041',
    '192.0.2.1:443/03-6216-8041'
  ],
  [
    'bare-domain pseudo-scheme cannot retain a numeric path',
    'example.test://03-6216-8041',
    'example.test://[contact omitted]'
  ],
  [
    'IPv4 pseudo-scheme cannot retain a numeric path',
    '192.0.2.1://03-6216-8041',
    '192.0.2.1://[contact omitted]'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    `${name}: only an approved URL origin or a numeric host port may acquire URL custody`
  );
}

for (const [name, contraction] of [
  ['halfwidth katakana voiced pair', 'ｶﾞ'],
  ['Kannada vowel-sign pair', '\u0CC6\u0CD5']
]) {
  const prefix = contraction.repeat(15);
  const input = `${prefix}:03-6216-8041=https://example.test/03-6216-8041`;
  assert.equal(
    redactContactData(input),
    `${prefix}:[contact omitted]=https://example.test/03-6216-8041`,
    `${name}: whole-segment NFKC mapping must not move a later URL origin backward across a phone`
  );
}
'''
if 'PR2231 V129 later-phone opener custody' in tests:
    raise SystemExit('V129 tests already present')
test.write_text(tests + append)
PY

python3 "$out/apply-v129.py" "$work/product/$library_path" "$work/product/$test_path"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2

cp "$work/product/$library_path" "$out/v129-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v129-industrial-exhaust.test.js"
sha256sum "$out/v129-industrial-exhaust.mjs" "$out/v129-industrial-exhaust.test.js" \
  > "$out/v129-file-sha256.txt"
printf 'library_blob=%s\ntest_blob=%s\n' \
  "$(git hash-object "$out/v129-industrial-exhaust.mjs")" \
  "$(git hash-object "$out/v129-industrial-exhaust.test.js")" \
  > "$out/v129-file-blobs.txt"
git -C "$work/product" diff --numstat > "$out/v129-numstat.txt"
git -C "$work/product" diff -- "$library_path" "$test_path" > "$out/v129.patch"

node "$out/v129-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/successor-direct.json"

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

run_focused "$work/product" repaired-product
run_release "$work/product" repaired-product

# Restore generated state while retaining only the exact candidate files.
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v129-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

cp "$out/v129-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/transplant/$test_path"
run_focused "$work/transplant" frozen-main-transplant
run_release "$work/transplant" frozen-main-transplant

git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v129-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v129-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

# Construct one deterministic unpushed direct-child candidate over the frozen main lease.
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_message=$'fix: bind V129 source-indexed contact custody\n\nPreserve V128 wrapper and embedded-email controls, reject malformed scheme syntax after bare-host matches, and map approved URL origins through grapheme-segment NFKC source coordinates.'
candidate_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-02T21:10:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-02T21:10:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$(git hash-object "$out/v129-industrial-exhaust.mjs")
test_blob=$(git hash-object "$out/v129-industrial-exhaust.test.js")
EOF
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree" candidate-tree
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count

git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" \
  > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"

snapshot_state after
for item in product-pr controller-pr main-ref product-ref review-comments reviews issue-comments; do
  cmp "$out/$item.before.${item#*-}" "$out/$item.after.${item#*-}" 2>/dev/null || true
done
# Explicit comparisons avoid filename-extension ambiguity in the compact loop above.
cmp "$out/product-pr.before.json" "$out/product-pr.after.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.after.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.after.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"

cat > "$out/qualification-terminal.txt" <<EOF
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
EOF
cat "$out/qualification-terminal.txt"
