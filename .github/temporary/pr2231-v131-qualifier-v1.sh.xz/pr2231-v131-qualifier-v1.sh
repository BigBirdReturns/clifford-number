#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=c3c1e291344f21822de97ebfda0ded2bbfd012d6
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_tree=971780945a5b026674d52ca9b1e48dc8b463b546
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=0a0674a40c1cfaaf329cb9efb473fefa9dacfce8
test_blob=74ea9cb67fe3223fe3aab31b42368df0fa7e3f4e
library_sha256=b846d476b0c83fa814fa1c71bc297710345f9ddeaa28e21e61bd0f96ac80b882
test_sha256=06cd363f2394087944c35e697db4cbc4f004e944b0ebc4548d1aab0fdf5d64d0
successor_library_blob=2a28f2a9104fdf339707ef09442f5f6580e5e038
successor_test_blob=00307b33b09e72ce249f696b0a48e946245f6036
successor_library_sha256=fbdfeb55189bb6c3073b23986eaab1288cb7a1b39631296ccd53ba3d55dbf575
successor_test_sha256=eef68a4494f5e3c8ae141143a3e447424a2bb144cd7ebcf593a8479f8bba800e
patch_blob=a1b0f675294882c33d8501193c1e34b746eb3194
patch_size=8695
patch_sha256=038cdfc8d067cfba7799dbe3d8980004ff588b848a95c47f287dcb9e61cfb5ff
review_comment=3919169446
review_commit=b771c928c33cf5cefa605531f6c9e249b4b20606
review_original_commit=b771c928c33cf5cefa605531f6c9e249b4b20606
review_body_sha256=73ca729abbebf3d827563f19ad5ee635afc70a3844d859319f974635efd465de

out=/tmp/pr2231-v131-phone-label-bare-host-qualification-v1
work=/tmp/pr2231-v131-phone-label-bare-host-work-v1
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec >> "$out/qualification.log" 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=read-only-v131-phone-label-bare-host-qualification-r1\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

phase=bootstrap
record_phase() {
  phase=$1
  printf '%s\n' "$phase" > "$out/phase.txt"
}

record_failure() {
  rc=$?
  trap - ERR
  set +e
  printf '%s\n' "${BASH_COMMAND:-}" > "$out/failure-command.txt"
  {
    printf 'exit_status=%s\n' "$rc"
    printf 'phase=%s\n' "$phase"
    printf 'line=%s\n' "${BASH_LINENO[0]:-unknown}"
    printf 'command_sha256=%s\n' "$(printf '%s' "${BASH_COMMAND:-}" | sha256sum | awk '{print $1}')"
  } > "$out/failure.env"
  exit "$rc"
}
trap record_failure ERR

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    {
      printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual"
    } | tee "$out/lease-mismatch.txt" >&2
    return 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,commit_id,original_commit_id,path,line,original_line,start_line,side,in_reply_to_id,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
}

record_phase controller-leases
require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

record_phase protected-state-snapshot
snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$main_sha" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count

require_equal "$(jq -r '.changed_files' "$out/controller-pr.before.json")" 2 controller-file-count

record_phase product-object-leases
gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit.json")" 1 product-parent-count

record_phase review-receipt-lease
gh api "repos/$repo/pulls/comments/$review_comment" > "$out/review-$review_comment.json"
require_equal "$(jq -r '.commit_id' "$out/review-$review_comment.json")" "$review_commit" review-commit
require_equal "$(jq -r '.original_commit_id' "$out/review-$review_comment.json")" "$review_original_commit" review-original-commit
require_equal "$(jq -r '.path' "$out/review-$review_comment.json")" "$library_path" review-path
review_body_actual_sha256=$(jq -j '.body' "$out/review-$review_comment.json" | sha256sum | awk '{print $1}')
require_equal "$review_body_actual_sha256" "$review_body_sha256" review-body-sha256
printf '%s\n' "$review_body_actual_sha256" > "$out/review-body-sha256.txt"

# Materialize the exact live V130 product over its exact main parent without
# fetching or moving the protected product ref.
record_phase materialize-v130
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v130-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v130-industrial-exhaust.test.js"

cat > "$out/v131-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const repaired = [
  [
    'Phone: 03-6216-8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 0362168041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 03.6216.8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 020.7946.0958.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 03-6216-8041.2026.example.test/03-6216-8041',
    'Phone: [contact omitted].2026.example.test/03-6216-8041'
  ],
  [
    'Phone: 03-6216-8041.example.test:443/03-6216-8041',
    'Phone: [contact omitted].example.test:443/03-6216-8041'
  ],
  [
    '電話番号：０３－６２１６－８０４１．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１',
    '電話番号：[contact omitted]．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１'
  ]
];

const preserved = [
  '03-6216-8041.example.test/03-6216-8041',
  'ID: 03-6216-8041.example.test/03-6216-8041',
  'Phone: 192.0.2.1/03-6216-8041',
  'Phone: https://example.test/03-6216-8041',
  'Phone: //example.test/03-6216-8041',
  'Phone: 2026-08-17.example.test/03-6216-8041',
  'example.test/path/bogus://x/03-6216-8041',
  'www.example.test/path/mailto://x/03-6216-8041',
  '192.0.2.1/path/ftp://x/03-6216-8041',
  '//example.test/path/bogus://x/03-6216-8041'
];

const refusals = [
  ['Phone: 03-6216-8041.example.test', 'Phone: [contact omitted].example.test'],
  ['example.test://03-6216-8041', 'example.test://[contact omitted]'],
  ['192.0.2.1://03-6216-8041', '192.0.2.1://[contact omitted]'],
  ['Phone: 03-6216-8041.https://example.test/03-6216-8041', 'Phone: [contact omitted].https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.mailto://example.test/03-6216-8041', 'Phone: [contact omitted].mailto://example.test/[contact omitted]'],
  ['mailto://example.test/03-6216-8041=https://example.test/03-6216-8041', 'mailto://example.test/[contact omitted]=https://example.test/[contact omitted]']
];

if (mode === 'predecessor') {
  for (const [input] of repaired) assert.equal(redactContactData(input), input);
  for (const input of preserved) assert.equal(redactContactData(input), input);
  for (const [input, expected] of refusals) assert.equal(redactContactData(input), expected);
  console.log(JSON.stringify({ mode, reproducedFailures: repaired.length }, null, 2));
  process.exit(0);
}

for (const [input, expected] of repaired) assert.equal(redactContactData(input), expected);
for (const input of preserved) assert.equal(redactContactData(input), input);
for (const [input, expected] of refusals) assert.equal(redactContactData(input), expected);

const scaleInput = `Phone: 03-6216-8041.example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const scaleExpected = `Phone: [contact omitted].example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const originalNormalize = String.prototype.normalize;
let normalizedCharacters = 0;
let actual;
try {
  String.prototype.normalize = function countedNormalize(form) {
    normalizedCharacters += String(this).length;
    return originalNormalize.call(this, form);
  };
  actual = redactContactData(scaleInput);
} finally {
  String.prototype.normalize = originalNormalize;
}
assert.equal(actual, scaleExpected);
assert.ok(
  normalizedCharacters < scaleInput.length * 25,
  `label-precedence classification must remain bounded; normalized ${normalizedCharacters} chars for ${scaleInput.length} source chars`
);

const fanoutInput = `Phone: ${'1.'.repeat(1000)}example.test/path/03-6216-8041`;
let fanoutNormalizedCharacters = 0;
try {
  String.prototype.normalize = function countedNormalize(form) {
    fanoutNormalizedCharacters += String(this).length;
    return originalNormalize.call(this, form);
  };
  actual = redactContactData(fanoutInput);
} finally {
  String.prototype.normalize = originalNormalize;
}
assert.equal(
  actual,
  fanoutInput,
  'numeric-label fanout beyond the telephone group denominator must fail closed'
);
assert.ok(
  fanoutNormalizedCharacters < fanoutInput.length * 8,
  `numeric-label fanout must retain bounded normalization work; normalized ${fanoutNormalizedCharacters} chars for ${fanoutInput.length} source chars`
);

console.log(JSON.stringify({
  mode,
  repairedTransitions: repaired.length,
  preservedControls: preserved.length,
  retainedRefusals: refusals.length,
  scaleInputLength: scaleInput.length,
  normalizedCharacters,
  fanoutInputLength: fanoutInput.length,
  fanoutNormalizedCharacters
}, null, 2));
NODE

record_phase reproduce-v130
node "$out/v131-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

cat > "$out/v131.patch" <<'PATCH_V131'
diff --git a/test/industrial-exhaust.test.js b/test/industrial-exhaust.test.js
index 74ea9cb..00307b3 100644
--- a/test/industrial-exhaust.test.js
+++ b/test/industrial-exhaust.test.js
@@ -5847,3 +5847,87 @@ for (const [name, input, expected] of [
     `${name}: quote wrappers may carry an approved HTTP origin only from an established source delimiter`
   );
 }
+
+// PR2231 V131 explicit phone-label precedence over ambiguous bare-host prefixes
+for (const [name, input, expected] of [
+  [
+    'hyphenated labelled phone defeats a bare-host interpretation at the indexed origin',
+    'Phone: 03-6216-8041.example.test/03-6216-8041',
+    'Phone: [contact omitted].example.test/03-6216-8041'
+  ],
+  [
+    'compact labelled phone defeats a bare-host interpretation at the indexed origin',
+    'Phone: 0362168041.example.test/03-6216-8041',
+    'Phone: [contact omitted].example.test/03-6216-8041'
+  ],
+  [
+    'dotted labelled phone defeats the complete phone-shaped host prefix',
+    'Phone: 03.6216.8041.example.test/03-6216-8041',
+    'Phone: [contact omitted].example.test/03-6216-8041'
+  ],
+  [
+    'dotted UK phone retains the domain suffix after its exact interval',
+    'Phone: 020.7946.0958.example.test/03-6216-8041',
+    'Phone: [contact omitted].example.test/03-6216-8041'
+  ],
+  [
+    'numeric subdomain remains protected after the exact labelled phone interval',
+    'Phone: 03-6216-8041.2026.example.test/03-6216-8041',
+    'Phone: [contact omitted].2026.example.test/03-6216-8041'
+  ],
+  [
+    'bare-host port and path custody resumes after the labelled phone interval',
+    'Phone: 03-6216-8041.example.test:443/03-6216-8041',
+    'Phone: [contact omitted].example.test:443/03-6216-8041'
+  ],
+  [
+    'fullwidth labelled phone retains source-exact domain and path custody',
+    '電話番号：０３－６２１６－８０４１．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１',
+    '電話番号：[contact omitted]．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１'
+  ]
+]) {
+  assert.equal(
+    redactContactData(input),
+    expected,
+    `${name}: explicit telephone-label provenance owns only the exact leading telephone interval`
+  );
+}
+
+for (const [name, input] of [
+  [
+    'unlabelled genuine bare host retains complete URL custody',
+    '03-6216-8041.example.test/03-6216-8041'
+  ],
+  [
+    'identifier-labelled genuine bare host retains complete URL custody',
+    'ID: 03-6216-8041.example.test/03-6216-8041'
+  ],
+  [
+    'telephone label cannot revoke an IPv4 origin with no domain suffix',
+    'Phone: 192.0.2.1/03-6216-8041'
+  ],
+  [
+    'telephone label cannot revoke an absolute HTTPS origin',
+    'Phone: https://example.test/03-6216-8041'
+  ],
+  [
+    'telephone label cannot revoke a scheme-relative origin',
+    'Phone: //example.test/03-6216-8041'
+  ],
+  [
+    'telephone label cannot convert a complete calendar date into a phone',
+    'Phone: 2026-08-17.example.test/03-6216-8041'
+  ]
+]) {
+  assert.equal(
+    redactContactData(input),
+    input,
+    `${name}: only one exact phone interval at an ambiguous bare-host prefix may override URL custody`
+  );
+}
+
+assert.equal(
+  redactContactData('Phone: 03-6216-8041.example.test'),
+  'Phone: [contact omitted].example.test',
+  'host-only phone-shaped text must retain the established refusal without manufacturing URL custody'
+);
diff --git a/tools/lib/industrial-exhaust.mjs b/tools/lib/industrial-exhaust.mjs
index 0a0674a..2a28f2a 100644
--- a/tools/lib/industrial-exhaust.mjs
+++ b/tools/lib/industrial-exhaust.mjs
@@ -1550,7 +1550,77 @@ function identifierContextNeedsExpansion(normalizedPrefix) {
     && (identifierChain.overflow || identifierChain.start <= 48);
 }
 
-function redactionPrefixContext(input, offset, tokenBoundaryIndex = null) {
+function approvedBareHostPhonePrefixEnd(
+  input,
+  candidateStart,
+  candidateEnd,
+  tokenBoundaryIndex
+) {
+  if (!tokenBoundaryIndex) return -1;
+  const boundedStart = Math.max(0, Math.min(input.length, candidateStart));
+  const boundedEnd = Math.max(boundedStart, Math.min(input.length, candidateEnd));
+  if (boundedEnd <= boundedStart || boundedStart >= input.length) return -1;
+
+  const tokenStart = tokenBoundaryIndex.start(boundedStart + 1);
+  if (tokenBoundaryIndex.urlStateAt(tokenStart, boundedStart) !== 1
+      || tokenBoundaryIndex.urlOriginStart(tokenStart) !== boundedStart) {
+    return -1;
+  }
+
+  const tokenEnd = tokenBoundaryIndex.end(boundedStart);
+  if (boundedEnd >= tokenEnd) return -1;
+
+  // Select the earliest exact telephone interval whose following dot begins a
+  // separately valid bare-host suffix. Examine at most the established maximum
+  // telephone group count, so a numeric-label fanout cannot turn suffix checks
+  // into an unbounded rescan of the containing token.
+  const candidateSource = input.slice(boundedStart, boundedEnd);
+  if (candidateSource.length > MAX_NUMERIC_OBSERVATION_SOURCE_CHARS) return -1;
+
+  const groups = [];
+  for (const group of candidateSource.matchAll(DIGIT_RUN_PATTERN)) {
+    // A telephone interval cannot exceed the existing bounded group ceiling.
+    // Refuse the ambiguous override before any suffix or scoring work when the
+    // candidate itself exceeds that denominator.
+    if (groups.length >= MAX_PHONE_DIGIT_GROUPS) return -1;
+    groups.push(group);
+  }
+  for (const group of groups) {
+    const prefixEnd = boundedStart + group.index + group[0].length;
+    if (prefixEnd >= tokenEnd) break;
+    const delimiter = String.fromCodePoint(input.codePointAt(prefixEnd));
+    if (delimiter.normalize('NFKC') !== '.') continue;
+
+    const suffix = input
+      .slice(prefixEnd + delimiter.length, tokenEnd)
+      .normalize('NFKC');
+    if (!DIRECT_URL_HOST_ORIGIN_PATTERN.test(suffix)) continue;
+
+    const phoneSource = input.slice(boundedStart, prefixEnd);
+    const ranges = phoneRedactionRanges(
+      phoneSource,
+      '',
+      '',
+      true,
+      true,
+      true,
+      false
+    );
+    if (ranges.length === 1
+        && ranges[0].start === 0
+        && ranges[0].end === phoneSource.length) {
+      return prefixEnd;
+    }
+  }
+  return -1;
+}
+
+function redactionPrefixContext(
+  input,
+  offset,
+  tokenBoundaryIndex = null,
+  inspectExplicitPhoneLabelAtUrlOrigin = false
+) {
   const boundedOffset = Math.max(0, Math.min(input.length, offset));
   const boundedStart = Math.max(0, boundedOffset - 64);
   const boundedTokenStart = nonWhitespaceTokenStart(
@@ -1574,7 +1644,8 @@ function redactionPrefixContext(input, offset, tokenBoundaryIndex = null) {
   // Direct URL custody is a source-index decision. Once the containing token is
   // approved, callback-local classification consumes that state without
   // reopening the complete growing token as textual prefix evidence.
-  if (contactUrlTokenState === 1) {
+  if (contactUrlTokenState === 1
+      && !inspectExplicitPhoneLabelAtUrlOrigin) {
     return {
       text: input.slice(boundedStart, boundedOffset),
       indeterminate: false,
@@ -4494,11 +4565,19 @@ function redactPhoneSpanCandidate(
 ) {
   const firstContactCharacter = candidate.search(/[+＋(（0-9０-９]/u);
   const contactOffset = offset + Math.max(0, firstContactCharacter);
-  const prefixContext = redactionPrefixContext(
+  const candidateEnd = offset + candidate.length;
+  const bareHostPhonePrefixEnd = approvedBareHostPhonePrefixEnd(
     input,
     contactOffset,
+    candidateEnd,
     tokenBoundaryIndex
   );
+  const prefixContext = redactionPrefixContext(
+    input,
+    contactOffset,
+    tokenBoundaryIndex,
+    bareHostPhonePrefixEnd >= 0
+  );
   const prefix = prefixContext.text;
   const suffix = input.slice(offset + candidate.length, offset + candidate.length + 64);
   const adjacentCharacter = previousCodePoint(input, contactOffset);
@@ -4552,6 +4631,24 @@ function redactPhoneSpanCandidate(
     };
   }
 
+  const explicitPhoneLabelOverridesBareHost = bareHostPhonePrefixEnd >= 0
+    && directExplicitPhoneLabelContext;
+  if (explicitPhoneLabelOverridesBareHost) {
+    const localPhoneStart = contactOffset - offset;
+    const localPhoneEnd = bareHostPhonePrefixEnd - offset;
+    const exactRange = {
+      start: localPhoneStart,
+      end: localPhoneEnd
+    };
+    return {
+      output: `${candidate.slice(
+        0,
+        exactRange.start
+      )}[contact omitted]${candidate.slice(exactRange.end)}`,
+      ranges: [exactRange],
+      explicitPhoneLabelContext: true
+    };
+  }
   if (prefixContext.urlTokenState === 1) {
     return {
       output: candidate,
PATCH_V131

record_phase apply-v131
require_equal "$(wc -c < "$out/v131.patch")" "$patch_size" patch-size
require_equal "$(git hash-object "$out/v131.patch")" "$patch_blob" patch-blob
require_equal "$(sha256sum "$out/v131.patch" | awk '{print $1}')" "$patch_sha256" patch-sha256
git -C "$work/product" apply --check "$out/v131.patch"
git -C "$work/product" apply "$out/v131.patch"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2

require_equal "$(git hash-object "$work/product/$library_path")" "$successor_library_blob" successor-library-blob
require_equal "$(git hash-object "$work/product/$test_path")" "$successor_test_blob" successor-test-blob
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$successor_library_sha256" successor-library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$successor_test_sha256" successor-test-sha256

cp "$work/product/$library_path" "$out/v131-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v131-industrial-exhaust.test.js"
sha256sum "$out/v131-industrial-exhaust.mjs" "$out/v131-industrial-exhaust.test.js" \
  > "$out/v131-file-sha256.txt"
printf 'library_blob=%s\ntest_blob=%s\n' \
  "$(git hash-object "$out/v131-industrial-exhaust.mjs")" \
  "$(git hash-object "$out/v131-industrial-exhaust.test.js")" \
  > "$out/v131-file-blobs.txt"
git -C "$work/product" diff --numstat > "$out/v131-numstat.txt"

record_phase direct-v131
node "$out/v131-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/successor-direct.json"

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

record_phase repaired-product-focused
run_focused "$work/product" repaired-product
record_phase repaired-product-release
run_release "$work/product" repaired-product

# Restore generated state while retaining only the exact candidate files.
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v131-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

cp "$out/v131-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/transplant/$test_path"
record_phase frozen-main-focused
run_focused "$work/transplant" frozen-main-transplant
record_phase frozen-main-release
run_release "$work/transplant" frozen-main-transplant

git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v131-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

# Construct one deterministic, unpushed, direct child of frozen main.
record_phase candidate-construction
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_message=$'fix: let explicit phone labels split ambiguous bare hosts\n\nAllow one exact labelled telephone interval at an indexed phone-shaped bare-host origin, then resume URL custody from the source-exact suffix while retaining genuine-host and bounded-work refusals.'
candidate_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-03T00:30:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-03T00:30:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$(git hash-object "$out/v131-industrial-exhaust.mjs")
test_blob=$(git hash-object "$out/v131-industrial-exhaust.test.js")
EOF
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree" candidate-tree
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count
git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"

record_phase protected-state-recheck
snapshot_state after
cmp "$out/product-pr.before.json" "$out/product-pr.after.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.after.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.after.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"

record_phase terminal-ledger
cat > "$out/qualification-terminal.txt" <<EOF
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
EOF
cat "$out/qualification-terminal.txt"
