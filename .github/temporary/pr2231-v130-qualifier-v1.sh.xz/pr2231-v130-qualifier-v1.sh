#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=b771c928c33cf5cefa605531f6c9e249b4b20606
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_tree=5316a5a8be2a11b9aac39d9f9ee53ba5ec58d3f8
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=1c33608daa7d00b8a7935a5afc40e37a280ac073
test_blob=0e148a88fc4787152a841303072bbfc2997e4b07
library_sha256=3653b44e8df1d07097eb861c92a1a8553bcae73344e6bdeb8ab1072cd6992450
test_sha256=33d42400663eb6a423a55d076675196999b490dd71841f97bbfce4ad663de2ec
successor_library_blob=0a0674a40c1cfaaf329cb9efb473fefa9dacfce8
successor_test_blob=74ea9cb67fe3223fe3aab31b42368df0fa7e3f4e
successor_library_sha256=b846d476b0c83fa814fa1c71bc297710345f9ddeaa28e21e61bd0f96ac80b882
successor_test_sha256=06cd363f2394087944c35e697db4cbc4f004e944b0ebc4548d1aab0fdf5d64d0
review_comment=3919199904
review_original_commit=bd1523d86a562be91acdc175f73607dab0fcac09
review_body_sha256=0bf0dd63bbdab28398400dc787b482c014a569dac65b600f9b8abfb800be44d0

out=/tmp/pr2231-v130-earliest-origin-qualification-v3
work=/tmp/pr2231-v130-earliest-origin-work-v3
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec >> "$out/qualification.log" 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=read-only-v130-earliest-origin-qualification-r3\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

phase=bootstrap
record_phase() {
  phase=$1
  printf '%s\n' "$phase" > "$out/phase.txt"
}

record_failure() {
  rc=$?
  trap - ERR
  set +e
  printf '%s\n' "${BASH_COMMAND:-}" > "$out/failure-command.txt"
  {
    printf 'exit_status=%s\n' "$rc"
    printf 'phase=%s\n' "$phase"
    printf 'line=%s\n' "${BASH_LINENO[0]:-unknown}"
    printf 'command_sha256=%s\n' "$(printf '%s' "${BASH_COMMAND:-}" | sha256sum | awk '{print $1}')"
  } > "$out/failure.env"
  exit "$rc"
}
trap record_failure ERR

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    {
      printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual"
    } | tee "$out/lease-mismatch.txt" >&2
    return 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,commit_id,original_commit_id,path,line,original_line,start_line,side,in_reply_to_id,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
}

record_phase controller-leases
require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

record_phase protected-state-snapshot
snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$main_sha" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count

require_equal "$(jq -r '.changed_files' "$out/controller-pr.before.json")" 2 controller-file-count

record_phase product-object-leases
gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit.json")" 1 product-parent-count

record_phase review-receipt-lease
gh api "repos/$repo/pulls/comments/$review_comment" > "$out/review-$review_comment.json"
require_equal "$(jq -r '.commit_id' "$out/review-$review_comment.json")" "$product_head" review-commit
require_equal "$(jq -r '.original_commit_id' "$out/review-$review_comment.json")" "$review_original_commit" review-original-commit
require_equal "$(jq -r '.path' "$out/review-$review_comment.json")" "$library_path" review-path
review_body_actual_sha256=$(jq -j '.body' "$out/review-$review_comment.json" | sha256sum | awk '{print $1}')
require_equal "$review_body_actual_sha256" "$review_body_sha256" review-body-sha256
printf '%s\n' "$review_body_actual_sha256" > "$out/review-body-sha256.txt"

# Materialize the exact live V129 product over its exact main parent without
# fetching or moving the protected product ref.
record_phase materialize-v129
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v129-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v129-industrial-exhaust.test.js"

cat > "$out/v130-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const repaired = [
  ['example.test/path/bogus://x/03-6216-8041', 'example.test/path/bogus://x/03-6216-8041'],
  ['www.example.test/path/mailto://x/03-6216-8041', 'www.example.test/path/mailto://x/03-6216-8041'],
  ['192.0.2.1/path/ftp://x/03-6216-8041', '192.0.2.1/path/ftp://x/03-6216-8041'],
  ['//example.test/path/bogus://x/03-6216-8041', '//example.test/path/bogus://x/03-6216-8041'],
  ['URL:example.test/path/bogus://x/03-6216-8041', 'URL:example.test/path/bogus://x/03-6216-8041'],
  ['URL:"example.test/path/bogus://x/03-6216-8041', 'URL:"example.test/path/bogus://x/03-6216-8041'],
  ['example.test.:443/path/bogus://x/03-6216-8041', 'example.test.:443/path/bogus://x/03-6216-8041'],
  ['[example.test/path/bogus://x/03-6216-8041]', '[example.test/path/bogus://x/03-6216-8041]'],
  ['ｅｘａｍｐｌｅ．ｔｅｓｔ／path／bogus：／／x／０３－６２１６－８０４１', 'ｅｘａｍｐｌｅ．ｔｅｓｔ／path／bogus：／／x／０３－６２１６－８０４１']
];

const refusals = [
  ['example.test://03-6216-8041', 'example.test://[contact omitted]'],
  ['192.0.2.1://03-6216-8041', '192.0.2.1://[contact omitted]'],
  ['Phone: 03-6216-8041.https://example.test/03-6216-8041', 'Phone: [contact omitted].https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.mailto://example.test/03-6216-8041', 'Phone: [contact omitted].mailto://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.example.test', 'Phone: [contact omitted].example.test'],
  ['mailto://example.test/03-6216-8041=https://example.test/03-6216-8041', 'mailto://example.test/[contact omitted]=https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041=https://example.test/03-6216-8041', 'Phone: [contact omitted]=https://example.test/03-6216-8041'],
  ['Phone: 03-6216-8041;//03-6216-8041', 'Phone: [contact omitted];//03-6216-8041'],
  ['example.test:443/03-6216-8041', 'example.test:443/03-6216-8041'],
  ['192.0.2.1:443/03-6216-8041', '192.0.2.1:443/03-6216-8041']
];

const predecessorOutputs = [
  'example.test/path/bogus://x/[contact omitted]',
  'www.example.test/path/mailto://x/[contact omitted]',
  '192.0.2.1/path/ftp://x/[contact omitted]',
  '//example.test/path/bogus://x/[contact omitted]',
  'URL:example.test/path/bogus://x/[contact omitted]'
];

const countNormalizeWork = input => {
  const originalNormalize = String.prototype.normalize;
  let normalizedCharacters = 0;
  let actual;
  try {
    String.prototype.normalize = function countedNormalize(form) {
      normalizedCharacters += String(this).length;
      return originalNormalize.call(this, form);
    };
    actual = redactContactData(input);
  } finally {
    String.prototype.normalize = originalNormalize;
  }
  return { actual, normalizedCharacters };
};

if (mode === 'predecessor') {
  for (let index = 0; index < predecessorOutputs.length; index += 1) {
    assert.equal(redactContactData(repaired[index][0]), predecessorOutputs[index]);
  }
  for (const [input, expected] of refusals) assert.equal(redactContactData(input), expected);
  console.log(JSON.stringify({
    mode,
    reproducedFailures: predecessorOutputs.length,
    outputs: predecessorOutputs
  }, null, 2));
  process.exit(0);
}

for (const [input, expected] of [...repaired, ...refusals]) {
  assert.equal(redactContactData(input), expected);
}
const scaleInput = `example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const scale = countNormalizeWork(scaleInput);
assert.equal(scale.actual, scaleInput);
assert.ok(
  scale.normalizedCharacters < scaleInput.length * 20,
  `earliest-origin classification must stay bounded; normalized ${scale.normalizedCharacters} chars for ${scaleInput.length} source chars`
);
console.log(JSON.stringify({
  mode,
  repairedTransitions: repaired.length,
  retainedRefusals: refusals.length,
  scaleInputLength: scaleInput.length,
  normalizedCharacters: scale.normalizedCharacters
}, null, 2));
NODE

record_phase reproduce-v129
node "$out/v130-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

cat > "$out/v130.patch" <<'PATCH_V130'
diff --git a/test/industrial-exhaust.test.js b/test/industrial-exhaust.test.js
index 0e148a8..74ea9cb 100644
--- a/test/industrial-exhaust.test.js
+++ b/test/industrial-exhaust.test.js
@@ -5703,6 +5703,112 @@ for (const [name, input, expected] of [
   );
 }
 
+// PR2231 V130 earliest complete URL-origin precedence
+for (const [name, input] of [
+  [
+    'bare-domain origin outranks a later unsupported-looking path substring',
+    'example.test/path/bogus://x/03-6216-8041'
+  ],
+  [
+    'www origin outranks a later unsupported-looking path substring',
+    'www.example.test/path/mailto://x/03-6216-8041'
+  ],
+  [
+    'IPv4 origin outranks a later unsupported-looking path substring',
+    '192.0.2.1/path/ftp://x/03-6216-8041'
+  ],
+  [
+    'boundary-anchored scheme-relative origin outranks later path syntax',
+    '//example.test/path/bogus://x/03-6216-8041'
+  ],
+  [
+    'legacy URL introducer retains the earlier bare-host origin',
+    'URL:example.test/path/bogus://x/03-6216-8041'
+  ],
+  [
+    'quoted legacy URL introducer retains the earlier bare-host origin',
+    'URL:"example.test/path/bogus://x/03-6216-8041'
+  ],
+  [
+    'root-dot and numeric-port origin outranks later path syntax',
+    'example.test.:443/path/bogus://x/03-6216-8041'
+  ],
+  [
+    'wrapped approved origin retains exact source bytes',
+    '[example.test/path/bogus://x/03-6216-8041]'
+  ],
+  [
+    'fullwidth approved origin retains exact source bytes',
+    'ｅｘａｍｐｌｅ．ｔｅｓｔ／path／bogus：／／x／０３－６２１６－８０４１'
+  ]
+]) {
+  assert.equal(
+    redactContactData(input),
+    input,
+    `${name}: later path text cannot revoke URL custody established at the earliest complete origin`
+  );
+}
+
+for (const [name, input, expected] of [
+  [
+    'host pseudo-scheme remains unsupported',
+    'example.test://03-6216-8041',
+    'example.test://[contact omitted]'
+  ],
+  [
+    'IPv4 pseudo-scheme remains unsupported',
+    '192.0.2.1://03-6216-8041',
+    '192.0.2.1://[contact omitted]'
+  ],
+  [
+    'interior approved-looking scheme remains unsupported before any valid origin',
+    'Phone: 03-6216-8041.https://example.test/03-6216-8041',
+    'Phone: [contact omitted].https://example.test/[contact omitted]'
+  ],
+  [
+    'host-only phone-shaped prefix does not acquire new URL custody',
+    'Phone: 03-6216-8041.example.test',
+    'Phone: [contact omitted].example.test'
+  ],
+  [
+    'earlier unsupported scheme outranks a later approved origin',
+    'mailto://example.test/03-6216-8041=https://example.test/03-6216-8041',
+    'mailto://example.test/[contact omitted]=https://example.test/[contact omitted]'
+  ]
+]) {
+  assert.equal(
+    redactContactData(input),
+    expected,
+    `${name}: unsupported syntax must still win when it begins before the first complete approved origin`
+  );
+}
+
+{
+  const repetitions = 1000;
+  const input = `example.test/path/${'bogus://x/'.repeat(repetitions)}03-6216-8041`;
+  const originalNormalize = String.prototype.normalize;
+  let normalizedCharacters = 0;
+  let actual;
+  try {
+    String.prototype.normalize = function countedNormalize(form) {
+      normalizedCharacters += String(this).length;
+      return originalNormalize.call(this, form);
+    };
+    actual = redactContactData(input);
+  } finally {
+    String.prototype.normalize = originalNormalize;
+  }
+  assert.equal(
+    actual,
+    input,
+    'an approved leading host must retain custody across every later path substring'
+  );
+  assert.ok(
+    normalizedCharacters < input.length * 20,
+    `earliest-origin classification must not reparse every later path delimiter; normalized ${normalizedCharacters} characters for ${input.length} source characters`
+  );
+}
+
 for (const [name, contraction] of [
   ['halfwidth katakana voiced pair', 'ｶﾞ'],
   ['Kannada vowel-sign pair', '\u0CC6\u0CD5']
diff --git a/tools/lib/industrial-exhaust.mjs b/tools/lib/industrial-exhaust.mjs
index 1c33608..0a0674a 100644
--- a/tools/lib/industrial-exhaust.mjs
+++ b/tools/lib/industrial-exhaust.mjs
@@ -164,8 +164,8 @@ const OBSERVATION_WRAPPER_CLOSERS = new Map(
   )
 );
 
-const DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN = /^(?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*$/iu;
-const LEGACY_DIRECT_URL_ORIGIN_PATTERN = /(?:^|[<([{=:;,|])(?:["'“”‘’]+)?((?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*|\/\/[^\s]*)/iu;
+const DIRECT_URL_HOST_ORIGIN_PATTERN = /^(?:(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})|(?:\d{1,3}\.){3}\d{1,3})\.?(?::\d{1,5}(?=$|[/?#])|(?=[/?#]))/iu;
+const LEGACY_APPROVED_URL_ORIGIN_PATTERN = /(?:^|[<([{=:;,|])(?:["'“”‘’]+)?((?:https?:\/\/|\/\/)[^\s]*|(?:(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})|(?:\d{1,3}\.){3}\d{1,3})\.?(?::\d{1,5}(?:[/?#][^\s]*)?|[/?#][^\s]*))$/iu;
 const LEGACY_UNSUPPORTED_URL_SCHEME_PATTERN = /(?:^|[<([{=:;,|])([\p{L}][\p{L}\p{N}+.-]*):\/\//iu;
 const LEGACY_URL_ORIGIN_DELIMITER_PATTERN = /[<([{=:;,|]/u;
 const LEGACY_URL_ORIGIN_QUOTE_WRAPPER_PATTERN = /["'“”‘’]/u;
@@ -212,23 +212,56 @@ function leadingUrlOriginStart(value) {
   return start;
 }
 
-function directUrlTokenOrigin(value) {
-  const normalized = String(value ?? '').normalize('NFKC');
-  const leadingOriginStart = leadingUrlOriginStart(normalized);
-  const leadingOrigin = normalized.slice(leadingOriginStart);
-  const leadingScheme = /^([\p{L}][\p{L}\p{N}+.-]*):\/\//iu.exec(
-    leadingOrigin
-  );
-  if (leadingScheme) {
-    const approved = /^https?$/iu.test(leadingScheme[1]);
+function directUrlOriginAt(value, start) {
+  const boundedStart = Math.min(Math.max(0, start), value.length);
+  const source = value.slice(boundedStart);
+  const scheme = /^([\p{L}][\p{L}\p{N}+.-]*):\/\//iu.exec(source);
+  if (scheme) {
+    const approved = /^https?$/iu.test(scheme[1]);
     return {
-      normalized,
-      originStart: leadingOriginStart,
+      originStart: boundedStart,
       approved,
       unsupported: !approved
     };
   }
+  if (/^\/\/[^\s]*$/u.test(source)
+      || DIRECT_URL_HOST_ORIGIN_PATTERN.test(source)) {
+    return {
+      originStart: boundedStart,
+      approved: true,
+      unsupported: false
+    };
+  }
+  return null;
+}
+
+function firstLegacyApprovedUrlOrigin(value) {
+  const match = LEGACY_APPROVED_URL_ORIGIN_PATTERN.exec(value);
+  if (!match) return null;
+  return {
+    originStart: match.index + match[0].length - match[1].length,
+    approved: true,
+    unsupported: false
+  };
+}
+
+function directUrlTokenOrigin(value) {
+  const normalized = String(value ?? '').normalize('NFKC');
+  const leadingOriginStart = leadingUrlOriginStart(normalized);
+  const leadingOrigin = directUrlOriginAt(normalized, leadingOriginStart);
+  if (leadingOrigin) return { normalized, ...leadingOrigin };
+
+  // Classify the earliest complete source origin. A valid bare host or
+  // scheme-relative origin cannot be revoked by later path text that happens
+  // to contain `<text>://`, while malformed syntax still wins when it begins
+  // before any independently approved legacy-position origin.
   const malformedSchemeLikeOrigin = malformedSchemeLikeUrlOrigin(normalized);
+  const legacyApprovedOrigin = firstLegacyApprovedUrlOrigin(normalized);
+  if (legacyApprovedOrigin
+      && (malformedSchemeLikeOrigin < 0
+        || legacyApprovedOrigin.originStart < malformedSchemeLikeOrigin)) {
+    return { normalized, ...legacyApprovedOrigin };
+  }
   if (malformedSchemeLikeOrigin >= 0) {
     return {
       normalized,
@@ -237,20 +270,7 @@ function directUrlTokenOrigin(value) {
       unsupported: true
     };
   }
-  if (DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN.test(leadingOrigin)
-      || /^\/\/[^\s]*$/u.test(leadingOrigin)) {
-    return {
-      normalized,
-      originStart: leadingOriginStart,
-      approved: true,
-      unsupported: false
-    };
-  }
 
-  // Preserve established introducers such as `URL:https://...` while keeping
-  // the token-leading wrapper parser authoritative for ordinary quoted and
-  // punctuated forms. An unsupported legacy-position scheme is classified
-  // before any later approved-looking suffix can acquire custody.
   const unsupported = LEGACY_UNSUPPORTED_URL_SCHEME_PATTERN.exec(normalized);
   if (unsupported && !/^https?$/iu.test(unsupported[1])) {
     return {
@@ -261,15 +281,6 @@ function directUrlTokenOrigin(value) {
       unsupported: true
     };
   }
-  const legacy = LEGACY_DIRECT_URL_ORIGIN_PATTERN.exec(normalized);
-  if (legacy) {
-    return {
-      normalized,
-      originStart: legacy.index + legacy[0].length - legacy[1].length,
-      approved: true,
-      unsupported: false
-    };
-  }
   return {
     normalized,
     originStart: -1,
PATCH_V130

record_phase apply-v130
git -C "$work/product" apply --check "$out/v130.patch"
git -C "$work/product" apply "$out/v130.patch"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2

require_equal "$(git hash-object "$work/product/$library_path")" "$successor_library_blob" successor-library-blob
require_equal "$(git hash-object "$work/product/$test_path")" "$successor_test_blob" successor-test-blob
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$successor_library_sha256" successor-library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$successor_test_sha256" successor-test-sha256

cp "$work/product/$library_path" "$out/v130-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v130-industrial-exhaust.test.js"
sha256sum "$out/v130-industrial-exhaust.mjs" "$out/v130-industrial-exhaust.test.js" \
  > "$out/v130-file-sha256.txt"
printf 'library_blob=%s\ntest_blob=%s\n' \
  "$(git hash-object "$out/v130-industrial-exhaust.mjs")" \
  "$(git hash-object "$out/v130-industrial-exhaust.test.js")" \
  > "$out/v130-file-blobs.txt"
git -C "$work/product" diff --numstat > "$out/v130-numstat.txt"

record_phase direct-v130
node "$out/v130-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/successor-direct.json"

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

record_phase repaired-product-focused
run_focused "$work/product" repaired-product
record_phase repaired-product-release
run_release "$work/product" repaired-product

# Restore generated state while retaining only the exact candidate files.
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v130-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

cp "$out/v130-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/transplant/$test_path"
record_phase frozen-main-focused
run_focused "$work/transplant" frozen-main-transplant
record_phase frozen-main-release
run_release "$work/transplant" frozen-main-transplant

git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v130-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

# Construct one deterministic, unpushed, direct child of frozen main.
record_phase candidate-construction
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_message=$'fix: bind V130 earliest URL-origin precedence\n\nPreserve the first complete approved source origin across later path syntax while retaining malformed host, unsupported-scheme, numeric-port, and candidate-relative URL refusals.'
candidate_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-02T22:30:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-02T22:30:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$(git hash-object "$out/v130-industrial-exhaust.mjs")
test_blob=$(git hash-object "$out/v130-industrial-exhaust.test.js")
EOF
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree" candidate-tree
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count
git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"

record_phase protected-state-recheck
snapshot_state after
cmp "$out/product-pr.before.json" "$out/product-pr.after.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.after.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.after.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"

record_phase terminal-ledger
cat > "$out/qualification-terminal.txt" <<EOF
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
EOF
cat "$out/qualification-terminal.txt"
