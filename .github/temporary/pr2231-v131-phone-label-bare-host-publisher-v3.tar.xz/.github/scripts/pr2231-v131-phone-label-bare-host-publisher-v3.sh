#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
repo_owner=BigBirdReturns
repo_name=clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
publisher_branch=agent/pr2231-v131-phone-label-bare-host-publisher-v3
qualifier_pr=2557
qualifier_branch=agent/pr2231-v131-phone-label-bare-host-qualification-v1
qualifier_controller=e5896aaf681233dd66d31af335e66c15af58bbc9
qualifier_controller_tree=fb758e5a0f12fd02009898f4701b7889794cf72f
qualifier_run=33700246537
qualifier_job=100477774771
qualifier_job_name=qualify-v131-phone-label-bare-host
qualifier_artifact=9873283138
qualifier_artifact_name=pr2231-v131-phone-label-bare-host-qualification-v1
qualifier_artifact_size=736632
qualifier_artifact_digest=sha256:85ee33a0e5bc9cf3a3d35044c6c241dd2734d7aab9ba17bcb4c3678e700d006b
qualifier_zip_sha256=85ee33a0e5bc9cf3a3d35044c6c241dd2734d7aab9ba17bcb4c3678e700d006b
qualifier_workflow=.github/workflows/temporary-pr2231-v131-qualification-v1.yml
qualifier_payload=.github/temporary/pr2231-v131-qualifier-v1.sh.xz

main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=c3c1e291344f21822de97ebfda0ded2bbfd012d6
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_tree=971780945a5b026674d52ca9b1e48dc8b463b546
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=0a0674a40c1cfaaf329cb9efb473fefa9dacfce8
test_blob=74ea9cb67fe3223fe3aab31b42368df0fa7e3f4e
library_sha256=b846d476b0c83fa814fa1c71bc297710345f9ddeaa28e21e61bd0f96ac80b882
test_sha256=06cd363f2394087944c35e697db4cbc4f004e944b0ebc4548d1aab0fdf5d64d0
successor_library_blob=2a28f2a9104fdf339707ef09442f5f6580e5e038
successor_test_blob=00307b33b09e72ce249f696b0a48e946245f6036
successor_library_sha256=fbdfeb55189bb6c3073b23986eaab1288cb7a1b39631296ccd53ba3d55dbf575
successor_test_sha256=eef68a4494f5e3c8ae141143a3e447424a2bb144cd7ebcf593a8479f8bba800e
patch_blob=a1b0f675294882c33d8501193c1e34b746eb3194
patch_size=8695
patch_sha256=038cdfc8d067cfba7799dbe3d8980004ff588b848a95c47f287dcb9e61cfb5ff
candidate_commit_expected=f4039261615fed4b0e595fc27e888587d516a56c
candidate_tree_expected=b12d5e5828a554ebb3d51cd812d95887d5d776c5
candidate_message=$'fix: let explicit phone labels split ambiguous bare hosts

Allow one exact labelled telephone interval at an indexed phone-shaped bare-host origin, then resume URL custody from the source-exact suffix while retaining genuine-host and bounded-work refusals.'
review_comment=3919169446
review_commit=b771c928c33cf5cefa605531f6c9e249b4b20606
review_original_commit=b771c928c33cf5cefa605531f6c9e249b4b20606
review_body_sha256=73ca729abbebf3d827563f19ad5ee635afc70a3844d859319f974635efd465de
review_thread_expected=PRRT_kwDOTGqftc6es6CQ

out=/tmp/pr2231-v131-phone-label-bare-host-publication-v3
work=/tmp/pr2231-v131-phone-label-bare-host-publisher-work-v3
qualifier_root="$work/qualifier-artifact"
qualifier_zip="$work/qualifier-artifact.zip"
qualifier_receipt="$qualifier_root/pr2231-v131-phone-label-bare-host-qualification-v1"
qualifier_controller_receipt="$qualifier_root/pr2231-v131-phone-label-bare-host-controller-v1"
patch_file=${V131_PATCH_FILE:?V131_PATCH_FILE is required}
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec >> "$out/publication.log" 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s
mode=exact-leased-replay-publish-v131-v3
' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P	%s
' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

phase=bootstrap
record_phase() {
  phase=$1
  printf '%s
' "$phase" > "$out/phase.txt"
}

record_failure() {
  rc=$?
  trap - ERR
  set +e
  printf '%s
' "${BASH_COMMAND:-}" > "$out/failure-command.txt"
  {
    printf 'exit_status=%s
' "$rc"
    printf 'phase=%s
' "$phase"
    printf 'line=%s
' "${BASH_LINENO[0]:-unknown}"
    printf 'command_sha256=%s
' "$(printf '%s' "${BASH_COMMAND:-}" | sha256sum | awk '{print $1}')"
  } > "$out/failure.env"
  exit "$rc"
}
trap record_failure ERR

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    {
      printf 'lease mismatch: %s
expected=%s
actual=%s
' "$label" "$expected" "$actual"
    } | tee "$out/lease-mismatch.txt" >&2
    return 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '
' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}


snapshot_review_threads() {
  local label=$1
  local page_dir="$out/review-threads.$label.pages"
  local raw="$out/review-threads.$label.raw.json"
  local stable="$out/review-threads-stable.$label.json"
  local cursor='' page=0 page_file has_next end_cursor
  local -A seen_cursors=()
  rm -rf "$page_dir"
  mkdir -p "$page_dir"

  while :; do
    page=$((page + 1))
    test "$page" -le 1000
    page_file=$(printf '%s/page-%04d.json' "$page_dir" "$page")
    if [[ -z "$cursor" ]]; then
      gh api graphql \
        -F owner="$repo_owner" \
        -F name="$repo_name" \
        -F number="$product_pr" \
        -f query='query($owner:String!,$name:String!,$number:Int!) {
          repository(owner:$owner,name:$name) {
            pullRequest(number:$number) {
              reviewThreads(first:100) {
                pageInfo { hasNextPage endCursor }
                nodes {
                  id
                  isResolved
                  comments(first:100) {
                    pageInfo { hasNextPage }
                    nodes { databaseId body author { login } }
                  }
                }
              }
            }
          }
        }' > "$page_file"
    else
      gh api graphql \
        -F owner="$repo_owner" \
        -F name="$repo_name" \
        -F number="$product_pr" \
        -F cursor="$cursor" \
        -f query='query($owner:String!,$name:String!,$number:Int!,$cursor:String!) {
          repository(owner:$owner,name:$name) {
            pullRequest(number:$number) {
              reviewThreads(first:100, after:$cursor) {
                pageInfo { hasNextPage endCursor }
                nodes {
                  id
                  isResolved
                  comments(first:100) {
                    pageInfo { hasNextPage }
                    nodes { databaseId body author { login } }
                  }
                }
              }
            }
          }
        }' > "$page_file"
    fi

    jq -e '.data.repository.pullRequest.reviewThreads != null' "$page_file" >/dev/null
    jq -e 'all(.data.repository.pullRequest.reviewThreads.nodes[]; .comments.pageInfo.hasNextPage == false)' "$page_file" >/dev/null
    has_next=$(jq -r '.data.repository.pullRequest.reviewThreads.pageInfo.hasNextPage' "$page_file")
    case "$has_next" in
      false)
        break
        ;;
      true)
        end_cursor=$(jq -r '.data.repository.pullRequest.reviewThreads.pageInfo.endCursor // empty' "$page_file")
        test -n "$end_cursor"
        if [[ -n "${seen_cursors[$end_cursor]+x}" ]]; then
          printf 'repeated review-thread cursor: %s\n' "$end_cursor" >&2
          return 1
        fi
        seen_cursors[$end_cursor]=1
        cursor=$end_cursor
        ;;
      *)
        printf 'invalid review-thread pageInfo.hasNextPage: %s\n' "$has_next" >&2
        return 1
        ;;
    esac
  done

  jq -s '.' "$page_dir"/page-*.json > "$raw"
  jq -S '[.[].data.repository.pullRequest.reviewThreads.nodes[]
    | {
        id,
        isResolved,
        comments: ([.comments.nodes[]
          | {databaseId,body,author:(.author.login // "")}
        ] | sort_by(.databaseId))
      }
    ] | sort_by(.id)' "$raw" > "$stable"
  jq -e '([.[].id] | length) == ([.[].id] | unique | length)' "$stable" >/dev/null
  printf 'pages=%s\nthreads=%s\n' \
    "$page" "$(jq 'length' "$stable")" > "$out/review-threads-census.$label.env"

  local target_count target_id target_resolved
  target_count=$(jq --argjson target "$review_comment" '[.[]
    | select(any(.comments[]; .databaseId == $target))] | length' "$stable")
  require_equal "$target_count" 1 "target-review-thread-count-$label"
  target_id=$(jq -r --argjson target "$review_comment" '.[]
    | select(any(.comments[]; .databaseId == $target)) | .id' "$stable")
  target_resolved=$(jq -r --argjson target "$review_comment" '.[]
    | select(any(.comments[]; .databaseId == $target)) | .isResolved' "$stable")
  require_equal "$target_id" "$review_thread_expected" "target-review-thread-id-$label"
  require_equal "$target_resolved" false "target-review-thread-unresolved-$label"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq -S '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  jq 'del(.head_sha)' "$out/product-pr.$label.json" > "$out/product-pr-stable.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq -S '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/publisher-pr.$label.json"
  gh api "repos/$repo/pulls/$qualifier_pr" \
    | jq -S '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/qualifier-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq -S 'add | sort_by(.id) | map({id,user:.user.login,body,path,original_commit_id,original_line,original_start_line,in_reply_to_id,created_at})' \
    > "$out/review-comments-stable.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq -S 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq -S 'add | sort_by(.id) | map({id,body,user:.user.login,created_at})' \
    > "$out/issue-comments.$label.json"
  snapshot_review_threads "$label"
}

verify_checksum_manifest() {
  local root=$1 manifest=$2 prefix=/tmp/
  local digest original relative target actual
  while read -r digest original; do
    [[ -n "$digest" && -n "$original" ]]
    relative=${original#"$prefix"}
    target="$root/$relative"
    test -f "$target"
    actual=$(sha256sum "$target" | awk '{print $1}')
    require_equal "$actual" "$digest" "artifact-checksum-$relative"
  done < "$manifest"
}

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

record_phase publisher-controller-leases
require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "${CONTROLLER_BRANCH:-}" "$publisher_branch" controller-branch-constant
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(git rev-parse HEAD^)" "$main_sha" controller-parent
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" publisher-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$publisher_branch" publisher-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true publisher-pr-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open publisher-pr-state
mapfile -t publisher_paths < <(git diff-tree --no-commit-id --name-only -r HEAD | sort)
require_equal "${#publisher_paths[@]}" 2 publisher-path-count
require_equal "${publisher_paths[0]}" .github/temporary/pr2231-v131-phone-label-bare-host-publisher-v3.tar.xz publisher-path-1
require_equal "${publisher_paths[1]}" .github/workflows/temporary-pr2231-v131-phone-label-bare-host-publisher-v3.yml publisher-path-2

record_phase protected-state-before
snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref-before
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref-before
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head-before
require_equal "$(jq -r '.head_ref' "$out/product-pr.before.json")" "$product_branch" product-pr-branch-before
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$main_sha" product-pr-base-before
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state-before
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft-before
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged-before
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count-before
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count-before
require_equal "$(jq -r '.head_sha' "$out/qualifier-pr.before.json")" "$qualifier_controller" qualifier-pr-head-before
require_equal "$(jq -r '.head_ref' "$out/qualifier-pr.before.json")" "$qualifier_branch" qualifier-pr-branch-before
require_equal "$(jq -r '.base_sha' "$out/qualifier-pr.before.json")" "$main_sha" qualifier-pr-base-before
require_equal "$(jq -r '.state' "$out/qualifier-pr.before.json")" open qualifier-pr-state-before
require_equal "$(jq -r '.draft' "$out/qualifier-pr.before.json")" true qualifier-pr-draft-before
require_equal "$(jq -r '.changed_files' "$out/qualifier-pr.before.json")" 2 qualifier-pr-file-count-before

record_phase product-object-leases
gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit-before.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit-before.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit-before.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit-before.json")" 1 product-parent-count

record_phase qualifier-controller-leases
gh api "repos/$repo/git/commits/$qualifier_controller" > "$out/qualifier-controller-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/qualifier-controller-commit.json")" "$qualifier_controller_tree" qualifier-controller-tree
require_equal "$(jq -r '.parents[0].sha' "$out/qualifier-controller-commit.json")" "$main_sha" qualifier-controller-parent
require_equal "$(jq '.parents | length' "$out/qualifier-controller-commit.json")" 1 qualifier-controller-parent-count
mapfile -t qualifier_paths < <(gh api "repos/$repo/pulls/$qualifier_pr/files?per_page=100" --paginate --jq '.[].filename' | sort)
require_equal "${#qualifier_paths[@]}" 2 qualifier-path-count
require_equal "${qualifier_paths[0]}" "$qualifier_payload" qualifier-path-1
require_equal "${qualifier_paths[1]}" "$qualifier_workflow" qualifier-path-2

record_phase review-receipt-lease
gh api "repos/$repo/pulls/comments/$review_comment" > "$out/review-$review_comment.before.json"
require_equal "$(jq -r '.commit_id' "$out/review-$review_comment.before.json")" "$review_commit" review-commit
require_equal "$(jq -r '.original_commit_id' "$out/review-$review_comment.before.json")" "$review_original_commit" review-original-commit
require_equal "$(jq -r '.path' "$out/review-$review_comment.before.json")" "$library_path" review-path
review_body_actual_sha256=$(jq -j '.body' "$out/review-$review_comment.before.json" | sha256sum | awk '{print $1}')
require_equal "$review_body_actual_sha256" "$review_body_sha256" review-body-sha256
printf '%s
' "$review_body_actual_sha256" > "$out/review-body-sha256.txt"

record_phase qualifier-api-receipts
gh api "repos/$repo/actions/runs/$qualifier_run" > "$out/qualifier-run.json"
gh api "repos/$repo/actions/jobs/$qualifier_job" > "$out/qualifier-job.json"
gh api "repos/$repo/actions/artifacts/$qualifier_artifact" > "$out/qualifier-artifact.json"
require_equal "$(jq -r '.status' "$out/qualifier-run.json")" completed qualifier-run-status
require_equal "$(jq -r '.conclusion' "$out/qualifier-run.json")" success qualifier-run-conclusion
require_equal "$(jq -r '.head_sha' "$out/qualifier-run.json")" "$qualifier_controller" qualifier-run-head
require_equal "$(jq -r '.head_branch' "$out/qualifier-run.json")" "$qualifier_branch" qualifier-run-branch
require_equal "$(jq -r '.event' "$out/qualifier-run.json")" pull_request qualifier-run-event
require_equal "$(jq -r '.path' "$out/qualifier-run.json")" "$qualifier_workflow" qualifier-run-workflow
require_equal "$(jq -r '.run_attempt' "$out/qualifier-run.json")" 1 qualifier-run-attempt
require_equal "$(jq -r '.id' "$out/qualifier-job.json")" "$qualifier_job" qualifier-job-id
require_equal "$(jq -r '.run_id' "$out/qualifier-job.json")" "$qualifier_run" qualifier-job-run
require_equal "$(jq -r '.name' "$out/qualifier-job.json")" "$qualifier_job_name" qualifier-job-name
require_equal "$(jq -r '.status' "$out/qualifier-job.json")" completed qualifier-job-status
require_equal "$(jq -r '.conclusion' "$out/qualifier-job.json")" success qualifier-job-conclusion
require_equal "$(jq -r '.head_sha' "$out/qualifier-job.json")" "$qualifier_controller" qualifier-job-head
require_equal "$(jq -r '.id' "$out/qualifier-artifact.json")" "$qualifier_artifact" qualifier-artifact-id
require_equal "$(jq -r '.name' "$out/qualifier-artifact.json")" "$qualifier_artifact_name" qualifier-artifact-name
require_equal "$(jq -r '.size_in_bytes' "$out/qualifier-artifact.json")" "$qualifier_artifact_size" qualifier-artifact-size
require_equal "$(jq -r '.expired' "$out/qualifier-artifact.json")" false qualifier-artifact-expired
require_equal "$(jq -r '.digest' "$out/qualifier-artifact.json")" "$qualifier_artifact_digest" qualifier-artifact-digest
require_equal "$(jq -r '.workflow_run.id' "$out/qualifier-artifact.json")" "$qualifier_run" qualifier-artifact-run
require_equal "$(jq -r '.workflow_run.head_sha' "$out/qualifier-artifact.json")" "$qualifier_controller" qualifier-artifact-head
require_equal "$(jq -r '.workflow_run.head_branch' "$out/qualifier-artifact.json")" "$qualifier_branch" qualifier-artifact-branch

record_phase qualifier-artifact-download
mkdir -p "$qualifier_root"
gh api --method GET "repos/$repo/actions/artifacts/$qualifier_artifact/zip" > "$qualifier_zip"
require_equal "$(wc -c < "$qualifier_zip")" "$qualifier_artifact_size" qualifier-zip-size
require_equal "$(sha256sum "$qualifier_zip" | awk '{print $1}')" "$qualifier_zip_sha256" qualifier-zip-sha256
unzip -q "$qualifier_zip" -d "$qualifier_root"
mapfile -t qualifier_topdirs < <(find "$qualifier_root" -mindepth 1 -maxdepth 1 -type d -printf '%f
' | sort)
require_equal "${#qualifier_topdirs[@]}" 2 qualifier-topdir-count
require_equal "${qualifier_topdirs[0]}" pr2231-v131-phone-label-bare-host-controller-v1 qualifier-topdir-1
require_equal "${qualifier_topdirs[1]}" pr2231-v131-phone-label-bare-host-qualification-v1 qualifier-topdir-2
verify_checksum_manifest "$qualifier_root" "$qualifier_receipt/artifact-sha256.txt"
verify_checksum_manifest "$qualifier_root" "$qualifier_controller_receipt/envelope-sha256.txt"

record_phase qualifier-artifact-adjudication
require_equal "$(cat "$qualifier_receipt/status.env")" $'exit_status=0
mode=read-only-v131-phone-label-bare-host-qualification-r1' qualifier-status
require_equal "$(cat "$qualifier_controller_receipt/controller-status.env")" $'outer_status=0
mode=read-only-v131-phone-label-bare-host-controller-v1' qualifier-controller-status
require_equal "$(cat "$qualifier_receipt/phase.txt")" terminal-ledger qualifier-phase
cat > "$out/expected-qualification-terminal.txt" <<EOF
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit_expected
candidate_parent=$main_sha
candidate_tree=$candidate_tree_expected
EOF
cmp "$out/expected-qualification-terminal.txt" "$qualifier_receipt/qualification-terminal.txt"
require_equal "$(sed -n 's/^candidate_commit=//p' "$qualifier_receipt/candidate.env")" "$candidate_commit_expected" qualifier-candidate-commit
require_equal "$(sed -n 's/^candidate_parent=//p' "$qualifier_receipt/candidate.env")" "$main_sha" qualifier-candidate-parent
require_equal "$(sed -n 's/^candidate_tree=//p' "$qualifier_receipt/candidate.env")" "$candidate_tree_expected" qualifier-candidate-tree
require_equal "$(sed -n 's/^library_blob=//p' "$qualifier_receipt/candidate.env")" "$successor_library_blob" qualifier-candidate-library-blob
require_equal "$(sed -n 's/^test_blob=//p' "$qualifier_receipt/candidate.env")" "$successor_test_blob" qualifier-candidate-test-blob
require_equal "$(jq -r '.reproducedFailures' "$qualifier_receipt/predecessor-reproduction.json")" 7 qualifier-predecessor-failures
require_equal "$(jq -r '.repairedTransitions' "$qualifier_receipt/successor-direct.json")" 7 qualifier-repaired-transitions
require_equal "$(jq -r '.preservedControls' "$qualifier_receipt/successor-direct.json")" 10 qualifier-preserved-controls
require_equal "$(jq -r '.retainedRefusals' "$qualifier_receipt/successor-direct.json")" 6 qualifier-retained-refusals
require_equal "$(jq -r '.scaleInputLength' "$qualifier_receipt/successor-direct.json")" 10050 qualifier-scale-length
require_equal "$(jq -r '.normalizedCharacters' "$qualifier_receipt/successor-direct.json")" 40544 qualifier-scale-normalization
require_equal "$(jq -r '.fanoutInputLength' "$qualifier_receipt/successor-direct.json")" 2037 qualifier-fanout-length
require_equal "$(jq -r '.fanoutNormalizedCharacters' "$qualifier_receipt/successor-direct.json")" 6180 qualifier-fanout-normalization
require_equal "$(git hash-object "$qualifier_receipt/v131.patch")" "$patch_blob" qualifier-patch-blob
require_equal "$(wc -c < "$qualifier_receipt/v131.patch")" "$patch_size" qualifier-patch-size
require_equal "$(sha256sum "$qualifier_receipt/v131.patch" | awk '{print $1}')" "$patch_sha256" qualifier-patch-sha256
require_equal "$(git hash-object "$qualifier_receipt/v131-industrial-exhaust.mjs")" "$successor_library_blob" qualifier-successor-library-blob
require_equal "$(git hash-object "$qualifier_receipt/v131-industrial-exhaust.test.js")" "$successor_test_blob" qualifier-successor-test-blob
require_equal "$(sha256sum "$qualifier_receipt/v131-industrial-exhaust.mjs" | awk '{print $1}')" "$successor_library_sha256" qualifier-successor-library-sha256
require_equal "$(sha256sum "$qualifier_receipt/v131-industrial-exhaust.test.js" | awk '{print $1}')" "$successor_test_sha256" qualifier-successor-test-sha256
require_equal "$(git hash-object "$patch_file")" "$patch_blob" packaged-patch-blob
require_equal "$(wc -c < "$patch_file")" "$patch_size" packaged-patch-size
require_equal "$(sha256sum "$patch_file" | awk '{print $1}')" "$patch_sha256" packaged-patch-sha256
cmp "$patch_file" "$qualifier_receipt/v131.patch"
grep -Fx 'industrial-exhaust artifact tests passed' "$qualifier_receipt/repaired-product-focused.log" >/dev/null
grep -Fx 'industrial-exhaust retained-store custody tests passed' "$qualifier_receipt/repaired-product-focused.log" >/dev/null
grep -Fx 'industrial-exhaust tests passed' "$qualifier_receipt/repaired-product-focused.log" >/dev/null
grep -Fx 'industrial-exhaust artifact tests passed' "$qualifier_receipt/frozen-main-transplant-focused.log" >/dev/null
grep -Fx 'industrial-exhaust retained-store custody tests passed' "$qualifier_receipt/frozen-main-transplant-focused.log" >/dev/null
grep -Fx 'industrial-exhaust tests passed' "$qualifier_receipt/frozen-main-transplant-focused.log" >/dev/null
grep -F 'validate-pages: OK' "$qualifier_receipt/repaired-product-release.log" >/dev/null
grep -F 'validate-pages: OK' "$qualifier_receipt/frozen-main-transplant-release.log" >/dev/null
printf '%s
' QUALIFIER_ARTIFACT_VERIFIED QUALIFIER_PROVENANCE_BOUND > "$out/qualifier-verification.txt"

record_phase materialize-v130
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v130-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v130-industrial-exhaust.test.js"

cat > "$out/v131-publication-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const repaired = [
  [
    'Phone: 03-6216-8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 0362168041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 03.6216.8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 020.7946.0958.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'Phone: 03-6216-8041.2026.example.test/03-6216-8041',
    'Phone: [contact omitted].2026.example.test/03-6216-8041'
  ],
  [
    'Phone: 03-6216-8041.example.test:443/03-6216-8041',
    'Phone: [contact omitted].example.test:443/03-6216-8041'
  ],
  [
    '電話番号：０３－６２１６－８０４１．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１',
    '電話番号：[contact omitted]．ｅｘａｍｐｌｅ．ｔｅｓｔ／０３－６２１６－８０４１'
  ]
];

const preserved = [
  '03-6216-8041.example.test/03-6216-8041',
  'ID: 03-6216-8041.example.test/03-6216-8041',
  'Phone: 192.0.2.1/03-6216-8041',
  'Phone: https://example.test/03-6216-8041',
  'Phone: //example.test/03-6216-8041',
  'Phone: 2026-08-17.example.test/03-6216-8041',
  'example.test/path/bogus://x/03-6216-8041',
  'www.example.test/path/mailto://x/03-6216-8041',
  '192.0.2.1/path/ftp://x/03-6216-8041',
  '//example.test/path/bogus://x/03-6216-8041'
];

const refusals = [
  ['Phone: 03-6216-8041.example.test', 'Phone: [contact omitted].example.test'],
  ['example.test://03-6216-8041', 'example.test://[contact omitted]'],
  ['192.0.2.1://03-6216-8041', '192.0.2.1://[contact omitted]'],
  ['Phone: 03-6216-8041.https://example.test/03-6216-8041', 'Phone: [contact omitted].https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.mailto://example.test/03-6216-8041', 'Phone: [contact omitted].mailto://example.test/[contact omitted]'],
  ['mailto://example.test/03-6216-8041=https://example.test/03-6216-8041', 'mailto://example.test/[contact omitted]=https://example.test/[contact omitted]']
];

if (mode === 'predecessor') {
  for (const [input] of repaired) assert.equal(redactContactData(input), input);
  for (const input of preserved) assert.equal(redactContactData(input), input);
  for (const [input, expected] of refusals) assert.equal(redactContactData(input), expected);
  console.log(JSON.stringify({ mode, reproducedFailures: repaired.length }, null, 2));
  process.exit(0);
}

for (const [input, expected] of repaired) assert.equal(redactContactData(input), expected);
for (const input of preserved) assert.equal(redactContactData(input), input);
for (const [input, expected] of refusals) assert.equal(redactContactData(input), expected);

const scaleInput = `Phone: 03-6216-8041.example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const scaleExpected = `Phone: [contact omitted].example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const originalNormalize = String.prototype.normalize;
let normalizedCharacters = 0;
let actual;
try {
  String.prototype.normalize = function countedNormalize(form) {
    normalizedCharacters += String(this).length;
    return originalNormalize.call(this, form);
  };
  actual = redactContactData(scaleInput);
} finally {
  String.prototype.normalize = originalNormalize;
}
assert.equal(actual, scaleExpected);
assert.ok(
  normalizedCharacters < scaleInput.length * 25,
  `label-precedence classification must remain bounded; normalized ${normalizedCharacters} chars for ${scaleInput.length} source chars`
);

const fanoutInput = `Phone: ${'1.'.repeat(1000)}example.test/path/03-6216-8041`;
let fanoutNormalizedCharacters = 0;
try {
  String.prototype.normalize = function countedNormalize(form) {
    fanoutNormalizedCharacters += String(this).length;
    return originalNormalize.call(this, form);
  };
  actual = redactContactData(fanoutInput);
} finally {
  String.prototype.normalize = originalNormalize;
}
assert.equal(
  actual,
  fanoutInput,
  'numeric-label fanout beyond the telephone group denominator must fail closed'
);
assert.ok(
  fanoutNormalizedCharacters < fanoutInput.length * 8,
  `numeric-label fanout must retain bounded normalization work; normalized ${fanoutNormalizedCharacters} chars for ${fanoutInput.length} source chars`
);

console.log(JSON.stringify({
  mode,
  repairedTransitions: repaired.length,
  preservedControls: preserved.length,
  retainedRefusals: refusals.length,
  scaleInputLength: scaleInput.length,
  normalizedCharacters,
  fanoutInputLength: fanoutInput.length,
  fanoutNormalizedCharacters
}, null, 2));
NODE

record_phase independent-predecessor-reproduction
node "$out/v131-publication-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

record_phase independent-patch-application
git -C "$work/product" apply --check "$patch_file"
git -C "$work/product" apply "$patch_file"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2
require_equal "$(git hash-object "$work/product/$library_path")" "$successor_library_blob" successor-library-blob
require_equal "$(git hash-object "$work/product/$test_path")" "$successor_test_blob" successor-test-blob
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$successor_library_sha256" successor-library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$successor_test_sha256" successor-test-sha256
cmp "$work/product/$library_path" "$qualifier_receipt/v131-industrial-exhaust.mjs"
cmp "$work/product/$test_path" "$qualifier_receipt/v131-industrial-exhaust.test.js"
cp "$work/product/$library_path" "$out/v131-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v131-industrial-exhaust.test.js"
git -C "$work/product" diff --numstat > "$out/candidate-numstat.txt"

record_phase independent-direct
node "$out/v131-publication-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/direct.json"
record_phase independent-focused
run_focused "$work/product" repaired-product
record_phase independent-release
run_release "$work/product" repaired-product

record_phase generated-state-restore
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v131-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

record_phase frozen-main-transplant
cp "$out/v131-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/transplant/$test_path"
run_focused "$work/transplant" frozen-main-transplant
run_release "$work/transplant" frozen-main-transplant
git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v131-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v131-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

record_phase deterministic-candidate-construction
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_commit=$(
  printf '%s
' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-03T00:30:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-03T00:30:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
require_equal "$candidate_tree" "$candidate_tree_expected" candidate-tree
require_equal "$candidate_commit" "$candidate_commit_expected" candidate-commit
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree_expected" candidate-tree-object
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count
require_equal "$(git -C "$work/transplant" show "$candidate_commit:$library_path" | git hash-object --stdin)" "$successor_library_blob" candidate-library-blob
require_equal "$(git -C "$work/transplant" show "$candidate_commit:$test_path" | git hash-object --stdin)" "$successor_test_blob" candidate-test-blob
git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$successor_library_blob
test_blob=$successor_test_blob
qualifier_controller=$qualifier_controller
qualifier_run=$qualifier_run
qualifier_job=$qualifier_job
qualifier_artifact=$qualifier_artifact
qualifier_artifact_digest=$qualifier_artifact_digest
publisher_controller=$EXPECTED_CONTROLLER
EOF

record_phase premutation-lease-recheck
snapshot_state premutation
cmp "$out/product-pr.before.json" "$out/product-pr.premutation.json"
cmp "$out/publisher-pr.before.json" "$out/publisher-pr.premutation.json"
cmp "$out/qualifier-pr.before.json" "$out/qualifier-pr.premutation.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.premutation.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.premutation.txt"
cmp "$out/review-comments-stable.before.json" "$out/review-comments-stable.premutation.json"
cmp "$out/reviews.before.json" "$out/reviews.premutation.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.premutation.json"
cmp "$out/review-threads-stable.before.json" "$out/review-threads-stable.premutation.json"
cmp "$out/review-$review_comment.before.json" <(gh api "repos/$repo/pulls/comments/$review_comment")
require_equal "$(cat "$out/main-ref.premutation.txt")" "$main_sha" main-ref-premutation
require_equal "$(cat "$out/product-ref.premutation.txt")" "$product_head" product-ref-premutation
printf '%s
' LEASE_RECHECK_SUCCESS > "$out/lease-recheck.txt"

record_phase exact-product-publication
git push origin "$candidate_commit:refs/heads/$product_branch" \
  --force-with-lease="refs/heads/$product_branch:$product_head"
for attempt in $(seq 1 60); do
  live_ref=$(gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha')
  live_pr=$(gh api "repos/$repo/pulls/$product_pr" --jq '.head.sha')
  if [[ "$live_ref" == "$candidate_commit" && "$live_pr" == "$candidate_commit" ]]; then
    break
  fi
  sleep 2
  if [[ "$attempt" == 60 ]]; then
    printf 'publication visibility timeout: ref=%s pr=%s
' "$live_ref" "$live_pr" >&2
    exit 1
  fi
done

record_phase postpublication-adjudication
snapshot_state after
require_equal "$(cat "$out/main-ref.after.txt")" "$main_sha" main-ref-after
require_equal "$(cat "$out/product-ref.after.txt")" "$candidate_commit" product-ref-after
require_equal "$(jq -r '.head_sha' "$out/product-pr.after.json")" "$candidate_commit" product-pr-head-after
require_equal "$(jq -r '.state' "$out/product-pr.after.json")" open product-pr-state-after
require_equal "$(jq -r '.draft' "$out/product-pr.after.json")" true product-pr-draft-after
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.after.json")" '' product-pr-merged-after
cmp "$out/product-pr-stable.before.json" "$out/product-pr-stable.after.json"
cmp "$out/publisher-pr.before.json" "$out/publisher-pr.after.json"
cmp "$out/qualifier-pr.before.json" "$out/qualifier-pr.after.json"
cmp "$out/review-comments-stable.before.json" "$out/review-comments-stable.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"
cmp "$out/review-threads-stable.before.json" "$out/review-threads-stable.after.json"
gh api "repos/$repo/git/commits/$candidate_commit" > "$out/published-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/published-commit.json")" "$candidate_tree_expected" published-tree
require_equal "$(jq -r '.parents[0].sha' "$out/published-commit.json")" "$main_sha" published-parent
require_equal "$(jq '.parents | length' "$out/published-commit.json")" 1 published-parent-count
require_equal "$(gh api "repos/$repo/git/blobs/$successor_library_blob" --jq '.sha')" "$successor_library_blob" published-library-blob
require_equal "$(gh api "repos/$repo/git/blobs/$successor_test_blob" --jq '.sha')" "$successor_test_blob" published-test-blob

record_phase terminal-ledger
cat > "$out/publication-terminal.txt" <<EOF
QUALIFIER_ARTIFACT_VERIFIED
QUALIFIER_PROVENANCE_BOUND
INDEPENDENT_REPLAY_SUCCESS
FOCUSED_SUCCESS
GENERATED_STATE_ENFORCED
RELEASE_SUCCESS
FROZEN_MAIN_TRANSPLANT_SUCCESS
LEASE_RECHECK_SUCCESS
PRODUCT_PUBLICATION_SUCCESS
EXACT_PRODUCT_REF_ADVANCE
MAIN_UNCHANGED
REVIEW_STATE_UNCHANGED
DRAFT_STATE_UNCHANGED
READINESS_MUTATION_SKIPPED
MERGE_SKIPPED
PUBLICATION_SUCCESS
published_commit=$candidate_commit
published_parent=$main_sha
published_tree=$candidate_tree
library_blob=$successor_library_blob
test_blob=$successor_test_blob
qualifier_controller=$qualifier_controller
qualifier_run=$qualifier_run
qualifier_job=$qualifier_job
qualifier_artifact=$qualifier_artifact
qualifier_artifact_digest=$qualifier_artifact_digest
publisher_controller=$EXPECTED_CONTROLLER
EOF
cat "$out/publication-terminal.txt"
