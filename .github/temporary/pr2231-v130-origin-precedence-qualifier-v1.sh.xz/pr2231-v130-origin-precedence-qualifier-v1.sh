#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=b771c928c33cf5cefa605531f6c9e249b4b20606
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_tree=5316a5a8be2a11b9aac39d9f9ee53ba5ec58d3f8
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
library_blob=1c33608daa7d00b8a7935a5afc40e37a280ac073
test_blob=0e148a88fc4787152a841303072bbfc2997e4b07
library_sha256=3653b44e8df1d07097eb861c92a1a8553bcae73344e6bdeb8ab1072cd6992450
test_sha256=33d42400663eb6a423a55d076675196999b490dd71841f97bbfce4ad663de2ec
review_comments=(3919169441 3919169446)
expected_review_titles=(
  'Restrict malformed schemes to the origin position'
  'Let phone labels defeat phone-shaped bare hosts'
)

out=/tmp/pr2231-v130-origin-precedence-qualification-v1
work=/tmp/pr2231-v130-origin-precedence-work-v1
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec > >(tee -a "$out/qualification.log") 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=read-only-v130-origin-precedence-qualification\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual" >&2
    exit 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob $sha"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,commit_id,original_commit_id,path,line,start_line,side,in_reply_to_id,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
}

require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$main_sha" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count

gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit.json")" "$product_tree" product-tree
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit.json")" "$product_parent" product-parent
require_equal "$(jq '.parents | length' "$out/product-commit.json")" 1 product-parent-count

for i in "${!review_comments[@]}"; do
  id=${review_comments[$i]}
  title=${expected_review_titles[$i]}
  gh api "repos/$repo/pulls/comments/$id" > "$out/review-$id.json"
  require_equal "$(jq -r '.original_commit_id' "$out/review-$id.json")" "$product_head" "review-$id-original-commit"
  require_equal "$(jq -r '.path' "$out/review-$id.json")" "$library_path" "review-$id-path"
  jq -er --arg title "$title" '.body | contains($title)' "$out/review-$id.json" >/dev/null
  printf '%s\t%s\t%s\n' "$id" "$(jq -r '.node_id' "$out/review-$id.json")" "$(jq -r '.commit_id' "$out/review-$id.json")" \
    >> "$out/review-denominator.txt"
done

# Materialize exact V129 product bytes over the frozen main lease without moving refs.
git worktree add --detach "$work/product" "$main_sha"
git worktree add --detach "$work/transplant" "$main_sha"
fetch_blob "$library_blob" "$work/product/$library_path"
fetch_blob "$test_blob" "$work/product/$test_path"
require_equal "$(sha256sum "$work/product/$library_path" | awk '{print $1}')" "$library_sha256" library-sha256
require_equal "$(sha256sum "$work/product/$test_path" | awk '{print $1}')" "$test_sha256" test-sha256
cp "$work/product/$library_path" "$out/v129-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v129-industrial-exhaust.test.js"

cat > "$out/v130-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const [modulePath, mode] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?mode=${mode}&t=${Date.now()}`);

const repairedCases = [
  [
    'bare host path may contain scheme-like text',
    'example.test/foo://03-6216-8041',
    'example.test/foo://03-6216-8041'
  ],
  [
    'www host path may contain unsupported scheme-like text',
    'www.example.test/path/mailto://03-6216-8041',
    'www.example.test/path/mailto://03-6216-8041'
  ],
  [
    'IPv4 host path may contain scheme-like text',
    '192.0.2.1/path/ftp://03-6216-8041',
    '192.0.2.1/path/ftp://03-6216-8041'
  ],
  [
    'bare host query may contain unsupported scheme-like text',
    'example.test?next=mailto://03-6216-8041',
    'example.test?next=mailto://03-6216-8041'
  ],
  [
    'bare host fragment may contain arbitrary scheme-like text',
    'example.test#next=bogus://03-6216-8041',
    'example.test#next=bogus://03-6216-8041'
  ],
  [
    'numeric host port retains custody before scheme-like path text',
    'example.test:443/foo://03-6216-8041',
    'example.test:443/foo://03-6216-8041'
  ],
  [
    'explicit phone label defeats a hyphenated phone-shaped host label',
    'Phone: 03-6216-8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'explicit phone label defeats a compact phone-shaped host label',
    'Phone: 09012345678.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'explicit phone label defeats a dotted phone-shaped host label',
    'Phone: 03.6216.8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'fullwidth explicit phone label defeats a phone-shaped host label',
    '電話：０３－６２１６－８０４１.example.test/03-6216-8041',
    '電話：[contact omitted].example.test/03-6216-8041'
  ]
];

const refusalCases = [
  [
    'unlabelled phone-shaped bare host remains URL-owned',
    'Archive 03-6216-8041.example.test/03-6216-8041',
    'Archive 03-6216-8041.example.test/03-6216-8041'
  ],
  [
    'identifier-labelled phone-shaped bare host remains identifier-owned',
    'ID: 03-6216-8041.example.test/03-6216-8041',
    'ID: 03-6216-8041.example.test/03-6216-8041'
  ],
  [
    'interior approved-looking pseudo-scheme remains malformed',
    'Phone: 03-6216-8041.https://example.test/03-6216-8041',
    'Phone: [contact omitted].https://example.test/[contact omitted]'
  ],
  [
    'IPv4 pseudo-scheme remains unsupported',
    '192.0.2.1://03-6216-8041',
    '192.0.2.1://[contact omitted]'
  ],
  [
    'bare-domain pseudo-scheme remains unsupported',
    'example.test://03-6216-8041',
    'example.test://[contact omitted]'
  ],
  [
    'unsupported leading scheme grants no path custody',
    'mailto://example.test/03-6216-8041',
    'mailto://example.test/[contact omitted]'
  ],
  [
    'genuine HTTP path retains scheme-like content',
    'https://example.test/foo://03-6216-8041',
    'https://example.test/foo://03-6216-8041'
  ],
  [
    'genuine scheme-relative path retains scheme-like content',
    '//example.test/foo://03-6216-8041',
    '//example.test/foo://03-6216-8041'
  ],
  [
    'candidate-relative HTTPS origin retains its exact suffix custody',
    'Phone: 03-6216-8041=https://example.test/03-6216-8041',
    'Phone: [contact omitted]=https://example.test/03-6216-8041'
  ],
  [
    'numeric IPv4 port remains approved',
    '192.0.2.1:443/03-6216-8041',
    '192.0.2.1:443/03-6216-8041'
  ]
];

if (mode === 'predecessor') {
  const pathWitness = repairedCases[0];
  const labelWitness = repairedCases[6];
  const pathActual = redactContactData(pathWitness[1]);
  const labelActual = redactContactData(labelWitness[1]);
  assert.equal(pathActual, 'example.test/foo://[contact omitted]');
  assert.equal(labelActual, labelWitness[1]);
  assert.notEqual(pathActual, pathWitness[2]);
  assert.notEqual(labelActual, labelWitness[2]);
  for (const [, input, expected] of refusalCases) {
    assert.equal(redactContactData(input), expected);
  }
  console.log(JSON.stringify({
    mode,
    pathWitness: { input: pathWitness[1], actual: pathActual, required: pathWitness[2] },
    labelWitness: { input: labelWitness[1], actual: labelActual, required: labelWitness[2] },
    retainedRefusals: refusalCases.length
  }, null, 2));
  process.exit(0);
}

for (const [name, input, expected] of [...repairedCases, ...refusalCases]) {
  assert.equal(redactContactData(input), expected, name);
}
console.log(JSON.stringify({
  mode,
  repairedTransitions: repairedCases.length,
  retainedRefusals: refusalCases.length
}, null, 2));
NODE

node "$out/v130-direct.mjs" "$work/product/$library_path" predecessor \
  | tee "$out/predecessor-reproduction.json"

cat > "$out/apply-v130.py" <<'PY'
from pathlib import Path
import sys

library = Path(sys.argv[1])
test = Path(sys.argv[2])
text = library.read_text()

def replace_once(source: str, old: str, new: str, label: str) -> str:
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'{label}: expected one anchor, found {count}')
    return source.replace(old, new, 1)

text = replace_once(text, r'''const DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN = /^(?:https?:\/\/|www\.|(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})(?=\.?[:/?#])|(?:\d{1,3}\.){3}\d{1,3}(?=\.?[:/?#]))[^\s]*$/iu;''', r'''const DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN = /^(?:https?:\/\/[^\s]*|(?:(?:[\p{L}\p{N}](?:[\p{L}\p{N}-]*[\p{L}\p{N}])?\.)+(?:[\p{L}]{2,}|xn--[\p{L}\p{N}-]{2,})|(?:\d{1,3}\.){3}\d{1,3})\.?(?:(?::\d{1,5})(?:[/?#][^\s]*)?|[/?#][^\s]*))$/iu;''', 'numeric host-port URL grammar')

text = replace_once(text, r'''  const malformedSchemeLikeOrigin = malformedSchemeLikeUrlOrigin(normalized);
  if (malformedSchemeLikeOrigin >= 0) {
    return {
      normalized,
      originStart: malformedSchemeLikeOrigin,
      approved: false,
      unsupported: true
    };
  }
  if (DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN.test(leadingOrigin)
      || /^\/\/[^\s]*$/u.test(leadingOrigin)) {
    return {
      normalized,
      originStart: leadingOriginStart,
      approved: true,
      unsupported: false
    };
  }
''', r'''  // A complete leading host or approved scheme-relative origin establishes
  // custody before path, query, or fragment text is inspected. Scheme-like
  // source later in that URL is content, while `://` immediately after a
  // putative host remains malformed because host ports require digits.
  if (DIRECT_URL_ABSOLUTE_OR_HOST_PATTERN.test(leadingOrigin)
      || /^\/\/[^\s]*$/u.test(leadingOrigin)) {
    return {
      normalized,
      originStart: leadingOriginStart,
      approved: true,
      unsupported: false
    };
  }
  const malformedSchemeLikeOrigin = malformedSchemeLikeUrlOrigin(normalized);
  if (malformedSchemeLikeOrigin >= 0) {
    return {
      normalized,
      originStart: malformedSchemeLikeOrigin,
      approved: false,
      unsupported: true
    };
  }
''', 'leading host precedence over path scheme-like text')

text = replace_once(text, r'''  const directExplicitPhoneLabelContext = effectiveInheritedPhoneLabelContext
    || hasPhoneLabelPrefix(prefix);
  const allowInitialGroup = prefixContext.indeterminate
    || directExplicitPhoneLabelContext
    || !/[\p{L}\p{N}]/u.test(adjacentCharacter);
''', r'''  const directExplicitPhoneLabelContext = effectiveInheritedPhoneLabelContext
    || hasPhoneLabelPrefix(prefix);
  const contactTokenStart = tokenBoundaryIndex.start(
    Math.min(input.length, contactOffset + 1)
  );
  const indexedUrlOriginStart = tokenBoundaryIndex.urlOriginStart(
    contactTokenStart
  );
  const explicitPhoneLabelOverridesLeadingHost = Boolean(
    prefixContext.urlTokenState === 1
      && indexedUrlOriginStart === contactOffset
      && directExplicitPhoneLabelContext
      && phoneCandidateScore(candidate.trim(), prefix, false)
  );
  const allowInitialGroup = prefixContext.indeterminate
    || directExplicitPhoneLabelContext
    || !/[\p{L}\p{N}]/u.test(adjacentCharacter);
''', 'explicit phone-label host override state')

text = replace_once(text, r'''  if (prefixContext.urlTokenState === 1) {
    return {
      output: candidate,
      ranges: [],
      explicitPhoneLabelContext: false
    };
  }
  const candidateEntryUrlContextOverride = prefixContext.urlTokenState === -1
    ? false
    : null;
''', r'''  // Bare-host custody is ambiguous only when the host begins with the exact
  // telephone candidate governed by an explicit phone label. In that narrow
  // case the candidate may be classified as contact data, while later source
  // in the same indexed URL token retains custody from its original origin.
  if (prefixContext.urlTokenState === 1
      && !explicitPhoneLabelOverridesLeadingHost) {
    return {
      output: candidate,
      ranges: [],
      explicitPhoneLabelContext: false
    };
  }
  const candidateEntryUrlContextOverride = prefixContext.urlTokenState === -1
      || explicitPhoneLabelOverridesLeadingHost
    ? false
    : null;
''', 'phone-label precedence over ambiguous leading host')

library.write_text(text)

tests = test.read_text()
marker = 'PR2231 V130 URL-origin and phone-label precedence'
if marker in tests:
    raise SystemExit('V130 regression block already present')
tests += r'''

// PR2231 V130 URL-origin and phone-label precedence
for (const [name, input, expected] of [
  [
    'bare host path may contain scheme-like text',
    'example.test/foo://03-6216-8041',
    'example.test/foo://03-6216-8041'
  ],
  [
    'www host path may contain unsupported scheme-like text',
    'www.example.test/path/mailto://03-6216-8041',
    'www.example.test/path/mailto://03-6216-8041'
  ],
  [
    'IPv4 host path may contain scheme-like text',
    '192.0.2.1/path/ftp://03-6216-8041',
    '192.0.2.1/path/ftp://03-6216-8041'
  ],
  [
    'bare host query may contain unsupported scheme-like text',
    'example.test?next=mailto://03-6216-8041',
    'example.test?next=mailto://03-6216-8041'
  ],
  [
    'bare host fragment may contain arbitrary scheme-like text',
    'example.test#next=bogus://03-6216-8041',
    'example.test#next=bogus://03-6216-8041'
  ],
  [
    'numeric host port retains custody before scheme-like path text',
    'example.test:443/foo://03-6216-8041',
    'example.test:443/foo://03-6216-8041'
  ],
  [
    'explicit phone label defeats a hyphenated phone-shaped host label',
    'Phone: 03-6216-8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'explicit phone label defeats a compact phone-shaped host label',
    'Phone: 09012345678.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'explicit phone label defeats a dotted phone-shaped host label',
    'Phone: 03.6216.8041.example.test/03-6216-8041',
    'Phone: [contact omitted].example.test/03-6216-8041'
  ],
  [
    'fullwidth explicit phone label defeats a phone-shaped host label',
    '電話：０３－６２１６－８０４１.example.test/03-6216-8041',
    '電話：[contact omitted].example.test/03-6216-8041'
  ],
  [
    'unlabelled phone-shaped bare host remains URL-owned',
    'Archive 03-6216-8041.example.test/03-6216-8041',
    'Archive 03-6216-8041.example.test/03-6216-8041'
  ],
  [
    'identifier-labelled phone-shaped bare host remains identifier-owned',
    'ID: 03-6216-8041.example.test/03-6216-8041',
    'ID: 03-6216-8041.example.test/03-6216-8041'
  ],
  [
    'interior approved-looking pseudo-scheme remains malformed',
    'Phone: 03-6216-8041.https://example.test/03-6216-8041',
    'Phone: [contact omitted].https://example.test/[contact omitted]'
  ],
  [
    'IPv4 pseudo-scheme remains unsupported',
    '192.0.2.1://03-6216-8041',
    '192.0.2.1://[contact omitted]'
  ],
  [
    'bare-domain pseudo-scheme remains unsupported',
    'example.test://03-6216-8041',
    'example.test://[contact omitted]'
  ],
  [
    'unsupported leading scheme grants no path custody',
    'mailto://example.test/03-6216-8041',
    'mailto://example.test/[contact omitted]'
  ],
  [
    'genuine HTTP path retains scheme-like content',
    'https://example.test/foo://03-6216-8041',
    'https://example.test/foo://03-6216-8041'
  ],
  [
    'genuine scheme-relative path retains scheme-like content',
    '//example.test/foo://03-6216-8041',
    '//example.test/foo://03-6216-8041'
  ],
  [
    'candidate-relative HTTPS origin retains its exact suffix custody',
    'Phone: 03-6216-8041=https://example.test/03-6216-8041',
    'Phone: [contact omitted]=https://example.test/03-6216-8041'
  ],
  [
    'numeric IPv4 port remains approved',
    '192.0.2.1:443/03-6216-8041',
    '192.0.2.1:443/03-6216-8041'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    `${name}: URL authority must begin at a valid source origin and yield only to an exact explicitly labelled telephone at that same origin`
  );
}
'''
test.write_text(tests)
PY

python3 "$out/apply-v130.py" "$work/product/$library_path" "$work/product/$test_path"
node --check "$work/product/$library_path"
node --check "$work/product/$test_path"
git -C "$work/product" diff --check
mapfile -t changed < <(git -C "$work/product" diff --name-only | sort)
require_equal "${#changed[@]}" 2 changed-path-count
require_equal "${changed[0]}" "$test_path" changed-path-1
require_equal "${changed[1]}" "$library_path" changed-path-2

cp "$work/product/$library_path" "$out/v130-industrial-exhaust.mjs"
cp "$work/product/$test_path" "$out/v130-industrial-exhaust.test.js"
sha256sum "$out/v130-industrial-exhaust.mjs" "$out/v130-industrial-exhaust.test.js" \
  > "$out/v130-file-sha256.txt"
printf 'library_blob=%s\ntest_blob=%s\n' \
  "$(git hash-object "$out/v130-industrial-exhaust.mjs")" \
  "$(git hash-object "$out/v130-industrial-exhaust.test.js")" \
  > "$out/v130-file-blobs.txt"
git -C "$work/product" diff --numstat > "$out/v130-numstat.txt"
git -C "$work/product" diff -- "$library_path" "$test_path" > "$out/v130.patch"

node "$out/v130-direct.mjs" "$work/product/$library_path" successor \
  | tee "$out/successor-direct.json"

run_focused() {
  local directory=$1 label=$2
  (
    cd "$directory"
    node --check "$library_path"
    node --check "$test_path"
    for file in test/industrial-exhaust*.test.js; do
      node "$file"
    done
  ) > "$out/$label-focused.log" 2>&1
}

run_release() {
  local directory=$1 label=$2
  (
    cd "$directory"
    npm run release:check
  ) > "$out/$label-release.log" 2>&1
}

run_focused "$work/product" repaired-product
run_release "$work/product" repaired-product

# Restore generated state while retaining only the exact candidate files.
git -C "$work/product" reset --hard "$main_sha"
cp "$out/v130-industrial-exhaust.mjs" "$work/product/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/product/$test_path"
mapfile -t restored_changed < <(git -C "$work/product" status --short | sed 's/^...//' | sort)
require_equal "${#restored_changed[@]}" 2 restored-path-count
require_equal "${restored_changed[0]}" "$test_path" restored-path-1
require_equal "${restored_changed[1]}" "$library_path" restored-path-2

cp "$out/v130-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/transplant/$test_path"
run_focused "$work/transplant" frozen-main-transplant
run_release "$work/transplant" frozen-main-transplant

git -C "$work/transplant" reset --hard "$main_sha"
cp "$out/v130-industrial-exhaust.mjs" "$work/transplant/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/transplant/$test_path"
mapfile -t transplant_changed < <(git -C "$work/transplant" status --short | sed 's/^...//' | sort)
require_equal "${#transplant_changed[@]}" 2 transplant-path-count
require_equal "${transplant_changed[0]}" "$test_path" transplant-path-1
require_equal "${transplant_changed[1]}" "$library_path" transplant-path-2

# Construct one deterministic unpushed direct-child candidate over frozen main.
git -C "$work/transplant" add -- "$library_path" "$test_path"
candidate_tree=$(git -C "$work/transplant" write-tree)
candidate_message=$'fix: bind V130 URL-origin precedence\n\nPreserve valid leading host custody across path-local scheme text and let an exact explicit telephone label defeat only a phone-shaped host at the same source origin.'
candidate_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-02T23:20:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-02T23:20:00Z' \
      git -C "$work/transplant" commit-tree "$candidate_tree" -p "$main_sha"
)
cat > "$out/candidate.env" <<CANDIDATE
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$(git hash-object "$out/v130-industrial-exhaust.mjs")
test_blob=$(git hash-object "$out/v130-industrial-exhaust.test.js")
CANDIDATE
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/transplant" cat-file -p "$candidate_commit" | sed -n 's/^tree //p')" "$candidate_tree" candidate-tree
require_equal "$(git -C "$work/transplant" diff-tree --no-commit-id --name-only -r "$candidate_commit" | sort | wc -l)" 2 candidate-path-count

git -C "$work/transplant" diff-tree --no-commit-id --name-status -r "$candidate_commit" \
  > "$out/candidate-paths.txt"
git -C "$work/transplant" cat-file -p "$candidate_commit" > "$out/candidate-commit.txt"

snapshot_state after
cmp "$out/product-pr.before.json" "$out/product-pr.after.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.after.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.after.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"

cat > "$out/qualification-terminal.txt" <<TERMINAL
PUBLICATION_SKIPPED
PRODUCT_MUTATION_SKIPPED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
TERMINAL
cat "$out/qualification-terminal.txt"
