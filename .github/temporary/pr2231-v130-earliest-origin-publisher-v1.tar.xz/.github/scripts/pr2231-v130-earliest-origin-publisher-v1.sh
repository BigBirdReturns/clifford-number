#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
main_sha=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
product_head=b771c928c33cf5cefa605531f6c9e249b4b20606
product_tree=5316a5a8be2a11b9aac39d9f9ee53ba5ec58d3f8
product_parent=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
v129_library_blob=1c33608daa7d00b8a7935a5afc40e37a280ac073
v129_test_blob=0e148a88fc4787152a841303072bbfc2997e4b07
v129_library_sha256=3653b44e8df1d07097eb861c92a1a8553bcae73344e6bdeb8ab1072cd6992450
v129_test_sha256=33d42400663eb6a423a55d076675196999b490dd71841f97bbfce4ad663de2ec
patch_path=.github/scripts/pr2231-v130-earliest-origin-v1.patch
patch_blob=8109cb0d72411c9cfbe4c00bbb322ebecf9ac1b4
patch_sha256=31cfa973a1a73beb0f213d4a8bdc8f6688211497a0216843ca11793d34eaecd2
candidate_commit=c2c391d063902067455ed2f254b4381d5bdfb806
candidate_tree=971780945a5b026674d52ca9b1e48dc8b463b546
candidate_library_blob=0a0674a40c1cfaaf329cb9efb473fefa9dacfce8
candidate_test_blob=74ea9cb67fe3223fe3aab31b42368df0fa7e3f4e
candidate_library_sha256=b846d476b0c83fa814fa1c71bc297710345f9ddeaa28e21e61bd0f96ac80b882
candidate_test_sha256=06cd363f2394087944c35e697db4cbc4f004e944b0ebc4548d1aab0fdf5d64d0
qualifier_controller_pr=2552
qualifier_controller=b52f1279ac64f0a6a7f8665425fde33a2f3a0d82
qualifier_run=33695153826
qualifier_job=100462335670
qualifier_artifact=9871559051
qualifier_artifact_name=pr2231-v130-earliest-origin-qualification-v3
qualifier_artifact_digest=sha256:a1414cf2f0ab6a6004ea09db64fa3d1777d427b1906b42f6c3e5300c440bf8b7
review_comment=3919199904
review_original_commit=bd1523d86a562be91acdc175f73607dab0fcac09
review_body_sha256=0bf0dd63bbdab28398400dc787b482c014a569dac65b600f9b8abfb800be44d0

controller_root=$(pwd)
patch_file=${V130_PATCH_FILE:-"$controller_root/$patch_path"}
out=/tmp/pr2231-v130-earliest-origin-publisher-v1
work=/tmp/pr2231-v130-earliest-origin-publisher-work-v1
rm -rf "$out" "$work"
mkdir -p "$out" "$work"
exec >> "$out/publication.log" 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=leased-v130-earliest-origin-product-only-publication\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

phase=bootstrap
record_phase() {
  phase=$1
  printf '%s\n' "$phase" > "$out/phase.txt"
}

record_failure() {
  rc=$?
  trap - ERR
  set +e
  printf '%s\n' "${BASH_COMMAND:-}" > "$out/failure-command.txt"
  {
    printf 'exit_status=%s\n' "$rc"
    printf 'phase=%s\n' "$phase"
    printf 'line=%s\n' "${BASH_LINENO[0]:-unknown}"
    printf 'command_sha256=%s\n' "$(printf '%s' "${BASH_COMMAND:-}" | sha256sum | awk '{print $1}')"
  } > "$out/failure.env"
  exit "$rc"
}
trap record_failure ERR

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    {
      printf 'lease mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual"
    } | tee "$out/lease-mismatch.txt" >&2
    return 1
  fi
}

fetch_blob() {
  local sha=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  gh api "repos/$repo/git/blobs/$sha" --jq '.content' \
    | tr -d '\n' | base64 -d > "$destination"
  require_equal "$(git hash-object "$destination")" "$sha" "blob-$sha"
}

snapshot_stable_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/pulls/$qualifier_controller_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/qualifier-controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,created_at,updated_at})' \
    > "$out/issue-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,path,original_commit_id,original_line,original_start_line,in_reply_to_id,created_at})' \
    > "$out/review-comments-stable.$label.json"
  gh api graphql \
    -F owner=BigBirdReturns \
    -F name=clifford-number \
    -F number="$product_pr" \
    -f query='query($owner:String!,$name:String!,$number:Int!){repository(owner:$owner,name:$name){pullRequest(number:$number){reviewThreads(first:100){nodes{id isResolved comments(first:100){nodes{databaseId body author{login}}}}}}}}' \
    | jq '.data.repository.pullRequest.reviewThreads.nodes | sort_by(.id) | map({id,isResolved,comments:(.comments.nodes | map({databaseId,body,author:.author.login}))})' \
    > "$out/review-threads-stable.$label.json"
}

assert_review_receipt() {
  local label=$1
  gh api "repos/$repo/pulls/comments/$review_comment" > "$out/review-$review_comment.$label.json"
  require_equal "$(jq -r '.commit_id' "$out/review-$review_comment.$label.json")" "$product_head" "review-commit-$label"
  require_equal "$(jq -r '.original_commit_id' "$out/review-$review_comment.$label.json")" "$review_original_commit" "review-original-commit-$label"
  require_equal "$(jq -r '.path' "$out/review-$review_comment.$label.json")" "$library_path" "review-path-$label"
  review_body_actual_sha256=$(jq -j '.body' "$out/review-$review_comment.$label.json" | sha256sum | awk '{print $1}')
  require_equal "$review_body_actual_sha256" "$review_body_sha256" "review-body-sha256-$label"
}

record_phase controller-and-transport-leases
require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state
mapfile -t controller_paths < <(gh api --paginate "repos/$repo/pulls/$CONTROLLER_PR/files?per_page=100" --jq '.[].filename' | sort)
require_equal "${#controller_paths[@]}" 2 controller-path-count
require_equal "${controller_paths[0]}" .github/temporary/pr2231-v130-earliest-origin-publisher-v1.tar.xz controller-path-1
require_equal "${controller_paths[1]}" .github/workflows/temporary-pr2231-v130-earliest-origin-publisher-v1.yml controller-path-2
require_equal "$(git hash-object "$patch_file")" "$patch_blob" patch-blob
require_equal "$(sha256sum "$patch_file" | awk '{print $1}')" "$patch_sha256" patch-sha256

record_phase qualifier-receipt-leases
gh api "repos/$repo/actions/artifacts/$qualifier_artifact" > "$out/qualifier-artifact.json"
require_equal "$(jq -r '.id' "$out/qualifier-artifact.json")" "$qualifier_artifact" qualifier-artifact-id
require_equal "$(jq -r '.name' "$out/qualifier-artifact.json")" "$qualifier_artifact_name" qualifier-artifact-name
require_equal "$(jq -r '.digest' "$out/qualifier-artifact.json")" "$qualifier_artifact_digest" qualifier-artifact-digest
require_equal "$(jq -r '.expired' "$out/qualifier-artifact.json")" false qualifier-artifact-expired
require_equal "$(jq -r '.workflow_run.id' "$out/qualifier-artifact.json")" "$qualifier_run" qualifier-artifact-run

gh api "repos/$repo/actions/runs/$qualifier_run" > "$out/qualifier-run.json"
require_equal "$(jq -r '.head_sha' "$out/qualifier-run.json")" "$qualifier_controller" qualifier-run-head
require_equal "$(jq -r '.status' "$out/qualifier-run.json")" completed qualifier-run-status
require_equal "$(jq -r '.conclusion' "$out/qualifier-run.json")" success qualifier-run-conclusion

gh api "repos/$repo/actions/jobs/$qualifier_job" > "$out/qualifier-job.json"
require_equal "$(jq -r '.run_id' "$out/qualifier-job.json")" "$qualifier_run" qualifier-job-run
require_equal "$(jq -r '.status' "$out/qualifier-job.json")" completed qualifier-job-status
require_equal "$(jq -r '.conclusion' "$out/qualifier-job.json")" success qualifier-job-conclusion
require_equal "$(gh api "repos/$repo/pulls/$qualifier_controller_pr" --jq '.head.sha')" "$qualifier_controller" qualifier-controller-head
require_equal "$(gh api "repos/$repo/pulls/$qualifier_controller_pr" --jq '.draft')" true qualifier-controller-draft
require_equal "$(gh api "repos/$repo/pulls/$qualifier_controller_pr" --jq '.state')" open qualifier-controller-state

record_phase protected-state-snapshot
snapshot_stable_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$main_sha" main-ref-before
require_equal "$(cat "$out/product-ref.before.txt")" "$product_head" product-ref-before
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$product_head" product-pr-head-before
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$main_sha" product-pr-base-before
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state-before
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft-before
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged-before
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commits-before
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-files-before
require_equal "$(jq -r '.head_sha' "$out/controller-pr.before.json")" "$EXPECTED_CONTROLLER" controller-pr-head-before
require_equal "$(jq -r '.head_sha' "$out/qualifier-controller-pr.before.json")" "$qualifier_controller" qualifier-controller-pr-head-before

record_phase product-object-and-review-leases
gh api "repos/$repo/git/commits/$product_head" > "$out/product-commit-before.json"
require_equal "$(jq -r '.tree.sha' "$out/product-commit-before.json")" "$product_tree" product-tree-before
require_equal "$(jq -r '.parents[0].sha' "$out/product-commit-before.json")" "$product_parent" product-parent-before
require_equal "$(jq '.parents | length' "$out/product-commit-before.json")" 1 product-parent-count-before
assert_review_receipt before

record_phase candidate-reconstruction
git worktree add --detach "$work/replay" "$main_sha"
fetch_blob "$v129_library_blob" "$work/replay/$library_path"
fetch_blob "$v129_test_blob" "$work/replay/$test_path"
require_equal "$(sha256sum "$work/replay/$library_path" | awk '{print $1}')" "$v129_library_sha256" v129-library-sha256
require_equal "$(sha256sum "$work/replay/$test_path" | awk '{print $1}')" "$v129_test_sha256" v129-test-sha256
cp "$work/replay/$library_path" "$out/v129-industrial-exhaust.mjs"
cp "$work/replay/$test_path" "$out/v129-industrial-exhaust.test.js"
git -C "$work/replay" apply --check "$patch_file"
git -C "$work/replay" apply "$patch_file"
node --check "$work/replay/$library_path"
node --check "$work/replay/$test_path"
git -C "$work/replay" diff --check

cp "$work/replay/$library_path" "$out/v130-industrial-exhaust.mjs"
cp "$work/replay/$test_path" "$out/v130-industrial-exhaust.test.js"
require_equal "$(git hash-object "$out/v130-industrial-exhaust.mjs")" "$candidate_library_blob" candidate-library-blob
require_equal "$(git hash-object "$out/v130-industrial-exhaust.test.js")" "$candidate_test_blob" candidate-test-blob
require_equal "$(sha256sum "$out/v130-industrial-exhaust.mjs" | awk '{print $1}')" "$candidate_library_sha256" candidate-library-sha256
require_equal "$(sha256sum "$out/v130-industrial-exhaust.test.js" | awk '{print $1}')" "$candidate_test_sha256" candidate-test-sha256
mapfile -t changed_paths < <(git -C "$work/replay" diff --name-only | sort)
require_equal "${#changed_paths[@]}" 2 candidate-changed-path-count
require_equal "${changed_paths[0]}" "$test_path" candidate-path-1
require_equal "${changed_paths[1]}" "$library_path" candidate-path-2
git -C "$work/replay" diff --numstat > "$out/candidate-numstat.txt"
git -C "$work/replay" diff -- "$library_path" "$test_path" > "$out/candidate.patch"

cat > "$out/v130-publication-direct.mjs" <<'NODE'
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';
const [modulePath] = process.argv.slice(2);
const { redactContactData } = await import(`${pathToFileURL(modulePath).href}?publisher=${Date.now()}`);
const repaired = [
  ['example.test/path/bogus://x/03-6216-8041', 'example.test/path/bogus://x/03-6216-8041'],
  ['www.example.test/path/mailto://x/03-6216-8041', 'www.example.test/path/mailto://x/03-6216-8041'],
  ['192.0.2.1/path/ftp://x/03-6216-8041', '192.0.2.1/path/ftp://x/03-6216-8041'],
  ['//example.test/path/bogus://x/03-6216-8041', '//example.test/path/bogus://x/03-6216-8041'],
  ['URL:example.test/path/bogus://x/03-6216-8041', 'URL:example.test/path/bogus://x/03-6216-8041'],
  ['URL:"example.test/path/bogus://x/03-6216-8041', 'URL:"example.test/path/bogus://x/03-6216-8041'],
  ['example.test.:443/path/bogus://x/03-6216-8041', 'example.test.:443/path/bogus://x/03-6216-8041'],
  ['[example.test/path/bogus://x/03-6216-8041]', '[example.test/path/bogus://x/03-6216-8041]'],
  ['ｅｘａｍｐｌｅ．ｔｅｓｔ／path／bogus：／／x／０３－６２１６－８０４１', 'ｅｘａｍｐｌｅ．ｔｅｓｔ／path／bogus：／／x／０３－６２１６－８０４１']
];
const refusals = [
  ['example.test://03-6216-8041', 'example.test://[contact omitted]'],
  ['192.0.2.1://03-6216-8041', '192.0.2.1://[contact omitted]'],
  ['Phone: 03-6216-8041.https://example.test/03-6216-8041', 'Phone: [contact omitted].https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.mailto://example.test/03-6216-8041', 'Phone: [contact omitted].mailto://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041.example.test', 'Phone: [contact omitted].example.test'],
  ['mailto://example.test/03-6216-8041=https://example.test/03-6216-8041', 'mailto://example.test/[contact omitted]=https://example.test/[contact omitted]'],
  ['Phone: 03-6216-8041=https://example.test/03-6216-8041', 'Phone: [contact omitted]=https://example.test/03-6216-8041'],
  ['Phone: 03-6216-8041;//03-6216-8041', 'Phone: [contact omitted];//03-6216-8041'],
  ['example.test:443/03-6216-8041', 'example.test:443/03-6216-8041'],
  ['192.0.2.1:443/03-6216-8041', '192.0.2.1:443/03-6216-8041']
];
for (const [input, expected] of [...repaired, ...refusals]) {
  assert.equal(redactContactData(input), expected);
}
const scaleInput = `example.test/path/${'bogus://x/'.repeat(1000)}03-6216-8041`;
const originalNormalize = String.prototype.normalize;
let normalizedCharacters = 0;
let scaleActual;
try {
  String.prototype.normalize = function countedNormalize(form) {
    normalizedCharacters += String(this).length;
    return originalNormalize.call(this, form);
  };
  scaleActual = redactContactData(scaleInput);
} finally {
  String.prototype.normalize = originalNormalize;
}
assert.equal(scaleActual, scaleInput);
assert.ok(normalizedCharacters < scaleInput.length * 20);
console.log(JSON.stringify({
  repairedTransitions: repaired.length,
  retainedRefusals: refusals.length,
  scaleInputLength: scaleInput.length,
  normalizedCharacters,
  status: 'direct-success'
}, null, 2));
NODE

record_phase direct-and-complete-gates
node "$out/v130-publication-direct.mjs" "$work/replay/$library_path" > "$out/direct.json"
(
  cd "$work/replay"
  for file in test/industrial-exhaust*.test.js; do
    node "$file"
  done
) > "$out/focused.log" 2>&1
(
  cd "$work/replay"
  npm run release:check
) > "$out/release.log" 2>&1

record_phase candidate-object-reproduction
git -C "$work/replay" reset --hard "$main_sha"
cp "$out/v130-industrial-exhaust.mjs" "$work/replay/$library_path"
cp "$out/v130-industrial-exhaust.test.js" "$work/replay/$test_path"
mapfile -t restored_paths < <(git -C "$work/replay" status --short | sed 's/^...//' | sort)
require_equal "${#restored_paths[@]}" 2 restored-path-count
require_equal "${restored_paths[0]}" "$test_path" restored-path-1
require_equal "${restored_paths[1]}" "$library_path" restored-path-2

git -C "$work/replay" add -- "$library_path" "$test_path"
replayed_tree=$(git -C "$work/replay" write-tree)
require_equal "$replayed_tree" "$candidate_tree" candidate-tree
candidate_message=$'fix: bind V130 earliest URL-origin precedence\n\nPreserve the first complete approved source origin across later path syntax while retaining malformed host, unsupported-scheme, numeric-port, and candidate-relative URL refusals.'
replayed_commit=$(
  printf '%s\n' "$candidate_message" \
    | GIT_AUTHOR_NAME='BigBirdReturns' \
      GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me' \
      GIT_AUTHOR_DATE='2026-09-02T22:30:00Z' \
      GIT_COMMITTER_NAME='BigBirdReturns' \
      GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me' \
      GIT_COMMITTER_DATE='2026-09-02T22:30:00Z' \
      git -C "$work/replay" commit-tree "$replayed_tree" -p "$main_sha"
)
require_equal "$replayed_commit" "$candidate_commit" candidate-commit
require_equal "$(git -C "$work/replay" cat-file -p "$replayed_commit" | sed -n 's/^parent //p')" "$main_sha" candidate-parent
require_equal "$(git -C "$work/replay" diff-tree --no-commit-id --name-only -r "$replayed_commit" | sort | wc -l)" 2 candidate-path-count

git -C "$work/replay" cat-file -p "$replayed_commit" > "$out/candidate-commit.txt"
git -C "$work/replay" diff-tree --no-commit-id --name-status -r "$replayed_commit" > "$out/candidate-paths.txt"
cat > "$out/candidate.env" <<EOF
candidate_commit=$candidate_commit
candidate_parent=$main_sha
candidate_tree=$candidate_tree
library_blob=$candidate_library_blob
test_blob=$candidate_test_blob
qualifier_controller=$qualifier_controller
qualifier_run=$qualifier_run
qualifier_job=$qualifier_job
qualifier_artifact=$qualifier_artifact
qualifier_artifact_digest=$qualifier_artifact_digest
EOF

record_phase final-premutation-leases
require_equal "$(git rev-parse HEAD)" "$EXPECTED_CONTROLLER" controller-head-final
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head-final
require_equal "$(gh api "repos/$repo/pulls/$qualifier_controller_pr" --jq '.head.sha')" "$qualifier_controller" qualifier-controller-head-final
require_equal "$(gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha')" "$main_sha" main-ref-final
require_equal "$(gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha')" "$product_head" product-ref-final
require_equal "$(gh api "repos/$repo/pulls/$product_pr" --jq '.head.sha')" "$product_head" product-pr-head-final
require_equal "$(gh api "repos/$repo/pulls/$product_pr" --jq '.draft')" true product-pr-draft-final
require_equal "$(gh api "repos/$repo/pulls/$product_pr" --jq '.state')" open product-pr-state-final
assert_review_receipt premutation
snapshot_stable_state premutation
cmp "$out/product-pr.before.json" "$out/product-pr.premutation.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.premutation.json"
cmp "$out/qualifier-controller-pr.before.json" "$out/qualifier-controller-pr.premutation.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.premutation.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.premutation.txt"
cmp "$out/issue-comments.before.json" "$out/issue-comments.premutation.json"
cmp "$out/reviews.before.json" "$out/reviews.premutation.json"
cmp "$out/review-comments-stable.before.json" "$out/review-comments-stable.premutation.json"
cmp "$out/review-threads-stable.before.json" "$out/review-threads-stable.premutation.json"

record_phase product-ref-publication
git -C "$work/replay" push origin \
  "$candidate_commit:refs/heads/$product_branch" \
  --force-with-lease="refs/heads/$product_branch:$product_head"

require_equal "$(gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha')" "$candidate_commit" product-ref-after
require_equal "$(gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha')" "$main_sha" main-ref-after
for attempt in $(seq 1 30); do
  current_projection=$(gh api "repos/$repo/pulls/$product_pr" \
    --jq '[.head.sha, (.commits|tostring), (.changed_files|tostring)] | join(" ")')
  if [[ "$current_projection" == "$candidate_commit 1 2" ]]; then
    break
  fi
  if [[ "$attempt" == 30 ]]; then
    printf 'product PR projection did not converge after publication: %s\n' "$current_projection" >&2
    false
  fi
  sleep 1
done

record_phase postpublication-proof
snapshot_stable_state after
require_equal "$(jq -r '.head_sha' "$out/product-pr.after.json")" "$candidate_commit" product-pr-head-after
require_equal "$(jq -r '.base_sha' "$out/product-pr.after.json")" "$main_sha" product-pr-base-after
require_equal "$(jq -r '.state' "$out/product-pr.after.json")" open product-pr-state-after
require_equal "$(jq -r '.draft' "$out/product-pr.after.json")" true product-pr-draft-after
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.after.json")" '' product-pr-merged-after
require_equal "$(jq -r '.commits' "$out/product-pr.after.json")" 1 product-pr-commits-after
require_equal "$(jq -r '.changed_files' "$out/product-pr.after.json")" 2 product-pr-files-after
require_equal "$(jq -r '.head_sha' "$out/controller-pr.after.json")" "$EXPECTED_CONTROLLER" controller-pr-head-after
require_equal "$(jq -r '.head_sha' "$out/qualifier-controller-pr.after.json")" "$qualifier_controller" qualifier-controller-pr-head-after
require_equal "$(cat "$out/main-ref.after.txt")" "$main_sha" main-ref-snapshot-after
require_equal "$(cat "$out/product-ref.after.txt")" "$candidate_commit" product-ref-snapshot-after

jq -S 'del(.head_sha,.commits)' "$out/product-pr.before.json" > "$out/product-pr.before.stable.json"
jq -S 'del(.head_sha,.commits)' "$out/product-pr.after.json" > "$out/product-pr.after.stable.json"
cmp "$out/product-pr.before.stable.json" "$out/product-pr.after.stable.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/qualifier-controller-pr.before.json" "$out/qualifier-controller-pr.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/review-comments-stable.before.json" "$out/review-comments-stable.after.json"
cmp "$out/review-threads-stable.before.json" "$out/review-threads-stable.after.json"

mapfile -t pr_paths < <(gh api --paginate "repos/$repo/pulls/$product_pr/files?per_page=100" --jq '.[].filename' | sort)
require_equal "${#pr_paths[@]}" 2 product-pr-path-count-after
require_equal "${pr_paths[0]}" "$test_path" product-pr-path-1-after
require_equal "${pr_paths[1]}" "$library_path" product-pr-path-2-after

gh api "repos/$repo/git/commits/$candidate_commit" > "$out/published-commit.json"
require_equal "$(jq -r '.tree.sha' "$out/published-commit.json")" "$candidate_tree" published-tree
require_equal "$(jq -r '.parents[0].sha' "$out/published-commit.json")" "$main_sha" published-parent
require_equal "$(jq '.parents | length' "$out/published-commit.json")" 1 published-parent-count
require_equal "$(gh api "repos/$repo/contents/$library_path?ref=$candidate_commit" --jq '.sha')" "$candidate_library_blob" published-library-blob
require_equal "$(gh api "repos/$repo/contents/$test_path?ref=$candidate_commit" --jq '.sha')" "$candidate_test_blob" published-test-blob

record_phase terminal-ledger
cat > "$out/publication-terminal.txt" <<EOF
PUBLICATION_SUCCESS
PRODUCT_REF_UPDATED
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
READINESS_MUTATION_SKIPPED
MERGE_SKIPPED
published_commit=$candidate_commit
published_parent=$main_sha
published_tree=$candidate_tree
library_blob=$candidate_library_blob
test_blob=$candidate_test_blob
qualifier_artifact=$qualifier_artifact
qualifier_artifact_digest=$qualifier_artifact_digest
EOF
cat "$out/publication-terminal.txt"
