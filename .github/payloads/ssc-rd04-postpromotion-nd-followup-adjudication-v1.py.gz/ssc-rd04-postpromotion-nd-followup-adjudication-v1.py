#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import html
import json
import os
import pathlib
import re
import subprocess
import sys
from html.parser import HTMLParser
from typing import Any

CANONICAL_MAIN = "048e9d13a2555d8e6fabdbee5f45aea858f919b7"
CANONICAL_TREE = "d354309d6b936b499c78f3d0ff47d20f69abda78"
PROTOCOL_BLOB = "7bbafd8f8c6c915442770ebbeca85b37afba8047"
FIELD_BLOB = "522ec8503299c0458d45f43f23512c8ff90ac0f2"
SOURCE_BLOB = "3b8e43073f9828d80d39a9dd2baadea471d7a301"
MATRIX_BLOB = "66896190dd575f9867f1e121d845acfb4d27f56f"
SUMMARY_BLOB = "5e0adc541a22c9b0bf4cd8a059bf083e08831a15"

PROTOCOL_PATH = pathlib.Path("data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-five-route-adjudication/selected-followup-protocol.json")
FIELD_PATH = pathlib.Path("data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-five-route-adjudication/field-adjudications.json")
SOURCE_PATH = pathlib.Path("data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-five-route-adjudication/source-adjudications.json")
MATRIX_PATH = pathlib.Path("data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-four-cell-promotion/promoted-partial-field-matrix.json")
SUMMARY_PATH = pathlib.Path("data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-four-cell-promotion/promotion-summary.json")

AUTH_ARTIFACT = {
    "artifact_id": 9026693727,
    "artifact_bytes": 31603,
    "artifact_zip_sha256": "8bd5195c615a183a14d7234bf216bedaf8a62f02701e0ae0d7bce9ef9b9c6c45",
    "workflow_run_id": 31274789228,
    "workflow_job_id": 93146516420,
    "carrier_head": "2662c0f71d37a2e482273957f087f6e08c155529",
    "pull_request": 1568,
    "authority_role": "authoritative_first_execution",
}
DUP_ARTIFACT = {
    "artifact_id": 9026709327,
    "artifact_bytes": 20578,
    "artifact_zip_sha256": "5b329ec2cd498c42cffc96a7698739df04780ec0c095d8f112978c91c60cec95",
    "workflow_run_id": 31274868579,
    "workflow_job_id": 93146708869,
    "carrier_head": "3a3fdb0c65524c7083ee09012e5a9de021070067",
    "pull_request": 1570,
    "authority_role": "duplicate_transport_no_independent_substantive_weight",
}

ROUTES = {
    "RD04-W03-PPN-ND-FU-001": {
        "ordinal": 1,
        "url": "https://www.nd.gov/dhs/policymanuals/SNAP/Content/Release%20Log.htm",
        "url_sha256": "2c86704f48dd300b64fe4a719bbea16b641e06ee16897e1c5f11fc09c64e69a1",
        "body_bytes": 54545,
        "body_sha256": "b67637ce96affea164d2a467bae37327eeb9141e15d824ab092e017364595d8d",
        "title": "Release Log",
        "visible_text_chars": 7544,
        "visible_word_count": 1152,
        "visible_text_sha256": "22fa1342c642c2504e9b466b87071d8f35f951c399e54d18a9907b9f68f29bfd",
        "target_decision_id": "RD04-PPN-ND-OPERATIVE-STATE-IMPLEMENTATION-AUTHORITY-AND-VERSION",
        "target_field_id": "operative_state_implementation_authority_and_version",
        "auth_body_path": "routes/RD04-W03-PPN-ND-FU-001/physical-01-body.bin",
        "auth_headers_path": "routes/RD04-W03-PPN-ND-FU-001/physical-01-headers.json",
        "auth_receipt_path": "routes/RD04-W03-PPN-ND-FU-001/receipt.json",
        "dup_body_path": "routes/RD04-W03-PPN-ND-FU-001/body.bin",
        "dup_headers_path": "routes/RD04-W03-PPN-ND-FU-001/headers.json",
        "dup_receipt_path": "routes/RD04-W03-PPN-ND-FU-001/receipt.json",
    },
    "RD04-W03-PPN-ND-FU-002": {
        "ordinal": 2,
        "url": "https://www.nd.gov/dhs/policymanuals/SNAP/Content/History/403%20Geographic%20Waiver/403%20History%20Log.htm",
        "url_sha256": "4d8eda2c6f512d784cca2430bfcf2ef04beef438c1616762c55604d599de9c57",
        "body_bytes": 16829,
        "body_sha256": "30268733f0aa5e2f1e3d7ce4aa0b3c748c0394afc5a0b860327ad64c19bdb81a",
        "title": "403 Geographic Waiver History Log",
        "visible_text_chars": 319,
        "visible_word_count": 45,
        "visible_text_sha256": "7db9dc71a00d968aef5df6d3bc8ac571a43baffc7a45a33c309bf31d699d6dae",
        "target_decision_id": "RD04-PPN-ND-ABAWD-OR-WORK-REQUIREMENT-WAIVER-STATE-AND-GOVERNING-PERIOD",
        "target_field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
        "auth_body_path": "routes/RD04-W03-PPN-ND-FU-002/physical-02-body.bin",
        "auth_headers_path": "routes/RD04-W03-PPN-ND-FU-002/physical-02-headers.json",
        "auth_receipt_path": "routes/RD04-W03-PPN-ND-FU-002/receipt.json",
        "dup_body_path": "routes/RD04-W03-PPN-ND-FU-002/body.bin",
        "dup_headers_path": "routes/RD04-W03-PPN-ND-FU-002/headers.json",
        "dup_receipt_path": "routes/RD04-W03-PPN-ND-FU-002/receipt.json",
    },
}

AUTHORITY = {
    "source_requests_executed_by_adjudication": 0,
    "artifact_downloads": 2,
    "source_admissions_created": 2,
    "field_classifications_created": 0,
    "field_terminalizations_created": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
    "national_prevalence_effect": "none",
    "discrimination_effect": "none",
    "racial_order_effect": "none",
    "coordination_effect": "none",
    "common_purpose_effect": "none",
    "complete_compact_effect": "none",
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_sha(value: Any) -> str:
    return sha256_bytes(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode())


def read_json(path: pathlib.Path) -> Any:
    return json.loads(path.read_text())


def write_json(path: pathlib.Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def file_identity(path: pathlib.Path, expected_blob: str | None = None) -> dict[str, Any]:
    data = path.read_bytes()
    row = {
        "path": path.as_posix(),
        "bytes": len(data),
        "sha256": sha256_bytes(data),
    }
    if expected_blob is not None:
        observed = subprocess.check_output(["git", "hash-object", str(path)], text=True).strip()
        if observed != expected_blob:
            raise AssertionError(f"Git blob mismatch for {path}: {observed} != {expected_blob}")
        row["git_blob"] = observed
    return row


class VisibleHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.skip_depth = 0
        self.in_title = False
        self.title_parts: list[str] = []
        self.text_parts: list[str] = []
        self.links: list[dict[str, str]] = []
        self.current_link: dict[str, Any] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        lowered = tag.lower()
        if lowered in {"script", "style", "noscript"}:
            self.skip_depth += 1
        if lowered == "title":
            self.in_title = True
        if lowered == "a":
            values = {key.lower(): value or "" for key, value in attrs}
            self.current_link = {"href": values.get("href", ""), "text_parts": []}

    def handle_endtag(self, tag: str) -> None:
        lowered = tag.lower()
        if lowered in {"script", "style", "noscript"} and self.skip_depth:
            self.skip_depth -= 1
        if lowered == "title":
            self.in_title = False
        if lowered == "a" and self.current_link is not None:
            self.links.append({
                "href": self.current_link["href"],
                "text": " ".join(" ".join(self.current_link["text_parts"]).split()),
            })
            self.current_link = None

    def handle_data(self, data: str) -> None:
        if self.skip_depth:
            return
        self.text_parts.append(data)
        if self.in_title:
            self.title_parts.append(data)
        if self.current_link is not None:
            self.current_link["text_parts"].append(data)

    def result(self) -> dict[str, Any]:
        title = " ".join(" ".join(self.title_parts).split())
        visible = " ".join(" ".join(self.text_parts).split())
        return {
            "document_title": title,
            "visible_text": visible,
            "visible_text_characters": len(visible),
            "visible_word_count": len(visible.split()),
            "visible_text_sha256": sha256_bytes(visible.encode()),
            "links": self.links,
        }


def header_map(path: pathlib.Path, duplicate: bool) -> dict[str, str]:
    value = read_json(path)
    if duplicate:
        return value["response_headers"]
    return {key: val for key, val in value["headers"]}


def validate_product(product: dict[str, Any]) -> None:
    custody = product["artifact_custody"]
    sources = product["source_adjudications"]
    fields = product["field_adjudications"]
    candidate = product["promotion_candidate_protocol"]
    text = product["source_text_custody"]
    summary = product["adjudication_summary"]

    assert custody["canonical_main"] == CANONICAL_MAIN
    assert custody["canonical_tree"] == CANONICAL_TREE
    assert custody["authoritative_artifact"]["artifact_id"] == AUTH_ARTIFACT["artifact_id"]
    assert custody["authoritative_artifact"]["artifact_zip_sha256"] == AUTH_ARTIFACT["artifact_zip_sha256"]
    assert custody["duplicate_artifact"]["artifact_id"] == DUP_ARTIFACT["artifact_id"]
    assert custody["duplicate_artifact"]["artifact_zip_sha256"] == DUP_ARTIFACT["artifact_zip_sha256"]
    assert custody["route_count"] == 2
    assert custody["transport_observation_count"] == 4
    assert custody["unique_body_identity_count"] == 2
    assert custody["substantive_source_weight_count"] == 2
    assert custody["duplicate_transport_substantive_weight_effect"] == "none"
    assert all(row["duplicate_body_byte_identical"] for row in custody["route_body_identity"])
    assert all(row["substantive_weight_count"] == 1 for row in custody["route_body_identity"])

    assert sources["summary"] == {
        "source_decisions": 2,
        "narrow_source_admissions": 2,
        "transport_observations": 4,
        "unique_body_identities": 2,
        "duplicate_transport_observations": 2,
        "substantive_weight_count": 2,
    }
    assert sources["authority_boundary"] == AUTHORITY
    assert [row["route_id"] for row in sources["decisions"]] == list(ROUTES)
    for row in sources["decisions"]:
        expected = ROUTES[row["route_id"]]
        assert row["body_bytes"] == expected["body_bytes"]
        assert row["body_sha256"] == expected["body_sha256"]
        assert row["document_title"] == expected["title"]
        assert row["source_admitted_for_narrow_scope"] is True
        assert row["candidate_fields_for_offline_review"] == [expected["target_field_id"]]
        assert row["duplicate_transport_observations"] == 2
        assert row["duplicate_body_identity_count"] == 1
        assert row["substantive_weight_count"] == 1
        assert len(row["transport_observations"]) == 2
        assert {obs["artifact_id"] for obs in row["transport_observations"]} == {AUTH_ARTIFACT["artifact_id"], DUP_ARTIFACT["artifact_id"]}
        assert all(obs["body_sha256"] == expected["body_sha256"] for obs in row["transport_observations"])
        assert row["field_classification_effect"] == "none"
        assert row["row_state_effect"] == "none"
        assert row["class_closed"] is False
        assert row["outside_human_dependency"] is False
        assert row["publication_effect"] == "none"
        assert row["adoption_effect"] == "none"
        assert row["graph_effect"] == "none"

    assert fields["summary"] == {
        "field_decisions": 2,
        "evidence_complete_candidates": 1,
        "held_open_fields": 1,
        "source_admissions_created": 2,
        "substantive_field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
    }
    assert fields["authority_boundary"] == AUTHORITY
    assert len(fields["decisions"]) == 2
    authority_decision, waiver_decision = fields["decisions"]
    assert authority_decision["decision_id"] == "RD04-PPN-ND-FU-OPERATIVE-STATE-IMPLEMENTATION-AUTHORITY-AND-VERSION"
    assert authority_decision["field_id"] == "operative_state_implementation_authority_and_version"
    assert authority_decision["disposition"] == "evidence_complete_bounded_finding"
    assert authority_decision["promotion_candidate"] is True
    assert authority_decision["source_route_ids"] == ["RD04-W03-PPN-ND-FU-001"]
    assert authority_decision["bounded_finding"]["finding_summary"] == "North Dakota's captured official SNAP Release Log lists release 26.5, effective June 15, 2026, as the latest visible release entry and identifies section 301 Work Registration among the affected sections."
    assert authority_decision["bounded_finding"]["latest_visible_release"] == "26.5"
    assert authority_decision["bounded_finding"]["latest_visible_effective_date"] == "2026-06-15"
    assert authority_decision["bounded_finding"]["every_section_revised_in_latest_release"] is False
    assert authority_decision["current_cell_state"] == "still_open"
    assert authority_decision["substantive_field_terminalizations"] == 0
    assert authority_decision["selected_followup_route_ids"] == []

    assert waiver_decision["decision_id"] == "RD04-PPN-ND-FU-ABAWD-OR-WORK-REQUIREMENT-WAIVER-STATE-AND-GOVERNING-PERIOD"
    assert waiver_decision["field_id"] == "abawd_or_work_requirement_waiver_state_and_governing_period"
    assert waiver_decision["disposition"] == "temporal_or_scope_ambiguity_hold_open"
    assert waiver_decision["promotion_candidate"] is False
    assert waiver_decision["source_route_ids"] == ["RD04-W03-PPN-ND-FU-002"]
    assert waiver_decision["bounded_finding"]["current_post_period_state"] == "not_expressly_stated_in_captured_body"
    assert waiver_decision["bounded_finding"]["latest_historical_period_end"] == "2025-10-31"
    assert waiver_decision["bounded_finding"]["history_log_scope"] == "previous_versions_only"
    assert waiver_decision["current_cell_state"] == "still_open"
    assert waiver_decision["substantive_field_terminalizations"] == 0
    assert waiver_decision["selected_followup_route_ids"] == []

    assert candidate["candidate_count"] == 1
    assert candidate["unique_candidate_cell_count"] == 1
    assert candidate["held_cell_count"] == 1
    assert candidate["candidates"][0]["candidate_id"] == "RD04-PPN-ND-FU-CANDIDATE-OPERATIVE-STATE-IMPLEMENTATION-AUTHORITY-AND-VERSION"
    assert candidate["candidates"][0]["decision_id"] == authority_decision["decision_id"]
    assert candidate["candidates"][0]["bounded_finding"] == authority_decision["bounded_finding"]
    assert candidate["candidates"][0]["source_route_ids"] == authority_decision["source_route_ids"]
    assert candidate["candidates"][0]["current_cell_state"] == "still_open"
    assert candidate["matrix_updates"] == 0
    assert candidate["field_terminalizations"] == 0
    assert candidate["row_state_mutations"] == 0
    assert candidate["class_closed"] is False

    assert len(text["routes"]) == 2
    text_by_route = {row["route_id"]: row for row in text["routes"]}
    for route_id, expected in ROUTES.items():
        row = text_by_route[route_id]
        assert row["document_title"] == expected["title"]
        assert row["visible_text_characters"] == expected["visible_text_chars"]
        assert row["visible_word_count"] == expected["visible_word_count"]
        assert row["visible_text_sha256"] == expected["visible_text_sha256"]
    assert text_by_route["RD04-W03-PPN-ND-FU-001"]["latest_visible_release"] == "26.5"
    assert text_by_route["RD04-W03-PPN-ND-FU-001"]["latest_visible_effective_date"] == "2026-06-15"
    assert text_by_route["RD04-W03-PPN-ND-FU-002"]["current_post_period_state"] == "not_expressly_stated_in_captured_body"

    assert summary["source_admissions"] == 2
    assert summary["field_decisions"] == 2
    assert summary["promotion_candidates"] == 1
    assert summary["held_open_fields"] == 1
    assert summary["duplicate_transport_observations"] == 2
    assert summary["duplicate_transport_substantive_weight_effect"] == "none"
    assert summary["current_matrix"] == {
        "materialized_cells": 450,
        "terminal_cells": 226,
        "still_open_cells": 224,
        "still_open_substantive_cells": 184,
        "terminal_units": 10,
    }
    assert summary["projected_separate_promotion"] == {
        "terminal_cells_before": 226,
        "terminal_cells_after": 227,
        "still_open_cells_before": 224,
        "still_open_cells_after": 223,
        "still_open_substantive_cells_before": 184,
        "still_open_substantive_cells_after": 183,
        "terminal_units_before": 10,
        "terminal_units_after": 10,
    }
    assert summary["matrix_updates"] == 0
    assert summary["field_terminalizations"] == 0
    assert summary["row_state_mutations"] == 0
    assert summary["class_closed"] is False
    assert summary["cumulative_ledger_effect"] == "none"
    assert summary["outside_human_dependency"] is False
    assert summary["publication_effect"] == "none"
    assert summary["adoption_effect"] == "none"
    assert summary["graph_effect"] == "none"


def build_product(authoritative_root: pathlib.Path, duplicate_root: pathlib.Path) -> dict[str, Any]:
    protocol = read_json(PROTOCOL_PATH)
    previous_fields = read_json(FIELD_PATH)
    previous_sources = read_json(SOURCE_PATH)
    matrix = read_json(MATRIX_PATH)
    promotion_summary = read_json(SUMMARY_PATH)

    assert protocol["fixed_route_count"] == 2
    assert [row["route_id"] for row in protocol["routes"]] == list(ROUTES)
    assert promotion_summary["matrix_transition"]["terminal_cells_after"] == 226
    assert promotion_summary["matrix_transition"]["still_open_cells_after"] == 224
    assert promotion_summary["matrix_transition"]["substantive_fields_still_open_after"] == 184
    assert promotion_summary["matrix_transition"]["terminal_units_after"] == 10
    assert promotion_summary["current_result"]["held_north_dakota_cells_remaining"] == 2
    assert matrix["counts"]["materialized_cells"] == 450
    assert matrix["counts"]["terminal_cells"] == 226
    assert matrix["counts"]["still_open_cells"] == 224
    assert matrix["counts"]["still_open_substantive_cells"] == 184
    assert matrix["counts"]["terminal_units"] == 10

    previous_field_by_id = {row["decision_id"]: row for row in previous_fields["decisions"]}
    previous_source_by_id = {row["route_id"]: row for row in previous_sources["decisions"]}
    assert previous_source_by_id["RD04-W03-PPN-ND-002"]["body_sha256"] == "a4bd1f3911ecb5693494dcbbf2a18b0e2758895bcee8b7d7fbb2e7c71fc6486a"
    assert previous_field_by_id[ROUTES["RD04-W03-PPN-ND-FU-001"]["target_decision_id"]]["disposition"] == "no_relevant_support_hold_open"
    assert previous_field_by_id[ROUTES["RD04-W03-PPN-ND-FU-002"]["target_decision_id"]]["disposition"] == "temporal_or_scope_ambiguity_hold_open"

    nd_row = next(row for row in matrix["rows"] if row["unit_id"] == "US-STATE-ND" and row["postal_code"] == "ND")
    cell_by_id = {row["field_id"]: row for row in nd_row["cells"]}
    for expected in ROUTES.values():
        cell = cell_by_id[expected["target_field_id"]]
        assert cell["state"] == "still_open" and cell["terminal"] is False

    auth_receipt = read_json(authoritative_root / "execution-receipt.json")
    dup_receipt = read_json(duplicate_root / "capture-receipt.json")
    assert auth_receipt["state"] == "terminal_transport_custody"
    assert auth_receipt["workflow_run_id"] == AUTH_ARTIFACT["workflow_run_id"]
    assert auth_receipt["carrier_head"] == AUTH_ARTIFACT["carrier_head"]
    assert auth_receipt["physical_requests_executed"] == 2
    assert auth_receipt["additional_execution_authorized_by_this_receipt"] is False
    assert dup_receipt["state"] == "captured_terminal"
    assert dup_receipt["physical_request_count"] == 2

    text_rows: list[dict[str, Any]] = []
    source_decisions: list[dict[str, Any]] = []
    custody_rows: list[dict[str, Any]] = []
    parsed_by_route: dict[str, dict[str, Any]] = {}

    for route_id, expected in ROUTES.items():
        auth_body_path = authoritative_root / expected["auth_body_path"]
        dup_body_path = duplicate_root / expected["dup_body_path"]
        auth_body = auth_body_path.read_bytes()
        dup_body = dup_body_path.read_bytes()
        assert len(auth_body) == expected["body_bytes"]
        assert sha256_bytes(auth_body) == expected["body_sha256"]
        assert dup_body == auth_body
        assert sha256_bytes(dup_body) == expected["body_sha256"]

        auth_route_receipt = read_json(authoritative_root / expected["auth_receipt_path"])
        dup_route_receipt = read_json(duplicate_root / expected["dup_receipt_path"])
        assert auth_route_receipt["route_id"] == route_id
        assert auth_route_receipt["http_status"] == 200
        assert auth_route_receipt["redirect_count"] == 0
        assert auth_route_receipt["body_sha256"] == expected["body_sha256"]
        assert auth_route_receipt["terminal_state"] == "terminal_http_success_body_captured"
        assert dup_route_receipt["route_id"] == route_id
        assert dup_route_receipt["http_status"] == 200
        assert dup_route_receipt["body_sha256"] == expected["body_sha256"]
        assert dup_route_receipt["terminal_state"] == "terminal_http_success_body_captured"

        parser = VisibleHTML()
        parser.feed(auth_body.decode("utf-8", "strict"))
        parsed = parser.result()
        assert parsed["document_title"] == expected["title"]
        assert parsed["visible_text_characters"] == expected["visible_text_chars"]
        assert parsed["visible_word_count"] == expected["visible_word_count"]
        assert parsed["visible_text_sha256"] == expected["visible_text_sha256"]
        parsed_by_route[route_id] = parsed

        auth_headers = header_map(authoritative_root / expected["auth_headers_path"], duplicate=False)
        dup_headers = header_map(duplicate_root / expected["dup_headers_path"], duplicate=True)
        assert auth_headers["Content-Length"] == str(expected["body_bytes"])
        assert dup_headers["Content-Length"] == str(expected["body_bytes"])
        assert auth_headers["ETag"] == dup_headers["ETag"]
        assert auth_headers["Last-Modified"] == dup_headers["Last-Modified"]

        custody_rows.append({
            "route_id": route_id,
            "authoritative_body_bytes": len(auth_body),
            "authoritative_body_sha256": sha256_bytes(auth_body),
            "duplicate_body_bytes": len(dup_body),
            "duplicate_body_sha256": sha256_bytes(dup_body),
            "duplicate_body_byte_identical": dup_body == auth_body,
            "transport_observation_count": 2,
            "unique_body_identity_count": 1,
            "substantive_weight_count": 1,
        })

        if route_id.endswith("001"):
            anchors = [
                "SNAP: Release Log 2026 Release Log Release Number Effective Date Sections Affected Notes",
                "26.5 6.15.2026 301 - Work Registration",
                "Update to the qualifying and non-qualifying E&T components",
                "25.7 11.1.2025 401 ABAWD Overview 402 ABAWD Countable Months - Exemptions 403 Geographic Waiver",
            ]
            for anchor in anchors:
                assert anchor in parsed["visible_text"]
            source_class = "exact_official_state_snap_release_log"
            rationale = "The first-party SNAP release log states a current visible release sequence, effective dates, affected sections, and release notes. It is admitted only for bounded public manual-release and version-boundary custody."
            exact_observations = {
                "latest_visible_release": "26.5",
                "latest_visible_effective_date": "2026-06-15",
                "latest_visible_affected_section": "301 - Work Registration",
                "latest_visible_release_note": "Update to the qualifying and non-qualifying E&T components",
                "visible_prior_section_403_release": "25.7",
                "visible_prior_section_403_effective_date": "2025-11-01",
            }
        else:
            anchors = [
                "Previous Versions of 403 Geographic Waiver",
                "Release 25.2-25.6 Effective 7/1/2025 - 10/31/2025",
                "Release 25.1 - Effective 5/15/2025 - 7/1/2025",
            ]
            for anchor in anchors:
                assert anchor in parsed["visible_text"]
            forbidden_current_claims = [
                "Effective 11/1/2025",
                "no waived reservations",
                "no waived counties",
                "current waiver",
            ]
            assert all(claim.lower() not in parsed["visible_text"].lower() for claim in forbidden_current_claims)
            source_class = "exact_official_state_policy_section_history_log"
            rationale = "The first-party section 403 history log enumerates previous versions and bounded historical effective periods. It is admitted only for historical-version and current-gap boundary custody."
            exact_observations = {
                "history_log_scope": "previous_versions_only",
                "previous_release_group": "25.2-25.6",
                "previous_release_group_period_start": "2025-07-01",
                "previous_release_group_period_end": "2025-10-31",
                "previous_release": "25.1",
                "previous_release_period_start": "2025-05-15",
                "previous_release_period_end": "2025-07-01",
                "current_post_period_state": "not_expressly_stated_in_captured_body",
            }

        text_rows.append({
            "route_id": route_id,
            "document_title": parsed["document_title"],
            "visible_text_characters": parsed["visible_text_characters"],
            "visible_word_count": parsed["visible_word_count"],
            "visible_text_sha256": parsed["visible_text_sha256"],
            "exact_anchors": anchors,
            **exact_observations,
        })
        source_decisions.append({
            "source_decision_id": f"{route_id}-SOURCE",
            "route_id": route_id,
            "route_ordinal": expected["ordinal"],
            "requested_url": expected["url"],
            "final_url": expected["url"],
            "content_type": "text/html; charset=UTF-8",
            "document_title": parsed["document_title"],
            "body_bytes": expected["body_bytes"],
            "body_sha256": expected["body_sha256"],
            "etag": auth_headers["ETag"],
            "last_modified": auth_headers["Last-Modified"],
            "source_class": source_class,
            "source_admitted_for_narrow_scope": True,
            "admission_rationale": rationale,
            "field_review_selected": True,
            "candidate_fields_for_offline_review": [expected["target_field_id"]],
            "html_review": {
                "document_title": parsed["document_title"],
                "visible_text_characters": parsed["visible_text_characters"],
                "visible_word_count": parsed["visible_word_count"],
                "visible_text_sha256": parsed["visible_text_sha256"],
                "exact_anchors": anchors,
                "exact_observations": exact_observations,
            },
            "duplicate_transport_observations": 2,
            "duplicate_body_identity_count": 1,
            "substantive_weight_count": 1,
            "transport_observations": [
                {
                    "observation_ordinal": 1,
                    "authority_role": AUTH_ARTIFACT["authority_role"],
                    "artifact_id": AUTH_ARTIFACT["artifact_id"],
                    "artifact_outer_sha256": AUTH_ARTIFACT["artifact_zip_sha256"],
                    "workflow_run_id": AUTH_ARTIFACT["workflow_run_id"],
                    "workflow_job_id": AUTH_ARTIFACT["workflow_job_id"],
                    "execution_head": AUTH_ARTIFACT["carrier_head"],
                    "pull_request": AUTH_ARTIFACT["pull_request"],
                    "response_date": auth_headers["Date"],
                    "http_status": 200,
                    "redirect_count": 0,
                    "attempts": 1,
                    "body_bytes": expected["body_bytes"],
                    "body_sha256": expected["body_sha256"],
                    "route_receipt_sha256": sha256_bytes((authoritative_root / expected["auth_receipt_path"]).read_bytes()),
                    "terminal_state": "terminal_http_success_body_captured",
                },
                {
                    "observation_ordinal": 2,
                    "authority_role": DUP_ARTIFACT["authority_role"],
                    "artifact_id": DUP_ARTIFACT["artifact_id"],
                    "artifact_outer_sha256": DUP_ARTIFACT["artifact_zip_sha256"],
                    "workflow_run_id": DUP_ARTIFACT["workflow_run_id"],
                    "workflow_job_id": DUP_ARTIFACT["workflow_job_id"],
                    "execution_head": DUP_ARTIFACT["carrier_head"],
                    "pull_request": DUP_ARTIFACT["pull_request"],
                    "response_date": dup_headers["Date"],
                    "http_status": 200,
                    "redirect_count": 0,
                    "attempts": 1,
                    "body_bytes": expected["body_bytes"],
                    "body_sha256": expected["body_sha256"],
                    "route_receipt_sha256": sha256_bytes((duplicate_root / expected["dup_receipt_path"]).read_bytes()),
                    "terminal_state": "terminal_http_success_body_captured",
                },
            ],
            "field_classification_effect": "none",
            "row_state_effect": "none",
            "class_closed": False,
            "outside_human_dependency": False,
            "publication_effect": "none",
            "adoption_effect": "none",
            "graph_effect": "none",
            "result_spawned_requests": 0,
        })

    authority_cell = cell_by_id["operative_state_implementation_authority_and_version"]
    waiver_cell = cell_by_id["abawd_or_work_requirement_waiver_state_and_governing_period"]
    row_hash = canonical_sha(nd_row)
    authority_finding = {
        "finding_code": "north_dakota_snap_release_log_latest_visible_entry_26_5_effective_2026_06_15",
        "finding_scope": "bounded_official_state_manual_release_boundary_candidate",
        "finding_summary": "North Dakota's captured official SNAP Release Log lists release 26.5, effective June 15, 2026, as the latest visible release entry and identifies section 301 Work Registration among the affected sections.",
        "latest_visible_release": "26.5",
        "latest_visible_effective_date": "2026-06-15",
        "latest_visible_affected_sections": ["301 - Work Registration"],
        "latest_visible_release_note": "Update to the qualifying and non-qualifying E&T components",
        "visible_prior_section_403_release": "25.7",
        "visible_prior_section_403_effective_date": "2025-11-01",
        "every_section_revised_in_latest_release": False,
    }
    waiver_finding = {
        "finding_code": "north_dakota_section_403_history_log_previous_versions_end_2025_10_31_current_period_unstated",
        "finding_scope": "bounded_official_history_log_gap_boundary",
        "finding_summary": "North Dakota's captured official section 403 history log lists only previous versions 25.1 and 25.2-25.6, with the latest listed historical period ending October 31, 2025; it does not state the current post-period waiver geography or governing period.",
        "history_log_scope": "previous_versions_only",
        "previous_release_groups": [
            {"release": "25.1", "period_start": "2025-05-15", "period_end": "2025-07-01"},
            {"release": "25.2-25.6", "period_start": "2025-07-01", "period_end": "2025-10-31"},
        ],
        "latest_historical_period_end": "2025-10-31",
        "current_post_period_state": "not_expressly_stated_in_captured_body",
    }

    field_decisions = [
        {
            "decision_id": "RD04-PPN-ND-FU-OPERATIVE-STATE-IMPLEMENTATION-AUTHORITY-AND-VERSION",
            "supersedes_or_refines_decision_id": ROUTES["RD04-W03-PPN-ND-FU-001"]["target_decision_id"],
            "unit_id": "US-STATE-ND",
            "postal_code": "ND",
            "state_name": "North Dakota",
            "field_id": "operative_state_implementation_authority_and_version",
            "disposition": "evidence_complete_bounded_finding",
            "promotion_candidate": True,
            "bounded_finding": authority_finding,
            "source_route_ids": ["RD04-W03-PPN-ND-FU-001"],
            "evidence_locators": [
                {"route_id": "RD04-W03-PPN-ND-FU-001", "anchor": "26.5 6.15.2026 301 - Work Registration"},
                {"route_id": "RD04-W03-PPN-ND-FU-001", "anchor": "Update to the qualifying and non-qualifying E&T components"},
                {"route_id": "RD04-W03-PPN-ND-FU-001", "anchor": "25.7 11.1.2025 401 ABAWD Overview 402 ABAWD Countable Months - Exemptions 403 Geographic Waiver"},
            ],
            "current_cell_state": authority_cell["state"],
            "current_cell_terminal": authority_cell["terminal"],
            "current_cell_canonical_sha256": canonical_sha(authority_cell),
            "current_row_canonical_sha256": row_hash,
            "limitations": [
                "the release log establishes the latest visible public SNAP release entry, not that every SNAP section was revised in release 26.5",
                "the release log does not establish uniform frontline implementation or person-level outcomes",
            ],
            "prohibited_inferences": [
                "do_not_count_duplicate_transport_as_independent_substantive_support",
                "do_not_infer_every_section_revised_in_release_26_5",
                "do_not_infer_uniform_frontline_practice",
                "do_not_infer_person_level_outcome",
                "do_not_infer_national_prevalence",
                "do_not_infer_discrimination_or_racial_order",
                "do_not_infer_coordination_or_common_purpose",
                "do_not_infer_complete_compact",
                "do_not_close_rd04_c02",
            ],
            "rationale_code": "official_release_log_supplies_current_visible_manual_release_boundary",
            "selected_followup_route_ids": [],
            "result_spawned_requests": 0,
            "field_classification_effect": "none",
            "substantive_field_terminalizations": 0,
            "row_state_effect": "none",
            "class_closed": False,
            "outside_human_dependency": False,
            "publication_effect": "none",
            "adoption_effect": "none",
            "graph_effect": "none",
        },
        {
            "decision_id": "RD04-PPN-ND-FU-ABAWD-OR-WORK-REQUIREMENT-WAIVER-STATE-AND-GOVERNING-PERIOD",
            "supersedes_or_refines_decision_id": ROUTES["RD04-W03-PPN-ND-FU-002"]["target_decision_id"],
            "unit_id": "US-STATE-ND",
            "postal_code": "ND",
            "state_name": "North Dakota",
            "field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
            "disposition": "temporal_or_scope_ambiguity_hold_open",
            "promotion_candidate": False,
            "bounded_finding": waiver_finding,
            "source_route_ids": ["RD04-W03-PPN-ND-FU-002"],
            "evidence_locators": [
                {"route_id": "RD04-W03-PPN-ND-FU-002", "anchor": "Previous Versions of 403 Geographic Waiver"},
                {"route_id": "RD04-W03-PPN-ND-FU-002", "anchor": "Release 25.2-25.6 Effective 7/1/2025 - 10/31/2025"},
                {"route_id": "RD04-W03-PPN-ND-FU-002", "anchor": "Release 25.1 - Effective 5/15/2025 - 7/1/2025"},
            ],
            "current_cell_state": waiver_cell["state"],
            "current_cell_terminal": waiver_cell["terminal"],
            "current_cell_canonical_sha256": canonical_sha(waiver_cell),
            "current_row_canonical_sha256": row_hash,
            "limitations": [
                "a previous-versions history log is not an affirmative statement of current waiver geography or governing period",
                "the historical periods cannot be carried forward beyond October 31, 2025",
            ],
            "prohibited_inferences": [
                "do_not_count_duplicate_transport_as_independent_substantive_support",
                "do_not_infer_current_no_waiver_state_from_previous_versions",
                "do_not_infer_uniform_frontline_practice",
                "do_not_infer_person_level_outcome",
                "do_not_infer_national_prevalence",
                "do_not_infer_discrimination_or_racial_order",
                "do_not_infer_coordination_or_common_purpose",
                "do_not_infer_complete_compact",
                "do_not_close_rd04_c02",
            ],
            "rationale_code": "official_history_log_ends_at_2025_10_31_and_does_not_state_current_post_period_waiver_geography",
            "selected_followup_route_ids": [],
            "result_spawned_requests": 0,
            "field_classification_effect": "none",
            "substantive_field_terminalizations": 0,
            "row_state_effect": "none",
            "class_closed": False,
            "outside_human_dependency": False,
            "publication_effect": "none",
            "adoption_effect": "none",
            "graph_effect": "none",
        },
    ]

    candidate_id = "RD04-PPN-ND-FU-CANDIDATE-OPERATIVE-STATE-IMPLEMENTATION-AUTHORITY-AND-VERSION"
    artifact_custody = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-artifact-custody@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "canonical_main": CANONICAL_MAIN,
        "canonical_tree": CANONICAL_TREE,
        "protocol_path": PROTOCOL_PATH.as_posix(),
        "protocol_blob": PROTOCOL_BLOB,
        "authoritative_artifact": AUTH_ARTIFACT,
        "duplicate_artifact": DUP_ARTIFACT,
        "route_count": 2,
        "transport_observation_count": 4,
        "unique_body_identity_count": 2,
        "substantive_source_weight_count": 2,
        "duplicate_transport_substantive_weight_effect": "none",
        "route_body_identity": custody_rows,
        "additional_execution_authorized": False,
        "authority_boundary": AUTHORITY,
    }
    source_adjudications = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-source-adjudication@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "artifact_custody_object": "artifact-custody.json",
        "summary": {
            "source_decisions": 2,
            "narrow_source_admissions": 2,
            "transport_observations": 4,
            "unique_body_identities": 2,
            "duplicate_transport_observations": 2,
            "substantive_weight_count": 2,
        },
        "decisions": source_decisions,
        "authority_boundary": AUTHORITY,
    }
    field_adjudications = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-field-adjudication@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "summary": {
            "field_decisions": 2,
            "evidence_complete_candidates": 1,
            "held_open_fields": 1,
            "source_admissions_created": 2,
            "substantive_field_terminalizations": 0,
            "matrix_updates": 0,
            "row_state_mutations": 0,
        },
        "frontier": {
            "terminal_matrix_cells_before": 226,
            "still_open_matrix_cells_before": 224,
            "open_substantive_cells_before": 184,
            "terminal_units_before": 10,
            "held_north_dakota_cells_before": 2,
        },
        "decisions": field_decisions,
        "authority_boundary": AUTHORITY,
    }
    promotion_candidate_protocol = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-promotion-candidate-protocol@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "candidate_count": 1,
        "unique_candidate_cell_count": 1,
        "held_cell_count": 1,
        "candidates": [
            {
                "candidate_ordinal": 1,
                "candidate_id": candidate_id,
                "decision_id": field_decisions[0]["decision_id"],
                "unit_id": "US-STATE-ND",
                "postal_code": "ND",
                "state_name": "North Dakota",
                "field_id": field_decisions[0]["field_id"],
                "bounded_finding": authority_finding,
                "source_route_ids": field_decisions[0]["source_route_ids"],
                "evidence_locators": field_decisions[0]["evidence_locators"],
                "current_cell_requirement": "must_remain_still_open_on_exact_promotion_parent",
                "current_cell_state": "still_open",
                "promotion_effect_authorized_here": "none",
                "row_state_effect": "none",
                "class_closed": False,
                "cumulative_ledger_effect": "none",
            }
        ],
        "held_decision": {
            "decision_id": field_decisions[1]["decision_id"],
            "field_id": field_decisions[1]["field_id"],
            "disposition": field_decisions[1]["disposition"],
            "current_post_period_state": waiver_finding["current_post_period_state"],
        },
        "promotion_preconditions": [
            "exact current matrix parent and North Dakota target cell are reauthenticated",
            "the candidate cell remains still_open",
            "authoritative artifact and source-body identities remain unchanged",
            "duplicate transport receives zero independent substantive weight",
            "promotion occurs in a separate permanent one-cell product",
            "the waiver-state hold does not enter the promotion denominator",
        ],
        "matrix_updates": 0,
        "field_terminalizations": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
    }
    source_text_custody = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-source-text-custody@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "authoritative_artifact_id": AUTH_ARTIFACT["artifact_id"],
        "routes": text_rows,
        "source_requests": 0,
        "outside_human_dependency": False,
    }
    adjudication_summary = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-adjudication-summary@1",
        "wave_id": "SSC-RD-W03",
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "issue": 1017,
        "source_admissions": 2,
        "field_decisions": 2,
        "promotion_candidates": 1,
        "held_open_fields": 1,
        "duplicate_transport_observations": 2,
        "duplicate_transport_substantive_weight_effect": "none",
        "current_matrix": {
            "materialized_cells": 450,
            "terminal_cells": 226,
            "still_open_cells": 224,
            "still_open_substantive_cells": 184,
            "terminal_units": 10,
        },
        "projected_separate_promotion": {
            "terminal_cells_before": 226,
            "terminal_cells_after": 227,
            "still_open_cells_before": 224,
            "still_open_cells_after": 223,
            "still_open_substantive_cells_before": 184,
            "still_open_substantive_cells_after": 183,
            "terminal_units_before": 10,
            "terminal_units_after": 10,
        },
        "matrix_updates": 0,
        "field_terminalizations": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "next_authorized_operation": "validate the one promotion candidate against the exact current cell, then construct a separate permanent one-cell promotion product; preserve the North Dakota waiver-state field as a typed-gap hold and authorize no further source request here",
    }

    return {
        "artifact_custody": artifact_custody,
        "source_adjudications": source_adjudications,
        "field_adjudications": field_adjudications,
        "promotion_candidate_protocol": promotion_candidate_protocol,
        "source_text_custody": source_text_custody,
        "adjudication_summary": adjudication_summary,
    }


def run_mutations(product: dict[str, Any]) -> dict[str, Any]:
    mutations: list[tuple[str, Any]] = [
        ("alter authoritative artifact", lambda p: p["artifact_custody"]["authoritative_artifact"].__setitem__("artifact_id", 1)),
        ("alter authoritative zip digest", lambda p: p["artifact_custody"]["authoritative_artifact"].__setitem__("artifact_zip_sha256", "0" * 64)),
        ("alter duplicate artifact", lambda p: p["artifact_custody"]["duplicate_artifact"].__setitem__("artifact_id", 1)),
        ("claim duplicate body drift", lambda p: p["artifact_custody"]["route_body_identity"][0].__setitem__("duplicate_body_byte_identical", False)),
        ("double duplicate substantive weight", lambda p: p["artifact_custody"]["route_body_identity"][0].__setitem__("substantive_weight_count", 2)),
        ("increase unique bodies", lambda p: p["artifact_custody"].__setitem__("unique_body_identity_count", 4)),
        ("drop source decision", lambda p: p["source_adjudications"]["decisions"].pop()),
        ("decrease source admissions", lambda p: p["source_adjudications"]["summary"].__setitem__("narrow_source_admissions", 1)),
        ("deny source admission", lambda p: p["source_adjudications"]["decisions"][0].__setitem__("source_admitted_for_narrow_scope", False)),
        ("widen release log target", lambda p: p["source_adjudications"]["decisions"][0]["candidate_fields_for_offline_review"].append("implementation_effective_date_or_typed_gap")),
        ("alter release log body", lambda p: p["source_adjudications"]["decisions"][0].__setitem__("body_sha256", "0" * 64)),
        ("count duplicate as two weights", lambda p: p["source_adjudications"]["decisions"][0].__setitem__("substantive_weight_count", 2)),
        ("drop field decision", lambda p: p["field_adjudications"]["decisions"].pop()),
        ("deny authority candidate", lambda p: p["field_adjudications"]["decisions"][0].__setitem__("promotion_candidate", False)),
        ("change release number", lambda p: p["field_adjudications"]["decisions"][0]["bounded_finding"].__setitem__("latest_visible_release", "26.6")),
        ("change release date", lambda p: p["field_adjudications"]["decisions"][0]["bounded_finding"].__setitem__("latest_visible_effective_date", "2026-07-01")),
        ("claim every section revised", lambda p: p["field_adjudications"]["decisions"][0]["bounded_finding"].__setitem__("every_section_revised_in_latest_release", True)),
        ("promote waiver hold", lambda p: p["field_adjudications"]["decisions"][1].__setitem__("promotion_candidate", True)),
        ("invent current waiver state", lambda p: p["field_adjudications"]["decisions"][1]["bounded_finding"].__setitem__("current_post_period_state", "no_approved_waiver_areas")),
        ("change historical period end", lambda p: p["field_adjudications"]["decisions"][1]["bounded_finding"].__setitem__("latest_historical_period_end", "2025-11-01")),
        ("create field terminalization", lambda p: p["field_adjudications"]["decisions"][0].__setitem__("substantive_field_terminalizations", 1)),
        ("candidate count drift", lambda p: p["promotion_candidate_protocol"].__setitem__("candidate_count", 2)),
        ("held count drift", lambda p: p["promotion_candidate_protocol"].__setitem__("held_cell_count", 0)),
        ("alter candidate finding", lambda p: p["promotion_candidate_protocol"]["candidates"][0]["bounded_finding"].__setitem__("finding_summary", "widened")),
        ("matrix update", lambda p: p["adjudication_summary"].__setitem__("matrix_updates", 1)),
        ("field terminalization", lambda p: p["adjudication_summary"].__setitem__("field_terminalizations", 1)),
        ("row mutation", lambda p: p["adjudication_summary"].__setitem__("row_state_mutations", 1)),
        ("class closure", lambda p: p["adjudication_summary"].__setitem__("class_closed", True)),
        ("ledger effect", lambda p: p["adjudication_summary"].__setitem__("cumulative_ledger_effect", "closed_one_class")),
        ("outside human", lambda p: p["adjudication_summary"].__setitem__("outside_human_dependency", True)),
        ("publication effect", lambda p: p["adjudication_summary"].__setitem__("publication_effect", "published")),
        ("wrong current matrix", lambda p: p["adjudication_summary"]["current_matrix"].__setitem__("terminal_cells", 227)),
        ("wrong projection", lambda p: p["adjudication_summary"]["projected_separate_promotion"].__setitem__("terminal_cells_after", 228)),
        ("alter visible text digest", lambda p: p["source_text_custody"]["routes"][0].__setitem__("visible_text_sha256", "0" * 64)),
        ("invent current text on history log", lambda p: p["source_text_custody"]["routes"][1].__setitem__("current_post_period_state", "current_no_waiver")),
    ]
    refused = 0
    for name, mutate in mutations:
        candidate = copy.deepcopy(product)
        mutate(candidate)
        try:
            validate_product(candidate)
        except (AssertionError, KeyError, IndexError, TypeError):
            refused += 1
        else:
            raise AssertionError(f"adversarial mutation admitted: {name}")
    return {"adversarial_refusals": refused, "mutation_names": [name for name, _ in mutations]}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--authoritative-root", required=True, type=pathlib.Path)
    parser.add_argument("--duplicate-root", required=True, type=pathlib.Path)
    parser.add_argument("--output-root", required=True, type=pathlib.Path)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)

    inventory = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-input-inventory@1",
        "canonical_main": CANONICAL_MAIN,
        "canonical_tree": CANONICAL_TREE,
        "repository_inputs": [
            file_identity(PROTOCOL_PATH, PROTOCOL_BLOB),
            file_identity(FIELD_PATH, FIELD_BLOB),
            file_identity(SOURCE_PATH, SOURCE_BLOB),
            file_identity(MATRIX_PATH, MATRIX_BLOB),
            file_identity(SUMMARY_PATH, SUMMARY_BLOB),
        ],
        "authoritative_artifact": AUTH_ARTIFACT,
        "duplicate_artifact": DUP_ARTIFACT,
    }
    product = build_product(args.authoritative_root, args.duplicate_root)
    validate_product(product)
    adversarial = run_mutations(product)

    output_names = {
        "artifact_custody": "artifact-custody.json",
        "source_adjudications": "source-adjudications.json",
        "field_adjudications": "field-adjudications.json",
        "promotion_candidate_protocol": "promotion-candidate-protocol.json",
        "source_text_custody": "source-text-custody.json",
        "adjudication_summary": "adjudication-summary.json",
    }
    for key, filename in output_names.items():
        write_json(args.output_root / filename, product[key])
    write_json(args.output_root / "input-inventory.json", inventory)
    write_json(args.output_root / "adversarial-refusals.json", adversarial)

    output_inventory = []
    for path in sorted(args.output_root.glob("*.json")):
        output_inventory.append(file_identity(path))
    receipt = {
        "schema_version": "ssc-rd04-postpromotion-nd-followup-artifact-only-adjudication-receipt@1",
        "state": "adjudicated",
        "failed_or_final_stage": "complete",
        "exit_code": 0,
        "canonical_main": CANONICAL_MAIN,
        "canonical_tree": CANONICAL_TREE,
        "authoritative_artifact_id": AUTH_ARTIFACT["artifact_id"],
        "duplicate_artifact_id": DUP_ARTIFACT["artifact_id"],
        "source_requests": 0,
        "artifact_downloads": 2,
        "source_admissions": 2,
        "field_decisions": 2,
        "promotion_candidates": 1,
        "held_open_fields": 1,
        "duplicate_transport_observations": 2,
        "duplicate_transport_substantive_weight_effect": "none",
        "adversarial_refusals": adversarial["adversarial_refusals"],
        "matrix_updates": 0,
        "field_terminalizations": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "additional_source_execution_authorized": False,
        "next_authorized_operation": "validate the single North Dakota release-boundary candidate against the exact current cell, then construct a separate permanent one-cell promotion product; preserve the North Dakota waiver-state field as a typed-gap hold",
        "output_inventory": output_inventory,
    }
    write_json(args.output_root / "adjudication-receipt.json", receipt)
    print(json.dumps({
        "state": receipt["state"],
        "source_admissions": receipt["source_admissions"],
        "promotion_candidates": receipt["promotion_candidates"],
        "held_open_fields": receipt["held_open_fields"],
        "adversarial_refusals": receipt["adversarial_refusals"],
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
