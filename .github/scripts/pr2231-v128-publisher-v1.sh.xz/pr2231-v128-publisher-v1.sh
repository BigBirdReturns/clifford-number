#!/usr/bin/env bash
set -Eeuo pipefail
export LC_ALL=C
export TZ=UTC

repo=BigBirdReturns/clifford-number
owner=BigBirdReturns
name=clifford-number
product_pr=2231
product_branch=agent/current-main-identifier-context-product-v1
product_ref=refs/heads/$product_branch
frozen_head=bd1523d86a562be91acdc175f73607dab0fcac09
frozen_main=5b992ba8b7573cc9a859ac0dcb0d5edd20ea81ed
frozen_tree=8252807a4b840ba20d69cd478c8fdb53a851a826
predecessor_library_blob=cdf13a780f97f42c64bdac2e745da52be44850a1
predecessor_test_blob=711003e4ce56e99cf51ceb0d8fd03df1e4473c31
candidate_commit=e0c772e962078878a1e4b659a861581cb2957a73
candidate_tree=24a1487dac3e221601b905fd696b4888444a0032
candidate_library_blob=b2aefcdc6a2ae6715c5ae9dd748c12310c57564f
candidate_test_blob=c76ea816162a2a47e1cbf3612322adc95cc60c4e
library_path=tools/lib/industrial-exhaust.mjs
test_path=test/industrial-exhaust.test.js
review_comments=(3912324673 3912338942 3912338949)
review_nodes=(
  PRRC_kwDOTGqftc7pMVZB
  PRRC_kwDOTGqftc7pMY3-
  PRRC_kwDOTGqftc7pMY4F
)
review_titles=(
  'Preserve a later phone-owned opener after the clean observation closer'
  'Compare embedded-email bounds in source coordinates'
  'Index token bounds before processing embedded emails'
)
review_source_head=73e4501c6da942ba326ecf146df1a71bbf953b25
out=/tmp/pr2231-v128-publisher-v1
qualification_out=/tmp/pr2231-v128-qualification-v1
qualification_work=/tmp/pr2231-v128-work-v1
rm -rf "$out"
mkdir -p "$out"
exec > >(tee -a "$out/publisher.log") 2>&1

preserve() {
  rc=$?
  trap - EXIT
  set +e
  printf 'exit_status=%s\nmode=exact-v128-leased-publication\n' "$rc" > "$out/status.env"
  find "$out" -type f ! -name artifact-sha256.txt -print0 \
    | sort -z | xargs -0 -r sha256sum > "$out/artifact-sha256.txt"
  find "$out" -type f -printf '%P\t%s\n' | sort > "$out/artifact-manifest.txt"
  exit "$rc"
}
trap preserve EXIT

require_equal() {
  local actual=$1 expected=$2 label=$3
  if [[ "$actual" != "$expected" ]]; then
    printf 'authority mismatch: %s\nexpected=%s\nactual=%s\n' "$label" "$expected" "$actual" >&2
    exit 1
  fi
}

thread_snapshot() {
  local destination=$1
  gh api graphql --paginate \
    -f query='query($owner:String!,$name:String!,$number:Int!,$endCursor:String){repository(owner:$owner,name:$name){pullRequest(number:$number){reviewThreads(first:100,after:$endCursor){nodes{id isResolved comments(first:100){nodes{databaseId}}}pageInfo{hasNextPage endCursor}}}}}' \
    -F owner="$owner" -F name="$name" -F number="$product_pr" \
    | jq -s '[.[].data.repository.pullRequest.reviewThreads.nodes[]] | sort_by(.id) | map({id,isResolved,comment_ids:(.comments.nodes | map(.databaseId) | sort)})' \
    > "$destination"
}

snapshot_state() {
  local label=$1
  gh api "repos/$repo/pulls/$product_pr" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/product-pr.$label.json"
  gh api "repos/$repo/pulls/$CONTROLLER_PR" \
    | jq '{state,draft,merged_at,head_sha:.head.sha,head_ref:.head.ref,base_sha:.base.sha,commits,changed_files,title,body}' \
    > "$out/controller-pr.$label.json"
  gh api "repos/$repo/git/ref/heads/main" --jq '.object.sha' > "$out/main-ref.$label.txt"
  gh api "repos/$repo/git/ref/heads/$product_branch" --jq '.object.sha' > "$out/product-ref.$label.txt"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,node_id,body,commit_id,path,line,start_line,side,in_reply_to_id,user:.user.login,updated_at})' \
    > "$out/review-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/reviews?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,state,commit_id,user:.user.login,submitted_at})' \
    > "$out/reviews.$label.json"
  gh api --paginate --slurp "repos/$repo/issues/$product_pr/comments?per_page=100" \
    | jq 'add | sort_by(.id) | map({id,body,user:.user.login,updated_at})' \
    > "$out/issue-comments.$label.json"
  gh api --paginate --slurp "repos/$repo/pulls/$product_pr/files?per_page=100" \
    | jq 'add | sort_by(.filename) | map({filename,status})' \
    > "$out/product-files.$label.json"
  thread_snapshot "$out/review-threads.$label.json"
}

verify_two_paths() {
  local file=$1
  require_equal "$(jq 'length' "$file")" 2 product-file-count
  require_equal "$(jq -r '.[0].filename' "$file")" "$test_path" product-file-1
  require_equal "$(jq -r '.[1].filename' "$file")" "$library_path" product-file-2
}

verify_p1_denominator() {
  local comments=$1 threads=$2
  for i in "${!review_comments[@]}"; do
    local id=${review_comments[$i]}
    local node=${review_nodes[$i]}
    local title=${review_titles[$i]}
    require_equal "$(jq --argjson id "$id" '[.[] | select(.id == $id)] | length' "$comments")" 1 "review-$id-count"
    require_equal "$(jq -r --argjson id "$id" '.[] | select(.id == $id) | .node_id' "$comments")" "$node" "review-$id-node"
    require_equal "$(jq -r --argjson id "$id" '.[] | select(.id == $id) | .commit_id' "$comments")" "$review_source_head" "review-$id-commit"
    require_equal "$(jq -r --argjson id "$id" '.[] | select(.id == $id) | .path' "$comments")" "$library_path" "review-$id-path"
    jq -er --argjson id "$id" --arg title "$title" '.[] | select(.id == $id) | .body | contains($title)' "$comments" >/dev/null
    require_equal "$(jq --argjson id "$id" '[.[] | select((.comment_ids | index($id)) != null)] | length' "$threads")" 1 "review-$id-thread-count"
    require_equal "$(jq -r --argjson id "$id" '.[] | select((.comment_ids | index($id)) != null) | .isResolved' "$threads")" false "review-$id-thread-resolution"
  done
}

verify_product_commit() {
  local sha=$1 tree=$2 library_blob=$3 test_blob=$4
  gh api "repos/$repo/git/commits/$sha" > "$out/product-commit-$sha.json"
  require_equal "$(jq -r '.tree.sha' "$out/product-commit-$sha.json")" "$tree" product-tree
  require_equal "$(jq -r '.parents[0].sha' "$out/product-commit-$sha.json")" "$frozen_main" product-parent
  require_equal "$(jq '.parents | length' "$out/product-commit-$sha.json")" 1 product-parent-count
  require_equal "$(gh api "repos/$repo/contents/$library_path?ref=$sha" --jq '.sha')" "$library_blob" product-library-blob
  require_equal "$(gh api "repos/$repo/contents/$test_path?ref=$sha" --jq '.sha')" "$test_blob" product-test-blob
}

require_equal "${CONTROLLER_BRANCH:-}" "${EXPECTED_CONTROLLER_BRANCH:-}" controller-branch-env
require_equal "$(git rev-parse HEAD)" "${EXPECTED_CONTROLLER:-}" controller-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.sha')" "$EXPECTED_CONTROLLER" controller-pr-head
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.head.ref')" "$EXPECTED_CONTROLLER_BRANCH" controller-pr-branch
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.draft')" true controller-draft
require_equal "$(gh api "repos/$repo/pulls/$CONTROLLER_PR" --jq '.state')" open controller-state

snapshot_state before
require_equal "$(cat "$out/main-ref.before.txt")" "$frozen_main" main-ref
require_equal "$(cat "$out/product-ref.before.txt")" "$frozen_head" product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.before.json")" "$frozen_head" product-pr-head
require_equal "$(jq -r '.head_ref' "$out/product-pr.before.json")" "$product_branch" product-pr-head-ref
require_equal "$(jq -r '.base_sha' "$out/product-pr.before.json")" "$frozen_main" product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.before.json")" open product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.before.json")" true product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.before.json")" '' product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.before.json")" 1 product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.before.json")" 2 product-pr-file-count
verify_two_paths "$out/product-files.before.json"
verify_p1_denominator "$out/review-comments.before.json" "$out/review-threads.before.json"
verify_product_commit "$frozen_head" "$frozen_tree" "$predecessor_library_blob" "$predecessor_test_blob"

# Ensure the exact frozen Git objects exist locally before the read-only replay.
git fetch --no-tags origin "$frozen_main" "$frozen_head"

bash .github/scripts/pr2231-v128-qualified-replay-v1.sh
source "$qualification_out/candidate.env"
require_equal "$candidate_commit" e0c772e962078878a1e4b659a861581cb2957a73 qualification-candidate
require_equal "$candidate_parent" "$frozen_main" qualification-parent
require_equal "$candidate_tree" 24a1487dac3e221601b905fd696b4888444a0032 qualification-tree
require_equal "$library_blob" "$candidate_library_blob" qualification-library-blob
require_equal "$test_blob" "$candidate_test_blob" qualification-test-blob
require_equal "$(git -C "$qualification_work/transplant" cat-file -t "$candidate_commit")" commit local-candidate-object

snapshot_state prepublication
cmp "$out/product-pr.before.json" "$out/product-pr.prepublication.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.prepublication.json"
cmp "$out/main-ref.before.txt" "$out/main-ref.prepublication.txt"
cmp "$out/product-ref.before.txt" "$out/product-ref.prepublication.txt"
cmp "$out/review-comments.before.json" "$out/review-comments.prepublication.json"
cmp "$out/reviews.before.json" "$out/reviews.prepublication.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.prepublication.json"
cmp "$out/product-files.before.json" "$out/product-files.prepublication.json"
cmp "$out/review-threads.before.json" "$out/review-threads.prepublication.json"
verify_p1_denominator "$out/review-comments.prepublication.json" "$out/review-threads.prepublication.json"

# The sole product mutation: exact qualified commit to the live PR head ref under the frozen lease.
git -C "$qualification_work/transplant" push \
  --force-with-lease="$product_ref:$frozen_head" \
  origin "$candidate_commit:$product_ref" \
  2>&1 | tee "$out/leased-push.log"

snapshot_state after
require_equal "$(cat "$out/main-ref.after.txt")" "$frozen_main" final-main-ref
require_equal "$(cat "$out/product-ref.after.txt")" "$candidate_commit" final-product-ref
require_equal "$(jq -r '.head_sha' "$out/product-pr.after.json")" "$candidate_commit" final-product-pr-head
require_equal "$(jq -r '.head_ref' "$out/product-pr.after.json")" "$product_branch" final-product-pr-head-ref
require_equal "$(jq -r '.base_sha' "$out/product-pr.after.json")" "$frozen_main" final-product-pr-base
require_equal "$(jq -r '.state' "$out/product-pr.after.json")" open final-product-pr-state
require_equal "$(jq -r '.draft' "$out/product-pr.after.json")" true final-product-pr-draft
require_equal "$(jq -r '.merged_at // ""' "$out/product-pr.after.json")" '' final-product-pr-merged
require_equal "$(jq -r '.commits' "$out/product-pr.after.json")" 1 final-product-pr-commit-count
require_equal "$(jq -r '.changed_files' "$out/product-pr.after.json")" 2 final-product-pr-file-count
verify_two_paths "$out/product-files.after.json"
verify_product_commit "$candidate_commit" "$candidate_tree" "$candidate_library_blob" "$candidate_test_blob"

jq 'del(.head_sha)' "$out/product-pr.before.json" > "$out/product-pr.before-without-head.json"
jq 'del(.head_sha)' "$out/product-pr.after.json" > "$out/product-pr.after-without-head.json"
cmp "$out/product-pr.before-without-head.json" "$out/product-pr.after-without-head.json"
cmp "$out/controller-pr.before.json" "$out/controller-pr.after.json"
cmp "$out/review-comments.before.json" "$out/review-comments.after.json"
cmp "$out/reviews.before.json" "$out/reviews.after.json"
cmp "$out/issue-comments.before.json" "$out/issue-comments.after.json"
cmp "$out/review-threads.before.json" "$out/review-threads.after.json"
cmp "$out/product-files.before.json" "$out/product-files.after.json"
verify_p1_denominator "$out/review-comments.after.json" "$out/review-threads.after.json"

cat > "$out/publication-terminal.txt" <<EOF
EXACT_LEASED_PRODUCT_PUBLICATION_CONFIRMED
PRODUCT_OLD_HEAD=$frozen_head
PRODUCT_NEW_HEAD=$candidate_commit
PRODUCT_PARENT=$frozen_main
PRODUCT_TREE=$candidate_tree
PRODUCT_LIBRARY_BLOB=$candidate_library_blob
PRODUCT_TEST_BLOB=$candidate_test_blob
MAIN_MUTATION_SKIPPED
REVIEW_MUTATION_SKIPPED
DRAFT_MUTATION_SKIPPED
MERGE_SKIPPED
QUALIFICATION_SUCCESS
EOF
cat "$out/publication-terminal.txt"
