#!/usr/bin/env bash
set -uo pipefail

rm -rf "$ARTIFACT_DIR" /tmp/pr2231-v101-product /tmp/pr2231-v101-index
mkdir -p "$ARTIFACT_DIR/qualified/test" "$ARTIFACT_DIR/qualified/tools/lib"
: > "$ARTIFACT_DIR/trace.txt"
printf '%s\n' STARTED > "$ARTIFACT_DIR/result.txt"

note() {
  printf '%s\n' "$*" | tee -a "$ARTIFACT_DIR/trace.txt"
  printf '::notice title=V101 leased publisher::%s\n' "$*"
}

fail() {
  note "FAIL:$*"
  printf '%s\n' "FAIL:$*" > "$ARTIFACT_DIR/result.txt"
  exit 1
}

require_equal() {
  local actual="$1"
  local expected="$2"
  local label="$3"
  [[ "$actual" == "$expected" ]] || {
    note "${label}_EXPECTED=$expected"
    note "${label}_ACTUAL=$actual"
    fail "$label"
  }
}

capture_pr_state() {
  local phase="$1"
  local expected_product_head="$2"
  local product_json="$ARTIFACT_DIR/product-pr-${phase}.json"
  local controller_json="$ARTIFACT_DIR/controller-pr-${phase}.json"

  gh api "repos/${GITHUB_REPOSITORY}/pulls/2231" > "$product_json" || fail "PRODUCT_PR_API_${phase}"
  gh api "repos/${GITHUB_REPOSITORY}/pulls/2391" > "$controller_json" || fail "CONTROLLER_PR_API_${phase}"

  python - "$product_json" "$controller_json" "$expected_product_head" "$EXPECTED_MAIN" "$CONTROLLER_SHA" <<'PY'
import json
from pathlib import Path
import sys

product_path, controller_path, expected_product, expected_main, expected_controller = sys.argv[1:]
product = json.loads(Path(product_path).read_text(encoding='utf-8'))
controller = json.loads(Path(controller_path).read_text(encoding='utf-8'))

def require(condition, label, actual=None):
    if not condition:
        if actual is not None:
            print(f'{label}_ACTUAL={actual!r}')
        raise SystemExit(f'PR_STATE_FAIL:{label}')

require(product.get('number') == 2231, 'PRODUCT_NUMBER', product.get('number'))
require(product.get('state') == 'open', 'PRODUCT_STATE', product.get('state'))
require(product.get('draft') is True, 'PRODUCT_DRAFT', product.get('draft'))
require(product.get('merged_at') is None, 'PRODUCT_MERGED_AT', product.get('merged_at'))
require(product.get('head', {}).get('ref') == 'agent/current-main-identifier-context-product-v1', 'PRODUCT_HEAD_REF', product.get('head', {}).get('ref'))
require(product.get('head', {}).get('sha') == expected_product, 'PRODUCT_HEAD_SHA', product.get('head', {}).get('sha'))
require(product.get('base', {}).get('ref') == 'main', 'PRODUCT_BASE_REF', product.get('base', {}).get('ref'))
require(product.get('base', {}).get('sha') == expected_main, 'PRODUCT_BASE_SHA', product.get('base', {}).get('sha'))
require(product.get('commits') == 1, 'PRODUCT_COMMIT_COUNT', product.get('commits'))
require(product.get('changed_files') == 2, 'PRODUCT_CHANGED_FILES', product.get('changed_files'))

require(controller.get('number') == 2391, 'CONTROLLER_NUMBER', controller.get('number'))
require(controller.get('state') == 'open', 'CONTROLLER_STATE', controller.get('state'))
require(controller.get('draft') is True, 'CONTROLLER_DRAFT', controller.get('draft'))
require(controller.get('merged_at') is None, 'CONTROLLER_MERGED_AT', controller.get('merged_at'))
require(controller.get('head', {}).get('ref') == 'agent/pr2231-cumulative-custody-controller-v92', 'CONTROLLER_HEAD_REF', controller.get('head', {}).get('ref'))
require(controller.get('head', {}).get('sha') == expected_controller, 'CONTROLLER_HEAD_SHA', controller.get('head', {}).get('sha'))
require(controller.get('base', {}).get('ref') == 'main', 'CONTROLLER_BASE_REF', controller.get('base', {}).get('ref'))
print('PR_STATE_SUCCESS')
PY
  status=$?
  [[ "$status" -eq 0 ]] || fail "PR_STATE_${phase}"
  note "PR_STATE_${phase}_SUCCESS"
}

capture_review_state() {
  local phase="$1"
  local raw="$ARTIFACT_DIR/review-threads-${phase}.json"
  local selected="$ARTIFACT_DIR/review-threads-selected-${phase}.json"
  local digest="$ARTIFACT_DIR/review-threads-${phase}.sha256"
  local owner="${GITHUB_REPOSITORY%%/*}"
  local repo="${GITHUB_REPOSITORY#*/}"

  gh api graphql \
    -f owner="$owner" \
    -f name="$repo" \
    -F number=2231 \
    -f query='query($owner:String!, $name:String!, $number:Int!) {
      repository(owner:$owner, name:$name) {
        pullRequest(number:$number) {
          reviewThreads(first:100) {
            nodes {
              id
              isResolved
              comments(first:100) {
                nodes { databaseId }
              }
            }
          }
        }
      }
    }' > "$raw" || fail "REVIEW_GRAPHQL_${phase}"

  python - "$raw" "$selected" "$digest" <<'PY'
import hashlib
import json
from pathlib import Path
import sys

raw_path, selected_path, digest_path = map(Path, sys.argv[1:])
expected = {
    'PRRT_kwDOTGqftc6dYT9g': 3885970995,
    'PRRT_kwDOTGqftc6dYT9i': 3885970997,
    'PRRT_kwDOTGqftc6dYT9j': 3885970998,
    'PRRT_kwDOTGqftc6dYVMi': 3885978331,
    'PRRT_kwDOTGqftc6dbRfO': 3887137144,
    'PRRT_kwDOTGqftc6dbRfP': 3887137145,
    'PRRT_kwDOTGqftc6dbRfR': 3887137149,
}
raw = json.loads(raw_path.read_text(encoding='utf-8'))
threads = raw.get('data', {}).get('repository', {}).get('pullRequest', {}).get('reviewThreads', {}).get('nodes', [])
by_id = {thread.get('id'): thread for thread in threads}
selected = []
for thread_id, comment_id in sorted(expected.items()):
    thread = by_id.get(thread_id)
    if thread is None:
        raise SystemExit(f'REVIEW_STATE_FAIL:MISSING_THREAD:{thread_id}')
    if thread.get('isResolved') is not False:
        raise SystemExit(f'REVIEW_STATE_FAIL:RESOLVED_THREAD:{thread_id}')
    comment_ids = {
        node.get('databaseId')
        for node in thread.get('comments', {}).get('nodes', [])
    }
    if comment_id not in comment_ids:
        raise SystemExit(f'REVIEW_STATE_FAIL:MISSING_COMMENT:{thread_id}:{comment_id}')
    selected.append({
        'thread_id': thread_id,
        'is_resolved': False,
        'bound_comment_database_id': comment_id,
    })
encoded = (json.dumps(selected, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')
selected_path.write_bytes(encoded)
digest_path.write_text(hashlib.sha256(encoded).hexdigest() + '\n', encoding='ascii')
print(f'REVIEW_THREAD_COUNT={len(selected)}')
print(f'REVIEW_THREAD_DIGEST={hashlib.sha256(encoded).hexdigest()}')
PY
  status=$?
  [[ "$status" -eq 0 ]] || fail "REVIEW_STATE_${phase}"
  note "REVIEW_THREAD_COUNT_${phase}=7"
  note "REVIEW_THREAD_DIGEST_${phase}=$(cat "$digest")"
}

note BOOTSTRAP_BIND_STARTED
actual_checkout="$(git rev-parse HEAD)" || fail RESOLVE_CHECKOUT_HEAD
require_equal "$actual_checkout" "$CONTROLLER_SHA" CONTROLLER_CHECKOUT_SHA
actual_script_blob="$(git rev-parse "${CONTROLLER_SHA}:${PUBLISHER_SCRIPT_PATH}")" || fail RESOLVE_PUBLISHER_SCRIPT_BLOB
actual_payload_blob="$(git rev-parse "${CONTROLLER_SHA}:${PAYLOAD_PATH}")" || fail RESOLVE_PAYLOAD_BLOB
require_equal "$actual_script_blob" "$EXPECTED_PUBLISHER_SCRIPT_BLOB" PUBLISHER_SCRIPT_BLOB
require_equal "$actual_payload_blob" "$EXPECTED_PAYLOAD_BLOB" PAYLOAD_BLOB
printf '%s\n' "$actual_script_blob" > "$ARTIFACT_DIR/publisher-script.blob"
printf '%s\n' "$actual_payload_blob" > "$ARTIFACT_DIR/payload.blob"
printf '%s\n' "$CONTROLLER_SHA" > "$ARTIFACT_DIR/controller.sha"
note "CONTROLLER_SHA=$CONTROLLER_SHA"
note "PUBLISHER_SCRIPT_BLOB=$actual_script_blob"
note "PAYLOAD_BLOB=$actual_payload_blob"

note QUALIFICATION_RECEIPT_BIND_STARTED
gh api "repos/${GITHUB_REPOSITORY}/actions/runs/${QUALIFICATION_RUN_ID}" > "$ARTIFACT_DIR/v100-run.json" || fail V100_RUN_API
gh api "repos/${GITHUB_REPOSITORY}/actions/artifacts/${QUALIFICATION_ARTIFACT_ID}" > "$ARTIFACT_DIR/v100-artifact.json" || fail V100_ARTIFACT_API
python - "$ARTIFACT_DIR/v100-run.json" "$ARTIFACT_DIR/v100-artifact.json" <<'PY'
import json
from pathlib import Path
import sys
run = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
artifact = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
checks = {
    'RUN_ID': run.get('id') == 33288385779,
    'RUN_STATUS': run.get('status') == 'completed',
    'RUN_CONCLUSION': run.get('conclusion') == 'success',
    'RUN_HEAD_SHA': run.get('head_sha') == '6fa9a44304ab8540ad188e20eaf768a6eb1640c7',
    'ARTIFACT_ID': artifact.get('id') == 9725178535,
    'ARTIFACT_NAME': artifact.get('name') == 'pr2231-current-line-v100-exact-qualification',
    'ARTIFACT_EXPIRED': artifact.get('expired') is False,
    'ARTIFACT_DIGEST': artifact.get('digest') == 'sha256:a9c79ce7b7c74469d7c721c3692a37093c1857af16247ed81d5fc9891246ab60',
    'ARTIFACT_HEAD_SHA': artifact.get('workflow_run', {}).get('head_sha') == '6fa9a44304ab8540ad188e20eaf768a6eb1640c7',
    'ARTIFACT_RUN_ID': artifact.get('workflow_run', {}).get('id') == 33288385779,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit('QUALIFICATION_RECEIPT_FAIL:' + ','.join(failed))
print('QUALIFICATION_RECEIPT_SUCCESS')
PY
status=$?
[[ "$status" -eq 0 ]] || fail QUALIFICATION_RECEIPT
note QUALIFICATION_RECEIPT_BIND_SUCCESS

note PREQUALIFICATION_LEASE_BIND_STARTED
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
  "+refs/heads/${CONTROLLER_BRANCH}:refs/remotes/origin/${CONTROLLER_BRANCH}" || fail INITIAL_FETCH
actual_main="$(git rev-parse refs/remotes/origin/main)" || fail RESOLVE_MAIN
actual_product="$(git rev-parse refs/remotes/origin/${PRODUCT_BRANCH})" || fail RESOLVE_PRODUCT
actual_controller="$(git rev-parse refs/remotes/origin/${CONTROLLER_BRANCH})" || fail RESOLVE_CONTROLLER
actual_parent="$(git rev-parse "${EXPECTED_PRODUCT}^")" || fail RESOLVE_PRODUCT_PARENT
actual_product_tree="$(git rev-parse "${EXPECTED_PRODUCT}^{tree}")" || fail RESOLVE_PRODUCT_TREE
ahead_count="$(git rev-list --count "${EXPECTED_MAIN}..${EXPECTED_PRODUCT}")" || fail COUNT_PRODUCT_AHEAD
behind_count="$(git rev-list --count "${EXPECTED_PRODUCT}..${EXPECTED_MAIN}")" || fail COUNT_PRODUCT_BEHIND
base_library="$(git rev-parse "${EXPECTED_MAIN}:tools/lib/industrial-exhaust.mjs")" || fail RESOLVE_BASE_LIBRARY
base_test="$(git rev-parse "${EXPECTED_MAIN}:test/industrial-exhaust.test.js")" || fail RESOLVE_BASE_TEST
predecessor_library="$(git rev-parse "${EXPECTED_PRODUCT}:tools/lib/industrial-exhaust.mjs")" || fail RESOLVE_PREDECESSOR_LIBRARY
predecessor_test="$(git rev-parse "${EXPECTED_PRODUCT}:test/industrial-exhaust.test.js")" || fail RESOLVE_PREDECESSOR_TEST

require_equal "$actual_main" "$EXPECTED_MAIN" MAIN_LEASE
require_equal "$actual_product" "$EXPECTED_PRODUCT" PRODUCT_LEASE
require_equal "$actual_controller" "$CONTROLLER_SHA" CONTROLLER_LEASE
require_equal "$actual_parent" "$EXPECTED_MAIN" PRODUCT_PARENT
require_equal "$actual_product_tree" "$EXPECTED_PREDECESSOR_TREE" PREDECESSOR_TREE
require_equal "$ahead_count" 1 PRODUCT_AHEAD_COUNT
require_equal "$behind_count" 0 PRODUCT_BEHIND_COUNT
require_equal "$base_library" "$EXPECTED_BASE_LIBRARY_BLOB" BASE_LIBRARY_BLOB
require_equal "$base_test" "$EXPECTED_BASE_FOCUSED_TEST_BLOB" BASE_FOCUSED_TEST_BLOB
require_equal "$predecessor_library" "$EXPECTED_PREDECESSOR_LIBRARY_BLOB" PREDECESSOR_LIBRARY_BLOB
require_equal "$predecessor_test" "$EXPECTED_PREDECESSOR_FOCUSED_TEST_BLOB" PREDECESSOR_FOCUSED_TEST_BLOB

printf '%s\n' "$actual_main" > "$ARTIFACT_DIR/main-before.sha"
printf '%s\n' "$actual_product" > "$ARTIFACT_DIR/product-before.sha"
printf '%s\n' "$actual_controller" > "$ARTIFACT_DIR/controller-before.sha"
printf '%s\n' "$actual_parent" > "$ARTIFACT_DIR/product-parent-before.sha"
printf '%s\n' "$actual_product_tree" > "$ARTIFACT_DIR/product-tree-before.sha"
printf '%s\n' "$base_library" > "$ARTIFACT_DIR/base-library.blob"
printf '%s\n' "$base_test" > "$ARTIFACT_DIR/base-focused-test.blob"
printf '%s\n' "$predecessor_library" > "$ARTIFACT_DIR/predecessor-library.blob"
printf '%s\n' "$predecessor_test" > "$ARTIFACT_DIR/predecessor-focused-test.blob"

capture_pr_state before "$EXPECTED_PRODUCT"
capture_review_state before
review_digest_before="$(cat "$ARTIFACT_DIR/review-threads-before.sha256")"
note PREQUALIFICATION_LEASE_BIND_SUCCESS

note PRODUCT_WORKTREE_STARTED
git worktree add --detach /tmp/pr2231-v101-product "$EXPECTED_PRODUCT" || fail ADD_PRODUCT_WORKTREE
cd /tmp/pr2231-v101-product || fail ENTER_PRODUCT_WORKTREE
note PRODUCT_WORKTREE_SUCCESS

note PREDECESSOR_REPRODUCTION_STARTED
node --input-type=module > "$ARTIFACT_DIR/predecessor-reproduction.txt" 2>&1 <<'NODE'
import assert from 'node:assert/strict';
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';
const witnesses = [
  ['Archive 03-6216-8041-3.14', 'Archive 03-6216-8041-3.14'],
  ['Phone: 09012345678 03.6216.8041', 'Phone: [contact omitted] 03.6216.8041'],
  ['Archive +81 3 6216 8041–3.14', 'Archive [contact omitted]']
];
for (const [input, expected] of witnesses) {
  const actual = redactContactData(input);
  console.log(JSON.stringify({ input, expected, actual }));
  assert.equal(actual, expected);
}
console.log('V101_PREDECESSOR_REPRODUCTION_SUCCESS');
NODE
status=$?
cat "$ARTIFACT_DIR/predecessor-reproduction.txt"
[[ "$status" -eq 0 ]] || fail PREDECESSOR_REPRODUCTION
note PREDECESSOR_REPRODUCTION_SUCCESS

note MUTATOR_RECOVERY_STARTED
base64 -d "$GITHUB_WORKSPACE/$PAYLOAD_PATH" | gzip -dc > /tmp/pr2231-v101.py || fail MUTATOR_DECODE
actual_mutator_sha="$(sha256sum /tmp/pr2231-v101.py | awk '{print $1}')" || fail MUTATOR_HASH
printf '%s\n' "$actual_mutator_sha" > "$ARTIFACT_DIR/mutator.sha256"
require_equal "$actual_mutator_sha" "$EXPECTED_MUTATOR_SHA256" MUTATOR_SHA256
python -W error -m py_compile /tmp/pr2231-v101.py > "$ARTIFACT_DIR/python-compile.log" 2>&1 || {
  cat "$ARTIFACT_DIR/python-compile.log"
  fail PYTHON_COMPILE
}
note MUTATOR_RECOVERY_SUCCESS

note MUTATOR_EXECUTION_STARTED
python /tmp/pr2231-v101.py > "$ARTIFACT_DIR/mutator.log" 2>&1
status=$?
cat "$ARTIFACT_DIR/mutator.log"
[[ "$status" -eq 0 ]] || fail MUTATOR_EXECUTION
git diff --check > "$ARTIFACT_DIR/diff-check.log" 2>&1 || {
  cat "$ARTIFACT_DIR/diff-check.log"
  fail DIFF_CHECK
}
git diff --name-only | sort > "$ARTIFACT_DIR/changed-paths.txt" || fail LIST_CHANGED_PATHS
mapfile -t changed_paths < "$ARTIFACT_DIR/changed-paths.txt"
require_equal "${#changed_paths[@]}" 2 CHANGED_PATH_COUNT
require_equal "${changed_paths[0]}" test/industrial-exhaust.test.js FIRST_CHANGED_PATH
require_equal "${changed_paths[1]}" tools/lib/industrial-exhaust.mjs SECOND_CHANGED_PATH
node --check tools/lib/industrial-exhaust.mjs > "$ARTIFACT_DIR/node-check.log" 2>&1 || {
  cat "$ARTIFACT_DIR/node-check.log"
  fail NODE_CHECK
}
candidate_library="$(git hash-object tools/lib/industrial-exhaust.mjs)" || fail HASH_CANDIDATE_LIBRARY
candidate_test="$(git hash-object test/industrial-exhaust.test.js)" || fail HASH_CANDIDATE_TEST
require_equal "$candidate_library" "$EXPECTED_CANDIDATE_LIBRARY_BLOB" CANDIDATE_LIBRARY_BLOB
require_equal "$candidate_test" "$EXPECTED_CANDIDATE_FOCUSED_TEST_BLOB" CANDIDATE_FOCUSED_TEST_BLOB
printf '%s\n' "$candidate_library" > "$ARTIFACT_DIR/candidate-library.blob"
printf '%s\n' "$candidate_test" > "$ARTIFACT_DIR/candidate-focused-test.blob"
note "CANDIDATE_LIBRARY_BLOB=$candidate_library"
note "CANDIDATE_FOCUSED_TEST_BLOB=$candidate_test"

note CANDIDATE_WITNESSES_STARTED
node --input-type=module > "$ARTIFACT_DIR/candidate-witnesses.txt" 2>&1 <<'NODE'
import assert from 'node:assert/strict';
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';
const witnesses = [
  ['synthetic-ascii', 'Archive 03-6216-8041-3.14', 'Archive [contact omitted]-3.14'],
  ['synthetic-fullwidth', 'Archive ０３－６２１６－８０４１－３．１４', 'Archive [contact omitted]－３．１４'],
  ['synthetic-endash', 'Archive 03-6216-8041–3.14', 'Archive [contact omitted]–3.14'],
  ['dotted-second-domestic', 'Phone: 09012345678 03.6216.8041', 'Phone: [contact omitted] [contact omitted]'],
  ['dotted-second-mobile', 'Phone: 09012345678 050.1234.5678', 'Phone: [contact omitted] [contact omitted]'],
  ['dotted-second-fullwidth', '電話番号：０９０１２３４５６７８ ０３．６２１６．８０４１', '電話番号：[contact omitted] [contact omitted]'],
  ['dash-observation-endash', 'Archive +81 3 6216 8041–3.14', 'Archive [contact omitted]–3.14'],
  ['dash-observation-emdash', 'Archive +81 3 6216 8041—3.14', 'Archive [contact omitted]—3.14'],
  ['dash-observation-fullwidth', 'Archive ＋８１ ３ ６２１６ ８０４１—３．１４', 'Archive [contact omitted]—３．１４'],
  ['calendar-year-first', 'Archive 2024-02-29', 'Archive 2024-02-29'],
  ['calendar-day-first', 'Archive 29-02-2024', 'Archive 29-02-2024'],
  ['calendar-dotted', 'Archive 03.04.2026', 'Archive 03.04.2026']
];
for (const [name, input, expected] of witnesses) {
  const actual = redactContactData(input);
  console.log(JSON.stringify({ name, input, expected, actual, pass: actual === expected }));
  assert.equal(actual, expected, name);
}
console.log(`V101_WITNESS_COUNT=${witnesses.length}`);
console.log('V101_CANDIDATE_WITNESSES_SUCCESS');
NODE
status=$?
cat "$ARTIFACT_DIR/candidate-witnesses.txt"
[[ "$status" -eq 0 ]] || fail CANDIDATE_WITNESSES
cp tools/lib/industrial-exhaust.mjs /tmp/pr2231-v101-qualified-library.mjs || fail COPY_QUALIFIED_LIBRARY
cp test/industrial-exhaust.test.js /tmp/pr2231-v101-qualified-focused-test.js || fail COPY_QUALIFIED_TEST
note CANDIDATE_WITNESSES_SUCCESS

note TESTS_STARTED
shopt -s nullglob
tests=(test/industrial-exhaust*.test.js)
[[ "${#tests[@]}" -gt 0 ]] || fail NO_FOCUSED_TESTS
: > "$ARTIFACT_DIR/test-files.txt"
for test_file in "${tests[@]}"; do
  printf '%s\n' "$test_file" >> "$ARTIFACT_DIR/test-files.txt"
  note "TEST_STARTED=$test_file"
  test_log="$ARTIFACT_DIR/$(basename "$test_file").log"
  node "$test_file" > "$test_log" 2>&1
  status=$?
  cat "$test_log"
  [[ "$status" -eq 0 ]] || fail "TEST_FAILED=$test_file"
  note "TEST_SUCCESS=$test_file"
done
note RELEASE_CHECK_STARTED
npm run release:check > "$ARTIFACT_DIR/release-check.log" 2>&1
status=$?
cat "$ARTIFACT_DIR/release-check.log"
[[ "$status" -eq 0 ]] || fail RELEASE_CHECK
note RELEASE_CHECK_SUCCESS
note TESTS_SUCCESS

note GENERATED_STATE_RESTORE_STARTED
git restore --source="$EXPECTED_PRODUCT" --staged --worktree -- . || fail RESTORE_PRODUCT
git clean -fd > "$ARTIFACT_DIR/git-clean.log" 2>&1 || {
  cat "$ARTIFACT_DIR/git-clean.log"
  fail GIT_CLEAN
}
cp /tmp/pr2231-v101-qualified-library.mjs tools/lib/industrial-exhaust.mjs || fail RESTORE_QUALIFIED_LIBRARY
cp /tmp/pr2231-v101-qualified-focused-test.js test/industrial-exhaust.test.js || fail RESTORE_QUALIFIED_TEST
git diff --check > "$ARTIFACT_DIR/final-diff-check.log" 2>&1 || {
  cat "$ARTIFACT_DIR/final-diff-check.log"
  fail FINAL_DIFF_CHECK
}
git diff --name-only | sort > "$ARTIFACT_DIR/final-paths.txt" || fail LIST_FINAL_PATHS
mapfile -t final_paths < "$ARTIFACT_DIR/final-paths.txt"
require_equal "${#final_paths[@]}" 2 FINAL_PATH_COUNT
require_equal "${final_paths[0]}" test/industrial-exhaust.test.js FINAL_FIRST_PATH
require_equal "${final_paths[1]}" tools/lib/industrial-exhaust.mjs FINAL_SECOND_PATH
git diff --name-only "$EXPECTED_MAIN" | sort > "$ARTIFACT_DIR/cumulative-paths.txt" || fail LIST_CUMULATIVE_PATHS
mapfile -t cumulative_paths < "$ARTIFACT_DIR/cumulative-paths.txt"
require_equal "${#cumulative_paths[@]}" 2 CUMULATIVE_PATH_COUNT
require_equal "${cumulative_paths[0]}" test/industrial-exhaust.test.js CUMULATIVE_FIRST_PATH
require_equal "${cumulative_paths[1]}" tools/lib/industrial-exhaust.mjs CUMULATIVE_SECOND_PATH
final_library="$(git hash-object -w tools/lib/industrial-exhaust.mjs)" || fail WRITE_FINAL_LIBRARY_BLOB
final_test="$(git hash-object -w test/industrial-exhaust.test.js)" || fail WRITE_FINAL_TEST_BLOB
require_equal "$final_library" "$EXPECTED_CANDIDATE_LIBRARY_BLOB" FINAL_LIBRARY_BLOB
require_equal "$final_test" "$EXPECTED_CANDIDATE_FOCUSED_TEST_BLOB" FINAL_FOCUSED_TEST_BLOB
note GENERATED_STATE_RESTORE_SUCCESS

note CANDIDATE_OBJECT_CONSTRUCTION_STARTED
index_file=/tmp/pr2231-v101-index
rm -f "$index_file"
GIT_INDEX_FILE="$index_file" git read-tree "$EXPECTED_MAIN" || fail INDEX_READ_MAIN
GIT_INDEX_FILE="$index_file" git update-index --add --cacheinfo 100644 "$final_library" tools/lib/industrial-exhaust.mjs || fail INDEX_LIBRARY
GIT_INDEX_FILE="$index_file" git update-index --add --cacheinfo 100644 "$final_test" test/industrial-exhaust.test.js || fail INDEX_TEST
candidate_tree="$(GIT_INDEX_FILE="$index_file" git write-tree)" || fail WRITE_CANDIDATE_TREE
require_equal "$candidate_tree" "$EXPECTED_CANDIDATE_TREE" CANDIDATE_TREE
printf '%s\n' "$candidate_tree" > "$ARTIFACT_DIR/candidate.tree"

commit_message=$'fix: preserve exact phone intervals across numeric observations\n\nCarry bounded intrinsic telephone geometry through numeric observation and date precedence without importing controller custody.'
export GIT_AUTHOR_NAME='BigBirdReturns'
export GIT_AUTHOR_EMAIL='bigbirdreturns@proton.me'
export GIT_AUTHOR_DATE='2026-08-30T02:37:00Z'
export GIT_COMMITTER_NAME='BigBirdReturns'
export GIT_COMMITTER_EMAIL='bigbirdreturns@proton.me'
export GIT_COMMITTER_DATE='2026-08-30T02:37:00Z'
new_commit="$(printf '%s\n' "$commit_message" | git commit-tree "$candidate_tree" -p "$EXPECTED_MAIN")" || fail CREATE_PRODUCT_COMMIT
new_parent="$(git rev-parse "${new_commit}^")" || fail RESOLVE_NEW_PARENT
new_tree="$(git rev-parse "${new_commit}^{tree}")" || fail RESOLVE_NEW_TREE
new_library="$(git rev-parse "${new_commit}:tools/lib/industrial-exhaust.mjs")" || fail RESOLVE_NEW_LIBRARY
new_test="$(git rev-parse "${new_commit}:test/industrial-exhaust.test.js")" || fail RESOLVE_NEW_TEST
require_equal "$new_parent" "$EXPECTED_MAIN" NEW_PRODUCT_PARENT
require_equal "$new_tree" "$EXPECTED_CANDIDATE_TREE" NEW_PRODUCT_TREE
require_equal "$new_library" "$EXPECTED_CANDIDATE_LIBRARY_BLOB" NEW_PRODUCT_LIBRARY_BLOB
require_equal "$new_test" "$EXPECTED_CANDIDATE_FOCUSED_TEST_BLOB" NEW_PRODUCT_FOCUSED_TEST_BLOB
mapfile -t new_paths < <(git diff-tree --no-commit-id --name-only -r "$new_commit" | sort)
require_equal "${#new_paths[@]}" 2 NEW_PRODUCT_PATH_COUNT
require_equal "${new_paths[0]}" test/industrial-exhaust.test.js NEW_PRODUCT_FIRST_PATH
require_equal "${new_paths[1]}" tools/lib/industrial-exhaust.mjs NEW_PRODUCT_SECOND_PATH
printf '%s\n' "$new_commit" > "$ARTIFACT_DIR/product-candidate.sha"
git cat-file -p "$new_commit" > "$ARTIFACT_DIR/product-candidate.commit"
git diff --binary "$EXPECTED_MAIN" "$new_commit" -- > "$ARTIFACT_DIR/product.patch" || fail WRITE_PRODUCT_PATCH
git diff --stat "$EXPECTED_MAIN" "$new_commit" -- > "$ARTIFACT_DIR/product.diffstat" || fail WRITE_PRODUCT_DIFFSTAT
cp tools/lib/industrial-exhaust.mjs "$ARTIFACT_DIR/qualified/tools/lib/industrial-exhaust.mjs" || fail RECEIPT_LIBRARY
cp test/industrial-exhaust.test.js "$ARTIFACT_DIR/qualified/test/industrial-exhaust.test.js" || fail RECEIPT_TEST
cp /tmp/pr2231-v101.py "$ARTIFACT_DIR/mutator.py" || fail RECEIPT_MUTATOR
sha256sum \
  tools/lib/industrial-exhaust.mjs \
  test/industrial-exhaust.test.js \
  /tmp/pr2231-v101.py \
  > "$ARTIFACT_DIR/sha256.txt" || fail WRITE_SHA256
note "PRODUCT_CANDIDATE_SHA=$new_commit"
note "PRODUCT_CANDIDATE_TREE=$candidate_tree"
note CANDIDATE_OBJECT_CONSTRUCTION_SUCCESS

note PREPUSH_REVALIDATION_STARTED
cd "$GITHUB_WORKSPACE" || fail RETURN_CONTROLLER_WORKSPACE
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
  "+refs/heads/${CONTROLLER_BRANCH}:refs/remotes/origin/${CONTROLLER_BRANCH}" || fail PREPUSH_FETCH
require_equal "$(git rev-parse refs/remotes/origin/main)" "$EXPECTED_MAIN" PREPUSH_MAIN_LEASE
require_equal "$(git rev-parse refs/remotes/origin/${PRODUCT_BRANCH})" "$EXPECTED_PRODUCT" PREPUSH_PRODUCT_LEASE
require_equal "$(git rev-parse refs/remotes/origin/${CONTROLLER_BRANCH})" "$CONTROLLER_SHA" PREPUSH_CONTROLLER_LEASE
require_equal "$(git rev-parse "${EXPECTED_PRODUCT}^")" "$EXPECTED_MAIN" PREPUSH_PRODUCT_PARENT
require_equal "$(git rev-parse "${EXPECTED_PRODUCT}^{tree}")" "$EXPECTED_PREDECESSOR_TREE" PREPUSH_PREDECESSOR_TREE
require_equal "$(git rev-parse "${CONTROLLER_SHA}:${PAYLOAD_PATH}")" "$EXPECTED_PAYLOAD_BLOB" PREPUSH_PAYLOAD_BLOB
require_equal "$(git rev-parse "${CONTROLLER_SHA}:${PUBLISHER_SCRIPT_PATH}")" "$EXPECTED_PUBLISHER_SCRIPT_BLOB" PREPUSH_PUBLISHER_SCRIPT_BLOB
capture_pr_state prepushed "$EXPECTED_PRODUCT"
capture_review_state prepushed
review_digest_prepush="$(cat "$ARTIFACT_DIR/review-threads-prepushed.sha256")"
require_equal "$review_digest_prepush" "$review_digest_before" REVIEW_DIGEST_PREPUSH
note PREPUSH_REVALIDATION_SUCCESS

note PUBLICATION_STARTED
git push origin "$new_commit:refs/heads/${PRODUCT_BRANCH}" \
  --force-with-lease="refs/heads/${PRODUCT_BRANCH}:${EXPECTED_PRODUCT}" \
  > "$ARTIFACT_DIR/push.log" 2>&1
status=$?
cat "$ARTIFACT_DIR/push.log"
[[ "$status" -eq 0 ]] || fail LEASED_PUSH
note PUBLICATION_PUSH_SUCCESS

note POSTPUSH_VERIFICATION_STARTED
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
  "+refs/heads/${CONTROLLER_BRANCH}:refs/remotes/origin/${CONTROLLER_BRANCH}" || fail POSTPUSH_FETCH
published_head="$(git rev-parse refs/remotes/origin/${PRODUCT_BRANCH})" || fail RESOLVE_PUBLISHED_HEAD
published_parent="$(git rev-parse "${published_head}^")" || fail RESOLVE_PUBLISHED_PARENT
published_tree="$(git rev-parse "${published_head}^{tree}")" || fail RESOLVE_PUBLISHED_TREE
published_library="$(git rev-parse "${published_head}:tools/lib/industrial-exhaust.mjs")" || fail RESOLVE_PUBLISHED_LIBRARY
published_test="$(git rev-parse "${published_head}:test/industrial-exhaust.test.js")" || fail RESOLVE_PUBLISHED_TEST
published_ahead="$(git rev-list --count "${EXPECTED_MAIN}..${published_head}")" || fail COUNT_PUBLISHED_AHEAD
published_behind="$(git rev-list --count "${published_head}..${EXPECTED_MAIN}")" || fail COUNT_PUBLISHED_BEHIND
require_equal "$published_head" "$new_commit" PUBLISHED_HEAD
require_equal "$published_parent" "$EXPECTED_MAIN" PUBLISHED_PARENT
require_equal "$published_tree" "$EXPECTED_CANDIDATE_TREE" PUBLISHED_TREE
require_equal "$published_library" "$EXPECTED_CANDIDATE_LIBRARY_BLOB" PUBLISHED_LIBRARY_BLOB
require_equal "$published_test" "$EXPECTED_CANDIDATE_FOCUSED_TEST_BLOB" PUBLISHED_FOCUSED_TEST_BLOB
require_equal "$published_ahead" 1 PUBLISHED_AHEAD_COUNT
require_equal "$published_behind" 0 PUBLISHED_BEHIND_COUNT
require_equal "$(git rev-parse refs/remotes/origin/main)" "$EXPECTED_MAIN" POSTPUSH_MAIN_LEASE
require_equal "$(git rev-parse refs/remotes/origin/${CONTROLLER_BRANCH})" "$CONTROLLER_SHA" POSTPUSH_CONTROLLER_LEASE
mapfile -t published_paths < <(git diff-tree --no-commit-id --name-only -r "$published_head" | sort)
require_equal "${#published_paths[@]}" 2 PUBLISHED_PATH_COUNT
require_equal "${published_paths[0]}" test/industrial-exhaust.test.js PUBLISHED_FIRST_PATH
require_equal "${published_paths[1]}" tools/lib/industrial-exhaust.mjs PUBLISHED_SECOND_PATH
printf '%s\n' "$published_head" > "$ARTIFACT_DIR/product-published.sha"
printf '%s\n' "$published_parent" > "$ARTIFACT_DIR/product-published-parent.sha"
printf '%s\n' "$published_tree" > "$ARTIFACT_DIR/product-published.tree"
printf '%s\n' "$published_library" > "$ARTIFACT_DIR/product-published-library.blob"
printf '%s\n' "$published_test" > "$ARTIFACT_DIR/product-published-focused-test.blob"

capture_pr_state after "$new_commit"
capture_review_state after
review_digest_after="$(cat "$ARTIFACT_DIR/review-threads-after.sha256")"
require_equal "$review_digest_after" "$review_digest_before" REVIEW_DIGEST_AFTER
printf '%s\n' PUBLICATION_SUCCESS > "$ARTIFACT_DIR/result.txt"
note "PUBLISHED_PRODUCT_SHA=$published_head"
note "PUBLISHED_PRODUCT_TREE=$published_tree"
note "PUBLISHED_LIBRARY_BLOB=$published_library"
note "PUBLISHED_FOCUSED_TEST_BLOB=$published_test"
note PUBLICATION_SUCCESS
