#!/usr/bin/env bash
set -Eeuo pipefail

: "${GH_TOKEN:?GH_TOKEN is required}"
: "${REPO:?REPO is required}"
: "${PRODUCT_BRANCH:?PRODUCT_BRANCH is required}"
: "${EXPECTED_MAIN:?EXPECTED_MAIN is required}"
: "${EXPECTED_PRODUCT:?EXPECTED_PRODUCT is required}"
: "${EXPECTED_PRODUCT_TREE:?EXPECTED_PRODUCT_TREE is required}"
: "${EXPECTED_LIBRARY_BLOB:?EXPECTED_LIBRARY_BLOB is required}"
: "${EXPECTED_TEST_BLOB:?EXPECTED_TEST_BLOB is required}"
: "${EXPECTED_REVIEW_THREAD:?EXPECTED_REVIEW_THREAD is required}"
: "${EXPECTED_REVIEW_COMMENT:?EXPECTED_REVIEW_COMMENT is required}"
: "${ARTIFACT_DIR:?ARTIFACT_DIR is required}"

PRODUCT_PR=2231
CONTROLLER_PR=2393
CONTROLLER_BRANCH='agent/pr2231-day-first-date-finality-controller-v104'
LIBRARY_PATH='tools/lib/industrial-exhaust.mjs'
TEST_PATH='test/industrial-exhaust.test.js'
CONTROLLER_SCRIPT='.github/tmp/pr2231-day-first-date-v104.sh.gz'
CONTROLLER_WORKFLOW='.github/workflows/temporary-pr2231-day-first-date-v104.yml'
WORKTREE='/tmp/pr2231-day-first-date-v104-product'
TRANSPLANT='/tmp/pr2231-day-first-date-v104-main'
OWNER="${REPO%%/*}"
NAME="${REPO#*/}"

rm -rf "$ARTIFACT_DIR" "$WORKTREE" "$TRANSPLANT"
mkdir -p "$ARTIFACT_DIR/candidate"
printf '%s\n' STARTED > "$ARTIFACT_DIR/result.txt"
: > "$ARTIFACT_DIR/trace.txt"

trace() {
  printf '%s\n' "$1" | tee -a "$ARTIFACT_DIR/trace.txt"
}

fail() {
  printf 'FAIL: %s\n' "$*" >&2
  return 1
}

on_exit() {
  local rc=$?
  if (( rc != 0 )); then
    printf 'FAILURE:%s\n' "$rc" > "$ARTIFACT_DIR/result.txt"
    printf 'FAILED:%s\n' "$rc" >> "$ARTIFACT_DIR/trace.txt"
  fi
}
trap on_exit EXIT

assert_exact_paths() {
  local actual_file=$1
  shift
  printf '%s\n' "$@" | sort > "$ARTIFACT_DIR/expected-paths.txt"
  sort -u "$actual_file" > "$ARTIFACT_DIR/actual-paths.sorted.txt"
  diff -u "$ARTIFACT_DIR/expected-paths.txt" "$ARTIFACT_DIR/actual-paths.sorted.txt"
}

fetch_review_census() {
  local output=$1
  gh api graphql \
    -F owner="$OWNER" \
    -F name="$NAME" \
    -F number="$PRODUCT_PR" \
    -f query='query($owner:String!,$name:String!,$number:Int!){repository(owner:$owner,name:$name){pullRequest(number:$number){reviewThreads(first:100){pageInfo{hasNextPage}nodes{id isResolved isOutdated comments(first:100){nodes{databaseId body author{login}}}}}}}}' \
    > "$output"
}

validate_review_lease() {
  local census=$1
  jq -e \
    --arg thread "$EXPECTED_REVIEW_THREAD" \
    --argjson comment "$EXPECTED_REVIEW_COMMENT" \
    '
      .data.repository.pullRequest.reviewThreads.pageInfo.hasNextPage == false and
      ([.data.repository.pullRequest.reviewThreads.nodes[] | select(.id == $thread)] | length) == 1 and
      ([.data.repository.pullRequest.reviewThreads.nodes[] | select(.id == $thread)][0].isResolved == false) and
      ([.data.repository.pullRequest.reviewThreads.nodes[] | select(.id == $thread)][0].isOutdated == false) and
      ([.data.repository.pullRequest.reviewThreads.nodes[] | select(.id == $thread) | .comments.nodes[] | select(.databaseId == $comment)] | length) == 1
    ' "$census" >/dev/null
}

validate_product_pr() {
  local json=$1
  jq -e \
    --arg branch "$PRODUCT_BRANCH" \
    --arg head "$EXPECTED_PRODUCT" \
    --arg base "$EXPECTED_MAIN" \
    '
      .state == "open" and
      .draft == true and
      .merged_at == null and
      .head.ref == $branch and
      .head.sha == $head and
      .base.ref == "main" and
      .base.sha == $base
    ' "$json" >/dev/null
}

validate_controller_pr() {
  local json=$1
  local controller_head=$2
  jq -e \
    --arg branch "$CONTROLLER_BRANCH" \
    --arg head "$controller_head" \
    --arg base "$EXPECTED_MAIN" \
    '
      .state == "open" and
      .draft == true and
      .merged_at == null and
      .head.ref == $branch and
      .head.sha == $head and
      .base.ref == "main" and
      .base.sha == $base
    ' "$json" >/dev/null
}

trace LEASE_BIND_STARTED
[[ "${PUBLISH:-false}" == 'false' ]] || fail 'V104 must remain read-only'
controller_head=$(git rev-parse HEAD)

# Bind exact live branch leases before any execution.
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}"
actual_main=$(git rev-parse refs/remotes/origin/main)
actual_product=$(git rev-parse "refs/remotes/origin/${PRODUCT_BRANCH}")
[[ "$actual_main" == "$EXPECTED_MAIN" ]] || fail "main moved: $actual_main"
[[ "$actual_product" == "$EXPECTED_PRODUCT" ]] || fail "product moved: $actual_product"
[[ "$(git rev-parse "${EXPECTED_PRODUCT}^{tree}")" == "$EXPECTED_PRODUCT_TREE" ]] || fail 'product tree mismatch'
[[ "$(git rev-parse "${EXPECTED_PRODUCT}:${LIBRARY_PATH}")" == "$EXPECTED_LIBRARY_BLOB" ]] || fail 'library blob mismatch'
[[ "$(git rev-parse "${EXPECTED_PRODUCT}:${TEST_PATH}")" == "$EXPECTED_TEST_BLOB" ]] || fail 'focused-test blob mismatch'
read -r commit parent extra <<<"$(git rev-list --parents -n 1 "$EXPECTED_PRODUCT")"
[[ "$commit" == "$EXPECTED_PRODUCT" && "$parent" == "$EXPECTED_MAIN" && -z "${extra:-}" ]] || fail 'product is not one direct child of frozen main'

git diff --name-only "$EXPECTED_MAIN" "$EXPECTED_PRODUCT" > "$ARTIFACT_DIR/product-paths-before.txt"
assert_exact_paths "$ARTIFACT_DIR/product-paths-before.txt" "$LIBRARY_PATH" "$TEST_PATH"

gh api "repos/${REPO}/pulls/${PRODUCT_PR}" > "$ARTIFACT_DIR/product-pr-before.json"
validate_product_pr "$ARTIFACT_DIR/product-pr-before.json"
gh api --paginate "repos/${REPO}/pulls/${PRODUCT_PR}/files" --jq '.[].filename' > "$ARTIFACT_DIR/product-pr-paths-before.txt"
assert_exact_paths "$ARTIFACT_DIR/product-pr-paths-before.txt" "$LIBRARY_PATH" "$TEST_PATH"

gh api "repos/${REPO}/pulls/${CONTROLLER_PR}" > "$ARTIFACT_DIR/controller-pr-before.json"
validate_controller_pr "$ARTIFACT_DIR/controller-pr-before.json" "$controller_head"
gh api --paginate "repos/${REPO}/pulls/${CONTROLLER_PR}/files" --jq '.[].filename' > "$ARTIFACT_DIR/controller-pr-paths-before.txt"
assert_exact_paths "$ARTIFACT_DIR/controller-pr-paths-before.txt" "$CONTROLLER_SCRIPT" "$CONTROLLER_WORKFLOW"

fetch_review_census "$ARTIFACT_DIR/review-threads-before.json"
validate_review_lease "$ARTIFACT_DIR/review-threads-before.json"
trace LEASE_BIND_SUCCESS

trace PREDECESSOR_REPRODUCTION_STARTED
git worktree add --detach "$WORKTREE" "$EXPECTED_PRODUCT" >/dev/null
pushd "$WORKTREE" >/dev/null
predecessor_actual=$(node --input-type=module <<'NODE'
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';
process.stdout.write(redactContactData('Archive +81 3 6216 8041–17.08.2026'));
NODE
)
expected_predecessor='Archive [contact omitted].08.2026'
[[ "$predecessor_actual" == "$expected_predecessor" ]] || fail "predecessor no longer reproduces: $predecessor_actual"
jq -n \
  --arg input 'Archive +81 3 6216 8041–17.08.2026' \
  --arg actual "$predecessor_actual" \
  --arg expectedFailure "$expected_predecessor" \
  '{input:$input,actual:$actual,expectedFailure:$expectedFailure}' \
  > "$ARTIFACT_DIR/predecessor-reproduction.json"
trace PREDECESSOR_REPRODUCTION_SUCCESS

trace PATCH_STARTED
python3 - <<'PY'
from pathlib import Path

library_path = Path('tools/lib/industrial-exhaust.mjs')
test_path = Path('test/industrial-exhaust.test.js')
source = library_path.read_text(encoding='utf-8')
old = """        const separator = candidate.slice(previousEnd, start);\n        const normalizedSeparator = separator.normalize('NFKC');\n        if (!/\\s/u.test(separator) && !/[.!?。！？]/u.test(normalizedSeparator)) continue;\n\n        const phonePrefix = candidate.slice(0, start).trimEnd();\n"""
new = """        const separator = candidate.slice(previousEnd, start);\n        const normalizedSeparator = separator.normalize('NFKC');\n        const dashCalendarBoundary = /[-‐‑‒–—−]/u.test(normalizedSeparator)\n          && completeCalendarDateObservationMatch(\n            candidate.slice(start).trim().normalize('NFKC')\n          );\n        if (!/\\s/u.test(separator)\n            && !/[.!?。！？]/u.test(normalizedSeparator)\n            && !dashCalendarBoundary) continue;\n\n        const phonePrefix = candidate.slice(0, start).trimEnd();\n"""
if source.count(old) != 1:
    raise SystemExit(f'expected one trailing-observation separator gate, found {source.count(old)}')
library_path.write_text(source.replace(old, new, 1), encoding='utf-8')

marker = '// PR2231 V104 complete day-first date interval-finality regressions'
tests = test_path.read_text(encoding='utf-8')
if marker in tests:
    raise SystemExit('V104 regression marker already present in predecessor')
tests += r'''

// PR2231 V104 complete day-first date interval-finality regressions
for (const [name, input, expected] of [
  [
    'international phone terminates before an en-dash day-first dotted date',
    'Archive +81 3 6216 8041–17.08.2026',
    'Archive [contact omitted]–17.08.2026'
  ],
  [
    'labelled international phone terminates before an em-dash day-first slash date',
    'Phone: +81 3 6216 8041—17/08/2026',
    'Phone: [contact omitted]—17/08/2026'
  ],
  [
    'domestic phone terminates before a hyphen day-first date',
    'Archive 03-6216-8041-17-08-2026',
    'Archive [contact omitted]-17-08-2026'
  ],
  [
    'fullwidth phone terminates before a fullwidth day-first dotted date',
    '電話：＋８１ ３ ６２１６ ８０４１－１７．０８．２０２６',
    '電話：[contact omitted]－１７．０８．２０２６'
  ],
  [
    'dash-owned decimal remains outside the preceding international phone',
    'Archive +81 3 6216 8041–3.14',
    'Archive [contact omitted]–3.14'
  ],
  [
    'standalone day-first dotted date remains source-faithful',
    'Archive 17.08.2026',
    'Archive 17.08.2026'
  ],
  [
    'intrinsic dotted domestic phone remains eligible',
    'Archive 03.6216.8041',
    'Archive [contact omitted]'
  ]
]) {
  assert.equal(redactContactData(input), expected, name);
}
'''
test_path.write_text(tests, encoding='utf-8')
PY

[[ "$(git diff --name-only | sort | tr '\n' ' ')" == "$TEST_PATH $LIBRARY_PATH " ]] \
  || fail 'patch changed paths outside the product denominator'
cp "$LIBRARY_PATH" "$ARTIFACT_DIR/candidate/industrial-exhaust.mjs"
cp "$TEST_PATH" "$ARTIFACT_DIR/candidate/industrial-exhaust.test.js"
git diff --binary -- "$LIBRARY_PATH" "$TEST_PATH" > "$ARTIFACT_DIR/candidate.patch"
trace PATCH_SUCCESS

trace DIRECT_MATRIX_STARTED
node --input-type=module <<'NODE' | tee "$ARTIFACT_DIR/direct-matrix.jsonl"
import assert from 'node:assert/strict';
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';

const cases = [
  ['Archive +81 3 6216 8041–17.08.2026', 'Archive [contact omitted]–17.08.2026'],
  ['Phone: +81 3 6216 8041—17/08/2026', 'Phone: [contact omitted]—17/08/2026'],
  ['Archive 03-6216-8041-17-08-2026', 'Archive [contact omitted]-17-08-2026'],
  ['電話：＋８１ ３ ６２１６ ８０４１－１７．０８．２０２６', '電話：[contact omitted]－１７．０８．２０２６'],
  ['Archive +81 3 6216 8041–3.14', 'Archive [contact omitted]–3.14'],
  ['Archive 17.08.2026', 'Archive 17.08.2026'],
  ['Archive 03.6216.8041', 'Archive [contact omitted]']
];
for (const [input, expected] of cases) {
  const actual = redactContactData(input);
  console.log(JSON.stringify({ input, actual, expected }));
  assert.equal(actual, expected, input);
}
NODE
trace DIRECT_MATRIX_SUCCESS

trace FOCUSED_PRODUCT_STARTED
node --check "$LIBRARY_PATH"
for focused in test/industrial-exhaust*.test.js; do
  node "$focused"
done
trace FOCUSED_PRODUCT_SUCCESS
popd >/dev/null

trace MAIN_TRANSPLANT_STARTED
git worktree add --detach "$TRANSPLANT" "$EXPECTED_MAIN" >/dev/null
cp "$ARTIFACT_DIR/candidate/industrial-exhaust.mjs" "$TRANSPLANT/$LIBRARY_PATH"
cp "$ARTIFACT_DIR/candidate/industrial-exhaust.test.js" "$TRANSPLANT/$TEST_PATH"
pushd "$TRANSPLANT" >/dev/null

git diff --name-only "$EXPECTED_MAIN" > "$ARTIFACT_DIR/transplant-paths-before-gate.txt"
assert_exact_paths "$ARTIFACT_DIR/transplant-paths-before-gate.txt" "$LIBRARY_PATH" "$TEST_PATH"
node --check "$LIBRARY_PATH"
for focused in test/industrial-exhaust*.test.js; do
  node "$focused"
done
trace MAIN_TRANSPLANT_FOCUSED_SUCCESS

trace INSTALL_STARTED
if ! npm ci > /tmp/pr2231-v104-npm-ci.log 2>&1; then
  tail -n 400 /tmp/pr2231-v104-npm-ci.log > "$ARTIFACT_DIR/npm-ci.tail.txt"
  fail 'npm ci failed'
fi
tail -n 120 /tmp/pr2231-v104-npm-ci.log > "$ARTIFACT_DIR/npm-ci.tail.txt"
trace INSTALL_SUCCESS

trace RELEASE_CHECK_STARTED
if ! npm run release:check > /tmp/pr2231-v104-release-check.log 2>&1; then
  tail -n 600 /tmp/pr2231-v104-release-check.log > "$ARTIFACT_DIR/release-check.tail.txt"
  fail 'release:check failed'
fi
tail -n 300 /tmp/pr2231-v104-release-check.log > "$ARTIFACT_DIR/release-check.tail.txt"
trace RELEASE_CHECK_SUCCESS

# Restore all generated state and reconstitute only the two qualified product files.
git reset --hard "$EXPECTED_MAIN" >/dev/null
git clean -fdx >/dev/null
cp "$ARTIFACT_DIR/candidate/industrial-exhaust.mjs" "$LIBRARY_PATH"
cp "$ARTIFACT_DIR/candidate/industrial-exhaust.test.js" "$TEST_PATH"

git diff --name-only "$EXPECTED_MAIN" > "$ARTIFACT_DIR/transplant-paths-after-gate.txt"
assert_exact_paths "$ARTIFACT_DIR/transplant-paths-after-gate.txt" "$LIBRARY_PATH" "$TEST_PATH"
node --check "$LIBRARY_PATH"
for focused in test/industrial-exhaust*.test.js; do
  node "$focused"
done
trace GENERATED_STATE_RESTORED

git add "$LIBRARY_PATH" "$TEST_PATH"
git diff --cached --name-only > "$ARTIFACT_DIR/candidate-paths.txt"
assert_exact_paths "$ARTIFACT_DIR/candidate-paths.txt" "$LIBRARY_PATH" "$TEST_PATH"
candidate_tree=$(git write-tree)
candidate_library_blob=$(git rev-parse ":${LIBRARY_PATH}")
candidate_test_blob=$(git rev-parse ":${TEST_PATH}")
printf '%s\n' "$candidate_tree" > "$ARTIFACT_DIR/candidate-tree.sha"
printf '%s\n' "$candidate_library_blob" > "$ARTIFACT_DIR/candidate-library.blob"
printf '%s\n' "$candidate_test_blob" > "$ARTIFACT_DIR/candidate-test.blob"
printf '%s\n' "$EXPECTED_MAIN" > "$ARTIFACT_DIR/candidate-parent.sha"
git diff --cached --numstat > "$ARTIFACT_DIR/candidate-numstat.txt"
git diff --cached --binary > "$ARTIFACT_DIR/candidate-final.patch"
sha256sum "$LIBRARY_PATH" "$TEST_PATH" > "$ARTIFACT_DIR/candidate-files.sha256"
trace CANDIDATE_BOUND
popd >/dev/null

trace FINAL_LEASE_REVALIDATION_STARTED
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}"
[[ "$(git rev-parse refs/remotes/origin/main)" == "$EXPECTED_MAIN" ]] || fail 'main moved during qualification'
[[ "$(git rev-parse "refs/remotes/origin/${PRODUCT_BRANCH}")" == "$EXPECTED_PRODUCT" ]] || fail 'product moved during qualification'
[[ "$(git rev-parse HEAD)" == "$controller_head" ]] || fail 'controller worktree moved during qualification'

gh api "repos/${REPO}/pulls/${PRODUCT_PR}" > "$ARTIFACT_DIR/product-pr-after.json"
validate_product_pr "$ARTIFACT_DIR/product-pr-after.json"
gh api --paginate "repos/${REPO}/pulls/${PRODUCT_PR}/files" --jq '.[].filename' > "$ARTIFACT_DIR/product-pr-paths-after.txt"
assert_exact_paths "$ARTIFACT_DIR/product-pr-paths-after.txt" "$LIBRARY_PATH" "$TEST_PATH"

gh api "repos/${REPO}/pulls/${CONTROLLER_PR}" > "$ARTIFACT_DIR/controller-pr-after.json"
validate_controller_pr "$ARTIFACT_DIR/controller-pr-after.json" "$controller_head"
fetch_review_census "$ARTIFACT_DIR/review-threads-after.json"
validate_review_lease "$ARTIFACT_DIR/review-threads-after.json"
trace FINAL_LEASE_REVALIDATION_SUCCESS

printf '%s\n' QUALIFICATION_SUCCESS > "$ARTIFACT_DIR/result.txt"
trace QUALIFICATION_SUCCESS
