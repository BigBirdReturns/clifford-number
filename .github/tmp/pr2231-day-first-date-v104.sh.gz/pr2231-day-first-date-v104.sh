#!/usr/bin/env bash
set -euo pipefail

REPO="${REPO:-BigBirdReturns/clifford-number}"
PRODUCT_BRANCH="${PRODUCT_BRANCH:-agent/current-main-identifier-context-product-v1}"
EXPECTED_MAIN="${EXPECTED_MAIN:-17aa3cfc22d5f9022164baf5c1d5a8e401b796cf}"
EXPECTED_PRODUCT="${EXPECTED_PRODUCT:-618d7f4fff23ea44d396f1476477e0163a1c50f1}"
EXPECTED_PRODUCT_TREE="${EXPECTED_PRODUCT_TREE:-ec2c1fdf2bc9e7b05d9fe1ec40f22c56e9ae4184}"
EXPECTED_LIBRARY_BLOB="${EXPECTED_LIBRARY_BLOB:-d02ac8fdb1dad6777d6a722a097706c5660ebe8a}"
EXPECTED_TEST_BLOB="${EXPECTED_TEST_BLOB:-1d8fd285563eea4121bbe178a4b54eb715af3ac0}"
EXPECTED_REVIEW_THREAD="${EXPECTED_REVIEW_THREAD:-PRRT_kwDOTGqftc6dept0}"
EXPECTED_REVIEW_COMMENT="${EXPECTED_REVIEW_COMMENT:-3888440222}"
PUBLISH="${PUBLISH:-false}"
ARTIFACT_DIR="${ARTIFACT_DIR:-/tmp/pr2231-day-first-date-finality}"
WORK_ROOT="${RUNNER_TEMP:-/tmp}/pr2231-day-first-date-finality"
PRODUCT_WORKTREE="${WORK_ROOT}/product"
TRANSPLANT_WORKTREE="${WORK_ROOT}/transplant"
COMMIT_MESSAGE="${COMMIT_MESSAGE:-fix: preserve complete dates after telephone intervals}"

rm -rf "$ARTIFACT_DIR" "$WORK_ROOT"
mkdir -p "$ARTIFACT_DIR" "$WORK_ROOT"
: > "$ARTIFACT_DIR/trace.txt"
printf '%s\n' STARTED > "$ARTIFACT_DIR/result.txt"

note() {
  printf '%s\n' "$*" | tee -a "$ARTIFACT_DIR/trace.txt"
  printf '::notice title=PR2231 day-first date finality::%s\n' "$*"
}

fail() {
  note "FAIL:$*"
  printf '%s\n' "FAIL:$*" > "$ARTIFACT_DIR/result.txt"
  exit 1
}

cleanup() {
  git worktree remove --force "$PRODUCT_WORKTREE" >/dev/null 2>&1 || true
  git worktree remove --force "$TRANSPLANT_WORKTREE" >/dev/null 2>&1 || true
}
trap cleanup EXIT

note LEASE_BIND_STARTED
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
  || fail FETCH_REFS

actual_main="$(git rev-parse refs/remotes/origin/main)" || fail RESOLVE_MAIN
actual_product="$(git rev-parse "refs/remotes/origin/${PRODUCT_BRANCH}")" || fail RESOLVE_PRODUCT
product_parent="$(git rev-parse "${EXPECTED_PRODUCT}^")" || fail RESOLVE_PRODUCT_PARENT
product_tree="$(git rev-parse "${EXPECTED_PRODUCT}^{tree}")" || fail RESOLVE_PRODUCT_TREE
library_blob="$(git rev-parse "${EXPECTED_PRODUCT}:tools/lib/industrial-exhaust.mjs")" || fail RESOLVE_LIBRARY_BLOB
test_blob="$(git rev-parse "${EXPECTED_PRODUCT}:test/industrial-exhaust.test.js")" || fail RESOLVE_TEST_BLOB

printf '%s\n' "$actual_main" > "$ARTIFACT_DIR/main.sha"
printf '%s\n' "$actual_product" > "$ARTIFACT_DIR/predecessor.sha"
printf '%s\n' "$product_parent" > "$ARTIFACT_DIR/predecessor-parent.sha"
printf '%s\n' "$product_tree" > "$ARTIFACT_DIR/predecessor-tree.sha"
printf '%s\n' "$library_blob" > "$ARTIFACT_DIR/predecessor-library.blob"
printf '%s\n' "$test_blob" > "$ARTIFACT_DIR/predecessor-test.blob"

[[ "$actual_main" == "$EXPECTED_MAIN" ]] || fail MAIN_LEASE
[[ "$actual_product" == "$EXPECTED_PRODUCT" ]] || fail PRODUCT_LEASE
[[ "$product_parent" == "$EXPECTED_MAIN" ]] || fail PRODUCT_PARENT
[[ "$product_tree" == "$EXPECTED_PRODUCT_TREE" ]] || fail PRODUCT_TREE
[[ "$library_blob" == "$EXPECTED_LIBRARY_BLOB" ]] || fail LIBRARY_BLOB
[[ "$test_blob" == "$EXPECTED_TEST_BLOB" ]] || fail TEST_BLOB

gh api "repos/${REPO}/pulls/2231" > "$ARTIFACT_DIR/product-pr-before.json" || fail FETCH_PRODUCT_PR
jq -e \
  --arg product "$EXPECTED_PRODUCT" \
  --arg branch "$PRODUCT_BRANCH" \
  --arg main "$EXPECTED_MAIN" \
  --arg repo "$REPO" \
  '.state == "open"
   and .draft == true
   and .merged == false
   and .head.sha == $product
   and .head.ref == $branch
   and .head.repo.full_name == $repo
   and .base.ref == "main"
   and .base.sha == $main
   and .commits == 1
   and .changed_files == 2' \
  "$ARTIFACT_DIR/product-pr-before.json" >/dev/null || fail PRODUCT_PR_STATE

gh api graphql \
  -F owner=BigBirdReturns \
  -F name=clifford-number \
  -F number=2231 \
  -f query='
    query($owner: String!, $name: String!, $number: Int!) {
      repository(owner: $owner, name: $name) {
        pullRequest(number: $number) {
          reviewThreads(first: 100) {
            nodes {
              id
              isResolved
              isOutdated
              comments(first: 100) {
                nodes {
                  databaseId
                }
              }
            }
          }
        }
      }
    }' > "$ARTIFACT_DIR/review-threads-before.json" || fail FETCH_REVIEW_THREADS

jq -e \
  --arg thread "$EXPECTED_REVIEW_THREAD" \
  --argjson comment "$EXPECTED_REVIEW_COMMENT" \
  'any(.data.repository.pullRequest.reviewThreads.nodes[];
       .id == $thread
       and .isResolved == false
       and .isOutdated == false
       and any(.comments.nodes[]; .databaseId == $comment))' \
  "$ARTIFACT_DIR/review-threads-before.json" >/dev/null || fail REVIEW_THREAD_LEASE
note LEASE_BIND_SUCCESS

git worktree add --detach "$PRODUCT_WORKTREE" "$EXPECTED_PRODUCT" >/dev/null || fail PRODUCT_WORKTREE
pushd "$PRODUCT_WORKTREE" >/dev/null

note PREDECESSOR_REPRODUCTION_STARTED
node --input-type=module <<'NODE' > "$ARTIFACT_DIR/predecessor-reproduction.txt"
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';

const input = 'Archive +81 3 6216 8041–17.08.2026';
const expectedFailure = 'Archive [contact omitted].08.2026';
const actual = redactContactData(input);
console.log(JSON.stringify({ input, actual, expectedFailure }, null, 2));
if (actual !== expectedFailure) {
  throw new Error(`exact predecessor did not reproduce reviewed failure: ${actual}`);
}
NODE
note PREDECESSOR_REPRODUCTION_SUCCESS

note PATCH_STARTED
python3 - <<'PY'
from pathlib import Path

library = Path('tools/lib/industrial-exhaust.mjs')
source = library.read_text()
old = """    const calendarDate = completeCalendarDateObservationMatch(tail);
    if (calendarDate) {
      const currentBounds = phoneWindowBounds(
        candidate,
        groups,
        first,
        index
      );
      return phoneCandidateScore(
        candidate.slice(currentBounds.start, currentBounds.end),
        '',
        false
      )
        ? index
        : index - 1;
    }
"""
new = """    const calendarDate = completeCalendarDateObservationMatch(tail);
    if (calendarDate) return index - 1;
"""
count = source.count(old)
if count != 1:
    raise SystemExit(f'expected one exact calendar precedence block, found {count}')
library.write_text(source.replace(old, new, 1))

test = Path('test/industrial-exhaust.test.js')
test_source = test.read_text()
marker = '// PR2231 exact complete-calendar finality after intrinsic telephone intervals'
if marker in test_source:
    raise SystemExit('calendar finality regression marker already exists')
addition = r"""

// PR2231 exact complete-calendar finality after intrinsic telephone intervals
for (const [input, expected] of [
  [
    'Archive +81 3 6216 8041–17.08.2026',
    'Archive [contact omitted]–17.08.2026'
  ],
  [
    'Archive +81 3 6216 8041—17.08.2026',
    'Archive [contact omitted]—17.08.2026'
  ],
  [
    'Archive +81 3 6216 8041-17.08.2026',
    'Archive [contact omitted]-17.08.2026'
  ],
  [
    'Archive ＋８１ ３ ６２１６ ８０４１－１７．０８．２０２６',
    'Archive [contact omitted]－１７．０８．２０２６'
  ],
  [
    'Archive +81 3 6216 8041–17/08/2026',
    'Archive [contact omitted]–17/08/2026'
  ],
  [
    'Archive +81 3 6216 8041–17-08-2026',
    'Archive [contact omitted]–17-08-2026'
  ],
  [
    'Archive +81 3 6216 8041–2026-08-17',
    'Archive [contact omitted]–2026-08-17'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    'a complete calendar observation after an intrinsic phone must own every source group'
  );
}

for (const [input, expected] of [
  [
    'Archive 03-6216-8041-3.14',
    'Archive [contact omitted]-3.14'
  ],
  [
    'Phone: 09012345678 03.6216.8041',
    'Phone: [contact omitted] [contact omitted]'
  ],
  [
    'Archive +81 3 6216 8041–3.14',
    'Archive [contact omitted]–3.14'
  ],
  [
    'Archive +81 3 6216 8041–03.6216.8041',
    'Archive [contact omitted]–[contact omitted]'
  ]
]) {
  assert.equal(
    redactContactData(input),
    expected,
    'calendar finality must preserve the qualified synthetic-date, dotted-phone, and dash-observation boundaries'
  );
}
"""
test.write_text(test_source + addition)
PY
note PATCH_SUCCESS

note DIRECT_MATRIX_STARTED
node --check tools/lib/industrial-exhaust.mjs
node --input-type=module <<'NODE' > "$ARTIFACT_DIR/direct-matrix.txt"
import assert from 'node:assert/strict';
import { redactContactData } from './tools/lib/industrial-exhaust.mjs';

const cases = [
  ['Archive +81 3 6216 8041–17.08.2026', 'Archive [contact omitted]–17.08.2026'],
  ['Archive +81 3 6216 8041—17.08.2026', 'Archive [contact omitted]—17.08.2026'],
  ['Archive +81 3 6216 8041-17.08.2026', 'Archive [contact omitted]-17.08.2026'],
  ['Archive ＋８１ ３ ６２１６ ８０４１－１７．０８．２０２６', 'Archive [contact omitted]－１７．０８．２０２６'],
  ['Archive +81 3 6216 8041–17/08/2026', 'Archive [contact omitted]–17/08/2026'],
  ['Archive +81 3 6216 8041–17-08-2026', 'Archive [contact omitted]–17-08-2026'],
  ['Archive +81 3 6216 8041–2026-08-17', 'Archive [contact omitted]–2026-08-17'],
  ['Archive 03-6216-8041-3.14', 'Archive [contact omitted]-3.14'],
  ['Phone: 09012345678 03.6216.8041', 'Phone: [contact omitted] [contact omitted]'],
  ['Archive +81 3 6216 8041–3.14', 'Archive [contact omitted]–3.14'],
  ['Archive +81 3 6216 8041–03.6216.8041', 'Archive [contact omitted]–[contact omitted]']
];

for (const [input, expected] of cases) {
  const actual = redactContactData(input);
  console.log(JSON.stringify({ input, actual, expected }));
  assert.equal(actual, expected);
}
NODE
note DIRECT_MATRIX_SUCCESS

git add tools/lib/industrial-exhaust.mjs test/industrial-exhaust.test.js
candidate_tree="$(git write-tree)" || fail WRITE_CANDIDATE_TREE
export GIT_AUTHOR_NAME=BigBirdReturns
export GIT_AUTHOR_EMAIL=bigbirdreturns@proton.me
export GIT_COMMITTER_NAME=BigBirdReturns
export GIT_COMMITTER_EMAIL=bigbirdreturns@proton.me
candidate_commit="$(printf '%s\n' "$COMMIT_MESSAGE" | git commit-tree "$candidate_tree" -p "$EXPECTED_MAIN")" || fail CREATE_CANDIDATE_COMMIT
candidate_parent="$(git rev-parse "${candidate_commit}^")"
candidate_library="$(git rev-parse "${candidate_commit}:tools/lib/industrial-exhaust.mjs")"
candidate_test="$(git rev-parse "${candidate_commit}:test/industrial-exhaust.test.js")"
candidate_parent_count="$(git rev-list --parents -n 1 "$candidate_commit" | awk '{print NF - 1}')"
candidate_ahead="$(git rev-list --count "${EXPECTED_MAIN}..${candidate_commit}")"
candidate_behind="$(git rev-list --count "${candidate_commit}..${EXPECTED_MAIN}")"

note "CANDIDATE_COMMIT=$candidate_commit"
note "CANDIDATE_TREE=$candidate_tree"
note "CANDIDATE_LIBRARY_BLOB=$candidate_library"
note "CANDIDATE_TEST_BLOB=$candidate_test"

printf '%s\n' "$candidate_commit" > "$ARTIFACT_DIR/candidate.sha"
printf '%s\n' "$candidate_parent" > "$ARTIFACT_DIR/candidate-parent.sha"
printf '%s\n' "$candidate_tree" > "$ARTIFACT_DIR/candidate-tree.sha"
printf '%s\n' "$candidate_library" > "$ARTIFACT_DIR/candidate-library.blob"
printf '%s\n' "$candidate_test" > "$ARTIFACT_DIR/candidate-test.blob"
printf '%s\n' "$candidate_parent_count" > "$ARTIFACT_DIR/candidate-parent-count.txt"
printf '%s\n' "$candidate_ahead" > "$ARTIFACT_DIR/candidate-ahead-count.txt"
printf '%s\n' "$candidate_behind" > "$ARTIFACT_DIR/candidate-behind-count.txt"
cp tools/lib/industrial-exhaust.mjs "$ARTIFACT_DIR/industrial-exhaust.mjs"
cp test/industrial-exhaust.test.js "$ARTIFACT_DIR/industrial-exhaust.test.js"

[[ "$candidate_parent" == "$EXPECTED_MAIN" ]] || fail CANDIDATE_PARENT
[[ "$candidate_parent_count" == 1 ]] || fail CANDIDATE_PARENT_COUNT
[[ "$candidate_ahead" == 1 ]] || fail CANDIDATE_AHEAD_COUNT
[[ "$candidate_behind" == 0 ]] || fail CANDIDATE_BEHIND_COUNT

git diff --name-only "$EXPECTED_MAIN" "$candidate_commit" | sort > "$ARTIFACT_DIR/candidate-paths.txt"
mapfile -t candidate_paths < "$ARTIFACT_DIR/candidate-paths.txt"
[[ "${#candidate_paths[@]}" -eq 2 ]] || fail CANDIDATE_PATH_COUNT
[[ "${candidate_paths[0]}" == 'test/industrial-exhaust.test.js' ]] || fail CANDIDATE_PATH_1
[[ "${candidate_paths[1]}" == 'tools/lib/industrial-exhaust.mjs' ]] || fail CANDIDATE_PATH_2

if [[ -n "${EXPECTED_CANDIDATE_TREE:-}" ]]; then
  [[ "$candidate_tree" == "$EXPECTED_CANDIDATE_TREE" ]] || fail EXPECTED_CANDIDATE_TREE
fi
if [[ -n "${EXPECTED_CANDIDATE_LIBRARY_BLOB:-}" ]]; then
  [[ "$candidate_library" == "$EXPECTED_CANDIDATE_LIBRARY_BLOB" ]] || fail EXPECTED_CANDIDATE_LIBRARY_BLOB
fi
if [[ -n "${EXPECTED_CANDIDATE_TEST_BLOB:-}" ]]; then
  [[ "$candidate_test" == "$EXPECTED_CANDIDATE_TEST_BLOB" ]] || fail EXPECTED_CANDIDATE_TEST_BLOB
fi

note FOCUSED_SUITES_STARTED
npm ci
for focused_test in test/industrial-exhaust*.test.js; do
  node "$focused_test"
done
note FOCUSED_SUITES_SUCCESS
popd >/dev/null

note FROZEN_MAIN_TRANSPLANT_STARTED
git worktree add --detach "$TRANSPLANT_WORKTREE" "$EXPECTED_MAIN" >/dev/null || fail TRANSPLANT_WORKTREE
pushd "$TRANSPLANT_WORKTREE" >/dev/null
git checkout "$candidate_commit" -- tools/lib/industrial-exhaust.mjs test/industrial-exhaust.test.js
node --check tools/lib/industrial-exhaust.mjs
npm ci
for focused_test in test/industrial-exhaust*.test.js; do
  node "$focused_test"
done
npm run release:check
git status --porcelain=v1 > "$ARTIFACT_DIR/post-release-status.txt"
git reset --hard "$candidate_commit" >/dev/null
git clean -fd >/dev/null
[[ -z "$(git status --porcelain=v1)" ]] || fail GENERATED_STATE_RESTORE
popd >/dev/null
note FROZEN_MAIN_TRANSPLANT_SUCCESS

note FINAL_LEASES_STARTED
git fetch --no-tags origin \
  "+refs/heads/main:refs/remotes/origin/main" \
  "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
  || fail FINAL_FETCH
[[ "$(git rev-parse refs/remotes/origin/main)" == "$EXPECTED_MAIN" ]] || fail FINAL_MAIN_LEASE
[[ "$(git rev-parse "refs/remotes/origin/${PRODUCT_BRANCH}")" == "$EXPECTED_PRODUCT" ]] || fail FINAL_PRODUCT_LEASE

gh api "repos/${REPO}/pulls/2231" > "$ARTIFACT_DIR/product-pr-final.json" || fail FINAL_PRODUCT_PR
jq -e --arg product "$EXPECTED_PRODUCT" \
  '.state == "open" and .draft == true and .merged == false and .head.sha == $product' \
  "$ARTIFACT_DIR/product-pr-final.json" >/dev/null || fail FINAL_PRODUCT_PR_STATE

gh api graphql \
  -F owner=BigBirdReturns \
  -F name=clifford-number \
  -F number=2231 \
  -f query='
    query($owner: String!, $name: String!, $number: Int!) {
      repository(owner: $owner, name: $name) {
        pullRequest(number: $number) {
          reviewThreads(first: 100) {
            nodes {
              id
              isResolved
              isOutdated
            }
          }
        }
      }
    }' > "$ARTIFACT_DIR/review-threads-final.json" || fail FINAL_REVIEW_THREADS
jq -e --arg thread "$EXPECTED_REVIEW_THREAD" \
  'any(.data.repository.pullRequest.reviewThreads.nodes[];
       .id == $thread and .isResolved == false and .isOutdated == false)' \
  "$ARTIFACT_DIR/review-threads-final.json" >/dev/null || fail FINAL_REVIEW_THREAD
note FINAL_LEASES_SUCCESS

if [[ "$PUBLISH" == "true" ]]; then
  note QUALIFICATION_RECEIPT_BIND_STARTED
  [[ -n "${QUALIFICATION_RUN_ID:-}" ]] || fail QUALIFICATION_RUN_ID_MISSING
  [[ -n "${QUALIFICATION_ARTIFACT_ID:-}" ]] || fail QUALIFICATION_ARTIFACT_ID_MISSING
  [[ -n "${QUALIFICATION_ARTIFACT_DIGEST:-}" ]] || fail QUALIFICATION_ARTIFACT_DIGEST_MISSING
  gh api "repos/${REPO}/actions/runs/${QUALIFICATION_RUN_ID}" > "$ARTIFACT_DIR/qualification-run.json" || fail FETCH_QUALIFICATION_RUN
  jq -e \
    --argjson run "$QUALIFICATION_RUN_ID" \
    '.id == $run and .status == "completed" and .conclusion == "success"' \
    "$ARTIFACT_DIR/qualification-run.json" >/dev/null || fail QUALIFICATION_RUN_STATE
  gh api "repos/${REPO}/actions/artifacts/${QUALIFICATION_ARTIFACT_ID}" > "$ARTIFACT_DIR/qualification-artifact.json" || fail FETCH_QUALIFICATION_ARTIFACT
  jq -e \
    --argjson id "$QUALIFICATION_ARTIFACT_ID" \
    --argjson run "$QUALIFICATION_RUN_ID" \
    --arg digest "$QUALIFICATION_ARTIFACT_DIGEST" \
    '.id == $id
     and .expired == false
     and .digest == $digest
     and .workflow_run.id == $run' \
    "$ARTIFACT_DIR/qualification-artifact.json" >/dev/null || fail QUALIFICATION_ARTIFACT_STATE
  note QUALIFICATION_RECEIPT_BIND_SUCCESS

  note PUBLICATION_STARTED
  git push \
    --force-with-lease="refs/heads/${PRODUCT_BRANCH}:${EXPECTED_PRODUCT}" \
    origin "${candidate_commit}:refs/heads/${PRODUCT_BRANCH}" \
    || fail PRODUCT_PUBLICATION
  git fetch --no-tags origin \
    "+refs/heads/${PRODUCT_BRANCH}:refs/remotes/origin/${PRODUCT_BRANCH}" \
    || fail POSTPUBLICATION_FETCH
  [[ "$(git rev-parse "refs/remotes/origin/${PRODUCT_BRANCH}")" == "$candidate_commit" ]] \
    || fail POSTPUBLICATION_PRODUCT_REF

  gh api "repos/${REPO}/pulls/2231" > "$ARTIFACT_DIR/product-pr-after-publication.json" || fail POSTPUBLICATION_PRODUCT_PR
  jq -e \
    --arg candidate "$candidate_commit" \
    --arg main "$EXPECTED_MAIN" \
    '.state == "open"
     and .draft == true
     and .merged == false
     and .head.sha == $candidate
     and .base.sha == $main
     and .commits == 1
     and .changed_files == 2' \
    "$ARTIFACT_DIR/product-pr-after-publication.json" >/dev/null || fail POSTPUBLICATION_PRODUCT_PR_STATE
  printf '%s\n' PUBLICATION_SUCCESS > "$ARTIFACT_DIR/result.txt"
  note PUBLICATION_SUCCESS
else
  printf '%s\n' QUALIFICATION_SUCCESS > "$ARTIFACT_DIR/result.txt"
  note QUALIFICATION_SUCCESS
fi

jq -n \
  --arg main "$EXPECTED_MAIN" \
  --arg predecessor "$EXPECTED_PRODUCT" \
  --arg candidate "$candidate_commit" \
  --arg candidate_tree "$candidate_tree" \
  --arg candidate_library_blob "$candidate_library" \
  --arg candidate_test_blob "$candidate_test" \
  --arg publish "$PUBLISH" \
  '{
    main: $main,
    predecessor: $predecessor,
    candidate: $candidate,
    candidate_tree: $candidate_tree,
    candidate_library_blob: $candidate_library_blob,
    candidate_test_blob: $candidate_test_blob,
    publish: ($publish == "true"),
    result: (if $publish == "true" then "PUBLICATION_SUCCESS" else "QUALIFICATION_SUCCESS" end)
  }' > "$ARTIFACT_DIR/receipt.json"
