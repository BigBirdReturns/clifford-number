set -Eeuo pipefail
python -m pip install --disable-pip-version-check --no-cache-dir 'playwright==1.55.0'
python -m playwright install --with-deps chromium
