set -Eeuo pipefail
BASE='1e52a58be874538509d6c0d3c06adc12fc53cad7'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml'
V4_BRANCH='agent/schoolhouse-legal-identity-current-frontier-materializer-v4'
V4_HEAD='0d7a6bbfdf85e2f51f67a580a7a671da37614343'
V4_WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v4.yml'
V4_WORKFLOW_BLOB='939c62ab9696b43c8560794e80e8d5e4219f6fef'
V4_WORKFLOW_BYTES='19719'
V4_WORKFLOW_SHA256='691d90dc0eb9cd73ff2d2f327e2bdd7f08abc5883cb23328154bf8c15b035462'
V4_RUN='31228084089'
V4_ARTIFACT='9012797247'
V4_ARTIFACT_BYTES='841'
V4_ARTIFACT_DIGEST='sha256:34aecb3526ca0eb50ba4d82d394cdebffc000ea2ae2758d34c92dbc7f713315e'
SOURCE_RUN_BYTES='14841'
SOURCE_RUN_SHA256='0de4cab804b1513e0116248deb5bcb4fc0eed8c249b679bea5b19a6d1203afd8'
PATCHED_RUN_BYTES='14971'
PATCHED_RUN_SHA256='9b4048574c5f34d9935fa93aa9020be52f81deb3c4bbbd9dc2b68e36b9c120c3'
WORK="$RUNNER_TEMP/schoolhouse-current-frontier-v5-wrapper"
RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v5"
SOURCE_YAML="$WORK/source-v4-workflow.yml"
SOURCE_RUN_SCRIPT="$WORK/source-v4-run.sh"
PATCHED_RUN_SCRIPT="$WORK/patched-v5-run.sh"
PATCH_RECEIPT="$WORK/v5-wrapper-repair.json"
rm -rf "$WORK" "$RECEIPT"
mkdir -p "$WORK" "$RECEIPT"
printf 'initializing-v5-wrapper\n' > "$WORK/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\n' > "$WORK/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  mkdir -p "$RECEIPT/wrapper"
  cp -a "$WORK"/. "$RECEIPT/wrapper/"
  printf '%s\n' "$rc" > "$RECEIPT/V5_WRAPPER_EXIT_CODE"
  (
    cd "$RECEIPT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-one-workflow-v5-and-exact-v4-failure\n' > "$WORK/STAGE"
git fetch --no-tags origin main "$V4_BRANCH"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
mapfile -t V5_PATHS < <(git diff --name-only "$BASE"..HEAD)
test "${#V5_PATHS[@]}" -eq 1
test "${V5_PATHS[0]}" = "$WORKFLOW"
git diff --check "$BASE"..HEAD
git merge-base --is-ancestor "$BASE" "$(git rev-parse origin/main)"
test "$(git rev-parse "origin/$V4_BRANCH")" = "$V4_HEAD"
test "$(git rev-parse "$V4_HEAD^")" = "$BASE"
test "$(git rev-parse "$V4_HEAD:$V4_WORKFLOW")" = "$V4_WORKFLOW_BLOB"

gh api "repos/$GITHUB_REPOSITORY/actions/runs/$V4_RUN" > "$WORK/v4-run.json"
test "$(jq -r .head_sha "$WORK/v4-run.json")" = "$V4_HEAD"
test "$(jq -r .status "$WORK/v4-run.json")" = 'completed'
test "$(jq -r .conclusion "$WORK/v4-run.json")" = 'failure'
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$V4_ARTIFACT" > "$WORK/v4-artifact-metadata.json"
test "$(jq -r .size_in_bytes "$WORK/v4-artifact-metadata.json")" = "$V4_ARTIFACT_BYTES"
test "$(jq -r .digest "$WORK/v4-artifact-metadata.json")" = "$V4_ARTIFACT_DIGEST"
test "$(jq -r .workflow_run.id "$WORK/v4-artifact-metadata.json")" = "$V4_RUN"
test "$(jq -r .expired "$WORK/v4-artifact-metadata.json")" = 'false'
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$V4_ARTIFACT/zip" > "$WORK/v4-artifact.zip"
test "$(stat -c%s "$WORK/v4-artifact.zip")" = "$V4_ARTIFACT_BYTES"
test "sha256:$(sha256sum "$WORK/v4-artifact.zip" | cut -d' ' -f1)" = "$V4_ARTIFACT_DIGEST"

printf 'extracting-and-patching-exact-v4-run-block\n' > "$WORK/STAGE"
git show "$V4_HEAD:$V4_WORKFLOW" > "$SOURCE_YAML"
test "$(stat -c%s "$SOURCE_YAML")" = "$V4_WORKFLOW_BYTES"
test "$(sha256sum "$SOURCE_YAML" | cut -d' ' -f1)" = "$V4_WORKFLOW_SHA256"

python - "$SOURCE_YAML" "$SOURCE_RUN_SCRIPT" "$PATCHED_RUN_SCRIPT" "$PATCH_RECEIPT" <<'PY'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

source_yaml_path, source_run_path, patched_run_path, receipt_path = sys.argv[1:]
workflow = Path(source_yaml_path).read_text(encoding='utf-8')
lines = workflow.splitlines()
step = '      - name: Recover immutable blobs, repair exact controller, and execute'
start = lines.index(step)
run_line = lines.index('        run: |', start)
body = []
for line in lines[run_line + 1:]:
    if line.startswith('      - name:'):
        break
    assert not line or line.startswith('          '), line
    body.append(line[10:] if line else '')
source = '\n'.join(body) + '\n'
assert len(source.encode()) == 14841
assert hashlib.sha256(source.encode()).hexdigest() == (
    '0de4cab804b1513e0116248deb5bcb4fc0eed8c249b679bea5b19a6d1203afd8'
)
Path(source_run_path).write_text(source, encoding='utf-8')

bad_parent = 'test "$(git rev-parse "$SOURCE_HEAD^")" = "$CARRIER_BASE"'
correct_parent = '''FIRST_SOURCE_COMMIT="$(git rev-list --reverse "$CARRIER_BASE".."$SOURCE_HEAD" | head -n1)"
test -n "$FIRST_SOURCE_COMMIT"
test "$(git rev-parse "$FIRST_SOURCE_COMMIT^")" = "$CARRIER_BASE"'''
replacements = [
    (bad_parent, correct_parent, 'first_carrier_commit_parent_topology'),
    ('.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v4.yml', '.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml', 'workflow_namespace'),
    ('schoolhouse-current-frontier-recovered-payload-v4', 'schoolhouse-current-frontier-recovered-payload-v5', 'payload_namespace'),
    ('schoolhouse-current-frontier-source-controller-v4.sh', 'schoolhouse-current-frontier-source-controller-v5.sh', 'source_controller_namespace'),
    ('schoolhouse-current-frontier-materializer-v4.sh', 'schoolhouse-current-frontier-materializer-v5.sh', 'patched_controller_namespace'),
    ('schoolhouse-current-frontier-controller-repair-v4.json', 'schoolhouse-current-frontier-controller-repair-v5.json', 'repair_receipt_namespace'),
    ('schoolhouse-current-frontier-bootstrap-v4', 'schoolhouse-current-frontier-bootstrap-v5', 'bootstrap_namespace'),
    ('schoolhouse-current-frontier-materialization-v4', 'schoolhouse-current-frontier-materialization-v5', 'materialization_namespace'),
    ('afacca79e3a1e6ba37081e352f3ceb762c1da9d84521f9b83a5968fff24336e3', 'c3efd228f296c4d6cde7a17048da3df70812a2a8a122e2a7d96034f9d73624ae', 'expected_inner_controller_sha256'),
    ('schoolhouse-current-frontier-controller-repair@4', 'schoolhouse-current-frontier-controller-repair@5', 'inner_repair_schema'),
    ('direct_v4_controller_repair=pass', 'direct_v5_controller_repair=pass', 'inner_repair_message'),
    ('initializing-direct-v4', 'initializing-direct-v5', 'initial_stage'),
    ('applying-seven-exact-v4-controller-repairs', 'applying-seven-exact-v5-controller-repairs', 'repair_stage'),
    ('executing-exact-direct-v4-controller', 'executing-exact-direct-v5-controller', 'execution_stage'),
]

repaired = source
applied = []
for old, new, name in replacements:
    count = repaired.count(old)
    assert count >= 1, (name, count)
    repaired = repaired.replace(old, new)
    applied.append({'name': name, 'occurrences': count})

assert bad_parent not in repaired
assert repaired.count('FIRST_SOURCE_COMMIT') == 3
assert len(repaired.encode()) == 14971
repaired_sha256 = hashlib.sha256(repaired.encode()).hexdigest()
assert repaired_sha256 == '9b4048574c5f34d9935fa93aa9020be52f81deb3c4bbbd9dc2b68e36b9c120c3'
Path(patched_run_path).write_text(repaired, encoding='utf-8')
Path(patched_run_path).chmod(0o755)

value = {
    'schema_version': 'schoolhouse-current-frontier-v5-wrapper-repair@1',
    'state': 'complete',
    'v4_run_bytes': len(source.encode()),
    'v4_run_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'v5_run_bytes': len(repaired.encode()),
    'v5_run_sha256': repaired_sha256,
    'repairs': applied,
    'repair_classes': len(applied),
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print('v5_wrapper_repair=pass topology=first_carrier_commit_parent product_payload_changes=0')
PY

test "$(stat -c%s "$SOURCE_RUN_SCRIPT")" = "$SOURCE_RUN_BYTES"
test "$(sha256sum "$SOURCE_RUN_SCRIPT" | cut -d' ' -f1)" = "$SOURCE_RUN_SHA256"
test "$(stat -c%s "$PATCHED_RUN_SCRIPT")" = "$PATCHED_RUN_BYTES"
test "$(sha256sum "$PATCHED_RUN_SCRIPT" | cut -d' ' -f1)" = "$PATCHED_RUN_SHA256"
bash -n "$PATCHED_RUN_SCRIPT"

printf 'injecting-source-window-recovery-into-v5-run-block\n' > "$WORK/STAGE"
python - "$PATCHED_RUN_SCRIPT" "$WORK/v5-source-window-injection.json" <<'PY_PATCH_INNER'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

script_path, receipt_path = sys.argv[1:]
source = Path(script_path).read_text(encoding='utf-8')
start_marker = "printf 'recovering-immutable-source-blobs\\n' > \"$BOOTSTRAP/STAGE\""
end_marker = "printf 'reconstructing-exact-source-controller\\n' > \"$BOOTSTRAP/STAGE\""
assert source.count(start_marker) == 1
assert source.count(end_marker) == 1
start = source.index(start_marker)
end = source.index(end_marker)
assert start < end

recovery = r"""printf 'recovering-intended-source-chunks-from-carrier-byte-windows\n' > "$BOOTSTRAP/STAGE"
python - "$SOURCE_HEAD" "$SOURCE_PAYLOAD" "$RECOVERED_PAYLOAD" "$BOOTSTRAP" <<'PY_RECOVER_WINDOWS'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import subprocess
import sys

source_head, source_payload, recovered_payload_raw, bootstrap_raw = sys.argv[1:]
recovered_payload = Path(recovered_payload_raw)
bootstrap = Path(bootstrap_raw)
recovered_payload.mkdir(parents=True, exist_ok=True)
bootstrap.mkdir(parents=True, exist_ok=True)

expected = [
    ('controller', 0, 'controller-00', 'c38b28b1598f126d2727a4d9228f494e4c1079d5', 5000, 'ec8b175c1473fd9f7f7c893a495269df2dfd440e4960f9d74487d706c14060f9'),
    ('controller', 1, 'controller-01', '4b80357e74d23fe7edb0e7ce25052e1929f81db0', 5000, '8e69b377c4a4208bded118d4b8477a9ceac6ef35e66931455816ce786a1e54e2'),
    ('controller', 2, 'controller-02', '9ceb01ab8c0f5efd09e26d66672a6dc9ceaf248d', 5000, 'f764d261b300f0062345e7df8c5a6d530455560896094b405df87520f7be618f'),
    ('controller', 3, 'controller-03', '9175ec1ad24346b9db9ab88722bb02ae1020414b', 5000, '79b2e68a76dc3ff0d13ec8c30cbedc8c41cbb8c5fc01cd95d94c2dbd513af2ee'),
    ('controller', 4, 'controller-04', '22d3e5b938499d0b56df11ac1a9211e05712dc30', 456, '0bdb8068c48e536d5d6698be2bc58031af338bedd7cb2231148e959af4170f68'),
    ('payload', 0, 'part-00', '417dab959423065d8cbfbe9af183cde4b7c5fd25', 10000, 'e932c87c3204e01fc208e6c2e3e46b86e255d42d57dadd1360e65f80269ae12b'),
    ('payload', 1, 'part-01', '35607251fbb7fcf7370b710a0baf1e99f196577b', 10000, 'f814e46666d96edaf076c6d8b992310e66baa62cc58622083955e38b7752e6d2'),
    ('payload', 2, 'part-02', 'ebd9841e850cef407c4d35191e234ec86a9da407', 10000, 'a2c3a61652bde254bb66dd7e27546bfd2c3bc078220aae89aa7ebbca482fda89'),
    ('payload', 3, 'part-03', '21971133a07421db3e3c219473c717d54e3479fb', 10000, '55b32a2d8c045e8cb2f2eebb565b70a5a3155b84746b05ac4895438487887f2f'),
    ('payload', 4, 'part-04', 'fc8dc1c4bb1cf991ae4a7f74f723569fa7307bf6', 10000, 'ce1a3e3f3c19cd97215580d8f0fd1f7548c633828f468d0f0949a891fc8639c8'),
    ('payload', 5, 'part-05', '5fb94d345a19f9b7df3fdc778ca2a89c03d18b57', 10000, '116a5d7864e3557b40ee4a4f35c466c6e0e82b13fc14d4326841dd86e2772a04'),
    ('payload', 6, 'part-06', '70c0d173f6b887ebc5f488ac407b504ee2a95835', 5880, '22a59c63b9aeea9f8a27febcaf5a0b12d34a07fc7c5340c1142825e0ec53339d'),
]

def git_output(*args: str) -> bytes:
    return subprocess.run(
        ['git', *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout

def git_blob_sha(data: bytes) -> str:
    header = f'blob {len(data)}\\0'.encode()
    return hashlib.sha1(header + data).hexdigest()

def matching_offsets(data: bytes, size: int, digest: str) -> list[int]:
    if len(data) < size:
        return []
    view = memoryview(data)
    return [
        offset
        for offset in range(len(data) - size + 1)
        if hashlib.sha256(view[offset:offset + size]).hexdigest() == digest
    ]

source_inventory = []
recovery_rows = []
for kind, ordinal, filename, expected_blob, expected_bytes, expected_sha256 in expected:
    relative = f'{source_payload}/{filename}'
    spec = f'{source_head}:{relative}'
    observed_blob = git_output('rev-parse', spec).decode().strip()
    observed = git_output('cat-file', 'blob', spec)
    observed_sha256 = hashlib.sha256(observed).hexdigest()
    source_inventory.append({
        'kind': kind,
        'ordinal': ordinal,
        'path': relative,
        'observed_blob': observed_blob,
        'observed_bytes': len(observed),
        'observed_sha256': observed_sha256,
    })
    offsets = matching_offsets(observed, expected_bytes, expected_sha256)
    assert len(offsets) == 1, {
        'path': relative,
        'expected_bytes': expected_bytes,
        'expected_sha256': expected_sha256,
        'matching_offsets': offsets,
        'observed_bytes': len(observed),
        'observed_sha256': observed_sha256,
    }
    offset = offsets[0]
    recovered = observed[offset:offset + expected_bytes]
    reconstructed_blob = git_blob_sha(recovered)
    assert len(recovered) == expected_bytes
    assert hashlib.sha256(recovered).hexdigest() == expected_sha256
    assert reconstructed_blob == expected_blob
    output = recovered_payload / filename
    output.write_bytes(recovered)
    if offset == 0 and expected_bytes == len(observed):
        window_class = 'whole_path'
    elif offset == 0:
        window_class = 'prefix'
    elif offset + expected_bytes == len(observed):
        window_class = 'suffix'
    else:
        window_class = 'interior'
    recovery_rows.append({
        'kind': kind,
        'ordinal': ordinal,
        'source_path': relative,
        'source_blob': observed_blob,
        'source_bytes': len(observed),
        'source_sha256': observed_sha256,
        'window_offset': offset,
        'window_length': expected_bytes,
        'window_class': window_class,
        'window_sha256': expected_sha256,
        'reconstructed_git_blob': reconstructed_blob,
        'expected_git_blob': expected_blob,
        'matching_windows_in_designated_path': 1,
    })

controller = b''.join((recovered_payload / f'controller-{index:02d}').read_bytes() for index in range(5))
payload_b64 = b''.join((recovered_payload / f'part-{index:02d}').read_bytes() for index in range(7))
assert len(controller) == 20456
assert hashlib.sha256(controller).hexdigest() == '7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd'
assert len(payload_b64) == 65880
assert hashlib.sha256(payload_b64).hexdigest() == '2ef3e418be0d06986d9825f7810e69e700884fc70a437c93bb381c40dd627aaa'

value = {
    'schema_version': 'schoolhouse-current-frontier-source-window-recovery@1',
    'state': 'complete',
    'source_head': source_head,
    'source_payload': source_payload,
    'source_path_count': len(source_inventory),
    'recovered_chunk_count': len(recovery_rows),
    'recovered_controller_bytes': len(controller),
    'recovered_controller_sha256': hashlib.sha256(controller).hexdigest(),
    'recovered_payload_b64_bytes': len(payload_b64),
    'recovered_payload_b64_sha256': hashlib.sha256(payload_b64).hexdigest(),
    'source_inventory': source_inventory,
    'recovery_windows': recovery_rows,
    'all_windows_unique_within_designated_source_path': True,
    'all_reconstructed_git_blobs_equal_expected': True,
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(bootstrap / 'source-window-recovery.json').write_text(
    json.dumps(value, indent=2, sort_keys=True) + '\\n',
    encoding='utf-8',
)
with (bootstrap / 'source-window-recovery.tsv').open('w', encoding='utf-8') as handle:
    handle.write(
        'kind\\tordinal\\tsource_path\\tsource_blob\\tsource_bytes\\t'
        'source_sha256\\twindow_offset\\twindow_length\\twindow_class\\t'
        'window_sha256\\treconstructed_git_blob\\n'
    )
    for row in recovery_rows:
        handle.write(
            f"{row['kind']}\\t{row['ordinal']}\\t{row['source_path']}\\t"
            f"{row['source_blob']}\\t{row['source_bytes']}\\t{row['source_sha256']}\\t"
            f"{row['window_offset']}\\t{row['window_length']}\\t{row['window_class']}\\t"
            f"{row['window_sha256']}\\t{row['reconstructed_git_blob']}\\n"
        )
print(
    'source_window_recovery=pass '
    f'chunks={len(recovery_rows)} controller_bytes={len(controller)} '
    f'payload_b64_bytes={len(payload_b64)}'
)
PY_RECOVER_WINDOWS

"""
repaired = source[:start] + recovery + source[end:]
assert repaired.count('source_window_recovery=pass') == 1
assert repaired.count(start_marker) == 0
Path(script_path).write_text(repaired, encoding='utf-8')
Path(script_path).chmod(0o755)
value = {
    'schema_version': 'schoolhouse-current-frontier-v5-source-window-injection@1',
    'state': 'complete',
    'source_v5_run_bytes': len(source.encode()),
    'source_v5_run_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'patched_v5_run_bytes': len(repaired.encode()),
    'patched_v5_run_sha256': hashlib.sha256(repaired.encode()).hexdigest(),
    'recovery_block_replacements': 1,
    'expected_recovered_chunks': 12,
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print('v5_source_window_injection=pass expected_recovered_chunks=12 product_payload_changes=0')
PY_PATCH_INNER
bash -n "$PATCHED_RUN_SCRIPT"

printf 'executing-corrected-v5-run-block-with-source-window-recovery\n' > "$WORK/STAGE"
bash "$PATCHED_RUN_SCRIPT"
printf 'complete\n' > "$WORK/STAGE"

