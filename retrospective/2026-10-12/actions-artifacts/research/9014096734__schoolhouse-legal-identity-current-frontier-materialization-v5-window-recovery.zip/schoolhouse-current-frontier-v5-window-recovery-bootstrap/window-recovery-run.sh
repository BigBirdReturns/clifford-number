set -Eeuo pipefail
BASE='1e52a58be874538509d6c0d3c06adc12fc53cad7'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml'
CLEAN_BRANCH='agent/schoolhouse-legal-identity-current-frontier-materializer-v5-clean'
CLEAN_HEAD='49a21f9a9a52180116214fa7d064f1c8c1be4297'
CLEAN_WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml'
CLEAN_WORKFLOW_BLOB='0017702db8d11f583575bc53b4c0a958048a2879'
OUTER="$RUNNER_TEMP/schoolhouse-current-frontier-v5-window-recovery-wrapper"
CLEAN_YAML="$OUTER/source-v5-clean-workflow.yml"
CLEAN_RUN="$OUTER/source-v5-clean-run.sh"
PATCHED_CLEAN_RUN="$OUTER/patched-v5-clean-window-recovery.sh"
OUTER_RECEIPT="$OUTER/window-recovery-wrapper.json"
INNER_RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v5"
rm -rf "$OUTER" "$INNER_RECEIPT"
mkdir -p "$OUTER"
printf 'initializing-window-recovery-wrapper\n' > "$OUTER/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\n' > "$OUTER/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  printf '%s\n' "$rc" > "$OUTER/WINDOW_RECOVERY_WRAPPER_EXIT_CODE"
  (
    cd "$OUTER"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-one-path-carrier-and-immutable-clean-wrapper\n' > "$OUTER/STAGE"
git fetch --no-tags origin main "$CLEAN_BRANCH"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
mapfile -t CARRIER_PATHS < <(git diff --name-only "$BASE"..HEAD)
test "${#CARRIER_PATHS[@]}" -eq 1
test "${CARRIER_PATHS[0]}" = "$WORKFLOW"
git diff --check "$BASE"..HEAD
git merge-base --is-ancestor "$BASE" "$(git rev-parse origin/main)"
test "$(git rev-parse "origin/$CLEAN_BRANCH")" = "$CLEAN_HEAD"
test "$(git rev-parse "$CLEAN_HEAD^")" = "$BASE"
test "$(git rev-list --count "$BASE".."$CLEAN_HEAD")" = '1'
mapfile -t CLEAN_PATHS < <(git diff --name-only "$BASE".."$CLEAN_HEAD")
test "${#CLEAN_PATHS[@]}" -eq 1
test "${CLEAN_PATHS[0]}" = "$CLEAN_WORKFLOW"
test "$(git rev-parse "$CLEAN_HEAD:$CLEAN_WORKFLOW")" = "$CLEAN_WORKFLOW_BLOB"

printf 'extracting-and-injecting-clean-v5-wrapper\n' > "$OUTER/STAGE"
git show "$CLEAN_HEAD:$CLEAN_WORKFLOW" > "$CLEAN_YAML"
python - "$CLEAN_YAML" "$CLEAN_RUN" "$PATCHED_CLEAN_RUN" "$OUTER_RECEIPT" <<'PY_PATCH_CLEAN'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

source_yaml_path, source_run_path, patched_run_path, receipt_path = sys.argv[1:]
workflow = Path(source_yaml_path).read_text(encoding='utf-8')
lines = workflow.splitlines()
step = '      - name: Authenticate v4, correct source-chain topology, and execute'
assert lines.count(step) == 1
start = lines.index(step)
run_line = lines.index('        run: |', start)
body = []
for line in lines[run_line + 1:]:
    if line.startswith('      - name:'):
        break
    assert not line or line.startswith('          '), line
    body.append(line[10:] if line else '')
source = '\n'.join(body) + '\n'
Path(source_run_path).write_text(source, encoding='utf-8')
Path(source_run_path).chmod(0o755)

old_execution = '''printf 'executing-corrected-v5-run-block\\n' > "$WORK/STAGE"
bash "$PATCHED_RUN_SCRIPT"
printf 'complete\\n' > "$WORK/STAGE"'''
new_execution = r'''printf 'injecting-source-window-recovery-into-v5-run-block\n' > "$WORK/STAGE"
python - "$PATCHED_RUN_SCRIPT" "$WORK/v5-source-window-injection.json" <<'PY_PATCH_INNER'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

script_path, receipt_path = sys.argv[1:]
source = Path(script_path).read_text(encoding='utf-8')
start_marker = "printf 'recovering-immutable-source-blobs\\n' > \"$BOOTSTRAP/STAGE\""
end_marker = "printf 'reconstructing-exact-source-controller\\n' > \"$BOOTSTRAP/STAGE\""
assert source.count(start_marker) == 1
assert source.count(end_marker) == 1
start = source.index(start_marker)
end = source.index(end_marker)
assert start < end

recovery = r"""printf 'recovering-intended-source-chunks-from-carrier-byte-windows\n' > "$BOOTSTRAP/STAGE"
python - "$SOURCE_HEAD" "$SOURCE_PAYLOAD" "$RECOVERED_PAYLOAD" "$BOOTSTRAP" <<'PY_RECOVER_WINDOWS'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import subprocess
import sys

source_head, source_payload, recovered_payload_raw, bootstrap_raw = sys.argv[1:]
recovered_payload = Path(recovered_payload_raw)
bootstrap = Path(bootstrap_raw)
recovered_payload.mkdir(parents=True, exist_ok=True)
bootstrap.mkdir(parents=True, exist_ok=True)

expected = [
    ('controller', 0, 'controller-00', 'c38b28b1598f126d2727a4d9228f494e4c1079d5', 5000, 'ec8b175c1473fd9f7f7c893a495269df2dfd440e4960f9d74487d706c14060f9'),
    ('controller', 1, 'controller-01', '4b80357e74d23fe7edb0e7ce25052e1929f81db0', 5000, '8e69b377c4a4208bded118d4b8477a9ceac6ef35e66931455816ce786a1e54e2'),
    ('controller', 2, 'controller-02', '9ceb01ab8c0f5efd09e26d66672a6dc9ceaf248d', 5000, 'f764d261b300f0062345e7df8c5a6d530455560896094b405df87520f7be618f'),
    ('controller', 3, 'controller-03', '9175ec1ad24346b9db9ab88722bb02ae1020414b', 5000, '79b2e68a76dc3ff0d13ec8c30cbedc8c41cbb8c5fc01cd95d94c2dbd513af2ee'),
    ('controller', 4, 'controller-04', '22d3e5b938499d0b56df11ac1a9211e05712dc30', 456, '0bdb8068c48e536d5d6698be2bc58031af338bedd7cb2231148e959af4170f68'),
    ('payload', 0, 'part-00', '417dab959423065d8cbfbe9af183cde4b7c5fd25', 10000, 'e932c87c3204e01fc208e6c2e3e46b86e255d42d57dadd1360e65f80269ae12b'),
    ('payload', 1, 'part-01', '35607251fbb7fcf7370b710a0baf1e99f196577b', 10000, 'f814e46666d96edaf076c6d8b992310e66baa62cc58622083955e38b7752e6d2'),
    ('payload', 2, 'part-02', 'ebd9841e850cef407c4d35191e234ec86a9da407', 10000, 'a2c3a61652bde254bb66dd7e27546bfd2c3bc078220aae89aa7ebbca482fda89'),
    ('payload', 3, 'part-03', '21971133a07421db3e3c219473c717d54e3479fb', 10000, '55b32a2d8c045e8cb2f2eebb565b70a5a3155b84746b05ac4895438487887f2f'),
    ('payload', 4, 'part-04', 'fc8dc1c4bb1cf991ae4a7f74f723569fa7307bf6', 10000, 'ce1a3e3f3c19cd97215580d8f0fd1f7548c633828f468d0f0949a891fc8639c8'),
    ('payload', 5, 'part-05', '5fb94d345a19f9b7df3fdc778ca2a89c03d18b57', 10000, '116a5d7864e3557b40ee4a4f35c466c6e0e82b13fc14d4326841dd86e2772a04'),
    ('payload', 6, 'part-06', '70c0d173f6b887ebc5f488ac407b504ee2a95835', 5880, '22a59c63b9aeea9f8a27febcaf5a0b12d34a07fc7c5340c1142825e0ec53339d'),
]

def git_output(*args: str) -> bytes:
    return subprocess.run(
        ['git', *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout

def git_blob_sha(data: bytes) -> str:
    header = f'blob {len(data)}\\0'.encode()
    return hashlib.sha1(header + data).hexdigest()

def matching_offsets(data: bytes, size: int, digest: str) -> list[int]:
    if len(data) < size:
        return []
    view = memoryview(data)
    return [
        offset
        for offset in range(len(data) - size + 1)
        if hashlib.sha256(view[offset:offset + size]).hexdigest() == digest
    ]

source_inventory = []
recovery_rows = []
for kind, ordinal, filename, expected_blob, expected_bytes, expected_sha256 in expected:
    relative = f'{source_payload}/{filename}'
    spec = f'{source_head}:{relative}'
    observed_blob = git_output('rev-parse', spec).decode().strip()
    observed = git_output('cat-file', 'blob', spec)
    observed_sha256 = hashlib.sha256(observed).hexdigest()
    source_inventory.append({
        'kind': kind,
        'ordinal': ordinal,
        'path': relative,
        'observed_blob': observed_blob,
        'observed_bytes': len(observed),
        'observed_sha256': observed_sha256,
    })
    offsets = matching_offsets(observed, expected_bytes, expected_sha256)
    assert len(offsets) == 1, {
        'path': relative,
        'expected_bytes': expected_bytes,
        'expected_sha256': expected_sha256,
        'matching_offsets': offsets,
        'observed_bytes': len(observed),
        'observed_sha256': observed_sha256,
    }
    offset = offsets[0]
    recovered = observed[offset:offset + expected_bytes]
    reconstructed_blob = git_blob_sha(recovered)
    assert len(recovered) == expected_bytes
    assert hashlib.sha256(recovered).hexdigest() == expected_sha256
    assert reconstructed_blob == expected_blob
    output = recovered_payload / filename
    output.write_bytes(recovered)
    if offset == 0 and expected_bytes == len(observed):
        window_class = 'whole_path'
    elif offset == 0:
        window_class = 'prefix'
    elif offset + expected_bytes == len(observed):
        window_class = 'suffix'
    else:
        window_class = 'interior'
    recovery_rows.append({
        'kind': kind,
        'ordinal': ordinal,
        'source_path': relative,
        'source_blob': observed_blob,
        'source_bytes': len(observed),
        'source_sha256': observed_sha256,
        'window_offset': offset,
        'window_length': expected_bytes,
        'window_class': window_class,
        'window_sha256': expected_sha256,
        'reconstructed_git_blob': reconstructed_blob,
        'expected_git_blob': expected_blob,
        'matching_windows_in_designated_path': 1,
    })

controller = b''.join((recovered_payload / f'controller-{index:02d}').read_bytes() for index in range(5))
payload_b64 = b''.join((recovered_payload / f'part-{index:02d}').read_bytes() for index in range(7))
assert len(controller) == 20456
assert hashlib.sha256(controller).hexdigest() == '7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd'
assert len(payload_b64) == 65880
assert hashlib.sha256(payload_b64).hexdigest() == '2ef3e418be0d06986d9825f7810e69e700884fc70a437c93bb381c40dd627aaa'

value = {
    'schema_version': 'schoolhouse-current-frontier-source-window-recovery@1',
    'state': 'complete',
    'source_head': source_head,
    'source_payload': source_payload,
    'source_path_count': len(source_inventory),
    'recovered_chunk_count': len(recovery_rows),
    'recovered_controller_bytes': len(controller),
    'recovered_controller_sha256': hashlib.sha256(controller).hexdigest(),
    'recovered_payload_b64_bytes': len(payload_b64),
    'recovered_payload_b64_sha256': hashlib.sha256(payload_b64).hexdigest(),
    'source_inventory': source_inventory,
    'recovery_windows': recovery_rows,
    'all_windows_unique_within_designated_source_path': True,
    'all_reconstructed_git_blobs_equal_expected': True,
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(bootstrap / 'source-window-recovery.json').write_text(
    json.dumps(value, indent=2, sort_keys=True) + '\\n',
    encoding='utf-8',
)
with (bootstrap / 'source-window-recovery.tsv').open('w', encoding='utf-8') as handle:
    handle.write(
        'kind\\tordinal\\tsource_path\\tsource_blob\\tsource_bytes\\t'
        'source_sha256\\twindow_offset\\twindow_length\\twindow_class\\t'
        'window_sha256\\treconstructed_git_blob\\n'
    )
    for row in recovery_rows:
        handle.write(
            f"{row['kind']}\\t{row['ordinal']}\\t{row['source_path']}\\t"
            f"{row['source_blob']}\\t{row['source_bytes']}\\t{row['source_sha256']}\\t"
            f"{row['window_offset']}\\t{row['window_length']}\\t{row['window_class']}\\t"
            f"{row['window_sha256']}\\t{row['reconstructed_git_blob']}\\n"
        )
print(
    'source_window_recovery=pass '
    f'chunks={len(recovery_rows)} controller_bytes={len(controller)} '
    f'payload_b64_bytes={len(payload_b64)}'
)
PY_RECOVER_WINDOWS

"""
repaired = source[:start] + recovery + source[end:]
assert repaired.count('source_window_recovery=pass') == 1
assert repaired.count(start_marker) == 0
Path(script_path).write_text(repaired, encoding='utf-8')
Path(script_path).chmod(0o755)
value = {
    'schema_version': 'schoolhouse-current-frontier-v5-source-window-injection@1',
    'state': 'complete',
    'source_v5_run_bytes': len(source.encode()),
    'source_v5_run_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'patched_v5_run_bytes': len(repaired.encode()),
    'patched_v5_run_sha256': hashlib.sha256(repaired.encode()).hexdigest(),
    'recovery_block_replacements': 1,
    'expected_recovered_chunks': 12,
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print('v5_source_window_injection=pass expected_recovered_chunks=12 product_payload_changes=0')
PY_PATCH_INNER
bash -n "$PATCHED_RUN_SCRIPT"

printf 'executing-corrected-v5-run-block-with-source-window-recovery\n' > "$WORK/STAGE"
bash "$PATCHED_RUN_SCRIPT"
printf 'complete\n' > "$WORK/STAGE"'''

assert source.count(old_execution) == 1
repaired = source.replace(old_execution, new_execution)
assert repaired.count('v5_source_window_injection=pass') == 1
Path(patched_run_path).write_text(repaired, encoding='utf-8')
Path(patched_run_path).chmod(0o755)
value = {
    'schema_version': 'schoolhouse-current-frontier-v5-clean-window-wrapper@1',
    'state': 'complete',
    'source_clean_head': '49a21f9a9a52180116214fa7d064f1c8c1be4297',
    'source_clean_workflow_blob': '0017702db8d11f583575bc53b4c0a958048a2879',
    'source_clean_run_bytes': len(source.encode()),
    'source_clean_run_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'patched_clean_run_bytes': len(repaired.encode()),
    'patched_clean_run_sha256': hashlib.sha256(repaired.encode()).hexdigest(),
    'execution_block_replacements': 1,
    'expected_recovered_chunks': 12,
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
print('clean_v5_window_wrapper=pass expected_recovered_chunks=12 product_payload_changes=0')
PY_PATCH_CLEAN
bash -n "$CLEAN_RUN"
bash -n "$PATCHED_CLEAN_RUN"

printf 'executing-clean-v5-wrapper-with-window-recovery\n' > "$OUTER/STAGE"
bash "$PATCHED_CLEAN_RUN"
printf 'complete\n' > "$OUTER/STAGE"

