# Research fan-out: formation-duarte-station-area-assessment-governance-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-duarte-station-area-assessment-governance
- Items: 3
- Fingerprint: `500bfab9d48d6af5c95e`

## formation:sig-place-formation-v1:assessment-governance:10eb5dc575643d0c3266: Formation control: duarte-station-area — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `0082194413b533caf47c`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA downtown association bylaws city agreement" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:assessment-governance:3d604bc269569988df25: Formation control: duarte-station-area — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `05d93538afb87d2f3321`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA business improvement district formation assessment" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:assessment-governance:445a6f7ccd367b88b4e4: Formation control: duarte-station-area — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `ff354c0563e8f8f08140`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA property and business improvement district 36600" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
