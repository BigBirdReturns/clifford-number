# Research fan-out: crawl-rejection-federal-register-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-federal-register
- Items: 20
- Fingerprint: `038a7190f0c9133526d5`

## crawl-rejection:reject_161832f63bfbda1d15b868bb: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `e8459e74d46ceb3d1fad`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_161832f63bfbda1d15b868bb`, `federal-register`

---

## crawl-rejection:reject_258439c0444f8ac2cb282584: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7fc8cb0183a4e555f2ab`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_258439c0444f8ac2cb282584`, `federal-register`

---

## crawl-rejection:reject_2ef2d6f5e42cf1e064830e07: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6d46fc8637cc9141b6cd`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_2ef2d6f5e42cf1e064830e07`, `federal-register`

---

## crawl-rejection:reject_30e9501a3dbb9ad0613564f0: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5e89d6ff5b0ff804a8f4`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_30e9501a3dbb9ad0613564f0`, `federal-register`

---

## crawl-rejection:reject_33bbdd10431adaf0cd175c60: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7c587209c2dbd53d0d63`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_33bbdd10431adaf0cd175c60`, `federal-register`

---

## crawl-rejection:reject_3da9151102d71e721fb00967: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `fab439f6c48b104318b5`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_3da9151102d71e721fb00967`, `federal-register`

---

## crawl-rejection:reject_3f43b2bd96fcbd69ed2f80fe: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `e3ecafad868e20b7f597`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_3f43b2bd96fcbd69ed2f80fe`, `federal-register`

---

## crawl-rejection:reject_3f9ccfb8b309565a8786a657: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `ed0510b524f08e1d002e`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_3f9ccfb8b309565a8786a657`, `federal-register`

---

## crawl-rejection:reject_409abb86b0ba01b75349c86c: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `92ff4db6f6fc74ecd6e6`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_409abb86b0ba01b75349c86c`, `federal-register`

---

## crawl-rejection:reject_42a34198ce1318efc09a8eb8: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `40cbd6b5bd6e581482f0`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_42a34198ce1318efc09a8eb8`, `federal-register`

---

## crawl-rejection:reject_46855c8660a4daec84baacac: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `279d0682d47d741e6988`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_46855c8660a4daec84baacac`, `federal-register`

---

## crawl-rejection:reject_4cce044ad37193a4e9894408: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `b1c981fccbcc795247df`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_4cce044ad37193a4e9894408`, `federal-register`

---

## crawl-rejection:reject_4e5a5234991eb2b31c1cf03c: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a7cffffaedc0c56dffc4`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_4e5a5234991eb2b31c1cf03c`, `federal-register`

---

## crawl-rejection:reject_612716b146c5f8a3d8c20e62: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `954869e37d04a3881c59`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_612716b146c5f8a3d8c20e62`, `federal-register`

---

## crawl-rejection:reject_63a38683f45bba25fe3bd67a: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `d5b0be65e9b226f87323`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_63a38683f45bba25fe3bd67a`, `federal-register`

---

## crawl-rejection:reject_64a5f6ce9ef3e82f70e3c3e6: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a68711656b58c1c39830`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_64a5f6ce9ef3e82f70e3c3e6`, `federal-register`

---

## crawl-rejection:reject_66d71cd12eac6b6f5523eb9e: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a7c5ab9174193a26ecd5`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_66d71cd12eac6b6f5523eb9e`, `federal-register`

---

## crawl-rejection:reject_6e3f2d994189682d85fc85ee: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6127b4cd82c205c8a775`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_6e3f2d994189682d85fc85ee`, `federal-register`

---

## crawl-rejection:reject_6e58c9b30346763cd6053288: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `472e3c217e40a124512f`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_6e58c9b30346763cd6053288`, `federal-register`

---

## crawl-rejection:reject_731c4d84fe3b3923d2bcf04d: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `740b2374063f149b5788`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_731c4d84fe3b3923d2bcf04d`, `federal-register`

---
