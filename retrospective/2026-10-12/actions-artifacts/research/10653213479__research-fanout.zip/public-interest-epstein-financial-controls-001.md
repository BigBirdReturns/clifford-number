# Research fan-out: public-interest-epstein-financial-controls-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-epstein-financial-controls
- Items: 1
- Fingerprint: `25faff8f45313348d809`

## public-interest:epstein-financial-controls: Map Epstein banking, transaction, and compliance predicates

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1a779e35034c387a233f`

**Observed**

The checked-in source manifest identifies nydfs-deutsche-epstein-order as a official_regulatory_order source family for epstein. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Extract account-relationship, transaction, compliance-alert, escalation, regulatory-finding, admission, and penalty events from the DFS order, Senate Finance materials, and the USVI v. JPMorgan docket. Preserve source-specific legal status and exact dates.

Refs: `epstein-financial-controls`, `nydfs-deutsche-epstein-order`, `https://www.dfs.ny.gov/system/files/documents/2020/07/ea20200706_deutsche_bank_consent_order.pdf`

---
