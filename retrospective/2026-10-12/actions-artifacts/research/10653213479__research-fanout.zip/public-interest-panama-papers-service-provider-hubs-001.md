# Research fan-out: public-interest-panama-papers-service-provider-hubs-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-service-provider-hubs
- Items: 1
- Fingerprint: `1d2f15a3052de661dde2`

## public-interest:panama-service-provider-hubs: Rank Panama Papers intermediary and address hubs

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `01c0cd47d2ec82b5723e`

**Observed**

The checked-in source manifest identifies icij-offshore-leaks-relationships as a investigative_graph_dataset source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Rank intermediary and registered-address nodes by entity degree, jurisdiction diversity, active-year span, and source dataset. Preserve whether the hub is a bank, law firm, incorporator, registered agent, branch, or address; apply degree penalties before person-level fan-out.

Refs: `panama-service-provider-hubs`, `icij-offshore-leaks-relationships`, `https://offshoreleaks.icij.org/schema/oldb`

---
