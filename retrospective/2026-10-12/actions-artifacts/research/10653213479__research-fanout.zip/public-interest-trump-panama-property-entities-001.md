# Research fan-out: public-interest-trump-panama-property-entities-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-trump-panama-property-entities
- Items: 1
- Fingerprint: `7f1ea8f56324cd745961`

## public-interest:trump-panama-unit-graph: Expand Trump Ocean Club unit entities without assigning ownership by brand

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `44c2c38c5a41fd67014f`

**Observed**

The checked-in source manifest identifies icij-trump-ocean-club-unit-entities as a investigative_offshore_dataset source family for trump. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Enumerate ICIJ nodes whose entity names reference Trump Ocean Club; expand officers, intermediaries, addresses, unit numbers, and linked entities, then verify against Panama registry and property records. Record licensing, management, developer, broker, unit-owner, and beneficial-owner roles separately.

Refs: `trump-panama-unit-graph`, `icij-trump-ocean-club-unit-entities`, `https://offshoreleaks.icij.org/nodes/10051325`

---
