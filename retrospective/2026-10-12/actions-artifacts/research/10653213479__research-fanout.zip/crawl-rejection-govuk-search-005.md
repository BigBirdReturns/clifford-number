# Research fan-out: crawl-rejection-govuk-search-005

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-govuk-search
- Items: 20
- Fingerprint: `487d0aaba6330b31c33d`

## crawl-rejection:reject_0ab3190ddd3d9acd54f92082: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `0d183726e4086c9ee244`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ab3190ddd3d9acd54f92082`, `govuk-search`

---

## crawl-rejection:reject_0ab98938c10cc455b389a1cd: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a3d588d7e99bbb38056d`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ab98938c10cc455b389a1cd`, `govuk-search`

---

## crawl-rejection:reject_0b542234f508d4c2a41687a1: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1404ceb54047babb6332`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0b542234f508d4c2a41687a1`, `govuk-search`

---

## crawl-rejection:reject_0b651851f49af91961e83672: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `76ac86d6990a719e8e5c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0b651851f49af91961e83672`, `govuk-search`

---

## crawl-rejection:reject_0b7c2f24b26b8355bedbb33f: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `37bc62d08aebb93993e1`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0b7c2f24b26b8355bedbb33f`, `govuk-search`

---

## crawl-rejection:reject_0b8363a2f85052b3efd7b408: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `bfe73e75e41206a81bfc`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0b8363a2f85052b3efd7b408`, `govuk-search`

---

## crawl-rejection:reject_0ba1804251a09b82efa42492: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1f1c8eae61988e9f5e55`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ba1804251a09b82efa42492`, `govuk-search`

---

## crawl-rejection:reject_0bdd94e2faf24bd38cc0d3e1: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7195c058a9fdffb3c325`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0bdd94e2faf24bd38cc0d3e1`, `govuk-search`

---

## crawl-rejection:reject_0c30864a46e04af33b857977: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `925d51dede51e102bef0`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0c30864a46e04af33b857977`, `govuk-search`

---

## crawl-rejection:reject_0cd150a8c223cf9a6253c292: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `34da9686a022fefb4684`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0cd150a8c223cf9a6253c292`, `govuk-search`

---

## crawl-rejection:reject_0cd72d67092587d62e2d0100: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6287eece850031e7b95c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0cd72d67092587d62e2d0100`, `govuk-search`

---

## crawl-rejection:reject_0d01258945d56cb439a59740: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8af8c7ca04620900cfeb`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0d01258945d56cb439a59740`, `govuk-search`

---

## crawl-rejection:reject_0d456e07794a06b35665f238: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1cee2e7a6a4e029087cd`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0d456e07794a06b35665f238`, `govuk-search`

---

## crawl-rejection:reject_0e095cf96d991c946ba0dd49: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `08ef0df7772d6b63ac66`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0e095cf96d991c946ba0dd49`, `govuk-search`

---

## crawl-rejection:reject_0ebc5645ac461f4f310443e7: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `ca5724e7aaac6272c0a3`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ebc5645ac461f4f310443e7`, `govuk-search`

---

## crawl-rejection:reject_0ec54f13a91db5ea39d76b83: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6adbb50e2cf1e08c827e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ec54f13a91db5ea39d76b83`, `govuk-search`

---

## crawl-rejection:reject_0ec8784c193b73231d129312: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `73745ef9a5aa61e22119`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0ec8784c193b73231d129312`, `govuk-search`

---

## crawl-rejection:reject_0eee433b516067a03b89bcf8: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a21cc2a50b2618ebd58b`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0eee433b516067a03b89bcf8`, `govuk-search`

---

## crawl-rejection:reject_0f1ed78c69ece2f8e2a6fb20: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a5834a4793e0ba2a89c0`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0f1ed78c69ece2f8e2a6fb20`, `govuk-search`

---

## crawl-rejection:reject_0f57fddaaccf765ccc7eb405: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6860981e0a144ec003f2`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_0f57fddaaccf765ccc7eb405`, `govuk-search`

---
