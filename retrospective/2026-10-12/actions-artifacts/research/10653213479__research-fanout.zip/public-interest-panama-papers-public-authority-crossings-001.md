# Research fan-out: public-interest-panama-papers-public-authority-crossings-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-public-authority-crossings
- Items: 1
- Fingerprint: `a7e54a5faaca09caa87c`

## public-interest:panama-public-authority-crossing: Test validated offshore nodes against public-authority and capital records

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `ebc9f1879127d1e8a759`

**Observed**

The checked-in source manifest identifies registry-fec-sec-ofac-crossing as a official_registry_crossing source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Intersect registry-validated owners, officers, and entities with time-bounded public office, contracting, lobbying, campaign-finance, regulatory, sanctions, land, aircraft, vessel, and securities records. Require an explicit source edge and temporal compatibility for every crossing.

Refs: `panama-public-authority-crossing`, `registry-fec-sec-ofac-crossing`, `https://api.open.fec.gov/developers/`

---
