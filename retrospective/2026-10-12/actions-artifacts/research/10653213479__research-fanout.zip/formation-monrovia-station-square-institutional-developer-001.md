# Research fan-out: formation-monrovia-station-square-institutional-developer-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-institutional-developer
- Items: 2
- Fingerprint: `c2056fdd14c87a4b9658`

## formation:sig-place-formation-v1:institutional-developer:18f7258d685297ea11aa: Formation control: monrovia-station-square — institutional-developer

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `fcb67ff3d35905cd6052`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA transit oriented development institutional developer project approved" using bounded_public_record_research against municipal_and_press_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:institutional-developer:d7c68b9e10ec6ba298ce: Formation control: monrovia-station-square — institutional-developer

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `b3e5848592388fbc567f`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA downtown mixed use apartment project entitlement" using bounded_public_record_research against municipal_and_press_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
