# Research fan-out: field-autopsy-arcadia-field-autopsy-institutional-developer-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-institutional-developer
- Items: 2
- Fingerprint: `de1c3b3d36f97d7c67e8`

## field-autopsy:arcadia-field-autopsy:trail-monrovia-control:1: The Arcadia Formation: Monrovia Station Square control comparison (1/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `8dbae877a0de1e7145ec`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-monrovia-control as a in_progress candidate trail at stage institutional-developer. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Monrovia Station Square parcel acquisition dates and prior owners for MODA and Alexan Foothills" against county_recorder_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-monrovia-control`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-monrovia-control:2: The Arcadia Formation: Monrovia Station Square control comparison (2/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `6f44975e47633e6115f5`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-monrovia-control as a in_progress candidate trail at stage institutional-developer. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Statewide California PBID count from an authoritative municipal or state source" against official_statistics. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-monrovia-control`, `sig-place-formation-v1`

---
