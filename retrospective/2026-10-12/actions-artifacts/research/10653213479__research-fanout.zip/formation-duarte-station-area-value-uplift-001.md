# Research fan-out: formation-duarte-station-area-value-uplift-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-duarte-station-area-value-uplift
- Items: 2
- Fingerprint: `ecf56d9ff34f5203e322`

## formation:sig-place-formation-v1:value-uplift:7d1abb227d52cb1b758d: Formation control: duarte-station-area — value-uplift

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `e83fafd3af5d6732b900`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA station area property values increase study" using bounded_public_record_research against assessor_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:value-uplift:d8d718e545ea4e51811b: Formation control: duarte-station-area — value-uplift

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `fac99f905fb236fe2bb5`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA downtown assessed value change assessment roll" using bounded_public_record_research against assessor_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
