# Research fan-out: public-interest-trump-campaign-to-business-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-trump-campaign-to-business
- Items: 1
- Fingerprint: `16962cad99299cfd47ef`

## public-interest:trump-campaign-business-disbursements: Resolve Trump committee disbursements to disclosed business entities

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `327574ff3c37ea63b7c4`

**Observed**

The checked-in source manifest identifies openfec-trump-committee-network as a official_campaign_finance_registry source family for trump. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Enumerate candidate P80001571 and the source-resolved authorized presidential committees C00580100, C00828541, and C00867275; extract Schedule B disbursements from 2015 through 2026 and resolve recipients only against exact legal entities in certified OGE disclosures. Preserve raw recipient names and filing/image IDs. Leadership PACs, joint-fundraising committees, and other affiliates require a separately typed and receipted expansion.

Refs: `trump-campaign-business-disbursements`, `openfec-trump-committee-network`, `https://www.fec.gov/data/candidate/p80001571/`

---
