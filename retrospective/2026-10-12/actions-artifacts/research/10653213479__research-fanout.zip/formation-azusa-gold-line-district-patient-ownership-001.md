# Research fan-out: formation-azusa-gold-line-district-patient-ownership-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-azusa-gold-line-district-patient-ownership
- Items: 2
- Fingerprint: `009e91b4e31fe40c9bd2`

## formation:sig-place-formation-v1:patient-ownership:302a37d0184b1adbcad6: Formation control: azusa-gold-line-district — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `cb6d86e658d67ef95fae`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA downtown parcels acquired before station opening" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:patient-ownership:b8cb4536a2047323514e: Formation control: azusa-gold-line-district — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `9f9a0f22c7587799dde8`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA station area property acquisition entitlement application" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
