# Research fan-out: scout-surface-type-recurrence-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-surface-type-recurrence
- Items: 13
- Fingerprint: `5325be226b56c4946adf`

## scout:finding-014: Dr. Ben Warner shows recurring surface logic

- Priority: high
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `debd4be12184df658321`

**Observed**

Dr. Ben Warner has 10 surfaces and secondary types category_formation_surface, governance_continuity_surface, model_governance_surface, public_private_ai_infrastructure, surface_factory_capital_layer. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `ben-warner-no10-digital-data-role-observation-2020-2021`, `faculty-science-officer-employee-overlap-2018-01-24`, `electric-twin-incorporation-2023-09-28`, `electric-twin-ben-warner-director-tenure-2023-09-28`, `electric-twin-seed2-governance-instrument-2025-09-12`, `centre-human-progress-director-appointments-2025-08-05`, `electric-twin-accuracy-methodology-publication-2026-02-11`, `electric-twin-virgin-madfest-session-2026-07-08`, `ben-warner-cummings-shafi-contain-delay-email-2020-03-08`, `electric-twin-registered-shareholdings-2025-09-27`

---

## scout:finding-013: Matt Clifford shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `cb8eaa62a6787e1b0ab1`

**Observed**

Matt Clifford has 9 surfaces and secondary types governance_continuity_surface, government_advisory_surface, model_governance_surface, policy_to_procurement_surface, public_private_ai_infrastructure, surface_factory_capital_layer. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `faculty-science-director-shareholder-overlap-2024-10-10`, `ai-opportunities-action-plan-development-2024-2025`, `ai-opportunities-action-plan-2025`, `dialog-public-directory-exposure-2026-06-16`, `dialog-matt-clifford-invitation-nonattendance-2026-06-16`, `ai-safety-summit-representative-appointment-2023-08-10`, `dsit-matt-clifford-ai-investor-roundtable-2023-10-25`, `frontier-ai-taskforce-external-advisory-board-appointments-2023-09-07`, `entrepreneur-first-cofounder-observation-2018-07-05`

---

## scout:finding-015: Dr. Marc Warner shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `877419c8122d96604fe3`

**Observed**

Dr. Marc Warner has 2 surfaces and secondary types public_private_ai_infrastructure. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `faculty-science-officer-employee-overlap-2018-01-24`, `faculty-science-director-shareholder-overlap-2024-10-10`

---

## scout:finding-016: Alex Cooper shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `f19a4d2bb44f42714453`

**Observed**

Alex Cooper has 5 surfaces and secondary types model_governance_surface, surface_factory_capital_layer. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `electric-twin-incorporation-2023-09-28`, `electric-twin-alex-cooper-director-tenure-2023-09-28`, `electric-twin-seed2-governance-instrument-2025-09-12`, `newsuk-times-exploraition-launch-publication-principals-2026-04-27`, `electric-twin-registered-shareholdings-2025-09-27`

---

## scout:finding-017: Sir Simon Case / Lord Case shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1381bfea04b6fd0332fd`

**Observed**

Sir Simon Case / Lord Case has 3 surfaces and secondary types defence_industrial_surface, democratic_input_replacement, governance_continuity_surface, model_governance_surface. Governance replacement score: 1.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `electric-twin-ethics-board-2026`, `simon-case-cabinet-secretary-2020-2024`, `team-barrow-public-private-fund-2026`

---

## scout:finding-018: Dominic Cummings shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `75a548c8dac1fdf2be0a`

**Observed**

Dominic Cummings has 2 surfaces and secondary types governance_continuity_surface, model_governance_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `vote-leave-data-science-2016`, `ben-warner-cummings-shafi-contain-delay-email-2020-03-08`

---

## scout:finding-019: Saul Klein shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0225a3489824ef558b7d`

**Observed**

Saul Klein has 2 surfaces and secondary types public_private_ai_infrastructure. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `faculty-science-officer-employee-overlap-2018-01-24`, `faculty-science-director-shareholder-overlap-2024-10-10`

---

## scout:finding-020: John Healey shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `bedefd4b20afedb4327d`

**Observed**

John Healey has 4 surfaces and secondary types defence_industrial_surface, government_advisory_surface, policy_to_procurement_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `strategic-defence-review-development-2024-2025`, `strategic-defence-review-2024-2025`, `anduril-ukraine-drone-deal-named-principals-2025-03-06`, `atlantic-bastion-launch-publication-2025-12-08`

---

## scout:finding-021: George Robertson shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `07ff5650f80cd06fb542`

**Observed**

George Robertson has 2 surfaces and secondary types defence_industrial_surface, government_advisory_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `strategic-defence-review-development-2024-2025`, `strategic-defence-review-2024-2025`

---

## scout:finding-022: Richard Barrons shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `fb0eb1393dcf237eca36`

**Observed**

Richard Barrons has 2 surfaces and secondary types defence_industrial_surface, government_advisory_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `strategic-defence-review-development-2024-2025`, `strategic-defence-review-2024-2025`

---

## scout:finding-023: Dr Fiona Hill shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `a0925518e448c6144950`

**Observed**

Dr Fiona Hill has 2 surfaces and secondary types defence_industrial_surface, government_advisory_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `strategic-defence-review-development-2024-2025`, `strategic-defence-review-2024-2025`

---

## scout:finding-024: Dr. Michael Muthukrishna shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `f0b88379aafc3d4a50f6`

**Observed**

Dr. Michael Muthukrishna has 2 surfaces and secondary types model_governance_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `centre-human-progress-director-appointments-2025-08-05`, `electric-twin-muthukrishna-science-adviser-observations-2024-2026`

---

## scout:finding-025: Dr Rich Drake shows recurring surface logic

- Priority: medium
- Type: surface_type_recurrence
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1070939451debce81fc7`

**Observed**

Dr Rich Drake has 3 surfaces and secondary types defence_industrial_surface, government_advisory_surface, policy_to_procurement_surface. Governance replacement score: 0.

**Bounded next action**

Check for additional venues where the same surface type recurs. Do not convert recurrence into a hop unless there is a bounded co-participation surface.

Refs: `anduril-uk-co-director-appointments-2024-07-31`, `anduril-ukraine-drone-deal-named-principals-2025-03-06`, `atlantic-bastion-launch-publication-2025-12-08`

---
