# Research fan-out: formation-monrovia-station-square-patient-ownership-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-patient-ownership
- Items: 2
- Fingerprint: `98718f0a9ec26e24d40c`

## formation:sig-place-formation-v1:patient-ownership:b59cc626302f02c05983: Formation control: monrovia-station-square — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `2cbb0b5f3cc234a10f11`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA station area property acquisition entitlement application" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:patient-ownership:bd202f5bef2b2fed9edf: Formation control: monrovia-station-square — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `9160721b88c0f83fd4f9`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA downtown parcels acquired before station opening" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
