# Research fan-out: public-interest-trump-foreign-state-to-property-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-trump-foreign-state-to-property
- Items: 1
- Fingerprint: `c61d2587294c8f43da6c`

## public-interest:trump-foreign-state-property-ledger: Normalize reported foreign-state payments to Trump businesses

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `cc59e8d1e8334f788ead`

**Observed**

The checked-in source manifest identifies house-mazars-foreign-government-report as a attributed_congressional_staff_finding source family for trump. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Extract the House/Mazars ledger by payer, country, state-entity status, Trump business, property, date, amount, underlying record locator, and report characterization. Compare contemporaneous policy requests only as a separately sourced temporal sequence.

Refs: `trump-foreign-state-property-ledger`, `house-mazars-foreign-government-report`, `https://oversightdemocrats.house.gov/sites/evo-subsites/democrats-oversight.house.gov/files/2024-01-04.COA%20DEMS%20-%20Mazars%20Report.pdf`

---
