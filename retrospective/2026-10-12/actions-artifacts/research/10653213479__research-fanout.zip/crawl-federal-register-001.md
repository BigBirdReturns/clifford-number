# Research fan-out: crawl-federal-register-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-federal-register
- Items: 4
- Fingerprint: `1d3faefbf211ac924cb4`

## crawl:candidate_19e9b062c0fd9fd513ac9db4: Self-Regulatory Organizations; NYSE Arca, Inc.; Notice of Filing of a Proposed Rule Change To Amend Rules 5.32-O and 5.35-O

- Priority: low
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `9c150ab482a62c3b10b0`

**Observed**

federal-register record 2026-13651; matched on body.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_fa931d4acb066c42ba9cdd83`, `https://www.federalregister.gov/documents/2026/07/07/2026-13651/self-regulatory-organizations-nyse-arca-inc-notice-of-filing-of-a-proposed-rule-change-to-amend`

---

## crawl:candidate_769816ad0f9429f8d228fa4d: Self-Regulatory Organizations; NYSE American LLC; Notice of Filing of a Proposed Rule Change To Amend Rule 903G and 906G

- Priority: low
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `4239e6e1be278e22292e`

**Observed**

federal-register record 2026-13650; matched on body.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_70113708870fe587b2f6f674`, `https://www.federalregister.gov/documents/2026/07/07/2026-13650/self-regulatory-organizations-nyse-american-llc-notice-of-filing-of-a-proposed-rule-change-to-amend`

---

## crawl:candidate_a9b76ef4aabef82ca3e4d466: Self-Regulatory Organizations; Cboe Exchange, Inc.; Notice of Filing of a Proposed Rule Change To Amend its Rules To Permit the Listing of Binary Options Overlying Key Performance Indicators (“KPIs”) Reported by Certain Issuers of Stock (“B

- Priority: low
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `739cbba57afa5d27605a`

**Observed**

federal-register record 2026-14201; matched on body.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_97b1d9d47b3e0ece5ace12e8`, `https://www.federalregister.gov/documents/2026/07/15/2026-14201/self-regulatory-organizations-cboe-exchange-inc-notice-of-filing-of-a-proposed-rule-change-to-amend`

---

## crawl:candidate_c03ad233fed753176113ba06: Hazardous Materials: Notice of Actions on Special Permits

- Priority: low
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `aa90ceeadb209e8b3542`

**Observed**

federal-register record 2026-15973; matched on body.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_3055d57ad6dbd93d54d08d6b`, `https://www.federalregister.gov/documents/2026/08/06/2026-15973/hazardous-materials-notice-of-actions-on-special-permits`

---
