# Research fan-out: scout-migration-queue-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-migration-queue
- Items: 1
- Fingerprint: `1a1287b20b1930930b04`

## scout:finding-157: Full master doc has been classified, not blindly migrated

- Priority: high
- Type: migration_queue
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `c0eac0868861b006c909`

**Observed**

ingest-master classified 718 typed rows. Buckets: {"receipt_candidate":170,"surface_candidate":120,"context_only":236,"participation_claim":117,"actor_claim":63,"organization_claim":12}.

**Bounded next action**

Review build/migration-review.md and promote rows into surfaces/participation ledgers only when boundedness is explicit.

Refs: `build/migration-review.md`

---
