# Research fan-out: scout-island-with-surfaces-007

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-island-with-surfaces
- Items: 10
- Fingerprint: `9f34f117c76f566cb613`

## scout:finding-146: Ben Blume has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b6c909001918fb0b7e9f`

**Observed**

Ben Blume participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `electric-twin-ben-blume-director-appointment-2025-09-12`

---

## scout:finding-147: Shyam Sankar has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `6196d78b154abe8f93c7`

**Observed**

Shyam Sankar participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-commissioning-2025`

---

## scout:finding-148: Andrew “Boz” Bosworth has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `4e35adaae9af8e18c4d3`

**Observed**

Andrew “Boz” Bosworth participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-commissioning-2025`

---

## scout:finding-149: Kevin Weil has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `8c3bf9132e5d0e72d490`

**Observed**

Kevin Weil participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-commissioning-2025`

---

## scout:finding-150: Bob McGrew has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `d265456ca1245b47db74`

**Observed**

Bob McGrew participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-commissioning-2025`

---

## scout:finding-151: Lieutenant Colonel Dan Sawyers has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b939356d8262b6b611e8`

**Observed**

Lieutenant Colonel Dan Sawyers participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `anduril-talos-phase-3-named-principals-2023-11-02`

---

## scout:finding-152: Greg Kausner has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0f7528809ac5eb3cdd0d`

**Observed**

Greg Kausner participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `anduril-talos-phase-3-named-principals-2023-11-02`

---

## scout:finding-153: Dane Knecht has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1229d0d5228b1c84de25`

**Observed**

Dane Knecht participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-second-cohort-commissioning-2026-06-10`

---

## scout:finding-154: Sam Pullara has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `5c778a7a047024f3cb29`

**Observed**

Sam Pullara participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-second-cohort-commissioning-2026-06-10`

---

## scout:finding-155: Serkan Piantino has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `bff94d9e186d7e6e91a3`

**Observed**

Serkan Piantino participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `detachment-201-second-cohort-commissioning-2026-06-10`

---
