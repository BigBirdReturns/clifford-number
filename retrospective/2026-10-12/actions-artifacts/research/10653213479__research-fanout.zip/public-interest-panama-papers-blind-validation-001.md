# Research fan-out: public-interest-panama-papers-blind-validation-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-blind-validation
- Items: 1
- Fingerprint: `5e3974940be66215ddde`

## public-interest:panama-blind-validation: Run a blind entity-first Panama Papers reconstruction test

- Priority: medium
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `2e71f1f08170211b60cb`

**Observed**

The checked-in source manifest identifies icij-withheld-name-evaluation as a derived_evaluation_protocol source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Freeze candidates generated from service-provider, registry, and public-authority topology before consulting withheld famous-name or case lists. Evaluate exact predicate recovery, identity precision, degree-adjusted enrichment, and false positives; preserve non-hits as unresolved under incomplete coverage.

Refs: `panama-blind-validation`, `icij-withheld-name-evaluation`, `https://offshoreleaks.icij.org/pages/database`

---
