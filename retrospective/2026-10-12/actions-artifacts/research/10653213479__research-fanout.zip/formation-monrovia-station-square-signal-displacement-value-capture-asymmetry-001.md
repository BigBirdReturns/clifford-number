# Research fan-out: formation-monrovia-station-square-signal-displacement-value-capture-asymmetry-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-signal-displacement-value-capture-asymmetry
- Items: 2
- Fingerprint: `dddcf9b1d8cda0a21bcd`

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:139c1312e4d5054a25a0: Formation control: monrovia-station-square — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `1d5b20eaddad0c448902`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA assessment district who pays who benefits" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:3ed0dd067d248e3caa25: Formation control: monrovia-station-square — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `e7b04f8a13259459b9ab`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA small business displacement downtown redevelopment reporting" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
