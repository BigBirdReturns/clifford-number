# Research fan-out: public-interest-epstein-corporate-offshore-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-epstein-corporate-offshore
- Items: 1
- Fingerprint: `4e6a55380742346256ef`

## public-interest:epstein-offshore-corporate-crossing: Resolve Epstein-associated companies against offshore and official registries

- Priority: medium
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0529a02d29dc2c279e25`

**Observed**

The checked-in source manifest identifies icij-sec-irs-entity-crosswalk as a investigative_dataset_plus_official_registries source family for epstein. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Generate entity-match candidates across ICIJ, SEC EDGAR, IRS nonprofit data, and USVI/state registries. Require a registration number or at least two independent identifying attributes before merging nodes; keep fuzzy matches unresolved.

Refs: `epstein-offshore-corporate-crossing`, `icij-sec-irs-entity-crosswalk`, `https://offshoreleaks.icij.org/pages/database`

---
