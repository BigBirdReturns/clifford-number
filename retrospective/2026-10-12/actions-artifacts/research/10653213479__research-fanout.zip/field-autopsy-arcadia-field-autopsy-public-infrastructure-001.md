# Research fan-out: field-autopsy-arcadia-field-autopsy-public-infrastructure-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-public-infrastructure
- Items: 4
- Fingerprint: `d72f795c6271031d102c`

## field-autopsy:arcadia-field-autopsy:trail-duarte-control:1: The Arcadia Formation: Duarte station-area control (additional same-line comparable) (1/1)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `e0b235c715982fcf66e2`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-duarte-control as a open candidate trail at stage public-infrastructure. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Duarte Station Specific Plan adoption date and developer roster" against municipal_planning_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-duarte-control`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-station-cost-share:1: The Arcadia Formation: Arcadia station cost share and any Metro joint development agreements (1/1)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `965a6500d08237030c59`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-station-cost-share as a open candidate trail at stage public-infrastructure. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Metro board reports and Foothill Gold Line Construction Authority funding agreements naming Arcadia contributions" against transit_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-station-cost-share`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-transcript-recovery:1: The Arcadia Formation: Original conversation transcript recovery (1/2)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `d082fd767011bee55b9d`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-transcript-recovery as a open candidate trail at stage public-infrastructure. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Search author-controlled chat exports for exact title 'Arcadia CA Development Insights' and conversation identifier" against author_chat_exports. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-transcript-recovery`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-transcript-recovery:2: The Arcadia Formation: Original conversation transcript recovery (2/2)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `232b7a95f6126c291ad7`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-transcript-recovery as a open candidate trail at stage public-infrastructure. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Recover the linked conversation artifact without reconstructing omitted turns from summaries" against conversation_store. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-transcript-recovery`, `sig-place-formation-v1`

---
