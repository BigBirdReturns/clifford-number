# Research fan-out: formation-duarte-station-area-public-infrastructure-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-duarte-station-area-public-infrastructure
- Items: 3
- Fingerprint: `6d7ab3dcf2bab6c59f6c`

## formation:sig-place-formation-v1:public-infrastructure:4e05570a9108bc93ee5e: Formation control: duarte-station-area — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `3e1e7c0d58022272d865`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Foothill Gold Line Duarte CA station funding measure" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:8e6461be52d41fc483fe: Formation control: duarte-station-area — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `f962114284100f289f40`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA capital improvement program streetscape" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:c28e6ec618125aae67b9: Formation control: duarte-station-area — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `1d6e68591b3c8175ecff`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA transit station plan adopted date" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
