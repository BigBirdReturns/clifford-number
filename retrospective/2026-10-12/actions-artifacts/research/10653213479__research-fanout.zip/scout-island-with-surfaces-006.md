# Research fan-out: scout-island-with-surfaces-006

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-island-with-surfaces
- Items: 20
- Fingerprint: `98eedc382b7119a5f00f`

## scout:finding-126: Astro Teller has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `90c409a726c9862f2b8e`

**Observed**

Astro Teller participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-127: Strauss Zelnick has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `a4c590880506a1a21b10`

**Observed**

Strauss Zelnick participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-128: Benj Pasek has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b6591813a45df7587e2e`

**Observed**

Benj Pasek participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-129: Drew Scott has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `10d79d33808ba73a57bc`

**Observed**

Drew Scott participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-130: Kim Scott has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `e31febbf2f117df84f8d`

**Observed**

Kim Scott participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-131: Rick Warren has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `59e2e2d616ad04f27a87`

**Observed**

Rick Warren participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-132: Gretchen Rubin has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `048b4e18f02aa680c8ec`

**Observed**

Gretchen Rubin participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-133: Charles Duhigg has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0757316339276a3aed65`

**Observed**

Charles Duhigg participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-134: Daniel Pink has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `68d3cc54d63856bb94f6`

**Observed**

Daniel Pink participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-135: Tom Goldstein has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `8d05d89983c3be5637bc`

**Observed**

Tom Goldstein participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-136: Neal Katyal has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `be0e975225955961c4cf`

**Observed**

Neal Katyal participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-137: Garry Kasparov has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `ecc90227eabbd36a734e`

**Observed**

Garry Kasparov participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-138: Atul Gawande has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0f5dfba33318dacd4f82`

**Observed**

Atul Gawande participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-139: Bob Cialdini has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `7b3dac2325486874a524`

**Observed**

Bob Cialdini participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-140: John Townsend has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `a8c4262bf1630ff11f8b`

**Observed**

John Townsend participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-141: Tim Urban has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b04e653d92228de4b48a`

**Observed**

Tim Urban participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-142: Thasunda Brown Duckett has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `e9483dddceebc1d7dfcb`

**Observed**

Thasunda Brown Duckett participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-143: Vas Narasimhan has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `28b5bf0c1ee9b1156af6`

**Observed**

Vas Narasimhan participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-144: Elizabeth Blackburn has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `01a8336671bccb378ae6`

**Observed**

Elizabeth Blackburn participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-145: Eric Salama has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `a80bf61c8707b1d7c945`

**Observed**

Eric Salama participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `electric-twin-seed-round-2026-02-11`

---
