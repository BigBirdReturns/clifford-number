# Research fan-out: public-interest-epstein-institutional-crossings-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-epstein-institutional-crossings
- Items: 1
- Fingerprint: `3b31931c9f0c9b456716`

## public-interest:epstein-institutional-crossings: Map Epstein gifts, visits, introductions, and institutional gates

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `3da4806ba1cb673bf056`

**Observed**

The checked-in source manifest identifies mit-harvard-apollo-reviews as a institutional_review_and_sec_filing source family for epstein. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Extract separately dated gifts, visits, appointments, introductions, services, internal approvals, review findings, and policy changes from MIT, Harvard, Apollo SEC filings, and referenced primary exhibits. Record decision gates and dissent without turning institutional proximity into person-to-person adjacency.

Refs: `epstein-institutional-crossings`, `mit-harvard-apollo-reviews`, `https://web.mit.edu/fact2020/`

---
