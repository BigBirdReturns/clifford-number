# Research fan-out: crawl-rejection-govuk-search-069

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-govuk-search
- Items: 20
- Fingerprint: `cdccd4cd3b2f2a6b7219`

## crawl-rejection:reject_d19cd3c2f4edf14e855b658d: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `36aeef5528584f8cc05e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d19cd3c2f4edf14e855b658d`, `govuk-search`

---

## crawl-rejection:reject_d1a37467d48c2f99a4d15829: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8155b174ae09d2d7dd70`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d1a37467d48c2f99a4d15829`, `govuk-search`

---

## crawl-rejection:reject_d1c2adccf38835817863c9d7: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `90523df76d78373f6505`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d1c2adccf38835817863c9d7`, `govuk-search`

---

## crawl-rejection:reject_d22798c3be7c53279488d13f: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `085fc797ffefd3e73021`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d22798c3be7c53279488d13f`, `govuk-search`

---

## crawl-rejection:reject_d23f4d0d434df780b6f50856: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `baaacb41d8be6fc2ef60`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d23f4d0d434df780b6f50856`, `govuk-search`

---

## crawl-rejection:reject_d263038ce7fc9f6083a4d972: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `460c8824273779b284af`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d263038ce7fc9f6083a4d972`, `govuk-search`

---

## crawl-rejection:reject_d2bb3e66c510f9941212292a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7c1e0b9ee77b5143e14e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d2bb3e66c510f9941212292a`, `govuk-search`

---

## crawl-rejection:reject_d33540825c19a8ef98d6873a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `da6820b64d0e868742b6`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d33540825c19a8ef98d6873a`, `govuk-search`

---

## crawl-rejection:reject_d3826db773a921ea919fa1de: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `69c3e1b35025c40b7c04`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d3826db773a921ea919fa1de`, `govuk-search`

---

## crawl-rejection:reject_d392f0670d04619282237c37: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `370642307ce981853b1f`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d392f0670d04619282237c37`, `govuk-search`

---

## crawl-rejection:reject_d3a02fb162ada1d07da6b99c: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `be461053756a0b6e138b`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d3a02fb162ada1d07da6b99c`, `govuk-search`

---

## crawl-rejection:reject_d404f4d1d5e360505483e599: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a76aa4dfd289210a4249`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d404f4d1d5e360505483e599`, `govuk-search`

---

## crawl-rejection:reject_d40898cd4a288f2387809d32: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `f4f9678a9c2cdd277553`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d40898cd4a288f2387809d32`, `govuk-search`

---

## crawl-rejection:reject_d43f03e95ec5c9de44d1962a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a2390d3d9dca83f7cbd7`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d43f03e95ec5c9de44d1962a`, `govuk-search`

---

## crawl-rejection:reject_d43f78cadf6b11a88b3a3402: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7bc5b7f0031eb3e73960`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d43f78cadf6b11a88b3a3402`, `govuk-search`

---

## crawl-rejection:reject_d479c04255523aaa9d82e9bd: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `96b674eda14949e3992e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d479c04255523aaa9d82e9bd`, `govuk-search`

---

## crawl-rejection:reject_d47e77b3bfb706c46f7a03e1: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5b80f248fd15f23a3a5c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d47e77b3bfb706c46f7a03e1`, `govuk-search`

---

## crawl-rejection:reject_d4bced239fb999e6134f2fed: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `0621ee97fed2374790aa`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d4bced239fb999e6134f2fed`, `govuk-search`

---

## crawl-rejection:reject_d4d3acfd37cbc54238040dd3: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `e5480e859e10c4e9b3d8`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d4d3acfd37cbc54238040dd3`, `govuk-search`

---

## crawl-rejection:reject_d4fcdb55417a758d7c6206c5: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `2c1e2e48926dc0fffcd4`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_d4fcdb55417a758d7c6206c5`, `govuk-search`

---
