# Research fan-out: public-interest-panama-papers-officer-roles-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-officer-roles
- Items: 1
- Fingerprint: `c67b4815b8dedf115488`

## public-interest:panama-role-separation: Separate Panama Papers ownership and nominee roles

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `da5f86539ca708f3eb58`

**Observed**

The checked-in source manifest identifies icij-panama-role-fields as a investigative_dataset_documentation source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Split beneficial owner, shareholder, director, secretary, nominee, trustee, settlor, protector, power-of-attorney, and intermediary relationships. Preserve source wording and effective dates; do not collapse officer into owner.

Refs: `panama-role-separation`, `icij-panama-role-fields`, `https://offshoreleaks.icij.org/pages/faq`

---
