# Research fan-out: field-autopsy-arcadia-field-autopsy-signal-recurring-intermediaries-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-signal-recurring-intermediaries
- Items: 2
- Fingerprint: `4175fe02336467b5d46c`

## field-autopsy:arcadia-field-autopsy:trail-wahl-title:1: The Arcadia Formation: Erik Wahl (Arcadia) title tenure and corporate scope (1/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `d2374c077c0a910e60df`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-wahl-title as a in_progress candidate trail at stage signal:recurring-intermediaries. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "DAIA Form 990 PDFs 2015-2025 officer schedules (page-level)" against irs_990_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-wahl-title`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-wahl-title:2: The Arcadia Formation: Erik Wahl (Arcadia) title tenure and corporate scope (2/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `a593633e1b073ad36588`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-wahl-title as a in_progress candidate trail at stage signal:recurring-intermediaries. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Positive Investments statements of information and dated filings defining Erik Wahl title tenure" against state_corporate_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-wahl-title`, `sig-place-formation-v1`

---
