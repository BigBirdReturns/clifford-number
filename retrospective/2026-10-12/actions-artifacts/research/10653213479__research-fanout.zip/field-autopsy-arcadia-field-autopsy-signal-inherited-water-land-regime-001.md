# Research fan-out: field-autopsy-arcadia-field-autopsy-signal-inherited-water-land-regime-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-signal-inherited-water-land-regime
- Items: 2
- Fingerprint: `10490554aaa67e535ad5`

## field-autopsy:arcadia-field-autopsy:trail-eb5-wash-dates:1: The Arcadia Formation: EB-5 capital in named Arcadia projects (1/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `3ba9c81fa37d087a47f6`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-eb5-wash-dates as a in_progress candidate trail at stage signal:inherited-water-land-regime. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Le Méridien Arcadia NCE/JCE offering, investor count, petition status, and source/use records" against federal_and_offering_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-eb5-wash-dates`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-eb5-wash-dates:2: The Arcadia Formation: EB-5 capital in named Arcadia projects (2/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `7d6c48ba64ee135877db`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-eb5-wash-dates as a in_progress candidate trail at stage signal:inherited-water-land-regime. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Arcadia Hilton I-956F approval or independent Rancon Regional Center offering record" against federal_and_regional_center_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-eb5-wash-dates`, `sig-place-formation-v1`

---
