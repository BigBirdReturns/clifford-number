# Research fan-out: crawl-rejection-federal-register-002

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-federal-register
- Items: 20
- Fingerprint: `fe82f2388a18860885e9`

## crawl-rejection:reject_762b3aad6eda8179ae52f6eb: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `56e3551c3aef66d684cd`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_762b3aad6eda8179ae52f6eb`, `federal-register`

---

## crawl-rejection:reject_7acd3e42b78785664e71af63: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `12563b53b0bef31a8e05`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_7acd3e42b78785664e71af63`, `federal-register`

---

## crawl-rejection:reject_7edb6336a1a10915d9679575: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `c1d3096c7cde932555ea`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_7edb6336a1a10915d9679575`, `federal-register`

---

## crawl-rejection:reject_849218fba43ad58f94205ca6: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6f02a2649410326dd003`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_849218fba43ad58f94205ca6`, `federal-register`

---

## crawl-rejection:reject_869c04d1280e3c45491dd403: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `49ca46f62d4415c4628b`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_869c04d1280e3c45491dd403`, `federal-register`

---

## crawl-rejection:reject_87da8f24762fcd1ada5d9ae9: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `72fbe24975c470336edb`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_87da8f24762fcd1ada5d9ae9`, `federal-register`

---

## crawl-rejection:reject_8d4e12b576be14340c6f0b7a: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `b6e8c2937bc71a974bb7`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_8d4e12b576be14340c6f0b7a`, `federal-register`

---

## crawl-rejection:reject_8dc836da436cefdacb2bfdc0: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1d91626b2c471e420d56`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_8dc836da436cefdacb2bfdc0`, `federal-register`

---

## crawl-rejection:reject_908caf13813c0355855c254c: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `9011bf9f690e8211ecf6`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_908caf13813c0355855c254c`, `federal-register`

---

## crawl-rejection:reject_91112fe38eeb753e8cf8299c: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `2d6c054be3839f6cba1d`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_91112fe38eeb753e8cf8299c`, `federal-register`

---

## crawl-rejection:reject_91a98171233a7212133b3672: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `31977c1d48abfc77af6e`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_91a98171233a7212133b3672`, `federal-register`

---

## crawl-rejection:reject_93ca0f3c2e965bc2ab0994f3: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `08cc9de2f0aebaae7a71`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_93ca0f3c2e965bc2ab0994f3`, `federal-register`

---

## crawl-rejection:reject_93fe16cc2b835017f3215f34: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `b660049bff67bfb403d9`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_93fe16cc2b835017f3215f34`, `federal-register`

---

## crawl-rejection:reject_99c5d1d952efd0c17c21daee: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `9f015bec1018b591c792`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_99c5d1d952efd0c17c21daee`, `federal-register`

---

## crawl-rejection:reject_9e0134583068a3132dfc98f6: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `aba4990e07bd6f82322c`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_9e0134583068a3132dfc98f6`, `federal-register`

---

## crawl-rejection:reject_9ed00e1a18fbd899d208a932: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `b10d91992bfad147008e`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_9ed00e1a18fbd899d208a932`, `federal-register`

---

## crawl-rejection:reject_9f2038e6d57f9381404fd792: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `0850775822bd8b75fcfa`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_9f2038e6d57f9381404fd792`, `federal-register`

---

## crawl-rejection:reject_a3d983eb050d3d06c6dbb908: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `db905addec7347dc4b0d`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_a3d983eb050d3d06c6dbb908`, `federal-register`

---

## crawl-rejection:reject_aa351e80ee2f9888f7f296d8: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `d5ac2aaad8afbe74dda9`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_aa351e80ee2f9888f7f296d8`, `federal-register`

---

## crawl-rejection:reject_ab9e13c6dfc66dc44c34c0fd: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `57c504d35dd2d0d90ee0`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ab9e13c6dfc66dc44c34c0fd`, `federal-register`

---
