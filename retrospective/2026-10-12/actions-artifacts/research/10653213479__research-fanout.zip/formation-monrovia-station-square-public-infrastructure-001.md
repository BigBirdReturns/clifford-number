# Research fan-out: formation-monrovia-station-square-public-infrastructure-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-public-infrastructure
- Items: 3
- Fingerprint: `76234511d93845a02361`

## formation:sig-place-formation-v1:public-infrastructure:38389549a7793e6b094a: Formation control: monrovia-station-square — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `cbc08e122b404735253f`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Foothill Gold Line Monrovia CA station funding measure" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:425f2548e2ce80aa654f: Formation control: monrovia-station-square — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `ba18f02555b48f395811`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA transit station plan adopted date" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:5f6674d228c93ec8597d: Formation control: monrovia-station-square — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `e8130d6cd7e7c28f47ce`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA capital improvement program streetscape" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
