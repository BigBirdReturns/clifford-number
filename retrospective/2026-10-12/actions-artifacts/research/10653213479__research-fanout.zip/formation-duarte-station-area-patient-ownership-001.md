# Research fan-out: formation-duarte-station-area-patient-ownership-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-duarte-station-area-patient-ownership
- Items: 2
- Fingerprint: `affeb98036c688f6ddd3`

## formation:sig-place-formation-v1:patient-ownership:3ff2fe735ce66387b1ca: Formation control: duarte-station-area — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `8d2a8d129950a6d0e4e5`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA downtown parcels acquired before station opening" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:patient-ownership:68e9169dbab1fe715371: Formation control: duarte-station-area — patient-ownership

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `f401a6fbba1e155fd19c`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA station area property acquisition entitlement application" using bounded_public_record_research against county_recorder_and_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
