# Research fan-out: public-interest-epstein-legal-status-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-epstein-legal-status
- Items: 1
- Fingerprint: `14cdd60d2a52f64f253c`

## public-interest:epstein-court-status-timeline: Build an instrument-level Epstein and Maxwell legal timeline

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `2cb972a3656d68f28410`

**Observed**

The checked-in source manifest identifies doj-epstein-court-records as a official_court_record_corpus source family for epstein. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Index complaints, indictments, pleas, verdicts, judgments, dismissals, settlements, orders, and authenticated exhibits by docket number and filing date. Reify allegations and dispositions instead of attaching unscoped guilt labels to people.

Refs: `epstein-court-status-timeline`, `doj-epstein-court-records`, `https://www.justice.gov/epstein/doj-disclosures`

---
