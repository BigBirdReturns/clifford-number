# Research fan-out: formation-azusa-gold-line-district-signal-displacement-value-capture-asymmetry-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-azusa-gold-line-district-signal-displacement-value-capture-asymmetry
- Items: 2
- Fingerprint: `716713b758f7518ec5bb`

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:22e58fa30ca9f64a5921: Formation control: azusa-gold-line-district — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `95de5a9c07c6f3e50a1a`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA small business displacement downtown redevelopment reporting" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:406e8badb890be7b2aac: Formation control: azusa-gold-line-district — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `77e1a6c3e23b8c24ca50`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA assessment district who pays who benefits" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
