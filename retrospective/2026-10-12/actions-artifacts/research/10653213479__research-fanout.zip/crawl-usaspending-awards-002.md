# Research fan-out: crawl-usaspending-awards-002

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-usaspending-awards
- Items: 7
- Fingerprint: `156ceb2a4cd96d1469ca`

## crawl:candidate_e58c9de0a649a308af092857: PALANTIR TECHNOLOGIES INC. — 70CTD026FC0000018

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `7b6df20af2b9f1023339`

**Observed**

usaspending-awards record 70CTD026FC0000018; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_5a54a109f4143f6bb8fa6997`, `https://www.usaspending.gov/award/CONT_AWD_70CTD026FC0000018_7012_70RTAC26A00000001_7001/`

---

## crawl:candidate_e640d4d6c592161edbf05aad: ANDURIL INDUSTRIES, INC. — 80GRC026C0009

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `3e04f9b356b0d8615d88`

**Observed**

usaspending-awards record 80GRC026C0009; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_9f74202d17edb5e2dbfe5555`, `https://www.usaspending.gov/award/CONT_AWD_80GRC026C0009_8000_-NONE-_-NONE-/`

---

## crawl:candidate_ea2b1c3b57702e93c6f4ce72: PALANTIR TECHNOLOGIES INC. — 692M1524F00208

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `4bd5fad50abcbc9bb91b`

**Observed**

usaspending-awards record 692M1524F00208; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_385129c82b26690eaed52b44`, `https://www.usaspending.gov/award/CONT_AWD_692M1524F00208_6920_47QTCA24D004L_4732/`

---

## crawl:candidate_ea903078023946fcc062425c: PALANTIR TECHNOLOGIES INC. — 36C10B25F0313

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `962a961a760c510e9c52`

**Observed**

usaspending-awards record 36C10B25F0313; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_a718df0af43c65b7f991a237`, `obs_e9c9225b38f5e1d4d974cf6d`, `https://www.usaspending.gov/award/CONT_AWD_36C10B25F0313_3600_GS35F0086U_4730/`

---

## crawl:candidate_f323b6c3aa67a959ba585625: PALANTIR TECHNOLOGIES INC. — 75P00125F37006

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `75012f9ec9d6f4f6eff6`

**Observed**

usaspending-awards record 75P00125F37006; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_1990432744e044608c09d62a`, `https://www.usaspending.gov/award/CONT_AWD_75P00125F37006_7570_75P00122A00010_7570/`

---

## crawl:candidate_770aac6f961b0f0133e71dcf: PALANTIR USG INC — W91QVN26FA191

- Priority: medium
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `baaeb2b7a8aed1c4d37e`

**Observed**

usaspending-awards record W91QVN26FA191; matched on record.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_16da69393a83edd146dd503c`, `https://www.usaspending.gov/award/CONT_AWD_W91QVN26FA191_9700_W519TC25D0039_9700/`

---

## crawl:candidate_c2f04128f5c338158629294d: PALANTIR USG INC — W912CM26FA009

- Priority: medium
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `6c31d4c08fde2b283ba2`

**Observed**

usaspending-awards record W912CM26FA009; matched on record.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_50f259b347d7f930d77cf631`, `https://www.usaspending.gov/award/CONT_AWD_W912CM26FA009_9700_W519TC25D0039_9700/`

---
