# Research fan-out: field-autopsy-arcadia-field-autopsy-signal-cultural-orientation-timing-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-signal-cultural-orientation-timing
- Items: 2
- Fingerprint: `4c5af08dc6f33e85433b`

## field-autopsy:arcadia-field-autopsy:trail-geomantic-mechanism:1: The Arcadia Formation: Material geomantic mechanisms in SGV institutional development (1/2)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `09f847f19161ef515cbd`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-geomantic-mechanism as a open candidate trail at stage signal:cultural-orientation-timing. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "Arcadia/SGV groundbreaking or opening dates of major projects vs. Chinese almanac auspicious dates (documented statements only)" against press_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-geomantic-mechanism`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-geomantic-mechanism:2: The Arcadia Formation: Material geomantic mechanisms in SGV institutional development (2/2)

- Priority: medium
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `dd2388c11e48a21c73e1`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-geomantic-mechanism as a open candidate trail at stage signal:cultural-orientation-timing. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "City of Arcadia address-change applications policy and any reporting on number-motivated changes" against municipal_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-geomantic-mechanism`, `sig-place-formation-v1`

---
