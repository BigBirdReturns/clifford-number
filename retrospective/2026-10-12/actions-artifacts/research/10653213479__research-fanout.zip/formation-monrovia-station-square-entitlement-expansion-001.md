# Research fan-out: formation-monrovia-station-square-entitlement-expansion-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-entitlement-expansion
- Items: 3
- Fingerprint: `04c816e1fb3fbf26aa01`

## formation:sig-place-formation-v1:entitlement-expansion:488c4b69e6ee28f1e33f: Formation control: monrovia-station-square — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `1c1a589ae64d097df664`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA zoning code amendment downtown height" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:entitlement-expansion:83fff96c28a99c93acc0: Formation control: monrovia-station-square — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `d0614cc029115e5d0f84`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA housing element sites inventory downtown" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:entitlement-expansion:88e96ea24a844e9b0a4a: Formation control: monrovia-station-square — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `ad06593633a64ce72f39`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA general plan update downtown mixed use density" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
