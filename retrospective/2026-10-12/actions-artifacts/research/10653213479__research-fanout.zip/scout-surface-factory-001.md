# Research fan-out: scout-surface-factory-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-surface-factory
- Items: 12
- Fingerprint: `c45d97c3fecd8f4a8f0b`

## scout:finding-001: Electric Twin behaves as a surface factory

- Priority: high
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `746a070bed337206a4be`

**Observed**

Electric Twin appears across 18 surface(s): electric-twin-incorporation-2023-09-28, electric-twin-ben-warner-director-tenure-2023-09-28, electric-twin-alex-cooper-director-tenure-2023-09-28, electric-twin-ethics-board-2026, electric-twin-seed-round-2026-02-11, electric-twin-seed-round-institutional-investors-2026-02-11, electric-twin-ben-blume-director-appointment-2025-09-12, electric-twin-seed2-governance-instrument-2025-09-12, electric-twin-seed2-capital-actions-2025-09-16-2025-09-26, electric-twin-capital-allotment-observations-2026-01-13-2026-07-09, electric-twin-newsuk-synthetic-audience, newsuk-times-exploraition-launch-publication-principals-2026-04-27, electric-twin-lebara-customer-use-2026-03-11, gartner-synthetic-population-category-2026, electric-twin-muthukrishna-science-adviser-observations-2024-2026, electric-twin-accuracy-methodology-publication-2026-02-11, electric-twin-virgin-madfest-session-2026-07-08, electric-twin-registered-shareholdings-2025-09-27. Secondary types: category_formation_surface, democratic_input_replacement, model_governance_surface, surface_factory_capital_layer.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `electric-twin-incorporation-2023-09-28`, `electric-twin-ben-warner-director-tenure-2023-09-28`, `electric-twin-alex-cooper-director-tenure-2023-09-28`, `electric-twin-ethics-board-2026`, `electric-twin-seed-round-2026-02-11`, `electric-twin-seed-round-institutional-investors-2026-02-11`, `electric-twin-ben-blume-director-appointment-2025-09-12`, `electric-twin-seed2-governance-instrument-2025-09-12`, `electric-twin-seed2-capital-actions-2025-09-16-2025-09-26`, `electric-twin-capital-allotment-observations-2026-01-13-2026-07-09`, `electric-twin-newsuk-synthetic-audience`, `newsuk-times-exploraition-launch-publication-principals-2026-04-27`, `electric-twin-lebara-customer-use-2026-03-11`, `gartner-synthetic-population-category-2026`, `electric-twin-muthukrishna-science-adviser-observations-2024-2026`, `electric-twin-accuracy-methodology-publication-2026-02-11`, `electric-twin-virgin-madfest-session-2026-07-08`, `electric-twin-registered-shareholdings-2025-09-27`

---

## scout:finding-002: Faculty / Faculty Science / ASI Data Science behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b7f01e2a6d0b56db1c80`

**Observed**

Faculty / Faculty Science / ASI Data Science appears across 2 surface(s): faculty-science-officer-employee-overlap-2018-01-24, faculty-science-director-shareholder-overlap-2024-10-10. Secondary types: public_private_ai_infrastructure.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `faculty-science-officer-employee-overlap-2018-01-24`, `faculty-science-director-shareholder-overlap-2024-10-10`

---

## scout:finding-003: Department for Science, Innovation and Technology (DSIT) behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0da96ad0c6430bdb3a6e`

**Observed**

Department for Science, Innovation and Technology (DSIT) appears across 6 surface(s): ai-opportunities-action-plan-development-2024-2025, ai-opportunities-action-plan-2025, ai-safety-summit-representative-appointment-2023-08-10, dsit-techuk-anduril-ai-safety-roundtable-2023-10-17, dsit-matt-clifford-ai-investor-roundtable-2023-10-25, frontier-ai-taskforce-external-advisory-board-appointments-2023-09-07. Secondary types: governance_continuity_surface, government_advisory_surface, model_governance_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `ai-opportunities-action-plan-development-2024-2025`, `ai-opportunities-action-plan-2025`, `ai-safety-summit-representative-appointment-2023-08-10`, `dsit-techuk-anduril-ai-safety-roundtable-2023-10-17`, `dsit-matt-clifford-ai-investor-roundtable-2023-10-25`, `frontier-ai-taskforce-external-advisory-board-appointments-2023-09-07`

---

## scout:finding-004: Atomico behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `261060c097b5f834f740`

**Observed**

Atomico appears across 3 surface(s): electric-twin-seed-round-institutional-investors-2026-02-11, electric-twin-seed2-governance-instrument-2025-09-12, electric-twin-registered-shareholdings-2025-09-27. Secondary types: model_governance_surface, surface_factory_capital_layer.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `electric-twin-seed-round-institutional-investors-2026-02-11`, `electric-twin-seed2-governance-instrument-2025-09-12`, `electric-twin-registered-shareholdings-2025-09-27`

---

## scout:finding-005: LocalGlobe behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `c7d740cb98a0143fe33c`

**Observed**

LocalGlobe appears across 3 surface(s): electric-twin-seed-round-institutional-investors-2026-02-11, electric-twin-seed2-governance-instrument-2025-09-12, electric-twin-registered-shareholdings-2025-09-27. Secondary types: model_governance_surface, surface_factory_capital_layer.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `electric-twin-seed-round-institutional-investors-2026-02-11`, `electric-twin-seed2-governance-instrument-2025-09-12`, `electric-twin-registered-shareholdings-2025-09-27`

---

## scout:finding-006: BAE Systems behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `7434f1fdc9b537297301`

**Observed**

BAE Systems appears across 3 surface(s): team-barrow-public-private-fund-2026, atlantic-bastion-launch-publication-2025-12-08, atlantic-bastion-industry-program-context-2025-12-08. Secondary types: defence_industrial_surface, governance_continuity_surface, government_advisory_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `team-barrow-public-private-fund-2026`, `atlantic-bastion-launch-publication-2025-12-08`, `atlantic-bastion-industry-program-context-2025-12-08`

---

## scout:finding-007: Entrepreneur First behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `ae5e3a25ffd2978b567b`

**Observed**

Entrepreneur First appears across 1 surface(s): entrepreneur-first-cofounder-observation-2018-07-05. Secondary types: public_private_ai_infrastructure, surface_factory_capital_layer.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `entrepreneur-first-cofounder-observation-2018-07-05`

---

## scout:finding-008: Dialog behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `4e0fec09fbd3a910b800`

**Observed**

Dialog appears across 1 surface(s): dialog-public-directory-exposure-2026-06-16. Secondary types: governance_continuity_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-009: US Army (Detachment 201, Executive Innovation Corps) behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `cb748349ef4826c507c3`

**Observed**

US Army (Detachment 201, Executive Innovation Corps) appears across 3 surface(s): detachment-201-program-context-2025, detachment-201-commissioning-2025, detachment-201-second-cohort-commissioning-2026-06-10. Secondary types: defence_industrial_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `detachment-201-program-context-2025`, `detachment-201-commissioning-2025`, `detachment-201-second-cohort-commissioning-2026-06-10`

---

## scout:finding-010: Ministry of Defence (MoD) behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `027da85dcfdfaa0daf83`

**Observed**

Ministry of Defence (MoD) appears across 13 surface(s): strategic-defence-review-development-2024-2025, strategic-defence-review-2024-2025, anduril-talos-phase-3-contract-observation-2023-11-02, anduril-talos-phase-3-named-principals-2023-11-02, anduril-ukraine-drone-deal-named-principals-2025-03-06, anduril-ai-fight-tonight-award-2021-07-31, anduril-talos-phase-2-award-2021-08-02, anduril-project-entrelezar-award-2023-10-09, anduril-ddad-framework-2026-01-09, anduril-project-nyx-seven-supplier-shortlist-2026-01-24, anduril-project-nyx-four-supplier-downselect-2026-05-15, atlantic-bastion-launch-publication-2025-12-08, atlantic-bastion-industry-program-context-2025-12-08. Secondary types: defence_industrial_surface, government_advisory_surface, model_governance_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `strategic-defence-review-development-2024-2025`, `strategic-defence-review-2024-2025`, `anduril-talos-phase-3-contract-observation-2023-11-02`, `anduril-talos-phase-3-named-principals-2023-11-02`, `anduril-ukraine-drone-deal-named-principals-2025-03-06`, `anduril-ai-fight-tonight-award-2021-07-31`, `anduril-talos-phase-2-award-2021-08-02`, `anduril-project-entrelezar-award-2023-10-09`, `anduril-ddad-framework-2026-01-09`, `anduril-project-nyx-seven-supplier-shortlist-2026-01-24`, `anduril-project-nyx-four-supplier-downselect-2026-05-15`, `atlantic-bastion-launch-publication-2025-12-08`, `atlantic-bastion-industry-program-context-2025-12-08`

---

## scout:finding-011: Anduril Industries behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `4214ca3de1371ed3f156`

**Observed**

Anduril Industries appears across 6 surface(s): dsit-techuk-anduril-ai-safety-roundtable-2023-10-17, anduril-talos-phase-3-contract-observation-2023-11-02, anduril-talos-phase-3-named-principals-2023-11-02, anduril-ai-fight-tonight-award-2021-07-31, anduril-talos-phase-2-award-2021-08-02, anduril-project-entrelezar-award-2023-10-09. Secondary types: defence_industrial_surface, government_advisory_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `dsit-techuk-anduril-ai-safety-roundtable-2023-10-17`, `anduril-talos-phase-3-contract-observation-2023-11-02`, `anduril-talos-phase-3-named-principals-2023-11-02`, `anduril-ai-fight-tonight-award-2021-07-31`, `anduril-talos-phase-2-award-2021-08-02`, `anduril-project-entrelezar-award-2023-10-09`

---

## scout:finding-012: Anduril Industries UK Ltd behaves as a surface factory

- Priority: medium
- Type: surface_factory
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `14e77985a6b4d9072f7d`

**Observed**

Anduril Industries UK Ltd appears across 8 surface(s): anduril-uk-co-director-appointments-2024-07-31, anduril-ukraine-drone-deal-named-principals-2025-03-06, anduril-copci-border-force-contract-2022-06-21, anduril-ddad-framework-2026-01-09, anduril-project-nyx-seven-supplier-shortlist-2026-01-24, anduril-project-nyx-four-supplier-downselect-2026-05-15, atlantic-bastion-launch-publication-2025-12-08, atlantic-bastion-industry-program-context-2025-12-08. Secondary types: defence_industrial_surface, government_advisory_surface, model_governance_surface, policy_to_procurement_surface.

**Bounded next action**

Review whether each surface is correctly bounded. Add missing customer, investor, board, filing, deployment, and procurement surfaces as separate rows rather than broad organization edges.

Refs: `anduril-uk-co-director-appointments-2024-07-31`, `anduril-ukraine-drone-deal-named-principals-2025-03-06`, `anduril-copci-border-force-contract-2022-06-21`, `anduril-ddad-framework-2026-01-09`, `anduril-project-nyx-seven-supplier-shortlist-2026-01-24`, `anduril-project-nyx-four-supplier-downselect-2026-05-15`, `atlantic-bastion-launch-publication-2025-12-08`, `atlantic-bastion-industry-program-context-2025-12-08`

---
