# Research fan-out: crawl-rejection-govuk-search-080

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-govuk-search
- Items: 20
- Fingerprint: `577d17d93861d5b033c0`

## crawl-rejection:reject_f326777bf7cdb0827c3b3df3: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `bcef6abf8c171240a300`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f326777bf7cdb0827c3b3df3`, `govuk-search`

---

## crawl-rejection:reject_f32b5b70dc0f591aa6ac02f7: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `eeb96d16be1fffc9f922`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f32b5b70dc0f591aa6ac02f7`, `govuk-search`

---

## crawl-rejection:reject_f35639adac01870974849a85: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8074d5b2d26992f1796d`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f35639adac01870974849a85`, `govuk-search`

---

## crawl-rejection:reject_f35dac017a3a8718a0d7dead: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `dfe9d9626ded4c9e36dc`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f35dac017a3a8718a0d7dead`, `govuk-search`

---

## crawl-rejection:reject_f3a26e6346a3dd2291197cb2: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `84f54a43e25fcd27b8c3`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f3a26e6346a3dd2291197cb2`, `govuk-search`

---

## crawl-rejection:reject_f3aca22a211bcf105a5a71b0: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `3c46b36e66cd8ec8438c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f3aca22a211bcf105a5a71b0`, `govuk-search`

---

## crawl-rejection:reject_f408d615604f125b032047bc: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `f0d00f38cc5b2752cabe`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f408d615604f125b032047bc`, `govuk-search`

---

## crawl-rejection:reject_f44a3204f9059e942a97d26c: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `05bb309d09215057e73b`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f44a3204f9059e942a97d26c`, `govuk-search`

---

## crawl-rejection:reject_f44c9cf9021182a8b8315d5e: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `98ef1f4a944b6b6ea830`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f44c9cf9021182a8b8315d5e`, `govuk-search`

---

## crawl-rejection:reject_f4590f446d4901e6629f0e36: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a085ee495d48e43c9d11`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f4590f446d4901e6629f0e36`, `govuk-search`

---

## crawl-rejection:reject_f470ce7524be83085230908b: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `e7733b9f832d6ce4753a`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f470ce7524be83085230908b`, `govuk-search`

---

## crawl-rejection:reject_f492e51a46a73f378b45e939: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `bb9a98c4224001fbb3fb`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f492e51a46a73f378b45e939`, `govuk-search`

---

## crawl-rejection:reject_f4b2430da4c3a3a2c517646b: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `87bafe9ff1771b07b74a`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f4b2430da4c3a3a2c517646b`, `govuk-search`

---

## crawl-rejection:reject_f51416ccd99a5a149dde3cde: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `33be53b559e1f8571551`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f51416ccd99a5a149dde3cde`, `govuk-search`

---

## crawl-rejection:reject_f51c18cb81e45d136314b34b: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `79a4cde654337e37cb22`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f51c18cb81e45d136314b34b`, `govuk-search`

---

## crawl-rejection:reject_f522786fe10daa987c1ffe7a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7e820e6f47e343a912bd`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f522786fe10daa987c1ffe7a`, `govuk-search`

---

## crawl-rejection:reject_f52d11f6790a2b6a1219ddf6: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `f47155ade9c4554e3fe3`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f52d11f6790a2b6a1219ddf6`, `govuk-search`

---

## crawl-rejection:reject_f5312f3afa296a1c02711413: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8e285f64c2d13bd3c056`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f5312f3afa296a1c02711413`, `govuk-search`

---

## crawl-rejection:reject_f5353d2f70f2edd9cfb5b143: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `eea63d69393782b10f50`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f5353d2f70f2edd9cfb5b143`, `govuk-search`

---

## crawl-rejection:reject_f5362f815ba62969c157c885: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `467c09a3e530c2fb0b30`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f5362f815ba62969c157c885`, `govuk-search`

---
