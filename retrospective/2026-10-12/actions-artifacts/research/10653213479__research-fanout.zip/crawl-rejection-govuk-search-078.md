# Research fan-out: crawl-rejection-govuk-search-078

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-govuk-search
- Items: 20
- Fingerprint: `52421efe5aab4700c50b`

## crawl-rejection:reject_edc19ba8b48d05cbf184908a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `353037cd6631227f3f98`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_edc19ba8b48d05cbf184908a`, `govuk-search`

---

## crawl-rejection:reject_ee022aeace57a9b42baef8a6: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1efab186888cd1964391`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee022aeace57a9b42baef8a6`, `govuk-search`

---

## crawl-rejection:reject_ee2238636cb285adce5ab9df: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `4e43723cc7e1400dfbaa`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee2238636cb285adce5ab9df`, `govuk-search`

---

## crawl-rejection:reject_ee2963e5f61bf90087876b41: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `2fcbfccc5619ecd863cc`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee2963e5f61bf90087876b41`, `govuk-search`

---

## crawl-rejection:reject_ee39bdb99e4bd9dc466e4761: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `93ca9ead0939ef48a72c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee39bdb99e4bd9dc466e4761`, `govuk-search`

---

## crawl-rejection:reject_ee433ec5177c8e3b609f8fd5: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7052244ddf2fa067fc6d`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee433ec5177c8e3b609f8fd5`, `govuk-search`

---

## crawl-rejection:reject_ee44e74b789d9ce190d6f65a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `fd8eb1c2ed29ceff1177`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee44e74b789d9ce190d6f65a`, `govuk-search`

---

## crawl-rejection:reject_ee569b7045649d5ba28c6ecd: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `82fc8bafd4e45d598548`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ee569b7045649d5ba28c6ecd`, `govuk-search`

---

## crawl-rejection:reject_eec71b87f8147eecb4e88440: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `21a750d21376096ad6f5`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_eec71b87f8147eecb4e88440`, `govuk-search`

---

## crawl-rejection:reject_eedded92fbc465c56740562d: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `484160c8036540b10bf8`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_eedded92fbc465c56740562d`, `govuk-search`

---

## crawl-rejection:reject_eedf74aedf9784bb51e134ad: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8a2817a95ae8c1e6b290`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_eedf74aedf9784bb51e134ad`, `govuk-search`

---

## crawl-rejection:reject_eef0069f5ceba61eb86965ba: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `3988c9e086b794d7602e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_eef0069f5ceba61eb86965ba`, `govuk-search`

---

## crawl-rejection:reject_ef133f9dde2650eda010ab56: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1ef471f02339dc930c7b`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ef133f9dde2650eda010ab56`, `govuk-search`

---

## crawl-rejection:reject_ef418709575792f6de854d19: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `97d99e1539b87a46d276`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ef418709575792f6de854d19`, `govuk-search`

---

## crawl-rejection:reject_ef46df16bf0a7354f07d47a5: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `33510b58cfe595f72be3`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ef46df16bf0a7354f07d47a5`, `govuk-search`

---

## crawl-rejection:reject_ef93e50be926f35b2af12265: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `904c1d8f65049e34d991`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ef93e50be926f35b2af12265`, `govuk-search`

---

## crawl-rejection:reject_efc71bf0caec0020a5818f79: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `aa01e26b52bbb3803786`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_efc71bf0caec0020a5818f79`, `govuk-search`

---

## crawl-rejection:reject_efe74a7eb3ffcd59b2e07d96: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `13549604ceabcb6f6c84`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_efe74a7eb3ffcd59b2e07d96`, `govuk-search`

---

## crawl-rejection:reject_efeb9d3ae57701329d1631a3: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `2b64f6ed99801d41fa08`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_efeb9d3ae57701329d1631a3`, `govuk-search`

---

## crawl-rejection:reject_effb1f8865df3fd453a00c63: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1eaaeb603e2c9b7820c5`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_effb1f8865df3fd453a00c63`, `govuk-search`

---
