# Research fan-out: crawl-rejection-sec-form-d-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-sec-form-d
- Items: 10
- Fingerprint: `62ab01d5e41dd7c22ce9`

## crawl-rejection:reject_04e1ec4ca3be0097a7b5b4b9: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1b67ed843c24cfdda08d`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_04e1ec4ca3be0097a7b5b4b9`, `sec-form-d`

---

## crawl-rejection:reject_17529017d9e49884548c1641: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `4451a1ad123cd797d209`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_17529017d9e49884548c1641`, `sec-form-d`

---

## crawl-rejection:reject_2028f427403ab3b7e077615e: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `565c61ef4dd9ab9fa4d9`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_2028f427403ab3b7e077615e`, `sec-form-d`

---

## crawl-rejection:reject_3583a954bb9ad9ff08425093: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `fc13675fd8d1653d4ef2`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_3583a954bb9ad9ff08425093`, `sec-form-d`

---

## crawl-rejection:reject_5360afd79aa5294e2d911faa: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `d3beba428c51b6da9b58`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_5360afd79aa5294e2d911faa`, `sec-form-d`

---

## crawl-rejection:reject_888a85214933984995f03a5d: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `df66b99f76a51e374071`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_888a85214933984995f03a5d`, `sec-form-d`

---

## crawl-rejection:reject_988c4e5291f62abf978e662f: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5abb97af8a4dece110b0`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_988c4e5291f62abf978e662f`, `sec-form-d`

---

## crawl-rejection:reject_a9ce4e3656c07b12315bf0ae: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `19cafb94b163417f58a6`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_a9ce4e3656c07b12315bf0ae`, `sec-form-d`

---

## crawl-rejection:reject_c3df07ee81aa1603902fca06: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1b58f8c6a7d9aa53a4ac`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_c3df07ee81aa1603902fca06`, `sec-form-d`

---

## crawl-rejection:reject_cce8f203d05795ddbf3f197d: Review held crawl observation from sec-form-d

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `eb8ca4bbab93134bd357`

**Observed**

The official-record crawler held one sec-form-d observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_cce8f203d05795ddbf3f197d`, `sec-form-d`

---
