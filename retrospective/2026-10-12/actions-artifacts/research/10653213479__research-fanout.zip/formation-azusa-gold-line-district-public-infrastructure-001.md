# Research fan-out: formation-azusa-gold-line-district-public-infrastructure-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-azusa-gold-line-district-public-infrastructure
- Items: 3
- Fingerprint: `3dbdf5db2d7942c94c5d`

## formation:sig-place-formation-v1:public-infrastructure:04543468adf245052014: Formation control: azusa-gold-line-district — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `0287244dedb39bf60444`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA transit station plan adopted date" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:2be229a4fdf8f717c124: Formation control: azusa-gold-line-district — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `a01b4692c9f02c29ab43`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Foothill Gold Line Azusa CA station funding measure" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:public-infrastructure:fc54f22b66530c1f7224: Formation control: azusa-gold-line-district — public-infrastructure

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `75302052a4a04310df9b`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA capital improvement program streetscape" using bounded_public_record_research against municipal_and_transit_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
