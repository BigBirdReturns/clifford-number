# Research fan-out: formation-azusa-gold-line-district-entitlement-expansion-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-azusa-gold-line-district-entitlement-expansion
- Items: 3
- Fingerprint: `31cdfa7c688197f5ab6f`

## formation:sig-place-formation-v1:entitlement-expansion:3fd41ea1381f434b0fa1: Formation control: azusa-gold-line-district — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `ec3278e4b5fb91a3f76b`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA housing element sites inventory downtown" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:entitlement-expansion:615665335542b3cf2045: Formation control: azusa-gold-line-district — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `501905f59d0e5091c8dc`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA general plan update downtown mixed use density" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:entitlement-expansion:bc044be4ea532775f9c8: Formation control: azusa-gold-line-district — entitlement-expansion

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `9ca3007882076799b032`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA zoning code amendment downtown height" using bounded_public_record_research against municipal_planning_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
