# Research fan-out: crawl-usaspending-awards-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-usaspending-awards
- Items: 20
- Fingerprint: `d4bcd6584431b93696ca`

## crawl:candidate_0efca4fbc1a627b4aed65732: PALANTIR TECHNOLOGIES INC. — 47QACA26F0278

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `ea22e5039f2e08b59427`

**Observed**

usaspending-awards record 47QACA26F0278; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_cb3e667e2b54eaa135e05ea6`, `obs_88b2c54966ab83dbb590ef10`, `https://www.usaspending.gov/award/CONT_AWD_47QACA26F0278_4732_47QTCA24D004L_4732/`

---

## crawl:candidate_1a1e3ab3ab16e8a6d6b9ad5f: PALANTIR TECHNOLOGIES INC. — 19AQMM26F0792

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `157cd766bbe66fcdffe2`

**Observed**

usaspending-awards record 19AQMM26F0792; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_c42baa52a8350e01e65d2334`, `obs_5a445e3f6a4be184242caa2f`, `https://www.usaspending.gov/award/CONT_AWD_19AQMM26F0792_1900_47QTCA24D004L_4732/`

---

## crawl:candidate_1fae07441fe1b3b179a1531b: ANDURIL INDUSTRIES, INC. — 70B02C26F00000661

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `9f5d1442a564cfe20286`

**Observed**

usaspending-awards record 70B02C26F00000661; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_5a6f45e2192cc2a6c39a9591`, `https://www.usaspending.gov/award/CONT_AWD_70B02C26F00000661_7014_70B02C20D00000019_7014/`

---

## crawl:candidate_2045a8b8eb40b92496e02f5b: ANDURIL INDUSTRIES, INC. — 1305M224P0146

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `f2fad2a029e2160f68e0`

**Observed**

usaspending-awards record 1305M224P0146; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_64e0cd2f883c9126de45cdc1`, `https://www.usaspending.gov/award/CONT_AWD_1305M224P0146_1330_-NONE-_-NONE-/`

---

## crawl:candidate_27e8756dec2f4a8bb6bb1dd0: PALANTIR TECHNOLOGIES INC. — 2023H225F00156

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `aaccc8f249b04cd7e81c`

**Observed**

usaspending-awards record 2023H225F00156; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_897ad07fc7c71f45c9f28b22`, `https://www.usaspending.gov/award/CONT_AWD_2023H225F00156_2050_2023H225A00002_2050/`

---

## crawl:candidate_29ded8188e88f376de0475aa: PALANTIR TECHNOLOGIES INC. — 75N99226F00002

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `a087e19f441ede7fc590`

**Observed**

usaspending-awards record 75N99226F00002; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_8e621bc9d73898c747ebf3d6`, `https://www.usaspending.gov/award/CONT_AWD_75N99226F00002_7529_47QTCA24D004L_4732/`

---

## crawl:candidate_51b060a5373c61ab76062bb1: PALANTIR TECHNOLOGIES INC. — 70CTD026FC0000012

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `4f85d80d2dca59761356`

**Observed**

usaspending-awards record 70CTD026FC0000012; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_97dae41eb5fb788e8cd37404`, `https://www.usaspending.gov/award/CONT_AWD_70CTD026FC0000012_7012_70RTAC26A00000001_7001/`

---

## crawl:candidate_522643f6767041b9dc183ec0: PALANTIR TECHNOLOGIES INC. — 75P00124F37005

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `6831be16e5e95ecd2546`

**Observed**

usaspending-awards record 75P00124F37005; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_3cdbd45f03a9d50479cd0301`, `https://www.usaspending.gov/award/CONT_AWD_75P00124F37005_7570_75P00122A00010_7570/`

---

## crawl:candidate_58177bc06e7fd5c103979b9e: ANDURIL INDUSTRIES, INC. — W911W625FA007

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `ae50b9c31dc7f6db5179`

**Observed**

usaspending-awards record W911W625FA007; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_e7af6edb9aa69b5f55a40e7b`, `https://www.usaspending.gov/award/CONT_AWD_W911W625FA007_9700_W911W624D0008_9700/`

---

## crawl:candidate_723d64d7c2832c42016a6aa4: PALANTIR TECHNOLOGIES INC. — 693KA726P00024

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `f4485318ab6163254801`

**Observed**

usaspending-awards record 693KA726P00024; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_a38773395918b25cc597613c`, `https://www.usaspending.gov/award/CONT_AWD_693KA726P00024_6920_-NONE-_-NONE-/`

---

## crawl:candidate_79dca2088bc702458c008651: PALANTIR TECHNOLOGIES INC. — 89233126FNA400763

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `8495d7cf546f9b6d1b46`

**Observed**

usaspending-awards record 89233126FNA400763; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_a7775340aea18457e908a761`, `obs_be9c6cab6d845feda22bb916`, `https://www.usaspending.gov/award/CONT_AWD_89233126FNA400763_8900_47QTCA24D004L_4732/`

---

## crawl:candidate_9090dbfe9a7053ff2b076ef0: PALANTIR TECHNOLOGIES INC. — 692M1526F00076

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `7abc3f8fb421b9d122f7`

**Observed**

usaspending-awards record 692M1526F00076; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_42274e5e4b28ba0ee35911b6`, `https://www.usaspending.gov/award/CONT_AWD_692M1526F00076_6920_47QTCA24D004L_4732/`

---

## crawl:candidate_96656782f739d32130c8ffd0: PALANTIR TECHNOLOGIES INC. — 12314426F0217

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `83a9aa35ed726268db51`

**Observed**

usaspending-awards record 12314426F0217; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_6346284aca94a22b8692c291`, `https://www.usaspending.gov/award/CONT_AWD_12314426F0217_1205_12314426A0009_1205/`

---

## crawl:candidate_a50cbdd639ab3ffb503eef71: ANDURIL INDUSTRIES, INC. — 70B02C25F00000422

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `1cc2893227b45fe08c46`

**Observed**

usaspending-awards record 70B02C25F00000422; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_928d2c5a42981522ad1dc23b`, `https://www.usaspending.gov/award/CONT_AWD_70B02C25F00000422_7014_70B02C20D00000019_7014/`

---

## crawl:candidate_b3282abf6d4f2770c0f50a97: ANDURIL INDUSTRIES, INC. — 70B02C25F00000926

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `3e8e1d8441b3e5a1a0ca`

**Observed**

usaspending-awards record 70B02C25F00000926; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_c2832582239bd19e1d51d134`, `https://www.usaspending.gov/award/CONT_AWD_70B02C25F00000926_7014_70B02C20D00000019_7014/`

---

## crawl:candidate_b5399c2dfff9f098c27bb9ad: ANDURIL INDUSTRIES, INC. — W9128Z26FA005

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `dcba6a4deac8e3f5d023`

**Observed**

usaspending-awards record W9128Z26FA005; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_7649c529cebd0d2c75857550`, `https://www.usaspending.gov/award/CONT_AWD_W9128Z26FA005_9700_W9128Z26DA001_9700/`

---

## crawl:candidate_b54b9b39edd46663337b1ae1: PALANTIR TECHNOLOGIES INC. — 86615526F00002

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `bfc95fa06996dd4891e1`

**Observed**

usaspending-awards record 86615526F00002; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_5e51cd71c0eceaebca1d66fc`, `https://www.usaspending.gov/award/CONT_AWD_86615526F00002_8600_47QTCA24D004L_4732/`

---

## crawl:candidate_d54c24af3b30532a68a5c4e3: ANDURIL INDUSTRIES, INC. — 89233126FNA400748

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `1e0de88317253132560a`

**Observed**

usaspending-awards record 89233126FNA400748; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_7ab1694d0af56998f6df6628`, `https://www.usaspending.gov/award/CONT_AWD_89233126FNA400748_8900_89233126DNA000072_8900/`

---

## crawl:candidate_d6cd4f4fc14f1766a237b378: ANDURIL INDUSTRIES, INC. — 70B02C26F00000480

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `a955babd4b752c6c6967`

**Observed**

usaspending-awards record 70B02C26F00000480; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_157e182ea3516b7c24dd7733`, `https://www.usaspending.gov/award/CONT_AWD_70B02C26F00000480_7014_70B02C20D00000019_7014/`

---

## crawl:candidate_e071f64dceb8540f406416d3: ANDURIL INDUSTRIES, INC. — 89233126FNA400803

- Priority: high
- Type: official_record_candidate
- Origin: official-record-crawl
- Discovery status: accepted_intake
- Certainty: source_record_observed
- Source availability: available
- Evidence state: observed
- Fingerprint: `fc9b50f217a6b24ff53a`

**Observed**

usaspending-awards record 89233126FNA400803; matched on title.

**Bounded next action**

Resolve canonical entities and attach independent claim-level receipts; promotion requires a human-reviewed PR.

Refs: `obs_63b52be04b4661742fb12e26`, `https://www.usaspending.gov/award/CONT_AWD_89233126FNA400803_8900_89233126DNA000072_8900/`

---
