# Research fan-out: scout-island-with-surfaces-005

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-island-with-surfaces
- Items: 20
- Fingerprint: `53c78516dcdc741aebcf`

## scout:finding-106: Tyler Cowen has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `cfbc90f0160b0913df82`

**Observed**

Tyler Cowen participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-107: Adam Grant has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `c49845581808da95fab4`

**Observed**

Adam Grant participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-108: Jonathan Haidt has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `7d9face67c3cc85d97e1`

**Observed**

Jonathan Haidt participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-109: Anne-Marie Slaughter has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `00023e87de85b7496434`

**Observed**

Anne-Marie Slaughter participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-110: Leonard Leo has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `6148186438a9191204bc`

**Observed**

Leonard Leo participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-111: Grover Norquist has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `2d874b306b0ec0c7e1a9`

**Observed**

Grover Norquist participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-112: Nick Thompson has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `127db6ff4b74f3ae7dd6`

**Observed**

Nick Thompson participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-113: Bret Stephens has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `a082a22fe30329675bf5`

**Observed**

Bret Stephens participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-114: Tim Ferriss has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `12dd54b10fe66159080c`

**Observed**

Tim Ferriss participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-115: Mike Cannon-Brookes has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `e406a791f979a47b1d64`

**Observed**

Mike Cannon-Brookes participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-116: Marcos Galperin has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `eea2938a956f0967947a`

**Observed**

Marcos Galperin participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-117: Demet Mutlu has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `51a1e7aa063d8aa6c2da`

**Observed**

Demet Mutlu participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-118: Cesar Carvalho has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `3525856038f0f1ec5757`

**Observed**

Cesar Carvalho participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-119: Howie Liu has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `735e062358e374c7fa15`

**Observed**

Howie Liu participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-120: Scott Belsky has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `cdd156f33b4103667027`

**Observed**

Scott Belsky participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-121: Steve Ells has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1431eec40820c4f1b292`

**Observed**

Steve Ells participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-122: Nicolas Berggruen has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `03667ee099547c384f83`

**Observed**

Nicolas Berggruen participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-123: Matt Cohler has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `baedc18f6834ce3aee5d`

**Observed**

Matt Cohler participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-124: Will Scharf has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `091ad42ddcd52f612362`

**Observed**

Will Scharf participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-125: Mario Schlosser has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1739f697b896ff750a13`

**Observed**

Mario Schlosser participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---
