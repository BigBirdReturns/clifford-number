# Research fan-out: public-interest-epstein-corpus-manifest-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-epstein-corpus-manifest
- Items: 1
- Fingerprint: `6fd1b28ea5782d620552`

## public-interest:epstein-doj-corpus-manifest: Enumerate and hash the DOJ Epstein Library

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `0fc3a5bf00028a2cff7d`

**Observed**

The checked-in source manifest identifies doj-epstein-library as a official_government_corpus source family for epstein. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Enumerate every linked EFTA and court artifact with URL, release page, artifact date, publication date, MIME type, byte size, page count, SHA-256, OCR status, redaction state, and duplicate cluster. Treat government publication as custody, not authentication of every submitted claim.

Refs: `epstein-doj-corpus-manifest`, `doj-epstein-library`, `https://www.justice.gov/epstein/doj-disclosures`

---
