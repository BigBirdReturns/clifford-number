# Research fan-out: crawl-rejection-federal-register-004

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-federal-register
- Items: 7
- Fingerprint: `e1aae05998e7ab54a151`

## crawl-rejection:reject_e93cb2ce05be3a63d5f73d77: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5ac630aa86f78f63e521`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_e93cb2ce05be3a63d5f73d77`, `federal-register`

---

## crawl-rejection:reject_e9d56328c4ecab163e60d953: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6bc082a4c444422313fa`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_e9d56328c4ecab163e60d953`, `federal-register`

---

## crawl-rejection:reject_edff36a00297e512a1585a2b: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5df6918b72189ac4f9c7`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_edff36a00297e512a1585a2b`, `federal-register`

---

## crawl-rejection:reject_f60f47f0159a9ff41a380627: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `0280160127f76fc96c0a`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f60f47f0159a9ff41a380627`, `federal-register`

---

## crawl-rejection:reject_f90e64f5bed576f3d2ecd8db: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `78983da14afc34955cb0`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_f90e64f5bed576f3d2ecd8db`, `federal-register`

---

## crawl-rejection:reject_fb514029ff7a7276f7f35d08: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a64c848d7a336803d146`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_fb514029ff7a7276f7f35d08`, `federal-register`

---

## crawl-rejection:reject_ff88b9319c4f0c4d66b1f77f: Review held crawl observation from federal-register

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `c6390aa8623c13c98e83`

**Observed**

The official-record crawler held one federal-register observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_ff88b9319c4f0c4d66b1f77f`, `federal-register`

---
