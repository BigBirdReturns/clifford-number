# Research fan-out: public-interest-trump-epstein-crossing-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-trump-epstein-crossing
- Items: 1
- Fingerprint: `7a22b8fa258961b52dbb`

## public-interest:trump-epstein-exact-predicates: Extract Trump–Epstein surfaces as exact predicates

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `ccf4fda3f7f7ae8d8d08`

**Observed**

The checked-in source manifest identifies doj-epstein-trump-bounded-surfaces as a officially_published_mixed_evidence source family for trump. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Create distinct records for logged flight-leg names, observed event co-presence, public self-description, self-claimed estrangement, property employment, witness testimony, proposed calls or visits, subpoena production, and explicit negative testimony. Preserve artifact authentication and legal status for each.

Refs: `trump-epstein-exact-predicates`, `doj-epstein-trump-bounded-surfaces`, `https://www.justice.gov/epstein/files/DataSet%208/EFTA00028716.pdf`

---
