# Research fan-out: formation-duarte-station-area-signal-displacement-value-capture-asymmetry-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-duarte-station-area-signal-displacement-value-capture-asymmetry
- Items: 2
- Fingerprint: `f1501022e33ee8d8546d`

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:4887693418cdbd53a005: Formation control: duarte-station-area — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `90bcefb33a8b086f75cb`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA small business displacement downtown redevelopment reporting" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:signal-displacement-value-capture-asymmetry:cd629892dafcba9c8d74: Formation control: duarte-station-area — signal:displacement-value-capture-asymmetry

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `a37fa7ea43942dc177d1`

**Observed**

The checked-in neutral target universe selected duarte-station-area for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Duarte CA assessment district who pays who benefits" using bounded_public_record_research against press_and_academic_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
