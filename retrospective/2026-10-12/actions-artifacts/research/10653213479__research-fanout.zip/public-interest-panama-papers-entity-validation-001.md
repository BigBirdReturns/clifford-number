# Research fan-out: public-interest-panama-papers-entity-validation-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-entity-validation
- Items: 1
- Fingerprint: `5b933ccccc017cb59f02`

## public-interest:panama-official-entity-validation: Validate offshore entities against official registries

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `edeaf22e4e95b089ad07`

**Observed**

The checked-in source manifest identifies official-registry-crosswalk as a official_registry_family source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Resolve high-interest entities using jurisdiction plus registration number, LEI, Companies House number or overseas-entity ID, SEC CIK, OFAC UID, incorporation date, and former-name history. Preserve unresolved and conflicting identities.

Refs: `panama-official-entity-validation`, `official-registry-crosswalk`, `https://www.gov.uk/guidance/register-an-overseas-entity`

---
