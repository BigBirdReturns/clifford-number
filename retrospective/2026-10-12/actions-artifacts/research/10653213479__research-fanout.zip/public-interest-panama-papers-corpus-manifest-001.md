# Research fan-out: public-interest-panama-papers-corpus-manifest-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-corpus-manifest
- Items: 1
- Fingerprint: `d267613ec6cf3b7a99f6`

## public-interest:panama-download-snapshot: Freeze and inventory the ICIJ Offshore Leaks dataset

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1139dfc3ff8a67420ff3`

**Observed**

The checked-in source manifest identifies icij-offshore-leaks-download as a investigative_graph_dataset source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Download the CSV or Neo4j release, preserve license, retrieval time, file hashes, dataset version, node/edge counts, source-dataset labels, and schema. Treat ICIJ node IDs as snapshot-local identifiers.

Refs: `panama-download-snapshot`, `icij-offshore-leaks-download`, `https://offshoreleaks.icij.org/pages/database`

---
