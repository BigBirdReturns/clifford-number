# Research fan-out: formation-azusa-gold-line-district-assessment-governance-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-azusa-gold-line-district-assessment-governance
- Items: 3
- Fingerprint: `9c9a2589d14f60114569`

## formation:sig-place-formation-v1:assessment-governance:24a23ff024bf17d077f6: Formation control: azusa-gold-line-district — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `52f9a3de7ca90e71a8b1`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA business improvement district formation assessment" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:assessment-governance:aab576a439aa408d12ce: Formation control: azusa-gold-line-district — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `28ff2c31c01e356695f2`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA downtown association bylaws city agreement" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:assessment-governance:ee6afce0d87579990563: Formation control: azusa-gold-line-district — assessment-governance

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `eeb0169062deada80973`

**Observed**

The checked-in neutral target universe selected azusa-gold-line-district for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Azusa CA property and business improvement district 36600" using bounded_public_record_research against municipal_and_state_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
