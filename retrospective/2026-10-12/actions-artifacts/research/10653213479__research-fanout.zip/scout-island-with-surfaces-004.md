# Research fan-out: scout-island-with-surfaces-004

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: scout-island-with-surfaces
- Items: 20
- Fingerprint: `58129a7cb38b3f2291ad`

## scout:finding-086: Manuel Bronstein has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `699afb07b45adb74c420`

**Observed**

Manuel Bronstein participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-087: Severin Hacker has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `f8224f577c9dfa7ddcf3`

**Observed**

Severin Hacker participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-088: Wences Casares has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `01e4a43a8fdcb348e72f`

**Observed**

Wences Casares participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-089: Immad Akhund has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `2d62fdb0c5fedd89ec1e`

**Observed**

Immad Akhund participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-090: Henry Kravis has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `05558f4b0a475d2ecd1f`

**Observed**

Henry Kravis participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-091: Pete Briger has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `3f77aa9bdfc26c661336`

**Observed**

Pete Briger participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-092: Peter Brown has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `b2323350e39504ace948`

**Observed**

Peter Brown participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-093: Karen Karniol-Tambour has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `173831b19bc61b9d66f7`

**Observed**

Karen Karniol-Tambour participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-094: Mike Novogratz has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `dd1ea735b9cb3a2a3294`

**Observed**

Mike Novogratz participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-095: Bob Jain has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `80b6dbeb8f9ac43ba1d1`

**Observed**

Bob Jain participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-096: Gaurva Kapadia has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `969b1a1347e83535866d`

**Observed**

Gaurva Kapadia participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-097: Micky Malka has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `c5cf9caca850020a1f30`

**Observed**

Micky Malka participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-098: Chamath Palihapitiya has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `65d171da6f6a8b182814`

**Observed**

Chamath Palihapitiya participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-099: Jared Kushner has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `ab60f489ffc8ad6a56c7`

**Observed**

Jared Kushner participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-100: John Arnold has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `581cb3f33da5e51615b8`

**Observed**

John Arnold participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-101: Robert Rubin has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `8a263a884d336730603c`

**Observed**

Robert Rubin participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-102: Lawrence Summers has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `e02e5da37281bcaad46f`

**Observed**

Lawrence Summers participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-103: Eric Schmidt has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `1b473ca4c00f08d03ac3`

**Observed**

Eric Schmidt participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-104: Susan Athey has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `99db26e5e71a8ade7f60`

**Observed**

Susan Athey participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---

## scout:finding-105: Steven Pinker has surfaces but no Clifford path

- Priority: medium
- Type: island_with_surfaces
- Origin: surface-scout
- Discovery status: derived_signal
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `96018c4cf65eb19d8fe8`

**Observed**

Steven Pinker participates in 1 surface(s), but no valid shared-surface path to Matt Clifford exists.

**Bounded next action**

Scout for bounded surfaces shared with actors already on the Clifford spine. Do not use broad institutions as bridges.

Refs: `dialog-public-directory-exposure-2026-06-16`

---
