# Research fan-out: field-autopsy-arcadia-field-autopsy-patient-ownership-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: field-autopsy-arcadia-field-autopsy-patient-ownership
- Items: 2
- Fingerprint: `fb2cd01b335f53ba2c27`

## field-autopsy:arcadia-field-autopsy:trail-deed-chronology:1: The Arcadia Formation: Station-area deed chronology (county recorder) (1/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `6129256c0417ae9a471f`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-deed-chronology as a in_progress candidate trail at stage patient-ownership. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "LA County recorder deed image for document 0174959 and predecessor documents 0039982/0612352/0350773/0157424" against county_recorder_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-deed-chronology`, `sig-place-formation-v1`

---

## field-autopsy:arcadia-field-autopsy:trail-deed-chronology:2: The Arcadia Formation: Station-area deed chronology (county recorder) (2/2)

- Priority: high
- Type: bounded_field_autopsy_trail_query
- Origin: field-autopsy-trail
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `469a4d25c588da3e8698`

**Observed**

The arcadia-field-autopsy field autopsy preserves trail-deed-chronology as a in_progress candidate trail at stage patient-ownership. This is a bounded research instruction, not a finding about the place, actors, coordination, causation, wrongdoing, or geomancy.

**Bounded next action**

Run the exact query "LA County recorder deed images for Town Center documents 0803058/1174890/0842724 and later partial-interest transfers" against county_recorder_records. Preserve inspected sources, record identifiers, dates, negative results, and access failures. Return candidates only; do not promote the trail from the search result.

Refs: `cases/arcadia-field-autopsy/trails.jsonl`, `trail-deed-chronology`, `sig-place-formation-v1`

---
