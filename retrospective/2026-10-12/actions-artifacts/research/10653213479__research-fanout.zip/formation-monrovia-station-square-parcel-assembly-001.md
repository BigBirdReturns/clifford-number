# Research fan-out: formation-monrovia-station-square-parcel-assembly-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: formation-monrovia-station-square-parcel-assembly
- Items: 2
- Fingerprint: `8e0939c747e2efff7b54`

## formation:sig-place-formation-v1:parcel-assembly:29b7dc038e9e3c247e4f: Formation control: monrovia-station-square — parcel-assembly

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `2d35e6ebb311cf5c8191`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA city parking lot disposition development agreement" using bounded_public_record_research against municipal_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---

## formation:sig-place-formation-v1:parcel-assembly:8e8c9f0d478d1df08a29: Formation control: monrovia-station-square — parcel-assembly

- Priority: medium
- Type: bounded_formation_signature_query
- Origin: formation-signature
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: unknown
- Evidence state: inferred
- Fingerprint: `e0b2fbcd22fed73779fb`

**Observed**

The checked-in neutral target universe selected monrovia-station-square for sig-place-formation-v1 before evaluating whether the formation matches. This task is a generated comparison query, not an assertion that any stage, coordination, causation, wrongdoing, or geomantic mechanism exists.

**Bounded next action**

Run the exact query "Monrovia CA exclusive negotiation agreement downtown parcel" using bounded_public_record_research against municipal_agenda_records. Preserve sources inspected, record identifiers, dates, negative results, and access failures. Return candidate observations only.

Refs: `data/research/place-formation-targets.jsonl`, `data/signatures/formation-signatures.json`

---
