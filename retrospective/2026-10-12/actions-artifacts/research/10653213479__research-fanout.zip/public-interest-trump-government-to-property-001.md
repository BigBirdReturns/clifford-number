# Research fan-out: public-interest-trump-government-to-property-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-trump-government-to-property
- Items: 1
- Fingerprint: `26576b7b3f91e24ccea3`

## public-interest:trump-government-property-spending: Map federal spending and leases involving Trump properties

- Priority: high
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `2f0174caee81c3d895ac`

**Observed**

The checked-in source manifest identifies usaspending-gsa-usss-property-records as a official_spending_and_inspector_general_records source family for trump. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Query exact OGE-disclosed legal entities, UEIs, award IDs, lease numbers, and agency records across USAspending, GSA, Secret Service, Defense, State, and inspector-general sources. Keep obligation, outlay, ceiling, refund, room charge, and lease payment as distinct amount stages.

Refs: `trump-government-property-spending`, `usaspending-gsa-usss-property-records`, `https://api.usaspending.gov/docs/`

---
