# Research fan-out: crawl-source-coverage-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-source-coverage
- Items: 1
- Fingerprint: `f2a52f5fdfe9c483d9e3`

## crawl-source-gap:sam-opportunities: Restore crawl coverage: SAM.gov Contract Opportunities

- Priority: medium
- Type: official_record_source_coverage_gap
- Origin: official-record-crawl-source-gap
- Discovery status: coverage_gap
- Certainty: not_observed_due_to_source_gap
- Source availability: unavailable
- Evidence state: observed
- Fingerprint: `2b8a745dd7162b217fa9`

**Observed**

The enabled sam-opportunities source has crawl status skipped_missing_credential. This records incomplete or unavailable coverage; it does not establish that no matching records exist.

**Bounded next action**

Retry this source when its configured credential is available. Until then, record the coverage gap explicitly and do not interpret the missing scan as evidence of absence.

Refs: `data/crawl/state.json`, `sam-opportunities`

---
