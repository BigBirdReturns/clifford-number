# Research fan-out: public-interest-panama-papers-cross-leak-recurrence-001

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: public-interest-panama-papers-cross-leak-recurrence
- Items: 1
- Fingerprint: `e812679f7129fa764b73`

## public-interest:panama-cross-leak-recurrence: Measure entity recurrence across Panama, Paradise, Pandora, and Offshore Leaks

- Priority: medium
- Type: bounded_public_interest_source_query
- Origin: public-interest-source-seed
- Discovery status: preserved_intake
- Certainty: machine_derived_unverified
- Source availability: available
- Evidence state: inferred
- Fingerprint: `da8c7bc55f75e8c1fb61`

**Observed**

The checked-in source manifest identifies icij-cross-dataset-graph as a investigative_graph_dataset source family for panama-papers. This is a bounded research instruction, not an assertion about any named person, entity, transaction, or event.

**Bounded next action**

Identify exact identifier matches and strongly corroborated entity matches across source datasets. Keep dataset-specific nodes and assertions, attach the merge basis, and distinguish repeated source custody from independent registry corroboration.

Refs: `panama-cross-leak-recurrence`, `icij-cross-dataset-graph`, `https://offshoreleaks.icij.org/pages/data`

---
