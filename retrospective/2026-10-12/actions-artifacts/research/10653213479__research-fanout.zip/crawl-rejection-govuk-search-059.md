# Research fan-out: crawl-rejection-govuk-search-059

> Machine-proposed and unverified. `graph_effect: none`. This packet cannot edit canonical data or create a Clifford hop.

- Lane: crawl-rejection-govuk-search
- Items: 20
- Fingerprint: `f53490f77b471ee61561`

## crawl-rejection:reject_b277c046add5e680327da3f9: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `93a70cfd6d67652f774f`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b277c046add5e680327da3f9`, `govuk-search`

---

## crawl-rejection:reject_b27d2fc88b5abd92d3ee9d02: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6b2ce6107713be4f85e4`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b27d2fc88b5abd92d3ee9d02`, `govuk-search`

---

## crawl-rejection:reject_b2babe9138b10bc177bf577d: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `3f1b080050fb61f23ce6`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b2babe9138b10bc177bf577d`, `govuk-search`

---

## crawl-rejection:reject_b2d479ab7203ab15d1c3b1e8: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6dd9e6c897c671eab3df`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b2d479ab7203ab15d1c3b1e8`, `govuk-search`

---

## crawl-rejection:reject_b2d48805016559ff3dce8441: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `6738495c6091a55249fe`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b2d48805016559ff3dce8441`, `govuk-search`

---

## crawl-rejection:reject_b2e27dfaf9df8f8306e5c78b: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `67b892d9c4ef1cd923b0`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b2e27dfaf9df8f8306e5c78b`, `govuk-search`

---

## crawl-rejection:reject_b34dca928b59bb7406c6671e: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `5be91b36113022116dfa`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b34dca928b59bb7406c6671e`, `govuk-search`

---

## crawl-rejection:reject_b4231f3b29b32b893c6ad909: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `1b0afda2fe603dfdb6ff`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b4231f3b29b32b893c6ad909`, `govuk-search`

---

## crawl-rejection:reject_b42392418896e8eb6327480f: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8250dc7deb711bd3e459`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b42392418896e8eb6327480f`, `govuk-search`

---

## crawl-rejection:reject_b42756d248ed4c6266cc9282: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `8a2c31567943a0705654`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b42756d248ed4c6266cc9282`, `govuk-search`

---

## crawl-rejection:reject_b4ce6fbed0818bf557410658: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a8f13235f89dc4f5b06e`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b4ce6fbed0818bf557410658`, `govuk-search`

---

## crawl-rejection:reject_b5020be91abef81c7a8b5bfe: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `f0a340016e32f0284de3`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b5020be91abef81c7a8b5bfe`, `govuk-search`

---

## crawl-rejection:reject_b518143d8902576bfe44166c: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `f607459a111ee86c4449`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b518143d8902576bfe44166c`, `govuk-search`

---

## crawl-rejection:reject_b523f76869b579e173ad7a0e: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `7ce6b4943319ac9ecf0d`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b523f76869b579e173ad7a0e`, `govuk-search`

---

## crawl-rejection:reject_b57a30f627453e30f79d06d1: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `ea3c478a477868da0b06`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b57a30f627453e30f79d06d1`, `govuk-search`

---

## crawl-rejection:reject_b58ee5217552bc311ee20c34: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `4cf0841342c0119f1633`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b58ee5217552bc311ee20c34`, `govuk-search`

---

## crawl-rejection:reject_b592ca99d0268cb8bfbfcc62: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `da67c230ac5ba7b5dd47`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b592ca99d0268cb8bfbfcc62`, `govuk-search`

---

## crawl-rejection:reject_b59a191270283f20f4bae84a: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `43c4d818e73967485d8d`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b59a191270283f20f4bae84a`, `govuk-search`

---

## crawl-rejection:reject_b5b53c213dad1d3c5f616609: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `03a9ab7cdf3b5cc1a812`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b5b53c213dad1d3c5f616609`, `govuk-search`

---

## crawl-rejection:reject_b5b880438be29cd61ed180af: Review held crawl observation from govuk-search

- Priority: low
- Type: official_record_rejection_review
- Origin: official-record-crawl-rejection
- Discovery status: held_for_review
- Certainty: rejection_metadata_observed
- Source availability: unknown
- Evidence state: observed
- Fingerprint: `a43af45f09b8dc61801c`

**Observed**

The official-record crawler held one govuk-search observation outside candidate intake under the relevance_gate class. This records a filtering or adapter outcome, not evidence that the underlying fact, relationship, or pattern is absent.

**Bounded next action**

Review the rejection ledger entry and, if the public record remains available, test whether the local relevance gate discarded a weak or indirect lead. Preserve the negative result or restore it only as intake; do not promote it.

Refs: `reject_b5b880438be29cd61ed180af`, `govuk-search`

---
