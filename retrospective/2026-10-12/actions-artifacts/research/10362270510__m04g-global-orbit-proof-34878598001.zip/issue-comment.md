<!-- m04g-global-orbit-proof:34878598001 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/34878598001
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/10` (`0.4`)
- Content success: `4/10` (`0.4`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/2`
- Proof SHA-256: `f8462c3bce1cf2780e893d299e45aa43032038aaa3b1f21dd98271149f0233ef`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
