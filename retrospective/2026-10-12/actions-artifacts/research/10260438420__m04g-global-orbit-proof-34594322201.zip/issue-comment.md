<!-- m04g-global-orbit-proof:34594322201 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/34594322201
- Head: `716a15edc3577e0bf8abb4d4236393a3a1924acc`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `19/25` (`0.76`)
- Content success: `17/25` (`0.68`)
- Metadata only: `2`
- Failed: `6`
- Healthy basins: `0/5`
- Proof SHA-256: `f26ba7a73900ecd1e63f80f86e9ede018060b5519231e3fc504363474f41f75d`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
