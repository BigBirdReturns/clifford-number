<!-- m04g-global-orbit-proof:30217094183 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30217094183
- Head: `8b37efb710470779aa346e95014dd238bd4b828a`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Complete: `true`
- Proof SHA-256: `0a23b42bf77639babb7b74cfb4e61442438b7227710c4887a223fe95dba4aa46`

| Basin | Selected | Succeeded | Failed | Candidates |
|---|---:|---:|---:|---:|
| `G01-GLOBAL-MULTILATERAL` | 5 | 4 | 1 | 4 |

```text
promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
