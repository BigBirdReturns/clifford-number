<!-- m04g-global-orbit-proof:31902043202 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31902043202
- Head: `c7d91194620feb00c6bff2469950897ecce9f656`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/5` (`0.8`)
- Content success: `4/5` (`0.8`)
- Metadata only: `0`
- Failed: `1`
- Healthy basins: `0/1`
- Proof SHA-256: `0dbb8a3075d63a13643a2dbec4b7dd9e8e2975dca69387cc6cdcb2bfceb8c44c`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
