<!-- m04g-global-orbit-proof:30485504832 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30485504832
- Head: `267b40e69a85588ae517a997c5bca41c263afd81`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/5` (`0.8`)
- Content success: `4/5` (`0.8`)
- Metadata only: `0`
- Failed: `1`
- Healthy basins: `0/1`
- Proof SHA-256: `2fe8f7c5736ca82188d2cf49329abf3a2955e0a4f7374e50b429566976d11a1a`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
