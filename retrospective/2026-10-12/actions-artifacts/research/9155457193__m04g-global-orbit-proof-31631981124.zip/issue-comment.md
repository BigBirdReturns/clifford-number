<!-- m04g-global-orbit-proof:31631981124 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31631981124
- Head: `b31614a7e2a10a5e488e273ce39c31271399ae4e`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/5` (`0.8`)
- Content success: `4/5` (`0.8`)
- Metadata only: `0`
- Failed: `1`
- Healthy basins: `0/1`
- Proof SHA-256: `8f879e01fdf00bd9aa90be7ca07d0668e28d2696cc5fc109c2de0f4eafde5387`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
