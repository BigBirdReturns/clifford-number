<!-- m04g-global-orbit-proof:31394408722 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31394408722
- Head: `bc3cf04459bb0d18829f376c9b937693b521e444`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/10` (`0.4`)
- Content success: `4/10` (`0.4`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/2`
- Proof SHA-256: `8ca15c837f5e08a64c63315760899efb5bb5158cf729acedfa3426b684e5710b`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
