# School.House IRS legal-identity candidate capture

This artifact scans official IRS public datasets for registry-name candidates. It retains EIN, legal name, status, city, and state fields but excludes street addresses, contact details, officers, private records, and private messages. A candidate is not an admitted identity.
