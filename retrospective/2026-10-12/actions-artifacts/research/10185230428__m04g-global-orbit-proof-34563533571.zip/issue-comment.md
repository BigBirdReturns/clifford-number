<!-- m04g-global-orbit-proof:34563533571 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/34563533571
- Head: `716a15edc3577e0bf8abb4d4236393a3a1924acc`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `4/4`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `9/20` (`0.45`)
- Content success: `8/20` (`0.4`)
- Metadata only: `1`
- Failed: `11`
- Healthy basins: `0/4`
- Proof SHA-256: `c192352d0d261def06bbe9ea946cce956478fdb8696f150b0e3d27bdad5c9f86`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G09-SOUTH-ASIA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G10-EAST-ASIA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G11-SOUTHEAST-ASIA` | 5 | 3 | 3 | 0 | 2 | `false` |
| `G12-OCEANIA-PACIFIC` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
