<!-- m04g-global-orbit-proof:34820924014 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/34820924014
- Head: `09cfc1b72d9da05b81c06f7c936066440c072df9`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `18/24` (`0.75`)
- Content success: `18/24` (`0.75`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/12`
- Proof SHA-256: `964d0ff109daf032602d28e80d2222b0395e8e351af652e769139d82b4c41f5a`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 1 | 1 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
