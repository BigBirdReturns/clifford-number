RD-04 five-state source-field adjudication materialization failed closed.

```text
workflow_run: 31202748867
carrier_head: 02a02567c679857a169d9dfd2328c11b72882888
bound_parent: unbound
exit_code: 1
```

No unverified product ref is authorized.
