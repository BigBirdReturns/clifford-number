#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,os,shutil,subprocess,traceback
from pathlib import Path
R=Path.cwd(); PKG=Path('/tmp/rd04-mt-row-state-validation-package'); PRODUCT=PKG/'product'; O=Path(os.environ['OUT']); W=Path('/tmp/rd04-mt-row-state-validation-work'); S=Path('/tmp/rd04-mt-row-state-validation-stage')
PARENT='e62de80e187f9be037cbdd3a4b942b5840d223de'; PTREE='0d1f8369e2c68d18b11a8f375903ff597ea8ccdb'; MATRIX='data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/promoted-partial-field-matrix.json'; MBLOB='6ba11a6025021e9df8ac6535be8c42499654c233'
WF='.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation-validation-v1.yml'; ROOT='data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation-validation-v1'; V='tools/validate-status-sovereignty-rd-wave03-rd04-mt-row-state-reconciliation-v1.py'; TWF='.tmp/rd04-mt-row-state-validation-materializer/permanent-workflow.yml'; SB='staging/ssc-rd04-mt-row-state-reconciliation-validation-v1'
PATHS=[WF,f'{ROOT}/current-row-custody.json',f'{ROOT}/row-state-validation.json',f'{ROOT}/validated-row-state-protocol.json',f'{ROOT}/summary.json',f'{ROOT}/product-manifest.json',V]
BASE_PATHS=['.github/workflows/temp-materialize-ssc-rd04-mt-row-state-validation-v1.yml','.tmp/rd04-mt-row-state-validation-materializer/package.tar.gz.b64']; TRIGGER='.tmp/rd04-mt-row-state-validation-materializer/trigger.json'
CB=os.environ['CARRIER_BASE_SHA']; CH=os.environ['EVENT_HEAD_SHA']
def cmd(*a,cwd=R,env=None,ok=True):
 p=subprocess.run(a,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env)
 if ok and p.returncode: raise RuntimeError(f"command {p.returncode}: {' '.join(a)}\n{p.stdout}")
 return p.stdout
def g(*a,cwd=R): return cmd('git',*a,cwd=cwd).strip()
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def jb(v): return (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode()
def write_log(name,text): O.mkdir(parents=True,exist_ok=True); (O/name).write_text(text)
def topology():
 assert g('rev-parse','HEAD')==CH and g('rev-parse','HEAD^')==CB
 assert int(g('rev-list','--count',f'{PARENT}..{CB}'))==2 and g('merge-base',PARENT,CB)==PARENT
 assert sorted(g('diff','--name-only',PARENT,CB).splitlines())==sorted(BASE_PATHS)
 assert sorted(g('diff','--name-only','--diff-filter=A',PARENT,CB).splitlines())==sorted(BASE_PATHS)
 assert sorted(g('diff','--name-only',CB,CH).splitlines())==[TRIGGER]
 assert sorted(g('diff','--name-only','--diff-filter=A',CB,CH).splitlines())==[TRIGGER]
 assert g('rev-parse',f'{PARENT}^{{tree}}')==PTREE
 g('fetch','--quiet','--force','origin','+refs/heads/main:refs/remotes/origin/main'); assert g('rev-parse','refs/remotes/origin/main')==PARENT
 assert g('rev-parse',f'{PARENT}:{MATRIX}')==MBLOB
 for rel in PATHS:
  p=PRODUCT/rel; assert p.is_file() and not p.is_symlink()
 assert sorted(str(p.relative_to(PRODUCT)) for p in PRODUCT.rglob('*') if p.is_file())==sorted(PATHS)
def build_candidate():
 shutil.rmtree(W,ignore_errors=True); cmd('git','worktree','add','--detach',str(W),PARENT)
 for rel in PATHS:
  dst=W/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes((PRODUCT/rel).read_bytes())
 assert sorted(g('status','--porcelain',cwd=W)[3:].splitlines()) if False else True
 changed=sorted(line[3:] for line in g('status','--porcelain','--untracked-files=all',cwd=W).splitlines()); assert changed==sorted(PATHS)
 cmd('git','add','--',*PATHS,cwd=W)
 env=os.environ.copy(); env.update(GIT_AUTHOR_NAME='BigBirdReturns',GIT_AUTHOR_EMAIL='bigbirdreturns@users.noreply.github.com',GIT_COMMITTER_NAME='BigBirdReturns',GIT_COMMITTER_EMAIL='bigbirdreturns@users.noreply.github.com')
 cmd('git','commit','-m','Validate request-free Montana row-state candidate',cwd=W,env=env)
 c=g('rev-parse','HEAD',cwd=W); t=g('rev-parse','HEAD^{tree}',cwd=W); assert g('rev-parse','HEAD^',cwd=W)==PARENT
 assert sorted(g('diff','--name-only',PARENT,c,cwd=W).splitlines())==sorted(PATHS); assert sorted(g('diff','--name-only','--diff-filter=A',PARENT,c,cwd=W).splitlines())==sorted(PATHS); assert not g('diff','--name-only','--diff-filter=MDTCRUXB',PARENT,c,cwd=W)
 return c,t
def qualify(c):
 env=os.environ.copy(); env['VALIDATION_HEAD']=c
 cmd('python','-m','py_compile',V,cwd=W)
 a=cmd('python',V,cwd=W,env=env); write_log('validation-receipt.json',a)
 x=json.loads(a); assert x['state']=='qualified_request_free_montana_row_state_candidate' and x['adversarial_refusals']==26 and x['projected_terminal_cells']==230 and x['projected_terminal_units']==12 and not x['promotion_executed_here'] and not x['class_closed']
 write_log('release-check.log',cmd('npm','run','release:check',cwd=W))
 cmd('git','reset','--hard','HEAD',cwd=W); cmd('git','clean','-fdx',cwd=W); assert not g('status','--porcelain',cwd=W)
 b=cmd('python',V,cwd=W,env=env); write_log('post-release-validation-receipt.json',b); assert a==b
 write_log('workflow-yaml-parse.txt',cmd('ruby','-e',"require 'yaml'; YAML.load_file(ARGV.fetch(0)); puts 'yaml_ok'",WF,cwd=W))
def file_records(c):
 rows=[]
 for rel in PATHS:
  d=cmd('git','show',f'{c}:{rel}',cwd=W).encode(); rows.append({'path':rel,'bytes':len(d),'sha256':sha(d),'git_blob':blob(d)})
 return rows
def stage(c):
 assert not g('ls-remote','--heads','origin',f'refs/heads/{SB}')
 shutil.rmtree(S,ignore_errors=True); cmd('git','worktree','add','--detach',str(S),PARENT)
 sp=[]
 for rel in PATHS:
  target=TWF if rel==WF else rel; dst=S/target; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_bytes(cmd('git','show',f'{c}:{rel}',cwd=W).encode()); sp.append(target)
 cmd('git','add','--',*sp,cwd=S)
 env=os.environ.copy(); env.update(GIT_AUTHOR_NAME='github-actions[bot]',GIT_AUTHOR_EMAIL='41898282+github-actions[bot]@users.noreply.github.com',GIT_COMMITTER_NAME='github-actions[bot]',GIT_COMMITTER_EMAIL='41898282+github-actions[bot]@users.noreply.github.com')
 cmd('git','commit','-m','Stage qualified Montana row-state validation objects',cwd=S,env=env)
 sc=g('rev-parse','HEAD',cwd=S); st=g('rev-parse','HEAD^{tree}',cwd=S); assert g('rev-parse','HEAD^',cwd=S)==PARENT
 assert sorted(g('diff','--name-only',PARENT,sc,cwd=S).splitlines())==sorted(sp)
 cmd('git','push','origin',f'{sc}:refs/heads/{SB}',cwd=S); assert g('ls-remote','--heads','origin',f'refs/heads/{SB}').split()[0]==sc
 return sc,st,sp
def seal(c,t,sc,st,sp):
 rows=file_records(c); by={r['path']:r for r in rows}; receipt={'schema_version':'ssc-rd04-mt-row-state-validation-materialization@1','state':'qualified_montana_validation_objects_staged','carrier_base':CB,'carrier_head':CH,'canonical_parent':PARENT,'canonical_parent_tree':PTREE,'product_commit_local':c,'product_tree':t,'permanent_paths':7,'added_paths':7,'modified_paths':0,'deleted_paths':0,'matrix':{'path':MATRIX,'git_blob':MBLOB,'sha256':'9f9dc05a057396056771bb566c44e9c3779d8ef6b0d2c078f7ffff11d9c7e6cb'},'candidate':{'unit_id':'US-STATE-MT','row_sha256':'06ab54ffbb8deaed317cfef33c44e685c43e17f2b3f6bb7f2c715f9a38ed86cc','current_cell_sha256':'221d9a1a9ecf55d786ab6f92faf77dd0795b3f4ef344cbccf64b4b72356ec2de','proposed_cell_sha256':'ba173d03c2f82316ca79eb8b6627057db6fdb54113340ff0f9539a85e89a1f2d','projected_row_sha256':'b6474320f690a653eae081cf655a090bb5d5da0f444e9a1c42077fd0b951bcbc','projected_matrix_bytes':502424,'projected_matrix_sha256':'12e52344af0c8ec3d845b6f05f8a20014fa84504d10dbc9ee0674d37715abe1d','projected_matrix_git_blob':'741bda42b609f386d71090e6368af537fd334914','projected_terminal_cells':230,'projected_still_open_cells':220,'projected_terminal_units':12},'qualification':{'validator':'passed','adversarial_refusals':26,'release_check':'passed','post_release_replay':'passed','workflow_yaml_parse':'passed'},'staging':{'branch':SB,'stage_commit':sc,'stage_tree':st,'paths':sp,'workflow_object_path':TWF,'workflow_git_blob':by[WF]['git_blob']},'file_records':rows,'authority_boundary':{'source_requests':0,'route_executions':0,'source_admissions':0,'field_terminalizations':0,'matrix_updates':0,'row_state_mutations':0,'row_terminalizations':0,'class_closed':False,'cumulative_ledger_effect':'none','publication_effect':'none','adoption_effect':'none','graph_effect':'none','outside_human_dependency':False}}
 O.mkdir(parents=True,exist_ok=True); (O/'materialization-receipt.json').write_bytes(jb(receipt)); (O/'SHA256SUMS').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(O.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
def main():
 O.mkdir(parents=True,exist_ok=True); owned=None
 try:
  topology(); c,t=build_candidate(); qualify(c); sc,st,sp=stage(c); owned=sc; seal(c,t,sc,st,sp); return 0
 except Exception:
  if owned:
   try:
    raw=g('ls-remote','--heads','origin',f'refs/heads/{SB}');
    if raw and raw.split()[0]==owned: cmd('git','push','origin',f':refs/heads/{SB}')
   except Exception: pass
  (O/'failure.txt').write_text(traceback.format_exc()); return 1
if __name__=='__main__': raise SystemExit(main())
