## Research fan-out issue reconciliation

- Dispatch result: **abandoned**
- Expected / matched batches: **169 / 169**
- Open fan-out issues / unique titles: **169 / 169**
- Unexpected historical open titles: **0**
- Expected digest: `ebf793cd4c3f8933b656955012884e5cc99846d9644869815b450a06ca0a6b8c`
- Actual digest: `ebf793cd4c3f8933b656955012884e5cc99846d9644869815b450a06ca0a6b8c`
- Result: **FAILED**

### Errors

- dispatch result: abandoned
