set -Eeuo pipefail
BASE='46036c01eaba31bdb18045307fe3ebcb67d576a6'
BASE_TREE='0ffec7018bcfc038a73cd280970f783d12a5c222'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-frontier-export-46036c-v3.yml'
SOURCE_HEAD='57ffae0c7d8f1588fcf929346a91bccb1bca989e'
SOURCE_WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-frontier-export-46036c-v1.yml'
SOURCE_BLOB='11d94bb3aa5e81da368104f4d9915a2e68f46a25'
SOURCE_NAMESPACE='schoolhouse-legal-identity-frontier-export-46036c-v1'
TARGET_NAMESPACE='schoolhouse-legal-identity-frontier-export-46036c-v3'
OUT="$RUNNER_TEMP/$TARGET_NAMESPACE"
WORK="$RUNNER_TEMP/schoolhouse-frontier-export-v2-reconstruction"
rm -rf "$WORK"
mkdir -p "$WORK"

git fetch --no-tags origin main agent/schoolhouse-legal-identity-frontier-export-46036c-v1
test "$(git rev-parse origin/main)" = "$BASE"
test "$(git rev-parse "$BASE^{tree}")" = "$BASE_TREE"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
mapfile -t DELTA < <(git diff --name-only "$BASE"..HEAD)
test "${#DELTA[@]}" -eq 1
test "${DELTA[0]}" = "$WORKFLOW"
git diff --check "$BASE"..HEAD
test "$(git rev-parse "$SOURCE_HEAD:$SOURCE_WORKFLOW")" = "$SOURCE_BLOB"

git show "$SOURCE_HEAD:$SOURCE_WORKFLOW" > "$WORK/source.yml"
python - "$WORK/source.yml" "$WORK/repaired.yml" "$WORK/export.sh" \
  "$WORK/repair.json" "$SOURCE_HEAD" "$SOURCE_BLOB" \
  "$SOURCE_NAMESPACE" "$TARGET_NAMESPACE" <<'PY'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

(
    source_path,
    repaired_path,
    script_path,
    receipt_path,
    source_head,
    source_blob,
    source_namespace,
    target_namespace,
) = sys.argv[1:]
source = Path(source_path).read_text(encoding='utf-8')
defect = "              for json_path, key, observed in walk(value, ()): \n"
repair = "              for json_path, key, observed in walk(value, ()):\n"
assert source.count(defect) == 1
assert source.count(source_namespace) == 7
repaired = source.replace(defect, repair)
repaired = repaired.replace(source_namespace, target_namespace)
assert defect not in repaired
assert source_namespace not in repaired
assert repaired.count(target_namespace) == 7

lines = repaired.splitlines()
step = "      - name: Export exact current School.House custody frontier"
start = lines.index(step)
run_line = lines.index("        run: |", start)
body = []
for line in lines[run_line + 1:]:
    if line.startswith("      - name:"):
        break
    assert not line or line.startswith("          "), line
    body.append(line[10:] if line else "")
assert body and body[0] == 'set -Eeuo pipefail'
script = '\n'.join(body) + '\n'

Path(repaired_path).write_text(repaired, encoding='utf-8')
Path(script_path).write_text(script, encoding='utf-8')
value = {
    'schema_version': 'schoolhouse-legal-identity-frontier-export-repair@1',
    'state': 'complete',
    'source_head': source_head,
    'source_workflow_blob': source_blob,
    'source_workflow_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'repaired_workflow_sha256': hashlib.sha256(repaired.encode()).hexdigest(),
    'extracted_script_sha256': hashlib.sha256(script.encode()).hexdigest(),
    'trailing_whitespace_repairs': 1,
    'namespace_replacements': 7,
    'other_source_changes': 0,
    'source_requests': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(
    json.dumps(value, indent=2, sort_keys=True) + '\n',
    encoding='utf-8',
)
print('frontier_export_reconstruction=pass repairs=1 namespace_replacements=7')
PY

bash -n "$WORK/export.sh"
bash "$WORK/export.sh"

test -d "$OUT"
cp "$WORK/repair.json" "$OUT/REPAIR.json"
cp "$WORK/repaired.yml" "$OUT/REPAIRED-SOURCE-WORKFLOW.yml"
cp "$WORK/export.sh" "$OUT/EXTRACTED-EXPORT-SCRIPT.sh"
(
  cd "$OUT"
  sha256sum REPAIR.json REPAIRED-SOURCE-WORKFLOW.yml \
    EXTRACTED-EXPORT-SCRIPT.sh >> SHA256SUMS
  sha256sum -c SHA256SUMS > FINAL-SHA256-CHECK.log
)
cat "$OUT/canonical.json"
cat "$OUT/REPAIR.json"

