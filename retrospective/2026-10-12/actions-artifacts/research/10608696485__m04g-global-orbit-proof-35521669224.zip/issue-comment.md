<!-- m04g-global-orbit-proof:35521669224 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/35521669224
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `5/10` (`0.5`)
- Content success: `5/10` (`0.5`)
- Metadata only: `0`
- Failed: `5`
- Healthy basins: `0/2`
- Proof SHA-256: `4095dfdd7294561f2fad60562b9e40b52407ec4f9c305d4e14936593e117a123`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
