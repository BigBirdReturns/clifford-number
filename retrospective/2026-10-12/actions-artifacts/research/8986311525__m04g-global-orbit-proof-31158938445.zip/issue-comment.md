<!-- m04g-global-orbit-proof:31158938445 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31158938445
- Head: `34583221f8d2485798fbe308241bf28fefd255ed`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `16/25` (`0.64`)
- Content success: `14/25` (`0.56`)
- Metadata only: `2`
- Failed: `9`
- Healthy basins: `0/5`
- Proof SHA-256: `6f85838680361344ee014bf609fd03ec80808a9e373ef33bb80881eee7fcff9d`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 3 | 3 | 0 | 2 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
