<!-- m04g-global-orbit-proof:35276041997 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/35276041997
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/5` (`0.8`)
- Content success: `4/5` (`0.8`)
- Metadata only: `0`
- Failed: `1`
- Healthy basins: `0/1`
- Proof SHA-256: `ea9fefe1368360879768a8cc19f8194d9d03faea0b5c1ca5a0f7394efb02a348`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
