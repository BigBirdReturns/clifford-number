<!-- m04g-global-orbit-proof:33323144903 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/33323144903
- Head: `0b1d8af5b86adad49b3451053dbb9166294d631c`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/10` (`0.4`)
- Content success: `4/10` (`0.4`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/2`
- Proof SHA-256: `c95ad33eea8d68cc16e045f131318865a115fdd73026dbf7544f66995de78ad5`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
