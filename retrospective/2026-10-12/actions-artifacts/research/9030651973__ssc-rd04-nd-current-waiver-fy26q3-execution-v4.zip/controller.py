#!/usr/bin/env python3
"""Fail-closed controller for the bounded RD-04 FY2026 Q3 PDF capture."""

from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any
import urllib.request
import zipfile

FAIL_SCHEMA = "ssc-rd04-nd-current-waiver-fy26q3-execution@1"
RD04_DELTA_PATTERN = re.compile(
    r"^(?:"
    r"data/intake/status-sovereignty-rd-wave03-rd04|"
    r"schemas/status-sovereignty-rd-wave03-rd04|"
    r"tools/.*status-sovereignty-rd-wave03-rd04|"
    r"test/.*status-sovereignty-rd-wave03-rd04|"
    r"docs/milestones/ssc-rd-wave03-rd04"
    r")"
)


def env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"missing required environment variable: {name}")
    return value


def run(*args: str) -> str:
    return subprocess.check_output(args, text=True).strip()


def git(*args: str) -> str:
    return run("git", *args)


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def github_get(path: str, *, binary: bool = False) -> bytes | dict[str, Any]:
    repository = env("GITHUB_REPOSITORY")
    token = env("GH_TOKEN")
    url = f"https://api.github.com/repos/{repository}{path}"
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "BigBirdReturns-RD04-controller/1.0",
        },
    )
    with urllib.request.urlopen(request, timeout=120) as response:
        payload = response.read()
    if binary:
        return payload
    return json.loads(payload)


def verify_checksum_ledger(root: Path, ledger_name: str = "SHA256SUMS") -> None:
    ledger = root / ledger_name
    if not ledger.is_file():
        raise RuntimeError(f"missing checksum ledger: {ledger}")
    for raw in ledger.read_text(encoding="utf-8").splitlines():
        if not raw.strip():
            continue
        expected, relative = raw.split(maxsplit=1)
        relative = relative.strip()
        if relative.startswith("*"):
            relative = relative[1:]
        if relative.startswith("./"):
            relative = relative[2:]
        target = root / relative
        if not target.is_file():
            raise RuntimeError(f"checksum target absent: {relative}")
        observed = sha256_bytes(target.read_bytes())
        if observed != expected:
            raise RuntimeError(f"checksum mismatch: {relative}")


def write_output_checksums(out: Path) -> None:
    rows: list[str] = []
    for path in sorted(p for p in out.rglob("*") if p.is_file()):
        if path.name == "SHA256SUMS":
            continue
        rows.append(f"{sha256_bytes(path.read_bytes())}  {path.relative_to(out).as_posix()}")
    (out / "SHA256SUMS").write_text("\n".join(rows) + "\n", encoding="utf-8")


def failure_receipt(stage: str, code: int) -> dict[str, Any]:
    return {
        "schema_version": FAIL_SCHEMA,
        "state": "failed_closed",
        "failed_or_final_stage": stage,
        "exit_code": code,
        "execution_parent": env("CURRENT_MAIN"),
        "fixed_route_ids": [env("ROUTE_ID")],
        "fixed_route_count": 1,
        "terminal_route_count": 0,
        "physical_requests": 0,
        "source_admissions": 0,
        "field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "additional_execution_authorized": False,
    }


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: rd04_fy26q3_controller_v4.py OUTPUT_DIR")

    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    adjudication_root = out / "adjudication"
    adjudication_root.mkdir(exist_ok=True)
    stage = "bootstrap"

    def set_stage(value: str) -> None:
        nonlocal stage
        stage = value
        (out / "STAGE").write_text(value + "\n", encoding="utf-8")

    try:
        current_main = env("CURRENT_MAIN")
        adjudication_parent = env("ADJUDICATION_PARENT")
        workflow_path = env("EXECUTION_WORKFLOW_PATH")
        trigger_path = env("EXECUTION_TRIGGER_PATH")
        matrix_path = env("MATRIX_PATH")
        matrix_blob = env("MATRIX_BLOB")

        set_stage("bind_execution_topology")
        head = git("rev-parse", "HEAD")
        base = git("rev-parse", "HEAD^")
        if git("rev-parse", f"{base}^") != current_main:
            raise RuntimeError("base parent is not current main")
        if int(git("rev-list", "--count", f"{current_main}..{base}")) != 1:
            raise RuntimeError("base commit denominator mismatch")
        if int(git("rev-list", "--count", f"{base}..{head}")) != 1:
            raise RuntimeError("trigger commit denominator mismatch")
        if git("diff", "--name-only", current_main, base) != workflow_path:
            raise RuntimeError("workflow path denominator mismatch")
        if git("diff", "--name-only", "--diff-filter=A", current_main, base) != workflow_path:
            raise RuntimeError("workflow is not addition-only")
        if git("diff", "--name-only", base, head) != trigger_path:
            raise RuntimeError("trigger path denominator mismatch")
        if git("diff", "--name-only", "--diff-filter=A", base, head) != trigger_path:
            raise RuntimeError("trigger is not addition-only")
        subprocess.run(["git", "diff", "--check", current_main, head], check=True)
        (out / "execution-base-commit.txt").write_text(base + "\n")
        (out / "execution-trigger-head.txt").write_text(head + "\n")

        set_stage("bind_live_main_and_current_matrix")
        subprocess.run(
            [
                "git",
                "fetch",
                "--no-tags",
                "--force",
                "origin",
                "+refs/heads/main:refs/remotes/origin/main",
            ],
            check=True,
        )
        if git("rev-parse", "origin/main") != current_main:
            raise RuntimeError("origin/main moved")
        remote_main = git("ls-remote", "--heads", "origin", "refs/heads/main").split()[0]
        if remote_main != current_main:
            raise RuntimeError("live main lease changed")
        subprocess.run(
            ["git", "merge-base", "--is-ancestor", adjudication_parent, current_main],
            check=True,
        )
        if git("rev-parse", f"HEAD:{matrix_path}") != matrix_blob:
            raise RuntimeError("current matrix blob mismatch")
        delta = git("diff", "--name-only", adjudication_parent, current_main).splitlines()
        (out / "main-delta.txt").write_text("\n".join(sorted(delta)) + "\n")
        overlap = sorted(path for path in delta if RD04_DELTA_PATTERN.search(path))
        write_json(out / "rd04-delta-overlap.json", overlap)
        if overlap:
            raise RuntimeError("intervening main delta touches RD-04 paths")
        (out / "current-main-tree.txt").write_text(
            git("rev-parse", f"{current_main}^{{tree}}") + "\n"
        )

        set_stage("reconstruct_immutable_executor")
        executor_path = out / "executor.py"
        blob_ids = env("EXECUTOR_BLOBS").split()
        chunks: list[bytes] = []
        inventory: list[dict[str, Any]] = []
        for blob_id in blob_ids:
            payload = github_get(f"/git/blobs/{blob_id}")
            if not isinstance(payload, dict):
                raise RuntimeError("unexpected blob response")
            if payload.get("sha") != blob_id or payload.get("encoding") != "base64":
                raise RuntimeError(f"blob identity mismatch: {blob_id}")
            chunk = base64.b64decode(str(payload["content"]).replace("\n", ""), validate=True)
            chunks.append(chunk)
            inventory.append(
                {
                    "sha": blob_id,
                    "bytes": len(chunk),
                    "sha256": sha256_bytes(chunk),
                }
            )
        executor = b"".join(chunks)
        if len(executor) != int(env("EXECUTOR_BYTES")):
            raise RuntimeError("executor byte denominator mismatch")
        if sha256_bytes(executor) != env("EXECUTOR_SHA256"):
            raise RuntimeError("executor digest mismatch")
        executor_path.write_bytes(executor)
        write_json(out / "executor-blob-inventory.json", inventory)
        subprocess.run([sys.executable, "-m", "py_compile", str(executor_path)], check=True)

        set_stage("authenticate_adjudication_artifact")
        artifact_id = int(env("ADJUDICATION_ARTIFACT_ID"))
        artifact_bytes = int(env("ADJUDICATION_ARTIFACT_BYTES"))
        artifact_digest = env("ADJUDICATION_ARTIFACT_DIGEST")
        metadata = github_get(f"/actions/artifacts/{artifact_id}")
        if not isinstance(metadata, dict):
            raise RuntimeError("unexpected artifact metadata")
        if (
            metadata.get("id") != artifact_id
            or metadata.get("size_in_bytes") != artifact_bytes
            or metadata.get("digest") != artifact_digest
            or metadata.get("expired") is not False
        ):
            raise RuntimeError("adjudication artifact metadata mismatch")
        write_json(out / "adjudication-artifact.json", metadata)
        artifact_zip = github_get(f"/actions/artifacts/{artifact_id}/zip", binary=True)
        if not isinstance(artifact_zip, bytes):
            raise RuntimeError("unexpected artifact ZIP response")
        if len(artifact_zip) != artifact_bytes:
            raise RuntimeError("adjudication artifact byte mismatch")
        if f"sha256:{sha256_bytes(artifact_zip)}" != artifact_digest:
            raise RuntimeError("adjudication artifact digest mismatch")
        zip_path = out / "adjudication.zip"
        zip_path.write_bytes(artifact_zip)
        with zipfile.ZipFile(zip_path) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise RuntimeError(f"corrupt adjudication ZIP member: {bad}")
            archive.extractall(adjudication_root)
        verify_checksum_ledger(adjudication_root)

        receipt_path = adjudication_root / "receipt.json"
        protocol_path = adjudication_root / "selected-followup-protocol.json"
        if sha256_bytes(receipt_path.read_bytes()) != env("ADJUDICATION_RECEIPT_SHA256"):
            raise RuntimeError("adjudication receipt digest mismatch")
        if sha256_bytes(protocol_path.read_bytes()) != env("FOLLOWUP_PROTOCOL_SHA256"):
            raise RuntimeError("follow-up protocol digest mismatch")
        receipt = json.loads(receipt_path.read_text())
        protocol = json.loads(protocol_path.read_text())
        if not (
            receipt.get("schema_version")
            == "ssc-rd04-nd-current-waiver-fna-adjudication@1"
            and receipt.get("state") == "complete"
            and receipt.get("failed_or_final_stage") == "complete"
            and receipt.get("exit_code") == 0
            and receipt.get("canonical_parent") == adjudication_parent
            and receipt.get("promotion_candidates") == 0
            and receipt.get("held_open_fields") == 1
            and receipt.get("selected_followup_routes") == 1
            and receipt.get("field_terminalizations") == 0
            and receipt.get("matrix_updates") == 0
            and receipt.get("row_state_mutations") == 0
            and receipt.get("class_closed") is False
        ):
            raise RuntimeError("adjudication receipt contract mismatch")
        routes = protocol.get("routes")
        if not (
            protocol.get("schema_version")
            == "ssc-rd04-nd-current-waiver-fy26q3-followup-protocol@1"
            and protocol.get("route_count") == 1
            and protocol.get("source_requests_executed_here") == 0
            and protocol.get("result_spawned_requests") == 0
            and protocol.get("same_host_expansion") == 0
            and isinstance(routes, list)
            and len(routes) == 1
            and routes[0].get("route_id") == env("ROUTE_ID")
            and routes[0].get("url") == env("ROUTE_URL")
            and routes[0].get("attempts") == 1
            and routes[0].get("redirects") == "manual_same_host_only"
            and routes[0].get("maximum_body_bytes") == 12_000_000
            and routes[0].get("expected_content_family") == "application/pdf"
        ):
            raise RuntimeError("follow-up protocol contract mismatch")

        set_stage("execute_exact_pdf_route")
        subprocess.run([sys.executable, str(executor_path), str(out)], check=True)

        set_stage("reconfirm_live_main")
        remote_main = git("ls-remote", "--heads", "origin", "refs/heads/main").split()[0]
        if remote_main != current_main:
            raise RuntimeError("live main changed after transport")

        set_stage("complete")
        (out / "EXIT_CODE").write_text("0\n")
        write_output_checksums(out)
        return 0
    except Exception as exc:
        write_json(
            out / "controller-error.json",
            {"stage": stage, "error_type": type(exc).__name__, "error": str(exc)},
        )
        receipt_path = out / "execution-receipt.json"
        if not receipt_path.is_file():
            write_json(receipt_path, failure_receipt(stage, 1))
        (out / "EXIT_CODE").write_text("1\n")
        (out / "STAGE").write_text(stage + "\n")
        write_output_checksums(out)
        print(f"controller failed closed at {stage}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
