# RD-04 next minimum frontier survey

```text
canonical RD-04 merge: a464dbbd96c365a7c040e17847486c5b3ba05c27
live main at survey: 1db9ac3c7ee9ffa07c06e029008d23f1f5ba7b5a
open substantive cells: 192
open state rows: 40
minimum cells per row: 4
selected states: US-STATE-FL US-STATE-MT US-STATE-ND US-STATE-OR US-STATE-WI
selected fields: abawd_or_work_requirement_waiver_state_and_governing_period implementation_effective_date_or_typed_gap operative_state_implementation_authority_and_version verification_evidence_and_staff_discretion_surface
selected substantive cells: 20
```

This survey executed no source route and changed no evidentiary or cumulative state.
