from __future__ import annotations
import copy, hashlib, json, os, pathlib, re, shutil, subprocess, sys, tarfile, base64, lzma

REPO=pathlib.Path.cwd()
CANONICAL_PARENT='283c5993cb2ac0bff173c72aba70088c67b2ac3c'
CANONICAL_PARENT_TREE='80a04c3d6a59816e9f7c99e585e077c92df42dbd'
OLD_COMMIT='d7530b8a8eb33c41458fa1ae986b9dacbb2c46a7'
OLD_SOURCE_PATH='.tmp/rd04-nd-row-state-reconciliation-materializer-v1/source.tar.xz.b64'
OLD_WORKFLOW_PATH='.tmp/rd04-nd-row-state-reconciliation-materializer-v1/standing-workflow.yml'
STAGING_BRANCH='staging/ssc-rd04-nd-current-public-record-gap-row-state-reconciliation-v1'
CARRIER_WORKFLOW_PATH='.tmp/rd04-nd-row-state-final-materializer-v1/permanent-workflow.yml'
OUTDIR=pathlib.Path('/tmp/rd04-nd-row-state-final-materializer-v1')
WORKTREE=pathlib.Path('/tmp/rd04-nd-row-state-final-worktree')
ROOT='data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation'


def run(args, *, cwd=REPO, check=True, text=True):
    p=subprocess.run(args,cwd=cwd,text=text,capture_output=True)
    if check and p.returncode:
        raise RuntimeError(f"{args!r} exited {p.returncode}: {(p.stdout or '')[-3000:]}{(p.stderr or '')[-3000:]}")
    return p

def git_show(spec):
    return subprocess.check_output(['git','show',spec],cwd=REPO)

def sha_bytes(b): return hashlib.sha256(b).hexdigest()

def blob_bytes(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

# Bind exact carrier and live canonical state.
event_base=os.environ['EVENT_BASE_SHA']; event_head=os.environ['EVENT_HEAD_SHA']
assert run(['git','rev-parse','HEAD']).stdout.strip()==event_head
assert event_base==os.environ['CARRIER_BASE_SHA']
run(['git','fetch','--no-tags','--force','origin','+refs/heads/main:refs/remotes/origin/main'])
assert run(['git','rev-parse','origin/main']).stdout.strip()==CANONICAL_PARENT
assert run(['git','rev-parse',f'{CANONICAL_PARENT}^{{tree}}']).stdout.strip()==CANONICAL_PARENT_TREE
# Refuse an existing output branch.
remote=run(['git','ls-remote','--heads','origin',f'refs/heads/{STAGING_BRANCH}']).stdout.strip()
assert remote==''

# Recover the exact authored eight-file source package and standing workflow.
source_b64=git_show(f'{OLD_COMMIT}:{OLD_SOURCE_PATH}')
assert len(source_b64)==19804 and sha_bytes(source_b64)== 'ae8be1ee9f30575cdbc5d31bcad3a9d4238b23e85c5ad1c6125ad6f184883642'
source_xz=base64.b64decode(source_b64)
assert len(source_xz)==14852 and sha_bytes(source_xz)=='4a735e9bc51ce471e39bfb3ded66f410735fe16b31123d7d5bdd80163fa01865'
source_tar=lzma.decompress(source_xz)
assert len(source_tar)==92160 and sha_bytes(source_tar)=='9b1ccf3e4799011ae968cbf4f5eb9e2118e5de254bfd2c80907930fd47f8bb87'
workflow=git_show(f'{OLD_COMMIT}:{OLD_WORKFLOW_PATH}')
assert len(workflow)==7747 and sha_bytes(workflow)=='25da2b10c5df34e508227a5b20cbde3515191c089de90a47506c77e4fc1eae40'

if WORKTREE.exists(): shutil.rmtree(WORKTREE)
run(['git','worktree','add','--detach',str(WORKTREE),CANONICAL_PARENT])
expected_template=[
'data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/input-custody.json',
'data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/row-state-decision.json',
'data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation/product-manifest.json',
'docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md',
'schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json',
'test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js',
'tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs',
'tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs']
import io
with tarfile.open(fileobj=io.BytesIO(source_tar),mode='r:') as tf:
    members=tf.getmembers(); names=[m.name for m in members]
    assert names==expected_template
    for m in members:
        assert m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts
    tf.extractall(WORKTREE,filter='data')
wf=WORKTREE/'.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml'
wf.parent.mkdir(parents=True,exist_ok=True); wf.write_bytes(workflow)
# The predecessor and V3 validation products are already canonical in this worktree.
OUT=WORKTREE
MATRIX_SRC=WORKTREE/'data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-current-public-record-gap-promotion/promoted-partial-field-matrix.json'
root=OUT/ROOT
PARENT='283c5993cb2ac0bff173c72aba70088c67b2ac3c'; PTREE='80a04c3d6a59816e9f7c99e585e077c92df42dbd'
VPRODUCT='0de57f1d6d395e28e495b456794fe92b681a35c6'; VTREE='fef73cc4267070c8cc7fb7c1dc15481477391d62'; VMERGE='789c800d00a6d4924cb69d2ce33d336ab315972f'
VPR=1798; VRUN=31357895694; VAID=9051293563; VABYTES=8908; VASHA='90cdfa87640ce7a6ebb9d6d381a4aa97f46f16455fa470bc59fff282e282124d'; VRECEIPT='8f1b31c8b8d8e664c9b25f128d2bc31a85ee08ea7b9c8ea3f4217805f2b54ab7'
PROPOSED='f0c6fe75d1720c1a6cf8b90fd44b96bc96fcb0656fc70808c5439d514d30217c'; ROW_AFTER='f75ac04e5c8fc53304e897d918ee80057c580e2b8bbeeca979e9f92312f96f4b'
SEM_SHA='6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c'; SEM_BLOB='8efadaa94bc9de68b4d90d471051d613ad0ce32e'; SEM_BYTES=498054
FINAL_SHA='9f9dc05a057396056771bb566c44e9c3779d8ef6b0d2c078f7ffff11d9c7e6cb'; FINAL_BLOB='6ba11a6025021e9df8ac6535be8c42499654c233'; FINAL_BYTES=499923
UNCHANGED='93dd5ec59cbde9943931358aecc87b2d2cef918ba1f04a2c40d43574017c1dd4'
CANDIDATE_ID='RD04-ND-EXACT-CURRENT-ROW-STATE-RECONCILIATION-CANDIDATE-V3'

# Update input custody and decision.
inp=json.loads((root/'input-custody.json').read_text())
inp['schema_version']='ssc-rd04-nd-row-state-reconciliation-input-custody@2'
inp['canonical_parent']=PARENT; inp['canonical_parent_tree']=PTREE
pv=inp['prior_candidate_validation']; pv.clear(); pv.update({
 'pull_request':VPR,'product_commit':VPRODUCT,'product_tree':VTREE,'merge_commit':VMERGE,'workflow_run':VRUN,
 'artifact_id':VAID,'artifact_bytes':VABYTES,'artifact_zip_sha256':VASHA,'validation_receipt_sha256':VRECEIPT,
 'row_candidate_id':CANDIDATE_ID,'row_candidate_sha256':PROPOSED,
 'projection_integrity_state':'repaired_counts_and_current_result_match',
 'corrected_semantic_projection_bytes':SEM_BYTES,'corrected_semantic_projection_sha256':SEM_SHA,'corrected_semantic_projection_git_blob':SEM_BLOB,
 'current_rebind':{'substantive_prerequisite_applied':True,'canonical_target_cell_sha256':'8700619932bd128250a308d5dcd7b1586a363ae3b78e4eb80c23bfb72c8a2e25','substantive_cell_reapplication_authorized':False,'row_candidate_semantics_retained':True,'successor_projection':'one_derivative_row_state_cell_only'}
})
inp['projection'].update({'proposed_row_state_cell_sha256':PROPOSED,'reconciled_row_sha256':ROW_AFTER,'promoted_matrix_bytes':FINAL_BYTES,'promoted_matrix_sha256':FINAL_SHA,'promoted_matrix_git_blob':FINAL_BLOB})
(root/'input-custody.json').write_text(json.dumps(inp,indent=2)+'\n')

dec=json.loads((root/'row-state-decision.json').read_text())
dec['schema_version']='ssc-rd04-nd-row-state-reconciliation-decision@2'
dec['candidate_id']=CANDIDATE_ID; dec['reconciled_row_sha256']=ROW_AFTER; dec['proposed_cell_sha256']=PROPOSED
dec['prerequisite_satisfaction']={'required_terminal_evidence_fields':8,'observed_terminal_evidence_fields':8,'all_eight_terminal':True,'substantive_prerequisite_applied':True,'substantive_cell_reapplication_authorized':False,'validation_repair_product_commit':VPRODUCT,'validation_repair_merge_commit':VMERGE,'validation_receipt_sha256':VRECEIPT,'corrected_semantic_projection_sha256':SEM_SHA}
# exact proposed cell from V3 validation
v3=json.loads((OUT/'data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation-validation-v3/row-state-validation.json').read_text())
dec['proposed_row_state_cell']=v3['proposed_row_state_cell']
(root/'row-state-decision.json').write_text(json.dumps(dec,indent=2)+'\n')

# Exact identities of authored inputs.
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
ib=(root/'input-custody.json').read_bytes(); db=(root/'row-state-decision.json').read_bytes()

builder=OUT/'tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs'
s=builder.read_text()
repls={
 "INPUT_BYTES: 5918":"INPUT_BYTES: %d"%len(ib), "INPUT_SHA: '3484f9e4280c4431ed27a45e15cb3d72ce0208001adf78e0ab246d8331ecb923'":f"INPUT_SHA: '{sha(ib)}'", "INPUT_BLOB: '40bd862c162680533d632ebb04852494ed7d5743'":f"INPUT_BLOB: '{blob(ib)}'",
 "DECISION_BYTES: 5207":"DECISION_BYTES: %d"%len(db), "DECISION_SHA: '10bbdc50b3d8740459b9558ba8374df4647612cd72f6cfe5ad5ca7e311744a11'":f"DECISION_SHA: '{sha(db)}'", "DECISION_BLOB: '7575b2d54569dd5b2ceb896d1acabc9d471343bc'":f"DECISION_BLOB: '{blob(db)}'",
 "CANONICAL_PARENT: '4eaa66d7a0f025e0c4ec797e9925634a22d9e49e'":f"CANONICAL_PARENT: '{PARENT}'", "CANONICAL_PARENT_TREE: '51c46f38071f7f5193ab7856a193095a86389356'":f"CANONICAL_PARENT_TREE: '{PTREE}'",
 "PROPOSED_ROW_STATE_SHA: '8107bfa8bcc247bfb02a8207d644c216e925ab89319ffce57b403f0e138c2139'":f"PROPOSED_ROW_STATE_SHA: '{PROPOSED}'", "RECONCILED_ND_ROW_SHA: 'cbbd017c2eeb9ce10e1df8c372f095c3a1382387d5184225c1a566465e9dcd07'":f"RECONCILED_ND_ROW_SHA: '{ROW_AFTER}'",
 "PROMOTED_MATRIX_BYTES: 499646":f"PROMOTED_MATRIX_BYTES: {FINAL_BYTES}", "PROMOTED_MATRIX_SHA: '54435248dcc17d4fa225868156a55f9d4c77fc2d6c9e9955366f1ed6253e464c'":f"PROMOTED_MATRIX_SHA: '{FINAL_SHA}'", "PROMOTED_MATRIX_BLOB: '5738d59c2f578dc3b18c31f36d16b323d817a637'":f"PROMOTED_MATRIX_BLOB: '{FINAL_BLOB}'", "UNCHANGED_ROWS_SHA: '93dd5ec59cbde9943931358aecc87b2d2cef918ba1f04a2c40d43574017c1dd4'":f"UNCHANGED_ROWS_SHA: '{UNCHANGED}'",
 "PRIOR_VALIDATION_PR: 1746":f"PRIOR_VALIDATION_PR: {VPR}", "PRIOR_VALIDATION_RUN: 31333605296":f"PRIOR_VALIDATION_RUN: {VRUN}", "PRIOR_VALIDATION_ARTIFACT_ID: 9043612271":f"PRIOR_VALIDATION_ARTIFACT_ID: {VAID}", "PRIOR_VALIDATION_ARTIFACT_BYTES: 9104":f"PRIOR_VALIDATION_ARTIFACT_BYTES: {VABYTES}", "PRIOR_VALIDATION_ARTIFACT_SHA: '7c4bf8442b79e4721d2170216df59ce6a697357339403f40062e5e709121ccf5'":f"PRIOR_VALIDATION_ARTIFACT_SHA: '{VASHA}'", "PRIOR_VALIDATION_RECEIPT_SHA: '9bac2c230df607228a3a7b0b6314370a9a0e89274d72a2ed879f1f6a75121261'":f"PRIOR_VALIDATION_RECEIPT_SHA: '{VRECEIPT}'", "PRIOR_ROW_CANDIDATE_ID: 'RD04-ND-FY2026-FIXED-PROTOCOL-ROW-STATE-CANDIDATE-V2'":f"PRIOR_ROW_CANDIDATE_ID: '{CANDIDATE_ID}'", "PRIOR_ROW_CANDIDATE_SHA: '02f9fceaec25649f4a160fa97ccf8e328274413fd43fde1fe1465fe5d50fd69f'":f"PRIOR_ROW_CANDIDATE_SHA: '{PROPOSED}'",
 "input.schema_version === 'ssc-rd04-nd-row-state-reconciliation-input-custody@1'":"input.schema_version === 'ssc-rd04-nd-row-state-reconciliation-input-custody@2'", "decision.schema_version === 'ssc-rd04-nd-row-state-reconciliation-decision@1'":"decision.schema_version === 'ssc-rd04-nd-row-state-reconciliation-decision@2'",
 "assert(decision.candidate_id === 'RD04-ND-EXACT-CURRENT-ROW-STATE-RECONCILIATION-CANDIDATE-V1', 'candidate id mismatch');":"assert(decision.candidate_id === C.PRIOR_ROW_CANDIDATE_ID, 'candidate id mismatch');",
 "promoted.schema_version='ssc-rd04-wave03-postpromotion-nd-row-state-reconciled-partial-field-matrix@1'":"promoted.schema_version='ssc-rd04-wave03-postpromotion-nd-row-state-reconciled-partial-field-matrix@2'",
 "promoted.counts.postpromotion_nd_row_state_reconciliation_candidate_cells=1;":"promoted.counts.postpromotion_nd_current_public_record_gap_row_state_candidate_cells=1;",
 "promoted.counts.newly_terminalized_postpromotion_nd_row_state_reconciliation_cells=1;":"promoted.counts.newly_terminalized_postpromotion_nd_current_public_record_gap_row_state_cells=1;",
 "promoted.postpromotion_nd_row_state_reconciliation_product={":"promoted.postpromotion_nd_current_public_record_gap_row_state_reconciliation_product={",
}
for a,b in repls.items():
 if a not in s: print('MISSING REPL',a,file=sys.stderr); sys.exit(2)
 s=s.replace(a,b)
# Replace prior-validation checks and metadata object body more directly.
s=re.sub(r"const prior = input\.prior_candidate_validation;.*?assert\(prior\.row_candidate_id === C\.PRIOR_ROW_CANDIDATE_ID && prior\.row_candidate_sha256 === C\.PRIOR_ROW_CANDIDATE_SHA, 'prior row candidate mismatch'\);", "const prior = input.prior_candidate_validation;\n  assert(prior.pull_request === C.PRIOR_VALIDATION_PR && prior.product_commit === '0de57f1d6d395e28e495b456794fe92b681a35c6' && prior.product_tree === 'fef73cc4267070c8cc7fb7c1dc15481477391d62' && prior.merge_commit === '789c800d00a6d4924cb69d2ce33d336ab315972f', 'prior validation venue mismatch');\n  assert(prior.workflow_run === C.PRIOR_VALIDATION_RUN && prior.artifact_id === C.PRIOR_VALIDATION_ARTIFACT_ID && prior.artifact_bytes === C.PRIOR_VALIDATION_ARTIFACT_BYTES && prior.artifact_zip_sha256 === C.PRIOR_VALIDATION_ARTIFACT_SHA, 'prior validation artifact mismatch');\n  assert(prior.validation_receipt_sha256 === C.PRIOR_VALIDATION_RECEIPT_SHA && prior.row_candidate_id === C.PRIOR_ROW_CANDIDATE_ID && prior.row_candidate_sha256 === C.PRIOR_ROW_CANDIDATE_SHA, 'prior validation candidate mismatch');\n  assert(prior.projection_integrity_state === 'repaired_counts_and_current_result_match' && prior.corrected_semantic_projection_bytes === 498054 && prior.corrected_semantic_projection_sha256 === '6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c' && prior.corrected_semantic_projection_git_blob === '8efadaa94bc9de68b4d90d471051d613ad0ce32e', 'projection repair custody mismatch');", s, flags=re.S)
# prerequisite checks now use validation-repair keys
s=s.replace("assert(decision.prerequisite_satisfaction.all_eight_terminal === true && decision.prerequisite_satisfaction.observed_terminal_evidence_fields === 8, 'decision prerequisite count mismatch');\n  assert(decision.prerequisite_satisfaction.substantive_prerequisite_applied === true && decision.prerequisite_satisfaction.substantive_cell_reapplication_authorized === false, 'decision prerequisite authority widened');", "assert(decision.prerequisite_satisfaction.all_eight_terminal === true && decision.prerequisite_satisfaction.observed_terminal_evidence_fields === 8, 'decision prerequisite count mismatch');\n  assert(decision.prerequisite_satisfaction.substantive_prerequisite_applied === true && decision.prerequisite_satisfaction.substantive_cell_reapplication_authorized === false, 'decision prerequisite authority widened');\n  assert(decision.prerequisite_satisfaction.validation_repair_product_commit === '0de57f1d6d395e28e495b456794fe92b681a35c6' && decision.prerequisite_satisfaction.validation_repair_merge_commit === '789c800d00a6d4924cb69d2ce33d336ab315972f' && decision.prerequisite_satisfaction.validation_receipt_sha256 === C.PRIOR_VALIDATION_RECEIPT_SHA && decision.prerequisite_satisfaction.corrected_semantic_projection_sha256 === '6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c', 'decision validation repair custody mismatch');")
# old key set accepts same outer keys; prerequisite nested is not closed.
# Replace product metadata object exactly.
pattern=r"promoted\.postpromotion_nd_current_public_record_gap_row_state_reconciliation_product=\{.*?\n  \};"
replacement="""promoted.postpromotion_nd_current_public_record_gap_row_state_reconciliation_product={
    predecessor_matrix_path:C.PREDECESSOR_MATRIX_PATH,predecessor_matrix_bytes:C.PREDECESSOR_MATRIX_BYTES,
    predecessor_matrix_sha256:C.PREDECESSOR_MATRIX_SHA,predecessor_matrix_git_blob:C.PREDECESSOR_MATRIX_BLOB,
    validation_repair_product_commit:'0de57f1d6d395e28e495b456794fe92b681a35c6',validation_repair_product_tree:'fef73cc4267070c8cc7fb7c1dc15481477391d62',validation_repair_merge_commit:'789c800d00a6d4924cb69d2ce33d336ab315972f',
    validation_artifact_id:C.PRIOR_VALIDATION_ARTIFACT_ID,validation_artifact_bytes:C.PRIOR_VALIDATION_ARTIFACT_BYTES,
    validation_artifact_zip_sha256:C.PRIOR_VALIDATION_ARTIFACT_SHA,validation_receipt_sha256:C.PRIOR_VALIDATION_RECEIPT_SHA,
    canonical_parent:C.CANONICAL_PARENT,canonical_parent_tree:C.CANONICAL_PARENT_TREE,
    current_north_dakota_row_sha256:C.CURRENT_ND_ROW_SHA,current_row_state_cell_sha256:C.CURRENT_ROW_STATE_SHA,
    proposed_row_state_cell_sha256:C.PROPOSED_ROW_STATE_SHA,reconciled_north_dakota_row_sha256:C.RECONCILED_ND_ROW_SHA,
    corrected_semantic_projection_sha256:'6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c',
    composition_rule:'delete_only_postpromotion_nd_current_public_record_gap_row_state_reconciliation_product_then_require_byte_identity_with_corrected_semantic_projection',
  };"""
s,n=re.subn(pattern,replacement,s,flags=re.S)
if n!=1: raise SystemExit(f'metadata replace count {n}')
# Insert normalized semantic projection assertion before final matrix identity.
needle="  const promotedBytes=jsonBytes(promoted);\n  assert(promotedBytes.length===C.PROMOTED_MATRIX_BYTES"
insert="""  const normalized=structuredClone(promoted); delete normalized.postpromotion_nd_current_public_record_gap_row_state_reconciliation_product;
  const normalizedBytes=jsonBytes(normalized);
  assert(normalizedBytes.length===498054&&sha(normalizedBytes)==='6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c'&&gitBlob(normalizedBytes)==='8efadaa94bc9de68b4d90d471051d613ad0ce32e','corrected semantic projection mismatch');
  const promotedBytes=jsonBytes(promoted);
  assert(promotedBytes.length===C.PROMOTED_MATRIX_BYTES"""
if needle not in s: raise SystemExit('normalization insertion missing')
s=s.replace(needle,insert)
builder.write_text(s)

# Global exact identity replacements in the supporting product files.
files=[wf,OUT/'docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md',OUT/'schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json',OUT/'test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js',OUT/'tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs']
subs={
 '4eaa66d7a0f025e0c4ec797e9925634a22d9e49e':PARENT,'51c46f38071f7f5193ab7856a193095a86389356':PTREE,
 '8107bfa8bcc247bfb02a8207d644c216e925ab89319ffce57b403f0e138c2139':PROPOSED,'cbbd017c2eeb9ce10e1df8c372f095c3a1382387d5184225c1a566465e9dcd07':ROW_AFTER,
 '54435248dcc17d4fa225868156a55f9d4c77fc2d6c9e9955366f1ed6253e464c':FINAL_SHA,'5738d59c2f578dc3b18c31f36d16b323d817a637':FINAL_BLOB,'499646':str(FINAL_BYTES),
 '93dd5ec59cbde9943931358aecc87b2d2cef918ba1f04a2c40d43574017c1dd4':UNCHANGED,
 '1746':str(VPR),'31333605296':str(VRUN),'9043612271':str(VAID),'9104':str(VABYTES),'7c4bf8442b79e4721d2170216df59ce6a697357339403f40062e5e709121ccf5':VASHA,'9bac2c230df607228a3a7b0b6314370a9a0e89274d72a2ed879f1f6a75121261':VRECEIPT,
 'RD04-ND-FY2026-FIXED-PROTOCOL-ROW-STATE-CANDIDATE-V2':CANDIDATE_ID,'02f9fceaec25649f4a160fa97ccf8e328274413fd43fde1fe1465fe5d50fd69f':PROPOSED,
 'postpromotion_nd_row_state_reconciliation_product':'postpromotion_nd_current_public_record_gap_row_state_reconciliation_product',
 'postpromotion_nd_row_state_reconciliation_candidate_cells':'postpromotion_nd_current_public_record_gap_row_state_candidate_cells',
 'newly_terminalized_postpromotion_nd_row_state_reconciliation_cells':'newly_terminalized_postpromotion_nd_current_public_record_gap_row_state_cells',
 'ssc-rd04-wave03-postpromotion-nd-row-state-reconciled-partial-field-matrix@1':'ssc-rd04-wave03-postpromotion-nd-row-state-reconciled-partial-field-matrix@2',
}
for f in files:
 t=f.read_text()
 for a,b in subs.items(): t=t.replace(a,b)
 f.write_text(t)
# Workflow artifact name V2 and canonical parent already replaced; make name explicit.
wt=wf.read_text().replace('ssc-rd04-nd-row-state-reconciliation-v1','ssc-rd04-nd-current-public-record-gap-row-state-reconciliation-v2')
wf.write_text(wt)
# Docs clarify projection repair.
doc=OUT/'docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md'
doc.write_text(doc.read_text()+f"\nThe canonical projection-integrity repair is merge `{PARENT}`. The final matrix normalizes to semantic projection `{SEM_SHA}` after deleting its sole product metadata object.\n")
# Schema consts: update input/decision versions and final matrix metadata key if present.
sch=OUT/'schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json'
t=sch.read_text().replace('ssc-rd04-nd-row-state-reconciliation-input-custody@1','ssc-rd04-nd-row-state-reconciliation-input-custody@2').replace('ssc-rd04-nd-row-state-reconciliation-decision@1','ssc-rd04-nd-row-state-reconciliation-decision@2')
sch.write_text(t)
# Builder may still mention old proposed product metadata key in tests/strings; prohibit any stale critical identity.
for old in ['4eaa66d7a0f025e0c4ec797e9925634a22d9e49e','8107bfa8bcc247bfb02a8207d644c216e925ab89319ffce57b403f0e138c2139','cbbd017c2eeb9ce10e1df8c372f095c3a1382387d5184225c1a566465e9dcd07','54435248dcc17d4fa225868156a55f9d4c77fc2d6c9e9955366f1ed6253e464c','5738d59c2f578dc3b18c31f36d16b323d817a637','9f85cbff7eba6d66f84508d262c408d580e1d55e95568d3265f10d1c1fa416ad']:
 hits=[]
 for f in OUT.rglob('*'):
  if f.is_file() and f.suffix not in {'.pyc'}:
   try: txt=f.read_text()
   except: continue
   if old in txt: hits.append(str(f.relative_to(OUT)))
 if hits: print('STALE',old,hits,file=sys.stderr)

# Generate derived files using the patched builder.
subprocess.run(['node',str(builder.relative_to(OUT)),'--out',str(root)],cwd=OUT,check=True)
# Generated matrix must be exact.
mat=(root/'promoted-partial-field-matrix.json').read_bytes()
assert len(mat)==FINAL_BYTES and sha(mat)==FINAL_SHA and blob(mat)==FINAL_BLOB
x=json.loads(mat); meta=x.pop('postpromotion_nd_current_public_record_gap_row_state_reconciliation_product')
norm=(json.dumps(x,indent=2,ensure_ascii=False)+'\n').encode(); assert len(norm)==SEM_BYTES and sha(norm)==SEM_SHA and blob(norm)==SEM_BLOB

# Regenerate self-describing manifest after every non-manifest file is final.
paths=[
 '.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml',
 f'{ROOT}/input-custody.json',f'{ROOT}/row-state-decision.json',f'{ROOT}/row-state-ledger.json',f'{ROOT}/promoted-partial-field-matrix.json',f'{ROOT}/remaining-open-field-census.json',f'{ROOT}/row-state-summary.json',f'{ROOT}/index.json',f'{ROOT}/product-manifest.json',
 'docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md','schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json','test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js','tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs','tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs']
hashed=[p for p in paths if not p.endswith('/product-manifest.json')]
rows=[]
for p in hashed:
 b=(OUT/p).read_bytes(); rows.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
combined=sha(''.join(sorted(f"{r['path']}\0{r['sha256']}\0{r['bytes']}\n" for r in rows)).encode())
manifest={'schema_version':'ssc-rd04-nd-row-state-reconciliation-manifest@2','permanent_path_count':14,'hashed_file_count':13,'permanent_paths':paths,'hashed_files':rows,'combined_sha256':combined,'authority_boundary':{'source_requests':0,'route_executions':0,'source_admissions':0,'field_terminalizations':0,'matrix_updates':1,'row_state_mutations':1,'row_terminalizations':1,'class_closed':False,'cumulative_ledger_effect':'none','publication_effect':'none','adoption_effect':'none','graph_effect':'none','outside_human_dependency':False}}
(root/'product-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Patch validator expected manifest schema.
val=OUT/'tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs'
t=val.read_text().replace("m.manifest.schema_version==='ssc-rd04-nd-row-state-reconciliation-manifest@1'","m.manifest.schema_version==='ssc-rd04-nd-row-state-reconciliation-manifest@2'")
# Add normalization contract assertion.
needle="  assert(m.matrix.counts.class_closed===false&&m.matrix.current_result.class_closed===false,'class closure widened');"
addition=needle+"\n  const normalized=structuredClone(m.matrix); delete normalized.postpromotion_nd_current_public_record_gap_row_state_reconciliation_product; const normalizedBytes=Buffer.from(`${JSON.stringify(normalized,null,2)}\\n`); assert(normalizedBytes.length===498054&&sha(normalizedBytes)==='6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c'&&gitBlob(normalizedBytes)==='8efadaa94bc9de68b4d90d471051d613ad0ce32e','semantic projection normalization mismatch');"
if needle not in t: raise SystemExit('validator insertion needle missing')
t=t.replace(needle,addition)
val.write_text(t)
# Manifest changed because validator changed. Recompute one final time.
rows=[]
for p in hashed:
 b=(OUT/p).read_bytes(); rows.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
manifest['hashed_files']=rows; manifest['combined_sha256']=sha(''.join(sorted(f"{r['path']}\0{r['sha256']}\0{r['bytes']}\n" for r in rows)).encode())
(root/'product-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')

# Syntax/local qualification. Fake release check is not run here; exact product validation and adversarial suite are.
subprocess.run(['node',str(builder.relative_to(OUT)),'--check'],cwd=OUT,check=True)
subprocess.run(['node',str(val.relative_to(OUT)),'--out',str(OUTDIR/'validator.json')],cwd=OUT,check=True)
subprocess.run(['node','--test','test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js'],cwd=OUT,check=True)
# Final inventory
inv=[]
for p in paths:
 b=(OUT/p).read_bytes(); inv.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
(OUTDIR/'product-inventory.json').write_text(json.dumps({'canonical_parent':PARENT,'canonical_parent_tree':PTREE,'permanent_path_count':14,'paths':inv,'manifest_combined_sha256':manifest['combined_sha256'],'matrix':{'bytes':FINAL_BYTES,'sha256':FINAL_SHA,'git_blob':FINAL_BLOB},'semantic_projection':{'bytes':SEM_BYTES,'sha256':SEM_SHA,'git_blob':SEM_BLOB}},indent=2)+'\n')
print(json.dumps({'state':'qualified_local','root':str(OUT),'paths':14,'manifest_combined_sha256':manifest['combined_sha256'],'matrix_sha256':FINAL_SHA,'matrix_blob':FINAL_BLOB},indent=2))


OUTDIR.mkdir(parents=True,exist_ok=True)
run(['ruby','-e',"require 'yaml'; YAML.load_file(ARGV[0])",str(wf.relative_to(WORKTREE))],cwd=WORKTREE)
run(['npm','run','release:check'],cwd=WORKTREE)
# Re-run deterministic checks after the complete gate without deleting the qualified product.
run(['node','tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs','--check'],cwd=WORKTREE)
run(['node','tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs','--out',str(OUTDIR/'post-release-validator.json')],cwd=WORKTREE)
# Stage exactly thirteen non-workflow permanent paths and one temporary workflow carrier.
inv=json.loads((OUTDIR/'product-inventory.json').read_text())
permanent=[r['path'] for r in inv['paths']]
nonworkflow=[p for p in permanent if not p.startswith('.github/workflows/')]
assert len(permanent)==14 and len(nonworkflow)==13
carrier=WORKTREE/CARRIER_WORKFLOW_PATH; carrier.parent.mkdir(parents=True,exist_ok=True); carrier.write_bytes(wf.read_bytes())
run(['git','add','--',*nonworkflow,CARRIER_WORKFLOW_PATH],cwd=WORKTREE)
run(['git','config','user.name','github-actions[bot]'],cwd=WORKTREE); run(['git','config','user.email','41898282+github-actions[bot]@users.noreply.github.com'],cwd=WORKTREE)
run(['git','commit','-m','Stage qualified North Dakota row-state product payload'],cwd=WORKTREE)
staging_commit=run(['git','rev-parse','HEAD'],cwd=WORKTREE).stdout.strip(); staging_tree=run(['git','rev-parse','HEAD^{tree}'],cwd=WORKTREE).stdout.strip()
changed=run(['git','diff','--name-status',CANONICAL_PARENT,staging_commit],cwd=WORKTREE).stdout.splitlines()
assert len(changed)==14 and all(x.startswith('A\t') for x in changed)
assert CARRIER_WORKFLOW_PATH in [x.split('\t',1)[1] for x in changed]
assert '.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.yml' not in [x.split('\t',1)[1] for x in changed]
# Bind every staged blob to the local qualified inventory; carrier workflow blob must equal permanent workflow blob.
for rec in inv['paths']:
    if rec['path'].startswith('.github/workflows/'):
        observed=run(['git','rev-parse',f'{staging_commit}:{CARRIER_WORKFLOW_PATH}'],cwd=WORKTREE).stdout.strip()
    else:
        observed=run(['git','rev-parse',f"{staging_commit}:{rec['path']}"],cwd=WORKTREE).stdout.strip()
    assert observed==rec['git_blob'],(rec['path'],observed,rec['git_blob'])
run(['git','push','origin',f'{staging_commit}:refs/heads/{STAGING_BRANCH}'],cwd=WORKTREE)
receipt={'schema_version':'ssc-rd04-nd-row-state-final-materializer@1','state':'qualified_nonworkflow_staging_published','canonical_parent':CANONICAL_PARENT,'canonical_parent_tree':CANONICAL_PARENT_TREE,'staging_branch':STAGING_BRANCH,'staging_commit':staging_commit,'staging_tree':staging_tree,'permanent_path_count':14,'staged_nonworkflow_paths':13,'temporary_workflow_carrier_paths':1,'matrix_sha256':'9f9dc05a057396056771bb566c44e9c3779d8ef6b0d2c078f7ffff11d9c7e6cb','semantic_projection_sha256':'6347024e87acf6d21192fa40844ae22b5b5c76c36bfb853edf5e6d35b58c829c','manifest_combined_sha256':inv['manifest_combined_sha256'],'source_requests':0,'route_executions':0,'source_admissions':0,'field_terminalizations':0,'matrix_updates':1,'row_state_mutations':1,'row_terminalizations':1,'class_closed':False,'outside_human_dependency':False,'final_product_commit_created':False,'canonical_merge_authorized':False}
(OUTDIR/'receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
# Preserve exact payload identities and controller state.
(OUTDIR/'staging-paths.txt').write_text('\n'.join(x.split('\t',1)[1] for x in changed)+'\n')
for name in ['validator.json','post-release-validator.json','product-inventory.json','receipt.json','staging-paths.txt']:
    assert (OUTDIR/name).is_file()
rows=[]
for p in sorted(x for x in OUTDIR.rglob('*') if x.is_file() and x.name!='SHA256SUMS'):
    rows.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(OUTDIR).as_posix()}\n")
(OUTDIR/'SHA256SUMS').write_text(''.join(rows))
print(json.dumps(receipt,indent=2,sort_keys=True))
