<!-- m04g-global-orbit-proof:30210885406 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30210885406
- Head: `a1fbe0a42e882b0475a33ed959902576ba7a56cc`
- Event: `push`
- Classes: `all`
- Basin denominator: `12/12`
- Orbit job: `success`
- Complete: `true`
- Proof SHA-256: `343a4f11d67d6ea4d821a6be74efa391f22f4f891204222a6856e90ab861746a`

| Basin | Selected | Succeeded | Failed | Candidates |
|---|---:|---:|---:|---:|
| `G01-GLOBAL-MULTILATERAL` | 8 | 6 | 2 | 6 |
| `G02-NORTH-AMERICA` | 8 | 4 | 4 | 4 |
| `G03-LATIN-AMERICA-CARIBBEAN` | 8 | 4 | 4 | 4 |
| `G04-EU-CONTINENTAL` | 8 | 6 | 2 | 6 |
| `G05-UK-IRELAND-NORDICS` | 8 | 7 | 1 | 7 |
| `G06-EASTERN-EUROPE-EURASIA` | 8 | 4 | 4 | 4 |
| `G07-MENA` | 8 | 3 | 5 | 3 |
| `G08-SUB-SAHARAN-AFRICA` | 8 | 4 | 4 | 4 |
| `G09-SOUTH-ASIA` | 8 | 3 | 5 | 3 |
| `G10-EAST-ASIA` | 8 | 4 | 4 | 4 |
| `G11-SOUTHEAST-ASIA` | 8 | 5 | 3 | 5 |
| `G12-OCEANIA-PACIFIC` | 8 | 3 | 5 | 3 |

```text
promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
