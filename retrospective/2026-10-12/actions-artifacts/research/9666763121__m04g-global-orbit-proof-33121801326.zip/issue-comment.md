<!-- m04g-global-orbit-proof:33121801326 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/33121801326
- Head: `564da53a373bfee43b026d7ed0ba0022bcc38633`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/10` (`0.4`)
- Content success: `4/10` (`0.4`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/2`
- Proof SHA-256: `46134358a36e6dfa169771389e84aa08fe1ff0722c6bb36213631a598394ffbe`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
