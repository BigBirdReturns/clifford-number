<!-- m04g-global-orbit-proof:31354952762 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31354952762
- Head: `bab9570ab043df7c5062e5a45a0717a82eed346b`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `18/24` (`0.75`)
- Content success: `18/24` (`0.75`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/12`
- Proof SHA-256: `f7d00464f98033e2c356e37069304ace28ed6ffec94e9a3afedb8af84eafd351`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G09-SOUTH-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 1 | 1 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
