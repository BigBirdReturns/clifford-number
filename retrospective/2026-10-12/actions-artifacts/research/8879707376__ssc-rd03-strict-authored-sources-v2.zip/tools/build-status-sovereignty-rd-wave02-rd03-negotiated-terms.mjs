#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const MATRIX_PATH = 'data/intake/status-sovereignty-rd-wave02-rd03-negotiated-terms/field-matrix.json';
export const PARENT_PATH = 'data/intake/status-sovereignty-rd03-osc-instrument-lifecycle.json';
export const SEED_PATH = 'data/project/ssc-residual-wave02/seeds/RD-03-C04.json';
export const EXECUTION_RECEIPT_PATH = 'data/intake/status-sovereignty-rd-wave02-rd03-negotiated-terms/public-record-census-execution-receipt.json';
export const CENSUS_ROOT = 'data/intake/status-sovereignty-rd-wave02-rd03-negotiated-terms/source-custody/public-record-census-v1';
export const PRODUCT_ROOT = 'data/research/status-sovereignty-rd-wave02-rd03-negotiated-terms';
export const CLOSURE_REFERENCE_PATH = 'data/project/ssc-residual-wave02/closures/RD-03-C04.json';
export const CURRENT_LEDGER_PATH = 'data/research/status-sovereignty-residual-denominator-wave-02-current.json';

export const CLASS_LABEL = 'complete negotiated loan, warrant, security, covenant, milestone, pricing, and seniority terms';
export const TERMINAL_STATE = 'bounded_source_unavailable';
export const RESEARCH_HEAD = 'e70aec0f6809c77e198e0c4ee80f6bcadb6bbdc4';
export const MATRIX_BLOB_SHA = '1ee428a1fc43365fd6987c5dbfe362a6338ec1e4';
export const MATRIX_SHA256 = '0d7924097f22816757891e70546d67c2bdfe685468e977b6d95406c108ddfa4a';
export const PARENT_SHA256 = '3bd111cc56eb5046ed5ba2aa8a8dfdecaec9d37bbb273e6c75b695e6ae1e05a0';
export const SEED_INPUT_MANIFEST_SHA256 = '12da3be1a750276357c93530f7390b6925d4f556184e9654dc87339346f46a59';
export const CENSUS_ARTIFACT_SHA256 = '5b5414816cb626a7d9bbe16d914f67d5d02d1233c6ca0d84e21930909eba5f08';
export const CENSUS_MANIFEST_SHA256 = '0bcee2db7be4904f775c55a2533a2a5f1c199edff47e273993925b742f24ac06';
export const CENSUS_MANIFEST_ENTRIES = 263;

export const REQUIRED_FIELDS = [
  'legal_borrower_and_material_affiliates',
  'instrument_state_and_governing_date',
  'principal_or_ceiling',
  'pricing_and_cost_of_capital',
  'maturity_and_amortization',
  'security_and_collateral',
  'seniority_and_subordination',
  'warrant_or_other_public_rights',
  'conditions_precedent_and_close_conditions',
  'covenants_and_operating_restrictions',
  'milestones_and_performance_obligations',
  'reporting_inspection_and_information_rights',
  'amendment_default_cure_and_enforcement',
  'source_identity_and_exact_custody'
];

export const INSTRUMENT_IDS = [
  'OSC-MP-MATERIALS-150M',
  'OSC-VULCAN-620M',
  'OSC-REELEMENT-80M',
  'OSC-PHOENIX-500M',
  'OSC-ENERGY-FUELS-725M'
];

const abs = (root, rel) => path.join(root, rel);
const readBytes = (root, rel) => fs.readFileSync(abs(root, rel));
const readJson = (root, rel) => JSON.parse(readBytes(root, rel).toString('utf8'));
const writeJson = (root, rel, value) => {
  fs.mkdirSync(path.dirname(abs(root, rel)), { recursive: true });
  fs.writeFileSync(abs(root, rel), `${JSON.stringify(value, null, 2)}\n`);
};
const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const same = (actual, expected, message) => ok(JSON.stringify(actual) === JSON.stringify(expected), message);

function terminalField(state, value, sourceIds, censusRouteIds, note) {
  return {
    state,
    value,
    source_ids: sourceIds,
    census_route_ids: censusRouteIds,
    note,
    fixed_protocol_complete: true,
    terminal_for_class_closure: true
  };
}

function readInputs(root) {
  return {
    matrix: readJson(root, MATRIX_PATH),
    matrixSha256: sha256(readBytes(root, MATRIX_PATH)),
    parent: readJson(root, PARENT_PATH),
    parentSha256: sha256(readBytes(root, PARENT_PATH)),
    seed: readJson(root, SEED_PATH),
    execution: readJson(root, EXECUTION_RECEIPT_PATH),
    censusSummary: readJson(root, `${CENSUS_ROOT}/summary.json`),
    censusManifest: readJson(root, `${CENSUS_ROOT}/manifest.json`),
    routeResults: readJson(root, `${CENSUS_ROOT}/route-results.json`),
    candidateIndex: readJson(root, `${CENSUS_ROOT}/candidate-index.json`),
    candidateUrls: readJson(root, `${CENSUS_ROOT}/candidate-url-ledger.json`),
    evidenceIndex: readJson(root, `${CENSUS_ROOT}/term-evidence-index.json`),
    protocolLedger: readJson(root, `${CENSUS_ROOT}/instrument-protocol-ledger.json`)
  };
}

function validateInputs(inputs) {
  const {
    matrix, matrixSha256, parent, parentSha256, seed, execution, censusSummary, censusManifest, routeResults,
    candidateIndex, candidateUrls, evidenceIndex, protocolLedger
  } = inputs;

  ok(matrixSha256 === MATRIX_SHA256, 'field matrix exact bytes changed');
  ok(matrix?.schema_version === 'ssc-rd-wave02-rd03-negotiated-terms-field-matrix@1', 'field matrix schema changed');
  ok(matrix?.wave_id === 'SSC-RD-W02' && matrix?.class_id === 'RD-03-C04' && matrix?.issue === 788, 'field matrix identity changed');
  same(matrix?.denominator_contract?.instrument_ids, INSTRUMENT_IDS, 'field matrix denominator changed');
  same(matrix?.required_fields, REQUIRED_FIELDS, 'required fields changed');
  ok(Array.isArray(matrix?.instruments) && matrix.instruments.length === 5, 'five matrix instruments required');
  same(matrix.instruments.map((row) => row.instrument_id), INSTRUMENT_IDS, 'matrix instrument order changed');
  ok(matrix?.counts?.fixed_protocol_completed_instruments === 0 && matrix?.counts?.closed_instruments === 0, 'historical matrix pre-protocol state changed');
  ok(matrix?.current_result?.fixed_protocol_complete === false && matrix?.current_result?.class_closed === false, 'historical matrix promoted itself');

  ok(parentSha256 === PARENT_SHA256, 'parent lifecycle exact bytes changed');
  ok(parent?.schema_version === 'status-sovereignty-residual-execution@1' && parent?.execution_id === 'SSC-RD03-OSC-01', 'parent lifecycle identity changed');
  same(parent.instruments.map((row) => row.instrument_id), INSTRUMENT_IDS, 'parent instrument denominator changed');
  ok(parent?.counts?.named_instruments === 5 && parent?.counts?.executed_loans === 1 && parent?.counts?.conditional_pre_close_commitments === 4, 'parent state split changed');
  ok(parent?.counts?.repayments_observed === 0 && parent?.counts?.public_recoveries_observed === 0, 'parent recovery state changed');
  same(parent.sources.map((row) => row.source_id), [
    'SSC-RD03-S001','SSC-RD03-S002','SSC-RD03-S003','SSC-RD03-S004','SSC-RD03-S005',
    'SSC-RD03-S006','SSC-RD03-S007','SSC-RD03-S008','SSC-RD03-S009'
  ], 'parent source registry changed');

  ok(seed?.schema_version === 'ssc-residual-denominator-wave02-lane-seed-reference@1', 'seed schema changed');
  ok(seed?.wave_issue === 785 && seed?.child_issue === 788 && seed?.class_id === 'RD-03-C04', 'seed identity changed');
  ok(seed?.closure_target === CLASS_LABEL, 'seed closure target changed');
  ok(seed?.input_manifest?.combined_sha256 === SEED_INPUT_MANIFEST_SHA256, 'seed input manifest changed');

  ok(execution?.schema_version === 'ssc-rd03-wave02-public-record-census-execution-receipt@1', 'execution receipt schema changed');
  ok(execution?.wave_id === 'SSC-RD-W02' && execution?.class_id === 'RD-03-C04' && execution?.issue === 788, 'execution receipt identity changed');
  ok(execution?.research_head === RESEARCH_HEAD, 'execution research head changed');
  ok(execution?.workflow_run === 30864413469 && execution?.job_id === 91853036710 && execution?.artifact_id === 8875551993, 'execution run custody changed');
  ok(execution?.artifact_zip_sha256 === CENSUS_ARTIFACT_SHA256, 'execution artifact digest changed');
  ok(execution?.manifest_entry_count === CENSUS_MANIFEST_ENTRIES && execution?.manifest_combined_sha256 === CENSUS_MANIFEST_SHA256, 'execution manifest custody changed');
  same(execution?.counts, {
    fixed_routes: 30,
    route_attempts: 30,
    http_success: 15,
    terminal_non_success: 15,
    candidate_result_rows: 150,
    unique_candidate_urls: 60,
    official_candidate_urls: 5,
    first_party_candidate_urls: 1,
    admitted_candidate_urls: 0,
    result_spawned_requests: 0
  }, 'execution counts changed');
  ok(execution?.authority?.outside_human_dependency === false && execution?.authority?.external_contacts === 0 && execution?.authority?.external_reviews === 0, 'execution external authority changed');
  ok(execution?.authority?.substantive_adjudication_performed_by_census === false && execution?.authority?.class_closed_by_census === false, 'transport census acquired adjudicative authority');

  ok(censusSummary?.schema_version === 'ssc-rd03-wave02-public-record-census-summary@1', 'census summary schema changed');
  ok(censusSummary?.research_head === RESEARCH_HEAD && censusSummary?.instruments === 5, 'census summary identity changed');
  ok(censusSummary?.fixed_routes === 30 && censusSummary?.exact_get_routes === 15 && censusSummary?.bing_rss_routes === 15, 'census route denominator changed');
  ok(censusSummary?.route_attempts === 30, 'census retry accounting changed');
  same(censusSummary?.terminal_transport_states, { http_terminal_non_success: 15, http_success: 15 }, 'census transport states changed');
  ok(censusSummary?.candidate_rows === 150 && censusSummary?.unique_candidate_urls === 60, 'census candidate counts changed');
  ok(censusSummary?.official_candidate_urls === 5 && censusSummary?.first_party_candidate_urls === 1, 'candidate host counts changed');
  ok(censusSummary?.transport_census_complete === true && censusSummary?.substantive_adjudication_complete === false && censusSummary?.class_closed === false, 'census authority changed');
  ok(censusSummary?.result_spawned_requests === 0 && censusSummary?.outside_human_dependency === false, 'census recursion or human dependency appeared');

  ok(censusManifest?.schema_version === 'ssc-rd03-wave02-public-record-census-manifest@1', 'census manifest schema changed');
  ok(censusManifest?.entry_count === CENSUS_MANIFEST_ENTRIES && censusManifest?.entries?.length === CENSUS_MANIFEST_ENTRIES, 'census manifest entry denominator changed');
  ok(censusManifest?.combined_sha256 === CENSUS_MANIFEST_SHA256, 'census manifest combined digest changed');

  ok(routeResults?.schema_version === 'ssc-rd03-wave02-public-record-route-results@1', 'route results schema changed');
  ok(routeResults?.research_head === RESEARCH_HEAD && routeResults?.route_count === 30 && routeResults?.routes?.length === 30, 'route results denominator changed');
  ok(routeResults.routes.every((row) => row.transport_terminal === true && row.result_spawned_requests === 0), 'route terminality or recursion changed');

  ok(candidateIndex?.schema_version === 'ssc-rd03-wave02-public-record-candidate-index@1', 'candidate index schema changed');
  ok(candidateIndex?.candidate_rows === 150 && candidateIndex?.unique_candidate_urls === 60, 'candidate index denominator changed');
  ok(candidateIndex?.authority?.candidate_hit_is_governing_instrument === false && candidateIndex?.authority?.search_result_is_term_evidence === false, 'candidate authority escalated');
  ok(candidateIndex?.authority?.result_spawned_requests === 0 && candidateIndex?.authority?.substantive_adjudication_complete === false, 'candidate recursion or adjudication appeared');

  ok(candidateUrls?.schema_version === 'ssc-rd03-wave02-candidate-url-ledger@1', 'candidate URL ledger schema changed');
  same(candidateUrls?.official_urls, [
    'https://www.eia.gov/energyexplained/what-is-energy/',
    'https://www.energy.ca.gov/',
    'https://www.energy.gov/',
    'https://www.phoenix.gov/',
    'https://www.phoenix.gov/explore.html'
  ], 'official candidate URLs changed');
  same(candidateUrls?.first_party_urls, ['https://mpmaterials.com/'], 'first-party candidate URLs changed');
  ok(candidateUrls?.admitted_sources === 0 && candidateUrls?.followup_requests_executed === 0, 'candidate URLs were silently admitted or followed');

  ok(evidenceIndex?.schema_version === 'ssc-rd03-wave02-term-evidence-index@1', 'evidence index schema changed');
  ok(evidenceIndex?.exact_routes?.length === 15, 'exact evidence-route denominator changed');
  ok(evidenceIndex?.authority?.marker_is_adjudicated_term === false && evidenceIndex?.authority?.text_match_is_complete_agreement === false, 'marker authority escalated');
  ok(evidenceIndex?.authority?.announcement_is_executed_instrument === false && evidenceIndex?.authority?.substantive_adjudication_complete === false, 'announcement or transport promoted itself');

  ok(protocolLedger?.schema_version === 'ssc-rd03-wave02-instrument-protocol-ledger@1', 'instrument protocol schema changed');
  ok(protocolLedger?.instrument_count === 5 && protocolLedger?.instruments?.length === 5, 'instrument protocol denominator changed');
  same(protocolLedger.instruments.map((row) => row.instrument_id), INSTRUMENT_IDS, 'instrument protocol membership changed');
  ok(protocolLedger?.transport_census_complete === true && protocolLedger?.substantive_adjudication_complete === false && protocolLedger?.class_closed === false, 'instrument protocol acquired closure authority');
  ok(protocolLedger.instruments.every((row) => row.fixed_protocol_complete === true && row.transport_terminal === true && row.instrument_closed_by_this_census === false), 'instrument protocol terminality changed');
}

function routesFor(protocolLedger, instrumentId) {
  const row = protocolLedger.instruments.find((candidate) => candidate.instrument_id === instrumentId);
  ok(row, `${instrumentId}: protocol row missing`);
  return row.fixed_route_ids;
}

function unavailable(routeIds, note) {
  return terminalField('source_unavailable_after_fixed_protocol', null, [], routeIds, note);
}

function commonFields(row, routeIds) {
  const source = row.parent_state;
  return {
    legal: unavailable(
      routeIds,
      'The row-level parent record preserves the announced borrower label, but the fixed protocol did not recover a complete legal-borrower and material-affiliate schedule. The field is therefore unavailable rather than partially observed.'
    ),
    custody: terminalField(
      'observed',
      {
        research_head: RESEARCH_HEAD,
        historical_field_matrix_path: MATRIX_PATH,
        historical_field_matrix_git_blob_sha: MATRIX_BLOB_SHA,
        historical_field_matrix_sha256: MATRIX_SHA256,
        parent_path: PARENT_PATH,
        parent_sha256: PARENT_SHA256,
        parent_source_ids: source.source_ids,
        census_root: CENSUS_ROOT,
        census_artifact_sha256: CENSUS_ARTIFACT_SHA256,
        census_manifest_combined_sha256: CENSUS_MANIFEST_SHA256,
        fixed_route_ids: routeIds
      },
      source.source_ids,
      routeIds,
      'Exact custody binds the historical matrix, parent sources, fixed route universe, retained artifact, and all captured bytes without expanding their claim scope.'
    )
  };
}

function buildMp(row, routeIds) {
  const source = row.parent_state;
  const common = commonFields(row, routeIds);
  return {
    legal_borrower_and_material_affiliates: common.legal,
    instrument_state_and_governing_date: unavailable(
      routeIds,
      'The parent lifecycle preserves execution, close, and cash receipt, but the fixed protocol did not recover the complete governing instrument and governing-date surface. The negotiated-term field remains unavailable rather than partially observed.'
    ),
    principal_or_ceiling: terminalField(
      'observed',
      { currency: 'USD', amount: 150000000, amount_type: 'executed_principal' },
      ['SSC-RD03-S001','SSC-RD03-S002','SSC-RD03-S003'],
      routeIds,
      'The executed unsecured promissory note has a stated principal of 150 million dollars.'
    ),
    pricing_and_cost_of_capital: terminalField(
      'observed',
      {
        annual_interest_rate_percent: 5.38,
        interest_payment_frequency: 'quarterly_cash',
        first_stated_cash_interest_date: '2025-10-15',
        fees_discounts_and_other_pricing: null,
        fees_discounts_and_other_pricing_state: 'source_unavailable_after_fixed_protocol'
      },
      ['SSC-RD03-S002','SSC-RD03-S003'],
      routeIds,
      'The public filings state 5.38 percent annual interest and quarterly cash interest. Fees, discounts, and any additional loan pricing remain unavailable.'
    ),
    maturity_and_amortization: unavailable(
      routeIds,
      'The public filing states an August 1, 2037 maturity, but the fixed protocol did not recover the complete maturity and amortization schedule. The composite negotiated-term field remains unavailable rather than partially observed.'
    ),
    security_and_collateral: terminalField(
      'observed',
      {
        instrument_form: 'unsecured_promissory_note',
        collateral: null,
        collateral_state: 'not_applicable_to_instrument_state'
      },
      ['SSC-RD03-S002'],
      routeIds,
      'The note is publicly described as unsecured; no collateral is assigned to an unsecured instrument.'
    ),
    seniority_and_subordination: unavailable(routeIds, 'Unsecured status does not establish seniority or subordination. No complete priority stack was recovered.'),
    warrant_or_other_public_rights: unavailable(
      routeIds,
      'The parent record preserves a companion preferred-stock, warrant, price-protection, and offtake package, but exact loan-specific allocation and complete right terms were not recovered. The negotiated-right field remains unavailable.'
    ),
    conditions_precedent_and_close_conditions: unavailable(
      routeIds,
      'Close and cash receipt remain preserved in the parent lifecycle, but the complete conditions-precedent and close-condition schedule was not recovered. The negotiated-condition field remains unavailable.'
    ),
    covenants_and_operating_restrictions: unavailable(routeIds, 'No complete affirmative, negative, or operating covenant schedule was recovered.'),
    milestones_and_performance_obligations: unavailable(routeIds, 'No complete milestone or performance-test schedule was recovered. Parent false observations do not establish contractual absence.'),
    reporting_inspection_and_information_rights: unavailable(routeIds, 'No complete reporting, inspection, audit, or information-right schedule was recovered.'),
    amendment_default_cure_and_enforcement: unavailable(routeIds, 'No complete amendment, waiver, default, cure, acceleration, or enforcement schedule was recovered.'),
    source_identity_and_exact_custody: common.custody
  };
}

function buildConditional(row, routeIds) {
  const source = row.parent_state;
  const common = commonFields(row, routeIds);
  const configs = {
    'OSC-VULCAN-620M': {
      amount: 620000000,
      warrant: { expected_public_right: 'warrant', issuance_observed: false, exact_terms_state: 'source_unavailable_after_fixed_protocol' },
      warrantSources: ['SSC-RD03-S005'],
      maturity: null,
      maturityState: 'source_unavailable_after_fixed_protocol',
      conditionNote: 'Financial, legal, technical, and other due-diligence conditions remained before financial close; no OSC funds were to be disbursed until disbursement conditions were met.'
    },
    'OSC-REELEMENT-80M': {
      amount: 80000000,
      warrant: { expected_public_right: 'warrant', issuance_observed: false, exact_terms_state: 'source_unavailable_after_fixed_protocol' },
      warrantSources: ['SSC-RD03-S005','SSC-RD03-S006'],
      maturity: null,
      maturityState: 'source_unavailable_after_fixed_protocol',
      conditionNote: 'Financial, legal, technical, and other due-diligence conditions remained before financial close; no OSC funds were to be disbursed until disbursement conditions were met.'
    },
    'OSC-PHOENIX-500M': {
      amount: 500000000,
      warrant: null,
      warrantSources: [],
      maturity: null,
      maturityState: 'source_unavailable_after_fixed_protocol',
      conditionNote: 'Financial, legal, technical, and other due-diligence conditions remained before financial close.'
    },
    'OSC-ENERGY-FUELS-725M': {
      amount: 725000000,
      warrant: null,
      warrantSources: [],
      maturity: { proposed_tenor_years: 20 },
      maturityState: 'conditional_term_only',
      conditionNote: 'Further due diligence, final agreements, customary closing conditions, and approvals remained. The company warned that the proposed financing might never complete or fund.'
    }
  };
  const config = configs[row.instrument_id];
  ok(config, `${row.instrument_id}: conditional configuration missing`);

  return {
    legal_borrower_and_material_affiliates: common.legal,
    instrument_state_and_governing_date: terminalField(
      'conditional_term_only',
      {
        bounded_state: source.bounded_state,
        announced: true,
        conditional_commitment: true,
        financial_close: false,
        executed_loan: false,
        cash_proceeds_received: false,
        governing_date: null,
        governing_date_state: 'source_unavailable_after_fixed_protocol'
      },
      source.source_ids,
      routeIds,
      'The public record supports only a conditional pre-close commitment. It is not converted into a final agreement, executed loan, or disbursement.'
    ),
    principal_or_ceiling: terminalField(
      'conditional_term_only',
      { currency: 'USD', amount: config.amount, amount_type: 'conditional_commitment_ceiling' },
      source.source_ids,
      routeIds,
      'The published amount is retained as a conditional commitment ceiling, not executed principal or cash drawn.'
    ),
    pricing_and_cost_of_capital: unavailable(routeIds, 'No final interest, fee, discount, warrant-economic, or other pricing schedule was recovered.'),
    maturity_and_amortization: config.maturityState === 'conditional_term_only'
      ? terminalField(
          'conditional_term_only',
          { ...config.maturity, exact_maturity_date: null, amortization: null, exact_schedule_state: 'source_unavailable_after_fixed_protocol' },
          source.source_ids,
          routeIds,
          'The proposed tenor is an advertised conditional term. Exact maturity and amortization remain unavailable.'
        )
      : unavailable(routeIds, 'No final maturity or amortization schedule was recovered.'),
    security_and_collateral: unavailable(routeIds, 'No final security or collateral package was recovered.'),
    seniority_and_subordination: unavailable(routeIds, 'No final seniority or subordination terms were recovered.'),
    warrant_or_other_public_rights: config.warrant
      ? terminalField(
          'conditional_term_only',
          config.warrant,
          config.warrantSources,
          routeIds,
          'The public record describes an expected warrant, not an issued right. Exact terms and issuance remain unavailable.'
        )
      : unavailable(routeIds, 'No source-addressable warrant, equity, price-protection, or other public-right term was recovered.'),
    conditions_precedent_and_close_conditions: terminalField(
      'conditional_term_only',
      {
        financial_close_observed: false,
        execution_observed: false,
        disbursement_observed: false,
        conditions_summary: config.conditionNote,
        complete_condition_schedule_state: 'source_unavailable_after_fixed_protocol'
      },
      source.source_ids,
      routeIds,
      config.conditionNote
    ),
    covenants_and_operating_restrictions: unavailable(routeIds, 'No final affirmative, negative, or operating covenant schedule was recovered.'),
    milestones_and_performance_obligations: unavailable(routeIds, 'No final milestone or performance-test schedule was recovered.'),
    reporting_inspection_and_information_rights: unavailable(routeIds, 'No final reporting, inspection, audit, or information-right schedule was recovered.'),
    amendment_default_cure_and_enforcement: unavailable(routeIds, 'No final amendment, waiver, default, cure, acceleration, or enforcement schedule was recovered.'),
    source_identity_and_exact_custody: common.custody
  };
}

function buildTerminalMatrix(inputs) {
  const { matrix, protocolLedger } = inputs;
  const instruments = matrix.instruments.map((row) => {
    const routeIds = routesFor(protocolLedger, row.instrument_id);
    const fields = row.instrument_id === 'OSC-MP-MATERIALS-150M'
      ? buildMp(row, routeIds)
      : buildConditional(row, routeIds);
    same(Object.keys(fields), REQUIRED_FIELDS, `${row.instrument_id}: terminal fields changed`);
    return {
      instrument_id: row.instrument_id,
      borrower: row.borrower,
      parent_state: row.parent_state,
      fields,
      instrument_result: {
        fixed_protocol_executed: true,
        terminal_fields: 14,
        required_fields: 14,
        instrument_closed: true,
        complete_negotiated_term_stack_observed: false,
        terminal_state: row.instrument_id === 'OSC-MP-MATERIALS-150M'
          ? 'executed_instrument_terms_partially_observed_remainder_source_unavailable'
          : 'conditional_commitment_terms_partially_observed_remainder_source_unavailable'
      }
    };
  });

  const allFields = instruments.flatMap((row) => Object.values(row.fields));
  const stateCounts = Object.fromEntries(
    ['observed','conditional_term_only','source_unavailable_after_fixed_protocol']
      .map((state) => [state, allFields.filter((field) => field.state === state).length])
  );
  same(stateCounts, { observed: 8, conditional_term_only: 15, source_unavailable_after_fixed_protocol: 47 }, 'terminal field-state accounting changed');

  return {
    schema_version: 'ssc-rd-wave02-rd03-negotiated-terms-terminal-matrix@1',
    wave_id: 'SSC-RD-W02',
    class_id: 'RD-03-C04',
    issue: 788,
    as_of: '2026-08-04',
    status: 'five_instrument_term_stack_terminal_bounded_source_unavailable',
    source_product: {
      research_head: RESEARCH_HEAD,
      historical_field_matrix_path: MATRIX_PATH,
      historical_field_matrix_git_blob_sha: MATRIX_BLOB_SHA,
      historical_field_matrix_sha256: MATRIX_SHA256,
      parent_path: PARENT_PATH,
      parent_sha256: PARENT_SHA256,
      execution_receipt_path: EXECUTION_RECEIPT_PATH,
      census_root: CENSUS_ROOT,
      census_artifact_sha256: CENSUS_ARTIFACT_SHA256,
      census_manifest_combined_sha256: CENSUS_MANIFEST_SHA256,
      census_manifest_entry_count: CENSUS_MANIFEST_ENTRIES
    },
    denominator_contract: {
      instruments: 5,
      instrument_ids: INSTRUMENT_IDS,
      executed_and_disbursed_instruments: 1,
      conditional_pre_close_commitments: 4,
      row_membership_frozen: true,
      silent_instrument_removal_allowed: false,
      outcome_based_selection_allowed: false,
      fixed_public_record_protocol_complete: true
    },
    required_fields: REQUIRED_FIELDS,
    permitted_field_states: [
      'observed',
      'not_applicable_to_instrument_state',
      'conditional_term_only',
      'source_restricted',
      'source_unavailable_after_fixed_protocol',
      'not_publicly_recovered'
    ],
    instruments,
    counts: {
      instruments: 5,
      executed_and_disbursed_parent_states: 1,
      conditional_pre_close_parent_states: 4,
      required_fields_per_instrument: 14,
      required_fields_total: 70,
      terminal_fields_total: 70,
      observed_fields: 8,
      conditional_term_only_fields: 15,
      source_unavailable_fields: 47,
      fixed_protocol_completed_instruments: 5,
      closed_instruments: 5,
      complete_negotiated_term_stacks_observed: 0,
      fixed_routes: 30,
      route_attempts: 30,
      exact_get_routes: 15,
      exact_route_terminal_non_successes: 15,
      discovery_routes: 15,
      discovery_route_successes: 15,
      candidate_result_rows: 150,
      unique_candidate_urls: 60,
      official_candidate_urls: 5,
      first_party_candidate_urls: 1,
      admitted_candidate_urls: 0,
      result_spawned_requests: 0,
      external_contacts: 0,
      external_reviews: 0,
      graph_effects: 0
    },
    current_result: {
      terminal_state: TERMINAL_STATE,
      exact_five_instrument_denominator_bound: true,
      fixed_protocol_complete: true,
      terminally_classified_instruments: 5,
      class_closed: true,
      complete_negotiated_term_stacks_observed: false,
      executed_and_conditional_state_distinction_preserved: true,
      source_unavailability_preserved: true,
      favoritism_finding: false,
      extraction_finding: false,
      public_recovery_finding: false,
      coordination_finding: false,
      common_purpose_finding: false,
      complete_compact_finding: false,
      reviewed_disposition_changed: false,
      project_blocking: false,
      publication_effect: 'none',
      adoption_effect: 'none',
      graph_effect: 'none'
    },
    boundaries: {
      conditional_commitment_is_executed_loan: false,
      executed_loan_is_complete_negotiated_term_stack: false,
      cash_disbursement_is_observed_performance_or_recovery: false,
      companion_right_package_is_loan_specific_right_allocation: false,
      expected_warrant_is_issued_warrant: false,
      advertised_tenor_is_final_maturity_schedule: false,
      direct_route_access_failure_is_record_absence: false,
      search_result_is_governing_instrument: false,
      unrecovered_term_is_zero_or_absent: false,
      parent_false_boolean_is_contractual_nonexistence: false,
      five_named_instruments_are_complete_OSC_cohort: false,
      strategic_financing_is_favoritism: false,
      private_capacity_is_extraction: false,
      functional_complementarity_is_coordination_or_common_purpose: false,
      matrix_completion_is_complete_compact: false,
      outside_human_dependency: false,
      publication_effect: 'none',
      adoption_effect: 'none',
      graph_effect: 'none'
    }
  };
}

function authority() {
  return {
    outside_human_dependency: false,
    external_contacts: 0,
    external_reviews: 0,
    reviewed_disposition_changed: false,
    complete_compact_finding: false,
    favoritism_finding: false,
    extraction_finding: false,
    public_recovery_finding: false,
    coordination_finding: false,
    common_purpose_finding: false,
    graph_effect: 'none',
    publication_effect: 'none',
    adoption_effect: 'none'
  };
}

export function deriveProduct(root = ROOT) {
  const inputs = readInputs(root);
  validateInputs(inputs);
  const matrix = buildTerminalMatrix(inputs);
  const classReceipt = {
    schema_version: 'ssc-rd-wave02-rd03-class-receipt@1',
    wave_id: 'SSC-RD-W02',
    lane_id: 'RD-03',
    class_id: 'RD-03-C04',
    issue: 788,
    class_label: CLASS_LABEL,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    closure_basis: [
      'the immutable five-instrument denominator remains complete and ordered',
      'the executed MP Materials loan remains separate from four conditional pre-close commitments',
      'the fixed thirty-route public-record protocol is terminal for every instrument with no recursive requests',
      'all fifteen direct official or regulatory routes terminated as typed access failures while all fifteen bounded discovery routes completed',
      'the six official or first-party search candidates contain no admissible governing loan, warrant, security, covenant, milestone, pricing, or seniority instrument',
      'all seventy required fields are terminally typed under a complete-field rule: eight observed, fifteen conditional-term-only, and forty-seven source unavailable rather than partial observations laundered into complete negotiated terms'
    ],
    counts: matrix.counts,
    residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06: {
      canonical_classes: 42,
      open_before: 38,
      closed_before: 4,
      open_after: 37,
      closed_after: 5
    },
    source_custody: {
      historical_field_matrix_path: MATRIX_PATH,
      historical_field_matrix_git_blob_sha: MATRIX_BLOB_SHA,
      execution_receipt_path: EXECUTION_RECEIPT_PATH,
      census_manifest_combined_sha256: CENSUS_MANIFEST_SHA256,
      census_artifact_sha256: CENSUS_ARTIFACT_SHA256
    },
    authority: authority()
  };
  const summary = {
    schema_version: 'ssc-rd-wave02-rd03-negotiated-terms-summary@1',
    wave_id: 'SSC-RD-W02',
    lane_id: 'RD-03',
    class_id: 'RD-03-C04',
    issue: 788,
    class_label: CLASS_LABEL,
    counts: matrix.counts,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    current_result: matrix.current_result,
    boundaries: matrix.boundaries,
    authority: authority()
  };
  return { matrix, classReceipt, summary };
}

function generatedPaths() {
  return [
    `${PRODUCT_ROOT}/class-receipt.json`,
    `${PRODUCT_ROOT}/summary.json`,
    `${PRODUCT_ROOT}/terminal-field-matrix.json`
  ];
}

export function writeProduct(root = ROOT) {
  const { matrix, classReceipt, summary } = deriveProduct(root);
  writeJson(root, `${PRODUCT_ROOT}/terminal-field-matrix.json`, matrix);
  writeJson(root, `${PRODUCT_ROOT}/class-receipt.json`, classReceipt);
  writeJson(root, `${PRODUCT_ROOT}/summary.json`, summary);

  const entries = generatedPaths().map((rel) => {
    const bytes = readBytes(root, rel);
    return { path: path.basename(rel), bytes: bytes.length, sha256: sha256(bytes) };
  });
  const combined = sha256(Buffer.from(entries.map((row) => `${row.path}\0${row.bytes}\0${row.sha256}\n`).join(''), 'utf8'));
  const manifest = {
    schema_version: 'ssc-rd-wave02-rd03-negotiated-terms-manifest@1',
    entries,
    combined_sha256: combined
  };
  writeJson(root, `${PRODUCT_ROOT}/manifest.json`, manifest);

  const closure = {
    schema_version: 'ssc-residual-denominator-wave02-class-closure-reference@1',
    wave_issue: 785,
    child_issue: 788,
    source_pr: 803,
    class_id: 'RD-03-C04',
    lane_id: 'RD-03',
    exact_label: CLASS_LABEL,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06: classReceipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06,
    product: {
      class_receipt_path: `${PRODUCT_ROOT}/class-receipt.json`,
      terminal_field_matrix_path: `${PRODUCT_ROOT}/terminal-field-matrix.json`,
      summary_path: `${PRODUCT_ROOT}/summary.json`,
      manifest_path: `${PRODUCT_ROOT}/manifest.json`,
      manifest_combined_sha256: combined
    },
    execution: {
      workflow_run: 30864413469,
      job_id: 91853036710,
      artifact_id: 8875551993,
      artifact_zip_sha256: CENSUS_ARTIFACT_SHA256,
      manifest_entry_count: CENSUS_MANIFEST_ENTRIES,
      census_manifest_combined_sha256: CENSUS_MANIFEST_SHA256,
      execution_receipt_path: EXECUTION_RECEIPT_PATH
    },
    authority: authority()
  };
  writeJson(root, CLOSURE_REFERENCE_PATH, closure);
  return { matrix, classReceipt, summary, manifest, closure };
}

export function checkProduct(root = ROOT) {
  const tempParent = path.dirname(abs(root, PRODUCT_ROOT));
  fs.mkdirSync(tempParent, { recursive: true });
  const temp = fs.mkdtempSync(path.join(tempParent, '.rd03-check-'));
  try {
    for (const rel of [
      MATRIX_PATH, PARENT_PATH, SEED_PATH, EXECUTION_RECEIPT_PATH,
      `${CENSUS_ROOT}/summary.json`, `${CENSUS_ROOT}/manifest.json`, `${CENSUS_ROOT}/route-results.json`,
      `${CENSUS_ROOT}/candidate-index.json`, `${CENSUS_ROOT}/candidate-url-ledger.json`,
      `${CENSUS_ROOT}/term-evidence-index.json`, `${CENSUS_ROOT}/instrument-protocol-ledger.json`
    ]) {
      const target = abs(temp, rel);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.copyFileSync(abs(root, rel), target);
    }
    writeProduct(temp);
    for (const rel of [...generatedPaths(), `${PRODUCT_ROOT}/manifest.json`, CLOSURE_REFERENCE_PATH]) {
      ok(readBytes(root, rel).equals(readBytes(temp, rel)), `${rel}: deterministic drift`);
    }
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const mode = process.argv[2] || '--write';
  if (mode === '--write') {
    const product = writeProduct(ROOT);
    console.log(`wrote RD-03 terminal product: ${product.matrix.counts.instruments} instruments, ${product.matrix.counts.terminal_fields_total} terminal fields`);
  } else if (mode === '--check') {
    checkProduct(ROOT);
    console.log('RD-03 terminal product deterministic: bounded_source_unavailable; 5/5 instruments terminal');
  } else {
    throw new Error(`unknown mode: ${mode}`);
  }
}
