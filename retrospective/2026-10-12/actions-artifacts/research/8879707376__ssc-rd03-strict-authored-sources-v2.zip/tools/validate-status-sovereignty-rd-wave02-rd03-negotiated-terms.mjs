#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  ROOT,
  MATRIX_PATH,
  PARENT_PATH,
  SEED_PATH,
  EXECUTION_RECEIPT_PATH,
  CENSUS_ROOT,
  PRODUCT_ROOT,
  CLOSURE_REFERENCE_PATH,
  CURRENT_LEDGER_PATH,
  CLASS_LABEL,
  TERMINAL_STATE,
  RESEARCH_HEAD,
  MATRIX_BLOB_SHA,
  MATRIX_SHA256,
  PARENT_SHA256,
  SEED_INPUT_MANIFEST_SHA256,
  CENSUS_ARTIFACT_SHA256,
  CENSUS_MANIFEST_SHA256,
  CENSUS_MANIFEST_ENTRIES,
  REQUIRED_FIELDS,
  INSTRUMENT_IDS,
  deriveProduct
} from './build-status-sovereignty-rd-wave02-rd03-negotiated-terms.mjs';

export const SCHEMA_PATH = 'schemas/status-sovereignty-rd-wave02-rd03-negotiated-terms.schema.json';

const abs = (root, rel) => path.join(root, rel);
const readBytes = (root, rel) => fs.readFileSync(abs(root, rel));
const readJson = (root, rel) => JSON.parse(readBytes(root, rel).toString('utf8'));
const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const same = (actual, expected, message) => ok(JSON.stringify(actual) === JSON.stringify(expected), message);
const unique = (values, message) => ok(new Set(values).size === values.length, message);

export function readBundle(root = ROOT) {
  return {
    terminal: readJson(root, `${PRODUCT_ROOT}/terminal-field-matrix.json`),
    receipt: readJson(root, `${PRODUCT_ROOT}/class-receipt.json`),
    summary: readJson(root, `${PRODUCT_ROOT}/summary.json`),
    manifest: readJson(root, `${PRODUCT_ROOT}/manifest.json`),
    closure: readJson(root, CLOSURE_REFERENCE_PATH),
    execution: readJson(root, EXECUTION_RECEIPT_PATH),
    censusSummary: readJson(root, `${CENSUS_ROOT}/summary.json`),
    censusManifest: readJson(root, `${CENSUS_ROOT}/manifest.json`),
    candidateIndex: readJson(root, `${CENSUS_ROOT}/candidate-index.json`),
    candidateUrls: readJson(root, `${CENSUS_ROOT}/candidate-url-ledger.json`),
    evidenceIndex: readJson(root, `${CENSUS_ROOT}/term-evidence-index.json`),
    protocolLedger: readJson(root, `${CENSUS_ROOT}/instrument-protocol-ledger.json`),
    parentMatrix: readJson(root, MATRIX_PATH),
    parentMatrixSha256: sha256(readBytes(root, MATRIX_PATH)),
    parent: readJson(root, PARENT_PATH),
    parentSha256: sha256(readBytes(root, PARENT_PATH)),
    seed: readJson(root, SEED_PATH)
  };
}

function exactKeys(value, keys, label) {
  ok(value && typeof value === 'object' && !Array.isArray(value), `${label}: object required`);
  same(Object.keys(value).sort(), [...keys].sort(), `${label}: keys changed`);
}

function allFalse(value, keys, label) {
  for (const key of keys) ok(value?.[key] === false, `${label}.${key} escalated`);
}

function allNone(value, keys, label) {
  for (const key of keys) ok(value?.[key] === 'none', `${label}.${key} escalated`);
}

function validateSchema(schema, terminal) {
  ok(schema?.$schema === 'https://json-schema.org/draft/2020-12/schema', 'schema dialect changed');
  ok(schema?.$id === 'https://bigbirdreturns.github.io/clifford-number/schemas/status-sovereignty-rd-wave02-rd03-negotiated-terms.schema.json', 'schema id changed');
  ok(schema?.type === 'object' && schema?.additionalProperties === false, 'schema root is not closed');
  ok(schema?.properties?.schema_version?.const === terminal.schema_version, 'schema version binding changed');
  ok(schema?.properties?.instruments?.minItems === 5 && schema?.properties?.instruments?.maxItems === 5, 'schema instrument denominator changed');
  ok(schema?.properties?.counts?.properties?.instruments?.const === 5, 'schema count denominator changed');
  ok(schema?.properties?.counts?.properties?.required_fields_total?.const === 70, 'schema field denominator changed');
  ok(schema?.properties?.counts?.properties?.terminal_fields_total?.const === 70, 'schema terminal field denominator changed');
  ok(schema?.properties?.counts?.properties?.source_unavailable_fields?.const === 47, 'schema unavailable-field denominator changed');
  ok(schema?.properties?.current_result?.properties?.terminal_state?.const === TERMINAL_STATE, 'schema terminal state changed');
  ok(schema?.properties?.current_result?.properties?.class_closed?.const === true, 'schema class closure changed');
  ok(schema?.$defs?.field?.additionalProperties === false, 'schema field object is not closed');
}

function validateCensusBytes(root, censusManifest) {
  ok(censusManifest?.entry_count === CENSUS_MANIFEST_ENTRIES && censusManifest?.entries?.length === CENSUS_MANIFEST_ENTRIES, 'census manifest entry denominator changed');
  unique(censusManifest.entries.map((row) => row.path), 'duplicate census manifest path');
  for (const entry of censusManifest.entries) {
    ok(!path.isAbsolute(entry.path) && !entry.path.split('/').includes('..'), `${entry.path}: unsafe census path`);
    const bytes = readBytes(root, `${CENSUS_ROOT}/${entry.path}`);
    ok(bytes.length === entry.bytes, `${entry.path}: census byte count changed`);
    ok(sha256(bytes) === entry.sha256, `${entry.path}: census digest changed`);
  }
  const combined = sha256(Buffer.from(censusManifest.entries.map((row) => `${row.sha256}  ${row.path}`).join('\n'), 'utf8'));
  ok(combined === censusManifest.combined_sha256, 'census manifest recomputation changed');
  ok(combined === CENSUS_MANIFEST_SHA256, 'census exact manifest binding changed');
}

function validateField(field, instrumentId, fieldName, permittedStates, fixedRouteIds) {
  exactKeys(field, ['state','value','source_ids','census_route_ids','note','fixed_protocol_complete','terminal_for_class_closure'], `${instrumentId}.${fieldName}`);
  ok(permittedStates.includes(field.state), `${instrumentId}.${fieldName}: impermissible state`);
  ok(Array.isArray(field.source_ids), `${instrumentId}.${fieldName}: source ids required`);
  ok(Array.isArray(field.census_route_ids) && field.census_route_ids.length > 0, `${instrumentId}.${fieldName}: census route ids required`);
  ok(field.census_route_ids.every((routeId) => fixedRouteIds.includes(routeId)), `${instrumentId}.${fieldName}: route outside instrument protocol`);
  ok(typeof field.note === 'string' && field.note.length > 20, `${instrumentId}.${fieldName}: bounded note required`);
  ok(field.fixed_protocol_complete === true && field.terminal_for_class_closure === true, `${instrumentId}.${fieldName}: field is not terminal`);
  if (field.state === 'source_unavailable_after_fixed_protocol') {
    ok(field.value === null, `${instrumentId}.${fieldName}: unavailable field manufactured a value`);
    same(field.source_ids, [], `${instrumentId}.${fieldName}: unavailable field cites a substantive source`);
  }
}

function validateInstrument(row, protocol, terminal) {
  exactKeys(row, ['instrument_id','borrower','parent_state','fields','instrument_result'], `${row.instrument_id}: instrument row`);
  ok(typeof row.borrower === 'string' && row.borrower.length > 0, `${row.instrument_id}: borrower missing`);
  same(Object.keys(row.fields), REQUIRED_FIELDS, `${row.instrument_id}: field order changed`);
  const fixedRouteIds = protocol.fixed_route_ids;
  for (const fieldName of REQUIRED_FIELDS) validateField(row.fields[fieldName], row.instrument_id, fieldName, terminal.permitted_field_states, fixedRouteIds);
  exactKeys(row.instrument_result, [
    'fixed_protocol_executed','terminal_fields','required_fields','instrument_closed',
    'complete_negotiated_term_stack_observed','terminal_state'
  ], `${row.instrument_id}: result`);
  ok(row.instrument_result.fixed_protocol_executed === true, `${row.instrument_id}: protocol not executed`);
  ok(row.instrument_result.terminal_fields === 14 && row.instrument_result.required_fields === 14, `${row.instrument_id}: terminal accounting changed`);
  ok(row.instrument_result.instrument_closed === true, `${row.instrument_id}: instrument reopened`);
  ok(row.instrument_result.complete_negotiated_term_stack_observed === false, `${row.instrument_id}: complete term stack manufactured`);
  const expectedState = row.instrument_id === 'OSC-MP-MATERIALS-150M'
    ? 'executed_instrument_terms_partially_observed_remainder_source_unavailable'
    : 'conditional_commitment_terms_partially_observed_remainder_source_unavailable';
  ok(row.instrument_result.terminal_state === expectedState, `${row.instrument_id}: terminal state changed`);

  const legal = row.fields.legal_borrower_and_material_affiliates;
  ok(legal.state === 'source_unavailable_after_fixed_protocol' && legal.value === null, `${row.instrument_id}: partial legal identity promoted`);
  same(legal.source_ids, [], `${row.instrument_id}: unavailable legal field cites substantive sources`);

  const state = row.fields.instrument_state_and_governing_date;
  if (row.instrument_id === 'OSC-MP-MATERIALS-150M') {
    ok(state.state === 'source_unavailable_after_fixed_protocol' && state.value === null, 'MP partial governing-instrument field promoted');
    ok(row.parent_state.executed_loan === true && row.parent_state.cash_proceeds_received === true, 'MP parent execution state changed');
    ok(row.parent_state.conditional_commitment === false && row.parent_state.financial_close === true, 'MP parent close state changed');
    same(row.fields.principal_or_ceiling.value, { currency: 'USD', amount: 150000000, amount_type: 'executed_principal' }, 'MP principal changed');
    ok(row.fields.principal_or_ceiling.state === 'observed', 'MP principal state changed');
    ok(row.fields.pricing_and_cost_of_capital.state === 'observed', 'MP pricing state changed');
    ok(row.fields.pricing_and_cost_of_capital.value.annual_interest_rate_percent === 5.38, 'MP interest changed');
    ok(row.fields.pricing_and_cost_of_capital.value.interest_payment_frequency === 'quarterly_cash', 'MP payment frequency changed');
    ok(row.fields.security_and_collateral.state === 'observed' && row.fields.security_and_collateral.value.instrument_form === 'unsecured_promissory_note', 'MP security form changed');
    for (const fieldName of ['maturity_and_amortization','warrant_or_other_public_rights','conditions_precedent_and_close_conditions']) {
      const field = row.fields[fieldName];
      ok(field.state === 'source_unavailable_after_fixed_protocol' && field.value === null, `MP ${fieldName}: partial field promoted`);
      same(field.source_ids, [], `MP ${fieldName}: unavailable field cites substantive sources`);
    }
  } else {
    ok(state.state === 'conditional_term_only' && state.value.conditional_commitment === true, `${row.instrument_id}: conditional state changed`);
    ok(state.value.governing_date === null && state.value.governing_date_state === 'source_unavailable_after_fixed_protocol', `${row.instrument_id}: governing date invented`);
    ok(state.value.financial_close === false && state.value.executed_loan === false && state.value.cash_proceeds_received === false, `${row.instrument_id}: conditional commitment promoted`);
    ok(row.fields.principal_or_ceiling.state === 'conditional_term_only', `${row.instrument_id}: conditional ceiling promoted`);
    ok(row.fields.principal_or_ceiling.value.amount_type === 'conditional_commitment_ceiling', `${row.instrument_id}: amount type changed`);
  }

  const custody = row.fields.source_identity_and_exact_custody;
  ok(custody.state === 'observed', `${row.instrument_id}: custody state changed`);
  ok(custody.value.research_head === RESEARCH_HEAD && custody.value.historical_field_matrix_git_blob_sha === MATRIX_BLOB_SHA, `${row.instrument_id}: research custody changed`);
  ok(custody.value.census_artifact_sha256 === CENSUS_ARTIFACT_SHA256 && custody.value.census_manifest_combined_sha256 === CENSUS_MANIFEST_SHA256, `${row.instrument_id}: census custody changed`);
  same(custody.value.fixed_route_ids, fixedRouteIds, `${row.instrument_id}: fixed route custody changed`);
}

export function validateProductShape(bundle, schema, root = ROOT) {
  const {
    terminal, receipt, summary, manifest, closure, execution, censusSummary, censusManifest,
    candidateIndex, candidateUrls, evidenceIndex, protocolLedger, parentMatrix, parentMatrixSha256, parent, parentSha256, seed
  } = bundle;

  validateSchema(schema, terminal);
  validateCensusBytes(root, censusManifest);

  ok(terminal?.schema_version === 'ssc-rd-wave02-rd03-negotiated-terms-terminal-matrix@1', 'terminal matrix schema changed');
  ok(terminal?.wave_id === 'SSC-RD-W02' && terminal?.class_id === 'RD-03-C04' && terminal?.issue === 788, 'terminal matrix identity changed');
  ok(terminal?.as_of === '2026-08-04' && terminal?.status === 'five_instrument_term_stack_terminal_bounded_source_unavailable', 'terminal matrix status changed');
  exactKeys(terminal.source_product, [
    'research_head','historical_field_matrix_path','historical_field_matrix_git_blob_sha','historical_field_matrix_sha256',
    'parent_path','parent_sha256','execution_receipt_path','census_root','census_artifact_sha256',
    'census_manifest_combined_sha256','census_manifest_entry_count'
  ], 'source product');
  ok(terminal.source_product.research_head === RESEARCH_HEAD, 'terminal research head changed');
  ok(terminal.source_product.historical_field_matrix_git_blob_sha === MATRIX_BLOB_SHA && terminal.source_product.historical_field_matrix_sha256 === MATRIX_SHA256, 'terminal matrix custody changed');
  ok(terminal.source_product.parent_sha256 === PARENT_SHA256, 'terminal parent custody changed');
  ok(terminal.source_product.census_artifact_sha256 === CENSUS_ARTIFACT_SHA256 && terminal.source_product.census_manifest_combined_sha256 === CENSUS_MANIFEST_SHA256, 'terminal census custody changed');
  ok(terminal.source_product.census_manifest_entry_count === CENSUS_MANIFEST_ENTRIES, 'terminal census manifest denominator changed');

  same(terminal.denominator_contract, {
    instruments: 5,
    instrument_ids: INSTRUMENT_IDS,
    executed_and_disbursed_instruments: 1,
    conditional_pre_close_commitments: 4,
    row_membership_frozen: true,
    silent_instrument_removal_allowed: false,
    outcome_based_selection_allowed: false,
    fixed_public_record_protocol_complete: true
  }, 'terminal denominator contract changed');
  same(terminal.required_fields, REQUIRED_FIELDS, 'terminal required fields changed');
  same(terminal.permitted_field_states, [
    'observed','not_applicable_to_instrument_state','conditional_term_only','source_restricted',
    'source_unavailable_after_fixed_protocol','not_publicly_recovered'
  ], 'terminal field-state vocabulary changed');

  ok(Array.isArray(terminal.instruments) && terminal.instruments.length === 5, 'five terminal instruments required');
  unique(terminal.instruments.map((row) => row.instrument_id), 'duplicate terminal instrument');
  same(terminal.instruments.map((row) => row.instrument_id), INSTRUMENT_IDS, 'terminal instrument order changed');
  const protocolById = new Map(protocolLedger.instruments.map((row) => [row.instrument_id, row]));
  for (const row of terminal.instruments) validateInstrument(row, protocolById.get(row.instrument_id), terminal);

  const allFields = terminal.instruments.flatMap((row) => Object.values(row.fields));
  const stateCounts = Object.fromEntries(['observed','conditional_term_only','source_unavailable_after_fixed_protocol'].map((state) => [state, allFields.filter((field) => field.state === state).length]));
  same(stateCounts, { observed: 8, conditional_term_only: 15, source_unavailable_after_fixed_protocol: 47 }, 'terminal field-state totals changed');

  same(terminal.counts, {
    instruments: 5,
    executed_and_disbursed_parent_states: 1,
    conditional_pre_close_parent_states: 4,
    required_fields_per_instrument: 14,
    required_fields_total: 70,
    terminal_fields_total: 70,
    observed_fields: 8,
    conditional_term_only_fields: 15,
    source_unavailable_fields: 47,
    fixed_protocol_completed_instruments: 5,
    closed_instruments: 5,
    complete_negotiated_term_stacks_observed: 0,
    fixed_routes: 30,
    route_attempts: 30,
    exact_get_routes: 15,
    exact_route_terminal_non_successes: 15,
    discovery_routes: 15,
    discovery_route_successes: 15,
    candidate_result_rows: 150,
    unique_candidate_urls: 60,
    official_candidate_urls: 5,
    first_party_candidate_urls: 1,
    admitted_candidate_urls: 0,
    result_spawned_requests: 0,
    external_contacts: 0,
    external_reviews: 0,
    graph_effects: 0
  }, 'terminal counts changed');

  ok(terminal.current_result.terminal_state === TERMINAL_STATE && terminal.current_result.class_closed === true, 'terminal class state changed');
  ok(terminal.current_result.fixed_protocol_complete === true && terminal.current_result.terminally_classified_instruments === 5, 'terminal protocol completion changed');
  ok(terminal.current_result.complete_negotiated_term_stacks_observed === false && terminal.current_result.source_unavailability_preserved === true, 'source-unavailability boundary changed');
  allFalse(terminal.current_result, [
    'favoritism_finding','extraction_finding','public_recovery_finding','coordination_finding','common_purpose_finding',
    'complete_compact_finding','reviewed_disposition_changed','project_blocking'
  ], 'terminal result');
  allNone(terminal.current_result, ['publication_effect','adoption_effect','graph_effect'], 'terminal result');
  for (const [key, value] of Object.entries(terminal.boundaries)) {
    if (key.endsWith('_effect')) ok(value === 'none', `${key} changed`);
    else ok(value === false, `${key} weakened`);
  }

  ok(receipt?.schema_version === 'ssc-rd-wave02-rd03-class-receipt@1', 'class receipt schema changed');
  ok(receipt?.wave_id === 'SSC-RD-W02' && receipt?.lane_id === 'RD-03' && receipt?.class_id === 'RD-03-C04' && receipt?.issue === 788, 'class receipt identity changed');
  ok(receipt?.class_label === CLASS_LABEL && receipt?.terminal_state === TERMINAL_STATE && receipt?.class_closed === true, 'class receipt result changed');
  ok(Array.isArray(receipt.closure_basis) && receipt.closure_basis.length === 6, 'closure basis changed');
  same(receipt.counts, terminal.counts, 'class receipt counts changed');
  same(receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06, { canonical_classes: 42, open_before: 38, closed_before: 4, open_after: 37, closed_after: 5 }, 'class receipt atlas effect changed');
  allFalse(receipt.authority, [
    'outside_human_dependency','reviewed_disposition_changed','complete_compact_finding','favoritism_finding',
    'extraction_finding','public_recovery_finding','coordination_finding','common_purpose_finding'
  ], 'class receipt authority');
  ok(receipt.authority.external_contacts === 0 && receipt.authority.external_reviews === 0, 'class receipt external activity changed');
  allNone(receipt.authority, ['graph_effect','publication_effect','adoption_effect'], 'class receipt authority');

  ok(summary?.schema_version === 'ssc-rd-wave02-rd03-negotiated-terms-summary@1', 'summary schema changed');
  ok(summary?.class_id === 'RD-03-C04' && summary?.terminal_state === TERMINAL_STATE && summary?.class_closed === true, 'summary result changed');
  same(summary.counts, terminal.counts, 'summary counts changed');
  same(summary.current_result, terminal.current_result, 'summary current result changed');
  same(summary.boundaries, terminal.boundaries, 'summary boundaries changed');
  same(summary.authority, receipt.authority, 'summary authority changed');

  ok(manifest?.schema_version === 'ssc-rd-wave02-rd03-negotiated-terms-manifest@1', 'product manifest schema changed');
  ok(Array.isArray(manifest.entries) && manifest.entries.length === 3, 'product manifest denominator changed');
  same(manifest.entries.map((row) => row.path), ['class-receipt.json','summary.json','terminal-field-matrix.json'], 'product manifest paths changed');
  unique(manifest.entries.map((row) => row.path), 'duplicate product manifest path');
  for (const entry of manifest.entries) {
    const bytes = readBytes(root, `${PRODUCT_ROOT}/${entry.path}`);
    ok(bytes.length === entry.bytes, `${entry.path}: product byte count changed`);
    ok(sha256(bytes) === entry.sha256, `${entry.path}: product digest changed`);
  }
  const productCombined = sha256(Buffer.from(manifest.entries.map((row) => `${row.path}\0${row.bytes}\0${row.sha256}\n`).join(''), 'utf8'));
  ok(productCombined === manifest.combined_sha256, 'product manifest recomputation changed');

  ok(closure?.schema_version === 'ssc-residual-denominator-wave02-class-closure-reference@1', 'closure reference schema changed');
  ok(closure?.wave_issue === 785 && closure?.child_issue === 788 && closure?.source_pr === 803, 'closure reference custody changed');
  ok(closure?.class_id === 'RD-03-C04' && closure?.lane_id === 'RD-03' && closure?.exact_label === CLASS_LABEL, 'closure reference identity changed');
  ok(closure?.terminal_state === TERMINAL_STATE && closure?.class_closed === true, 'closure reference result changed');
  same(closure.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06, receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06, 'closure atlas effect changed');
  ok(closure?.product?.manifest_combined_sha256 === manifest.combined_sha256, 'closure product manifest changed');
  ok(closure?.execution?.workflow_run === 30864413469 && closure?.execution?.job_id === 91853036710 && closure?.execution?.artifact_id === 8875551993, 'closure execution custody changed');
  ok(closure?.execution?.artifact_zip_sha256 === CENSUS_ARTIFACT_SHA256 && closure?.execution?.census_manifest_combined_sha256 === CENSUS_MANIFEST_SHA256, 'closure census digest changed');
  same(closure.authority, receipt.authority, 'closure authority changed');

  ok(execution?.schema_version === 'ssc-rd03-wave02-public-record-census-execution-receipt@1', 'execution receipt schema changed');
  ok(execution?.research_head === RESEARCH_HEAD && execution?.artifact_zip_sha256 === CENSUS_ARTIFACT_SHA256, 'execution receipt custody changed');
  ok(execution?.manifest_entry_count === CENSUS_MANIFEST_ENTRIES && execution?.manifest_combined_sha256 === CENSUS_MANIFEST_SHA256, 'execution receipt manifest changed');
  ok(execution?.authority?.substantive_adjudication_performed_by_census === false && execution?.authority?.class_closed_by_census === false, 'execution receipt promoted transport');

  ok(censusSummary?.fixed_routes === 30 && censusSummary?.route_attempts === 30 && censusSummary?.class_closed === false, 'census historical summary changed');
  ok(candidateIndex?.authority?.candidate_hit_is_governing_instrument === false && candidateIndex?.authority?.search_result_is_term_evidence === false, 'candidate authority changed');
  ok(candidateUrls?.admitted_sources === 0 && candidateUrls?.followup_requests_executed === 0, 'candidate URLs were admitted');
  ok(evidenceIndex?.authority?.substantive_adjudication_complete === false, 'evidence index promoted itself');
  ok(protocolLedger?.transport_census_complete === true && protocolLedger?.class_closed === false, 'protocol ledger historical state changed');

  ok(parentMatrixSha256 === MATRIX_SHA256, 'parent matrix exact bytes changed');
  ok(parentSha256 === PARENT_SHA256, 'parent lifecycle exact bytes changed');
  ok(seed?.input_manifest?.combined_sha256 === SEED_INPUT_MANIFEST_SHA256 && seed?.closure_target === CLASS_LABEL, 'seed custody changed');

  const derived = deriveProduct(root);
  same(terminal, derived.matrix, 'terminal matrix differs from deterministic derivation');
  same(receipt, derived.classReceipt, 'class receipt differs from deterministic derivation');
  same(summary, derived.summary, 'summary differs from deterministic derivation');

  const committed = readBundle(root);
  same(bundle, committed, 'candidate bundle differs from exact committed bundle');
  return bundle;
}

function validateGitCustody(root) {
  const inside = spawnSync('git', ['rev-parse', '--is-inside-work-tree'], { cwd: root, encoding: 'utf8' });
  if (inside.status !== 0) return;
  const tracked = spawnSync('git', ['ls-files'], { cwd: root, encoding: 'utf8' }).stdout.split('\n').filter(Boolean);
  ok(!tracked.some((rel) => rel.startsWith('.rd03-public-record-census/')), 'RD-03 transport plan retained in product branch');
  ok(!tracked.some((rel) => rel.includes('temporary-ssc-rd03')), 'RD-03 temporary workflow retained');
  const matrixBlob = spawnSync('git', ['rev-parse', `${RESEARCH_HEAD}:${MATRIX_PATH}`], { cwd: root, encoding: 'utf8' });
  ok(matrixBlob.status === 0 && matrixBlob.stdout.trim() === MATRIX_BLOB_SHA, 'historical field-matrix Git blob changed');
  const ancestor = spawnSync('git', ['merge-base', '--is-ancestor', RESEARCH_HEAD, 'HEAD'], { cwd: root, encoding: 'utf8' });
  ok(ancestor.status === 0, 'research head is not an ancestor of product head');

  if (fs.existsSync(abs(root, CURRENT_LEDGER_PATH))) {
    const current = readJson(root, CURRENT_LEDGER_PATH);
    ok(current?.counts?.canonical_residual_classes === 42 && current?.counts?.closed_residual_classes === 4 && current?.counts?.open_residual_classes === 38, 'current atlas pre-promotion state changed');
    same(current?.current_result?.closed_class_ids, ['RD-04-C01','RD-05-C03','RD-01-C03','RD-06-C01'], 'prior closed-class custody changed');
    ok(current?.current_result?.open_selected_class_ids?.includes('RD-03-C04'), 'RD-03 missing from current open selected classes');
  }
}

export function validateProduct(root = ROOT) {
  const bundle = readBundle(root);
  const schema = readJson(root, SCHEMA_PATH);
  validateProductShape(bundle, schema, root);
  validateGitCustody(root);
  return bundle;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const bundle = validateProduct(ROOT);
  console.log(`RD-03 terminal product validated: ${bundle.terminal.counts.instruments}/5 instruments; ${bundle.terminal.counts.terminal_fields_total}/70 fields terminal`);
}
