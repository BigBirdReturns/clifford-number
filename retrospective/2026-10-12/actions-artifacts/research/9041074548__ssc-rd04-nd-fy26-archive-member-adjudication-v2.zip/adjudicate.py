from pathlib import Path
import collections, hashlib, json, os, re, zipfile

out=Path(os.environ["OUT"])
root=out/"source"
trigger=json.loads(Path(os.environ["TRIGGER_PATH"]).read_text())

def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b""):
            h.update(chunk)
    return h.hexdigest()

checksum_rows=0
for line in (root/"SHA256SUMS").read_text().splitlines():
    if not line.strip():
        continue
    expected, rel=line.split(None,1)
    rel=rel.lstrip("*")
    assert digest(root/rel)==expected, rel
    checksum_rows += 1
assert checksum_rows==10
assert (root/"STAGE").read_text().strip()=="complete"
assert (root/"EXIT_CODE").read_text().strip()=="0"

execution=json.loads((root/"execution-receipt.json").read_text())
route=json.loads((root/"route-receipt.json").read_text())
assert execution["state"]=="transport_complete"
assert execution["physical_requests"]==1
assert execution["source_admissions"]==0
assert execution["field_terminalizations"]==0
assert execution["matrix_updates"]==0
assert execution["row_state_mutations"]==0
assert execution["class_closed"] is False
assert route["route_id"]==trigger["transport"]["route_id"]
assert route["requested_url"]==trigger["transport"]["url"]
assert route["physical_requests"]==1
assert route["http_status"]==200
assert route["followed_redirects"]==0
assert route["body_bytes"]==int(os.environ["SOURCE_BODY_BYTES"])
assert route["body_sha256"]==os.environ["SOURCE_BODY_SHA256"]
assert route["zip_magic"] is True
assert route["terminal_state"]=="http_success_zip_captured"

source_zip=root/"source.zip"
assert source_zip.stat().st_size==int(os.environ["SOURCE_BODY_BYTES"])
assert digest(source_zip)==os.environ["SOURCE_BODY_SHA256"]
assert (root/"response-body.bin").read_bytes()==source_zip.read_bytes()

members=[]
with zipfile.ZipFile(source_zip) as archive:
    assert archive.testzip() is None
    for info in archive.infolist():
        if info.is_dir():
            continue
        data=archive.read(info.filename)
        parts=info.filename.split("/")
        members.append({
            "path":info.filename,
            "bytes":info.file_size,
            "compressed_bytes":info.compress_size,
            "crc32":f"{info.CRC:08x}",
            "sha256":hashlib.sha256(data).hexdigest(),
            "state_directory":parts[1] if len(parts)>1 else None,
            "suffix":Path(info.filename).suffix.lower().lstrip("."),
        })
members.sort(key=lambda row:row["path"])
assert members==sorted(trigger["members"],key=lambda row:row["path"])

state_counts=dict(sorted(collections.Counter(row["state_directory"] for row in members).items()))
suffix_counts=dict(sorted(collections.Counter(row["suffix"] for row in members).items()))
nd=[row for row in members if re.search(r"north[ _-]*dakota|(^|/)nd(/|$)",row["path"],re.I)]
groups=collections.defaultdict(list)
for row in members:
    groups[(row["bytes"],row["sha256"])].append(row["path"])
duplicate_groups=sorted(
    [{"bytes":key[0],"sha256":key[1],"paths":sorted(paths)}
     for key,paths in groups.items() if len(paths)>1],
    key=lambda row:(row["sha256"],row["paths"])
)
assert len(members)==16
assert state_counts=={"NV":3,"NY":8,"OR":4,"WI":1}
assert suffix_counts=={"pdf":12,"png":1,"xlsx":3}
assert nd==[]
assert duplicate_groups==trigger["duplicate_body_groups"]

outputs={
  "archive-inventory.json":{
    "schema_version":"ssc-rd04-nd-fy26-archive-inventory@1",
    "source_artifact":int(os.environ["SOURCE_ARTIFACT_ID"]),
    "source_artifact_sha256":os.environ["SOURCE_ARTIFACT_SHA256"],
    "source_body_bytes":int(os.environ["SOURCE_BODY_BYTES"]),
    "source_body_sha256":os.environ["SOURCE_BODY_SHA256"],
    "member_count":len(members),
    "members":members,
    "state_directory_counts":state_counts,
    "suffix_counts":suffix_counts,
    "north_dakota_member_count":0,
    "duplicate_body_groups":duplicate_groups
  },
  "archive-adjudication.json":{
    "schema_version":"ssc-rd04-nd-fy26-archive-adjudication@1",
    "source_role":"official_fy2026_state_request_support_archive_member_census_only",
    "source_admitted":True,
    "admitted_weight":1,
    "member_contents_interpreted":False,
    "pdf_contents_interpreted":False,
    "xlsx_contents_interpreted":False,
    "png_contents_interpreted":False,
    "observed_state_directories":["NV","NY","OR","WI"],
    "north_dakota_member_count":0,
    "north_dakota_nonmembership_effect":"bounded_archive_observation_only",
    "negative_existence_claims":0,
    "limitations":[
      "archive membership does not prove complete federal filing coverage",
      "zero North Dakota members does not prove no request, no waiver, no policy, or no current status",
      "member names do not establish the contents of any enclosed document",
      "the archive range and title do not make every state in the range a represented member"
    ]
  },
  "field-adjudication.json":{
    "schema_version":"ssc-rd04-nd-fy26-archive-field-adjudication@1",
    "unit_id":"US-STATE-ND",
    "field_id":"abawd_or_work_requirement_waiver_state_and_governing_period",
    "predecessor_cell_sha256":"cbaabfa791f02aa4f17bc1b5b31e28775368b125a4b658cb216c22cd90a26dfe",
    "state_before":"still_open",
    "state_after":"still_open",
    "terminal_before":False,
    "terminal_after":False,
    "disposition":"captured_fy2026_nv_wi_request_archive_contains_no_north_dakota_member_but_archive_nonmembership_does_not_prove_no_request_no_waiver_or_current_status_hold_open",
    "promotion_candidate":None,
    "negative_existence_claims":0,
    "matrix_update":False,
    "row_state_mutation":False,
    "class_closed":False
  },
  "selected-protocol.json":{
    "schema_version":"ssc-rd04-nd-fy26-archive-successor-protocol@1",
    "routes":[],
    "route_count":0,
    "explicit_successor_protocol":False,
    "additional_execution_authorized":False,
    "next_authorized_operation":"none_without_separately_authored_exact_official_route_protocol"
  },
  "summary.json":{
    "schema_version":"ssc-rd04-nd-fy26-archive-adjudication-summary@1",
    "state":"terminal_archive_member_hold",
    "source_admissions":1,
    "field_decisions":1,
    "promotion_candidates":0,
    "held_open_fields":1,
    "selected_follow_up_routes":0,
    "negative_existence_claims":0,
    "source_requests":0,
    "route_executions":0,
    "field_terminalizations":0,
    "matrix_updates":0,
    "row_state_mutations":0,
    "class_closed":False,
    "cumulative_ledger_effect":"none",
    "outside_human_dependency":False,
    "publication_effect":"none",
    "adoption_effect":"none",
    "graph_effect":"none"
  }
}
outputs["receipt.json"]={
  "schema_version":"ssc-rd04-nd-fy26-archive-member-adjudication-receipt@1",
  "state":"complete",
  "failed_or_final_stage":"complete",
  "exit_code":0,
  "canonical_main":os.environ["EXPECTED_MAIN"],
  "matrix_blob":os.environ["MATRIX_BLOB"],
  "transport_artifact":int(os.environ["SOURCE_ARTIFACT_ID"]),
  "transport_artifact_sha256":os.environ["SOURCE_ARTIFACT_SHA256"],
  "internal_checksum_rows_verified":checksum_rows,
  "archive_member_count":len(members),
  "north_dakota_member_count":0,
  "source_admissions":1,
  "promotion_candidates":0,
  "held_open_fields":1,
  "selected_follow_up_routes":0,
  "negative_existence_claims":0,
  "source_requests":0,
  "route_executions":0,
  "field_terminalizations":0,
  "matrix_updates":0,
  "row_state_mutations":0,
  "class_closed":False,
  "outside_human_dependency":False
}
outputs["member-freeze.json"]=trigger
for name,value in outputs.items():
    (out/name).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")
