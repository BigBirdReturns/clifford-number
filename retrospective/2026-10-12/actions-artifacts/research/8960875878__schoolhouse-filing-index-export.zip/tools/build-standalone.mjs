#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { root } from './lib/ledger.mjs';

const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const readJson = file => JSON.parse(read(file));
const escapeScript = value => value.replace(/<\/script/gi, '<\\/script');
const faviconData = Buffer.from(read('assets/favicon.svg')).toString('base64');

const catalog = readJson('build/public-catalog.json');
const dataPaths = [
  'build/surface-graph.json',
  'build/hop-graph.json',
  'build/scores.json',
  'graph.json',
  'build/scout-report.json',
  'build/receipt-graph.json',
  'build/public-catalog.json',
  ...(catalog.cases ?? []).map(item => item.href),
  ...(catalog.tracks ?? []).map(item => item.href)
];
const embedded = Object.fromEntries([...new Set(dataPaths)].map(file => [file, readJson(file)]));

const helpers = [read('src/ui-utils.js'), read('src/i18n.js')]
  .join('\n\n')
  .replace(/^export\s+/gm, '');
const apertureModuleFiles = [
  'src/visual-aperture-core.mjs',
  'src/visual-aperture-state.mjs',
  'src/visual-aperture-workspace.mjs',
  'src/visual-aperture-export.mjs',
  'src/visual-aperture-windowing.mjs'
];
const apertureModuleRecords = apertureModuleFiles.map(file => {
  const source = read(file);
  const names = [...source.matchAll(/^export\s+(?:const|function|class)\s+(\w+)/gm)].map(match => match[1]);
  const body = source.replace(/^export\s+/gm, '');
  return { file, names, body };
});
const apertureNames = [...new Set(apertureModuleRecords.flatMap(record => record.names))];
const apertureModules = apertureModuleRecords
  .map(record => `(function apertureModule() {\n${record.body}\nObject.assign(globalThis, { ${record.names.join(', ')} });\n})();`)
  .join('\n');
const apertureRuntime = [
  read('src/visual-aperture-workspace-runtime.js'),
  read('src/visual-aperture-export-runtime.js'),
  ...Array.from({ length: 10 }, (_, index) => read(`src/visual-aperture-part-${index + 1}.js`)),
  read('src/visual-aperture-bounded-runtime.js'),
  read('src/visual-aperture-export-preview-runtime.js'),
  read('src/visual-aperture-part-11.js'),
  read('src/visual-aperture-bounded-address-runtime.js')
].join('\n\n');
const apertureBundle = `(function visualApertureBundle() {\n${apertureModules}\n(function visualApertureRuntime() {\nconst { ${apertureNames.join(', ')} } = globalThis;\n${apertureRuntime}\n})();\n})();`;
let app = read('app.js')
  .replace(/^import .*?;\r?\n/gm, '')
  .replace(
    /async function loadJson\(path\) \{[\s\S]*?\n\}/,
    `async function loadJson(path) {\n  if (!Object.hasOwn(EMBEDDED_DATA, path)) throw new Error(\`embedded release does not contain \${path}\`);\n  return structuredClone(EMBEDDED_DATA[path]);\n}`
  );
const inlineApp = escapeScript(`globalThis.__CLIFFORD_APERTURE_BUNDLED__ = true;\nconst EMBEDDED_DATA = ${JSON.stringify(embedded)};\n${helpers}\n${app}\n${apertureBundle}`);
const inlineCss = [
  read('styles.css'),
  read('src/visual-aperture-layout.css'),
  read('src/visual-aperture-svg.css'),
  read('src/visual-aperture-responsive.css'),
  read('src/visual-aperture-workspace.css'),
  read('src/visual-aperture-export.css'),
  read('src/visual-aperture-bounded.css')
].join('\n\n');

/* Replacement strings treat `$$`, `$&`, `$\`` and `$'` as substitution tokens.
 * The aperture runtime intentionally defines a `$$` selector helper, so arbitrary
 * bundled source must be inserted through replacer functions, never replacement
 * strings. Otherwise valid source is silently rewritten during packaging. */
let html = read('index.html')
  .replace(/\s*<link rel="preconnect" href="https:\/\/fonts\.googleapis\.com">/, '')
  .replace(/\s*<link rel="preconnect" href="https:\/\/fonts\.gstatic\.com" crossorigin>/, '')
  .replace(/\s*<link href="https:\/\/fonts\.googleapis\.com\/css2\?[^\"]+" rel="stylesheet">/, '')
  .replace('href="assets/favicon.svg"', () => `href="data:image/svg+xml;base64,${faviconData}"`)
  .replace(/  <link rel="stylesheet" href="styles\.css(?:\?[^\"]*)?">/, () => `  <style>\n${inlineCss}\n  </style>`)
  .replace(
    /  <script src="app\.js(?:\?[^\"]*)?" type="module"><\/script>/,
    () => `  <script>\n${inlineApp}\n  </script>`
  )
  .replace(/\s*<script src="src\/aperture-bootstrap\.js(?:\?[^\"]*)?" type="module"><\/script>/, '')
  .replace('<body>', '<body data-portable-release="true">');

const inlineScripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(match => match[1]);
for (const [index, script] of inlineScripts.entries()) {
  try {
    new Function(script);
  } catch (error) {
    throw new Error(`standalone inline script ${index + 1} does not parse: ${error.message}`, { cause: error });
  }
}

const output = path.join(root, 'dist', 'Clifford-Number-standalone.html');
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, html);
const estateApertureSource = path.join(root, 'estates', 'index.html');
const estateApertureOutput = path.join(root, 'dist', 'Clifford-Estate-Aperture-standalone.html');
const gameTrailSource = path.join(root, 'gametrails', 'index.html');
const gameTrailOutput = path.join(root, 'dist', 'Clifford-Game-Trail-Aperture-standalone.html');
if (!fs.existsSync(estateApertureSource)) throw new Error('Estate Aperture must be rendered before standalone packaging');
if (!fs.existsSync(gameTrailSource)) throw new Error('Game-Trail Aperture must be rendered before standalone packaging');
fs.copyFileSync(estateApertureSource, estateApertureOutput);
fs.copyFileSync(gameTrailSource, gameTrailOutput);
console.log(`build-standalone: ${path.relative(root, output)} (${fs.statSync(output).size} bytes, ${dataPaths.length} embedded records, ${inlineScripts.length} parsed scripts); ${path.relative(root, estateApertureOutput)} (${fs.statSync(estateApertureOutput).size} bytes); ${path.relative(root, gameTrailOutput)} (${fs.statSync(gameTrailOutput).size} bytes)`);
