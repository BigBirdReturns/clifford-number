import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import {
  compilePreferenceCausalAssuranceFixture,
  renderPreferenceCausalAssuranceMarkdown
} from './lib/preference-causal-assurance.mjs';

const sourcePath = process.argv[2] ?? 'data/research/preference-custody/causal-assurance.fixture.json';
const jsonPath = process.argv[3] ?? 'build/research/preference-causal-assurance.json';
const markdownPath = process.argv[4] ?? 'build/research/preference-causal-assurance.md';

const fixture = JSON.parse(readFileSync(sourcePath, 'utf8'));
const compiled = compilePreferenceCausalAssuranceFixture(fixture);
mkdirSync(dirname(jsonPath), { recursive: true });
mkdirSync(dirname(markdownPath), { recursive: true });
writeFileSync(jsonPath, JSON.stringify(compiled, null, 2) + '\n');
writeFileSync(markdownPath, renderPreferenceCausalAssuranceMarkdown(compiled));
console.log(`compiled ${compiled.fixture_id} -> ${jsonPath}, ${markdownPath}`);
