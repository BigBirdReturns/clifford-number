<!-- m04g-global-orbit-proof:31991356958 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31991356958
- Head: `49d1f3617132248484647eca4ddfa4fa49db40fb`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `14/24` (`0.5833`)
- Content success: `14/24` (`0.5833`)
- Metadata only: `0`
- Failed: `10`
- Healthy basins: `0/12`
- Proof SHA-256: `cee0654d479a65b2c04974232500865d67742bd0ee1a78bec6dea01fb643bcc5`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G07-MENA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 2 | 2 | 0 | 0 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
