import datetime as dt
import json
import re
import subprocess
from pathlib import Path

json_paths = [
    'build/axm-identity.json',
    'build/build-hop-report.json',
    'build/hop-graph.json',
    'build/migration-summary.json',
    'build/receipt-graph.json',
    'build/scores.json',
    'build/scout-report.json',
    'build/surface-graph.json',
]
markdown_paths = [
    'build/migration-review.md',
    'build/scout-report.md',
]
paths = json_paths + markdown_paths
iso = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$')

def head_bytes(path: str) -> bytes:
    return subprocess.check_output(['git', 'show', f'HEAD:{path}'])

def normalize_markdown(raw: bytes, path: str) -> bytes:
    text = raw.decode('utf-8')
    lines = text.splitlines(keepends=True)
    indexes = [i for i, line in enumerate(lines) if line.startswith('Generated: ')]
    if len(indexes) != 1:
        raise SystemExit(f'{path}: Generated-line denominator drift: {len(indexes)}')
    i = indexes[0]
    stamp = lines[i][len('Generated: '):].rstrip('\r\n')
    if not iso.fullmatch(stamp):
        raise SystemExit(f'{path}: malformed generated timestamp: {stamp!r}')
    ending = '\r\n' if lines[i].endswith('\r\n') else '\n' if lines[i].endswith('\n') else ''
    lines[i] = 'Generated: <normalized>' + ending
    return ''.join(lines).encode('utf-8')

changed = []
for path in paths:
    current_path = Path(path)
    if not current_path.is_file():
        raise SystemExit(f'{path}: generated product missing')
    before = head_bytes(path)
    after = current_path.read_bytes()
    if before == after:
        continue
    if path.endswith('.json'):
        old = json.loads(before)
        new = json.loads(after)
        if not isinstance(old, dict) or not isinstance(new, dict):
            raise SystemExit(f'{path}: expected top-level JSON objects')
        if set(old) != set(new) or 'generated' not in old:
            raise SystemExit(f'{path}: JSON structure changed outside timestamp')
        if not isinstance(old['generated'], str) or not iso.fullmatch(old['generated']):
            raise SystemExit(f'{path}: malformed HEAD generated timestamp')
        if not isinstance(new['generated'], str) or not iso.fullmatch(new['generated']):
            raise SystemExit(f'{path}: malformed worktree generated timestamp')
        old['generated'] = '<normalized>'
        new['generated'] = '<normalized>'
        if old != new:
            raise SystemExit(f'{path}: substantive generated product drift')
    else:
        if normalize_markdown(before, path) != normalize_markdown(after, path):
            raise SystemExit(f'{path}: substantive markdown generated product drift')
    changed.append(path)

if len(changed) not in (0, 10):
    raise SystemExit(f'generated timestamp drift denominator: {len(changed)} {changed}')
if changed:
    subprocess.run(
        ['git', 'restore', '--staged', '--worktree', '--', *changed],
        check=True,
    )
print(f'generated_timestamp_drift_restored={len(changed)}')
