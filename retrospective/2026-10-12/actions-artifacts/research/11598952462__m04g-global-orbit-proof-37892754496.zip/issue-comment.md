<!-- m04g-global-orbit-proof:37892754496 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/37892754496
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `4/4`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `6/20` (`0.3`)
- Content success: `6/20` (`0.3`)
- Metadata only: `0`
- Failed: `14`
- Healthy basins: `0/4`
- Proof SHA-256: `8233c85522965ecb940fc0c7f27b670e7bc5e9a0e9a9ec80e94c6117a1fa66b2`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G09-SOUTH-ASIA` | 5 | 1 | 1 | 0 | 4 | `false` |
| `G10-EAST-ASIA` | 5 | 1 | 1 | 0 | 4 | `false` |
| `G11-SOUTHEAST-ASIA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G12-OCEANIA-PACIFIC` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
