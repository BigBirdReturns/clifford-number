# BVVC SEC Form D denominator capture

Coverage: `2019Q1` through `2026Q2` across all six official quarterly Form D tables.

Matched accessions: **0**. BVVC-branded issuer candidates: **0**. Name collisions or embedded-token issuer names: **0**.

Every output is candidate-only and graph-inert. A Form D filing does not establish a portfolio-company transaction, current ownership, governance rights, operating control, or technical performance.
