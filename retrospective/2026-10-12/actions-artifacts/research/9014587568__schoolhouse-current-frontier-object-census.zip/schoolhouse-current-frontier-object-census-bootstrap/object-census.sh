#!/usr/bin/env bash
set -Eeuo pipefail

BASE='1e52a58be874538509d6c0d3c06adc12fc53cad7'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml'
SOURCE_BRANCH='agent/schoolhouse-legal-identity-current-frontier-materializer-v1'
SOURCE_HEAD='901c16b0a8f32bfe2a83c4e0d619d3168cd668ff'
SOURCE_ROOT='.github/materializers/schoolhouse-current-frontier-v1'
EXPECTED_PART04_BLOB='fc8dc1c4bb1cf991ae4a7f74f723569fa7307bf6'
EXPECTED_PART04_BYTES='10000'
EXPECTED_PART04_SHA256='ce1a3e3f3c19cd97215580d8f0fd1f7548c633828f468d0f0949a891fc8639c8'
OUT="$RUNNER_TEMP/schoolhouse-current-frontier-object-census"
RECOVERED="$OUT/recovered"
rm -rf "$OUT"
mkdir -p "$RECOVERED"
printf 'initializing\n' > "$OUT/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\nproduct_execution=0\nproduct_writes=0\n' > "$OUT/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  printf '%s\n' "$rc" > "$OUT/DIAGNOSTIC_EXIT_CODE"
  (
    cd "$OUT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-diagnostic-carrier\n' > "$OUT/STAGE"
git fetch --no-tags origin main "$SOURCE_BRANCH"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
mapfile -t carrier_paths < <(git diff --name-only "$BASE"..HEAD)
test "${#carrier_paths[@]}" -eq 1
test "${carrier_paths[0]}" = "$WORKFLOW"
git diff --check "$BASE"..HEAD
git merge-base --is-ancestor "$BASE" "$(git rev-parse origin/main)"
test "$(git rev-parse "origin/$SOURCE_BRANCH")" = "$SOURCE_HEAD"
test "$(git rev-list --count "$BASE".."$SOURCE_HEAD")" = '13'

printf 'fetching-all-advertised-repository-refs\n' > "$OUT/STAGE"
: > "$OUT/fetch-ledger.tsv"
fetch_optional() {
  local label="$1"
  shift
  set +e
  "$@" > "$OUT/fetch-${label}.stdout" 2> "$OUT/fetch-${label}.stderr"
  local rc="$?"
  set -e
  printf '%s\t%s\n' "$label" "$rc" >> "$OUT/fetch-ledger.tsv"
}
fetch_optional heads git fetch --force --prune --no-tags origin '+refs/heads/*:refs/remotes/origin/*'
fetch_optional tags git fetch --force --prune origin '+refs/tags/*:refs/tags/*'
fetch_optional pull-heads git fetch --force --prune origin '+refs/pull/*/head:refs/remotes/pull/*/head'
fetch_optional pull-merges git fetch --force --prune origin '+refs/pull/*/merge:refs/remotes/pull/*/merge'

printf 'recovering-historical-workflow-heads\n' > "$OUT/STAGE"
cat > "$OUT/branch-candidates.txt" <<'EOF_BRANCHES'
agent/schoolhouse-legal-identity-current-frontier-history-recovery-v7
agent/schoolhouse-legal-identity-current-frontier-materializer-v1
agent/schoolhouse-legal-identity-current-frontier-materializer-v2
agent/schoolhouse-legal-identity-current-frontier-materializer-v3
agent/schoolhouse-legal-identity-current-frontier-materializer-v4
agent/schoolhouse-legal-identity-current-frontier-materializer-v5
agent/schoolhouse-legal-identity-current-frontier-materializer-v5-clean
agent/schoolhouse-legal-identity-current-frontier-materializer-v5-custody-repair
agent/schoolhouse-legal-identity-current-frontier-materializer-v6
agent/schoolhouse-v5-controller-wrapper-trigger-v4
agent/schoolhouse-v5-materializer-controller-trigger-v3
agent/schoolhouse-legal-identity-current-frontier-source-export-v1
agent/schoolhouse-legal-identity-current-frontier-source-export-v2
agent/schoolhouse-legal-identity-current-frontier-source-export-v3
agent/schoolhouse-legal-identity-frontier-export-46036c-v3
EOF_BRANCHES
: > "$OUT/workflow-runs.tsv"
while IFS= read -r branch; do
  set +e
  gh api --paginate -X GET "repos/$GITHUB_REPOSITORY/actions/runs" \
    -f branch="$branch" -f per_page=100 \
    --jq '.workflow_runs[] | [.id, .head_sha, (.head_branch // ""), .event, .status, (.conclusion // ""), .created_at, .updated_at] | @tsv' \
    >> "$OUT/workflow-runs.tsv" 2>> "$OUT/workflow-run-query-errors.log"
  printf '%s\t%s\n' "$branch" "$?" >> "$OUT/workflow-run-query-status.tsv"
  set -e
done < "$OUT/branch-candidates.txt"
sort -u "$OUT/workflow-runs.tsv" -o "$OUT/workflow-runs.tsv"

: > "$OUT/historical-head-fetch.tsv"
cut -f2 "$OUT/workflow-runs.tsv" | grep -E '^[0-9a-f]{40}$' | sort -u > "$OUT/historical-heads.txt" || true
while IFS= read -r sha; do
  [ -n "$sha" ] || continue
  set +e
  git fetch --no-tags origin "$sha" > "$OUT/fetch-head-$sha.stdout" 2> "$OUT/fetch-head-$sha.stderr"
  rc="$?"
  set -e
  present=false
  if git cat-file -e "$sha^{commit}" 2>/dev/null; then
    present=true
    git update-ref "refs/recovery/workflow-heads/$sha" "$sha"
  fi
  printf '%s\t%s\t%s\n' "$sha" "$rc" "$present" >> "$OUT/historical-head-fetch.tsv"
done < "$OUT/historical-heads.txt"

printf 'recovering-current-frontier-pr-commit-objects\n' > "$OUT/STAGE"
: > "$OUT/pr-commits.tsv"
for pr in $(seq 1424 1433); do
  set +e
  gh api --paginate "repos/$GITHUB_REPOSITORY/pulls/$pr/commits" \
    --jq ".[] | [$pr, .sha, (.commit.message | split(\"\\n\")[0])] | @tsv" \
    >> "$OUT/pr-commits.tsv" 2>> "$OUT/pr-query-errors.log"
  printf '%s\t%s\n' "$pr" "$?" >> "$OUT/pr-query-status.tsv"
  set -e
done
sort -u "$OUT/pr-commits.tsv" -o "$OUT/pr-commits.tsv"
cut -f2 "$OUT/pr-commits.tsv" | grep -E '^[0-9a-f]{40}$' | sort -u > "$OUT/pr-commit-heads.txt" || true
: > "$OUT/pr-commit-fetch.tsv"
while IFS= read -r sha; do
  [ -n "$sha" ] || continue
  set +e
  git fetch --no-tags origin "$sha" > "$OUT/fetch-pr-$sha.stdout" 2> "$OUT/fetch-pr-$sha.stderr"
  rc="$?"
  set -e
  present=false
  if git cat-file -e "$sha^{commit}" 2>/dev/null; then
    present=true
    git update-ref "refs/recovery/pr-commits/$sha" "$sha"
  fi
  printf '%s\t%s\t%s\n' "$sha" "$rc" "$present" >> "$OUT/pr-commit-fetch.tsv"
done < "$OUT/pr-commit-heads.txt"

printf 'testing-direct-git-and-api-blob-recovery\n' > "$OUT/STAGE"
direct_before=false
if git cat-file -e "$EXPECTED_PART04_BLOB^{blob}" 2>/dev/null; then direct_before=true; fi
printf '%s\n' "$direct_before" > "$OUT/expected-blob-present-before-direct-fetch.txt"
set +e
git fetch --no-tags origin "$EXPECTED_PART04_BLOB" > "$OUT/direct-blob-fetch.stdout" 2> "$OUT/direct-blob-fetch.stderr"
printf '%s\n' "$?" > "$OUT/direct-blob-fetch-exit-code.txt"
set -e
direct_after=false
if git cat-file -e "$EXPECTED_PART04_BLOB^{blob}" 2>/dev/null; then direct_after=true; fi
printf '%s\n' "$direct_after" > "$OUT/expected-blob-present-after-direct-fetch.txt"

set +e
gh api "repos/$GITHUB_REPOSITORY/git/blobs/$EXPECTED_PART04_BLOB" > "$OUT/expected-blob-api.json" 2> "$OUT/expected-blob-api.stderr"
api_rc="$?"
set -e
printf '%s\n' "$api_rc" > "$OUT/expected-blob-api-exit-code.txt"
if [ "$api_rc" -eq 0 ]; then
  jq -r '.content' "$OUT/expected-blob-api.json" | tr -d '\n' | base64 --decode > "$RECOVERED/part-04-from-api"
  test "$(stat -c%s "$RECOVERED/part-04-from-api")" = "$EXPECTED_PART04_BYTES"
  test "$(sha256sum "$RECOVERED/part-04-from-api" | cut -d' ' -f1)" = "$EXPECTED_PART04_SHA256"
  test "$(git hash-object "$RECOVERED/part-04-from-api")" = "$EXPECTED_PART04_BLOB"
fi

printf 'recording-source-chain-trees\n' > "$OUT/STAGE"
git rev-list --reverse --ancestry-path "$BASE..$SOURCE_HEAD" > "$OUT/source-chain-commits.txt"
test "$(wc -l < "$OUT/source-chain-commits.txt")" = '13'
printf 'commit\tparent\tcommit_time\tpath\tblob\tbytes\tsha256\n' > "$OUT/source-chain-path-ledger.tsv"
while IFS= read -r commit; do
  parent="$(git rev-parse "$commit^")"
  commit_time="$(git show -s --format=%cI "$commit")"
  git diff-tree --root --no-commit-id --name-status -r "$commit" > "$OUT/source-chain-change-$commit.tsv"
  for name in controller-00 controller-01 controller-02 controller-03 controller-04 part-00 part-01 part-02 part-03 part-04 part-05 part-06; do
    path="$SOURCE_ROOT/$name"
    entry="$(git ls-tree "$commit" -- "$path")"
    [ -n "$entry" ] || continue
    blob="$(printf '%s\n' "$entry" | awk '{print $3}')"
    bytes="$(git cat-file -s "$blob")"
    sha256="$(git cat-file blob "$blob" | sha256sum | cut -d' ' -f1)"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$commit" "$parent" "$commit_time" "$path" "$blob" "$bytes" "$sha256" >> "$OUT/source-chain-path-ledger.tsv"
  done
done < "$OUT/source-chain-commits.txt"

git show-ref --head | sort > "$OUT/all-fetched-refs.txt"
git rev-list --objects --all | sort -u > "$OUT/reachable-objects.txt"
set +e
git fsck --full --unreachable --no-reflogs > "$OUT/git-fsck.stdout" 2> "$OUT/git-fsck.stderr"
printf '%s\n' "$?" > "$OUT/git-fsck-exit-code.txt"
set -e
git cat-file --batch-all-objects --batch-check='%(objectname) %(objecttype) %(objectsize)' | sort > "$OUT/all-local-objects.txt"

printf 'scanning-local-blob-corpus-for-exact-custody-targets\n' > "$OUT/STAGE"
python - "$OUT" "$RECOVERED" "$EXPECTED_PART04_BLOB" "$EXPECTED_PART04_SHA256" <<'PY'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

out = Path(sys.argv[1])
recovered = Path(sys.argv[2])
expected_blob = sys.argv[3]
expected_part04_sha = sys.argv[4]

targets = {
    expected_part04_sha: ('part-04', 10000),
    '2ef3e418be0d06986d9825f7810e69e700884fc70a437c93bb381c40dd627aaa': ('payload-base64', 65880),
    'b0482a70ace37bdd3ba554241a9adca7e1c65a8cb6ed025b7639e41d525ce213': ('payload-xz', 49408),
    '606ee4efaac88f5c0ee97cd21f4e68979b6818da8e26e359c88ead9385cb3bb8': ('payload-tar', 317440),
    'ce062526a534718d1dc1dd055d4cf78d1f50eba7005b62cde7481a6206e170cf': ('template-validator', None),
    'ab9ca9d89ba8f4726e5b58cda93274b59e2d0da34ed2ba5cd8465ecb9a6088e1': ('template-product-manifest', None),
}

objects = []
for line in (out / 'all-local-objects.txt').read_text().splitlines():
    sha, kind, size_raw = line.split()
    size = int(size_raw)
    if kind == 'blob' and size <= 1_000_000:
        objects.append((sha, size))

proc = subprocess.Popen(
    ['git', 'cat-file', '--batch'],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)
assert proc.stdin is not None and proc.stdout is not None
matches = []
scanned_bytes = 0
for sha, expected_size in objects:
    proc.stdin.write((sha + '\n').encode())
    proc.stdin.flush()
    header = proc.stdout.readline().decode().rstrip('\n').split()
    assert len(header) == 3 and header[0] == sha and header[1] == 'blob', (sha, header)
    size = int(header[2])
    assert size == expected_size
    data = proc.stdout.read(size)
    assert len(data) == size
    assert proc.stdout.read(1) == b'\n'
    scanned_bytes += size
    digest = hashlib.sha256(data).hexdigest()
    if digest in targets or sha == expected_blob:
        label, expected_target_size = targets.get(digest, ('expected-blob-id-with-unexpected-content', None))
        if expected_target_size is not None:
            assert size == expected_target_size, (label, size, expected_target_size)
        target_path = recovered / f'{label}-{sha}'
        target_path.write_bytes(data)
        matches.append({
            'label': label,
            'git_blob': sha,
            'bytes': size,
            'sha256': digest,
            'expected_git_blob_match': sha == expected_blob,
            'path': str(target_path.relative_to(out)),
        })
proc.stdin.close()
proc.wait(timeout=30)
assert proc.returncode == 0, proc.stderr.read().decode() if proc.stderr else ''

api_rc = int((out / 'expected-blob-api-exit-code.txt').read_text().strip())
direct_before = (out / 'expected-blob-present-before-direct-fetch.txt').read_text().strip() == 'true'
direct_after = (out / 'expected-blob-present-after-direct-fetch.txt').read_text().strip() == 'true'
run_rows = [line for line in (out / 'workflow-runs.tsv').read_text().splitlines() if line]
historical_fetch_rows = [line.split('\t') for line in (out / 'historical-head-fetch.tsv').read_text().splitlines() if line]
pr_rows = [line for line in (out / 'pr-commits.tsv').read_text().splitlines() if line]
pr_fetch_rows = [line.split('\t') for line in (out / 'pr-commit-fetch.tsv').read_text().splitlines() if line]
source_rows = [line for line in (out / 'source-chain-path-ledger.tsv').read_text().splitlines()[1:] if line]

part04_matches = [row for row in matches if row['sha256'] == expected_part04_sha]
receipt = {
    'schema_version': 'schoolhouse-current-frontier-object-census@1',
    'state': 'complete',
    'authority_class': 'read_only_diagnostic',
    'source_head': '901c16b0a8f32bfe2a83c4e0d619d3168cd668ff',
    'source_chain_commit_count': 13,
    'source_chain_path_observation_count': len(source_rows),
    'workflow_run_rows_recovered': len(run_rows),
    'historical_workflow_head_count': len(historical_fetch_rows),
    'historical_workflow_heads_fetched': sum(row[2] == 'true' for row in historical_fetch_rows),
    'pr_commit_rows_recovered': len(pr_rows),
    'pr_commit_object_count': len(pr_fetch_rows),
    'pr_commit_objects_fetched': sum(row[2] == 'true' for row in pr_fetch_rows),
    'local_blob_count_scanned': len(objects),
    'local_blob_bytes_scanned': scanned_bytes,
    'direct_expected_blob_present_before_fetch': direct_before,
    'direct_expected_blob_present_after_fetch': direct_after,
    'expected_blob_api_exit_code': api_rc,
    'exact_target_matches': matches,
    'exact_part04_match_count': len(part04_matches),
    'exact_part04_recovered': len(part04_matches) == 1,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'contacts': 0,
    'payments': 0,
    'uploads': 0,
    'controller_execution': 0,
    'product_execution': 0,
    'product_writes': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
(out / 'exact-matches.json').write_text(json.dumps(matches, indent=2, sort_keys=True) + '\n')
print(
    'object_census=complete '
    f'workflow_runs={len(run_rows)} historical_heads={len(historical_fetch_rows)} '
    f'blobs={len(objects)} bytes={scanned_bytes} exact_part04_matches={len(part04_matches)}'
)
PY

printf 'complete\n' > "$OUT/STAGE"
