<!-- m04g-global-orbit-proof:35576559006 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/35576559006
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `15/24` (`0.625`)
- Content success: `15/24` (`0.625`)
- Metadata only: `0`
- Failed: `9`
- Healthy basins: `0/12`
- Proof SHA-256: `7f76be79f5c6602287faa00d1ff705dcfb9e028cf6cf96b31d905fbcf035a716`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 2 | 2 | 0 | 0 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
