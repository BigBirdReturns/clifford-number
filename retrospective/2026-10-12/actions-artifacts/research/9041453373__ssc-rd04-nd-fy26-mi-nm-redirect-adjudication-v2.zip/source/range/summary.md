# RD-04 North Dakota FY2026 archive range correction

The consumed NV-WI archive contains 16 members under NV, NY, OR, and WI and no North Dakota member. The index partitions FY2026 archives by inclusive two-letter postal-code ranges. ND satisfies MI <= ND <= NM and does not satisfy NV <= ND <= WI. The North Dakota field remains open. Exactly one unexecuted MI-NM origin route is selected.
