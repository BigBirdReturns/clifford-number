<!-- m04g-global-orbit-proof:32731357626 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32731357626
- Head: `952d5b3423492bee296cfc8e4d25c11060774f43`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `5/10` (`0.5`)
- Content success: `5/10` (`0.5`)
- Metadata only: `0`
- Failed: `5`
- Healthy basins: `0/2`
- Proof SHA-256: `36aaa8a8d23d8575061c71b585d8c64ce8a37e7566476c4e296ce32db72eea37`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
