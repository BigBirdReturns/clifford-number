<!-- m04g-global-orbit-proof:30511511506 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30511511506
- Head: `b305eb935864b8adef320e8db5ff471d2a778403`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `4/4`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `8/20` (`0.4`)
- Content success: `7/20` (`0.35`)
- Metadata only: `1`
- Failed: `12`
- Healthy basins: `0/4`
- Proof SHA-256: `92f0320cf086ab80864b8886e58ff57561387d53a7e75ce3f698fe8246fca508`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G09-SOUTH-ASIA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G10-EAST-ASIA` | 5 | 1 | 1 | 0 | 4 | `false` |
| `G11-SOUTHEAST-ASIA` | 5 | 3 | 3 | 0 | 2 | `false` |
| `G12-OCEANIA-PACIFIC` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
