<!-- m04g-global-orbit-proof:33374975016 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/33374975016
- Head: `0b1d8af5b86adad49b3451053dbb9166294d631c`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `12/24` (`0.5`)
- Content success: `12/24` (`0.5`)
- Metadata only: `0`
- Failed: `12`
- Healthy basins: `0/12`
- Proof SHA-256: `ad2f30bead3ea05168515c7e6568d082917b1a4ea1f314d4e06fa2c9701184fe`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G07-MENA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 1 | 1 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
