<!-- m04g-global-orbit-proof:33135077129 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/33135077129
- Head: `564da53a373bfee43b026d7ed0ba0022bcc38633`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `1/1`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `3/5` (`0.6`)
- Content success: `3/5` (`0.6`)
- Metadata only: `0`
- Failed: `2`
- Healthy basins: `0/1`
- Proof SHA-256: `33255633f14f3318282dfab361622a898725c3aa6bc644338f60cf53d78ff652`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
