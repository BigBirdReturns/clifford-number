<!-- m04g-global-orbit-proof:33504116237 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/33504116237
- Head: `771a64b6b467748d2f4df667b5f78e76f9432d69`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `17/25` (`0.68`)
- Content success: `16/25` (`0.64`)
- Metadata only: `1`
- Failed: `8`
- Healthy basins: `0/5`
- Proof SHA-256: `c0bea9fa30565a7be53f73de65ad276ff0be5fd79bd470e67ac3994a38d333b4`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
