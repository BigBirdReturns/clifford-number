from __future__ import annotations

import hashlib
import json
import os
import re
import ssl
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from html import unescape
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote_plus, urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

PROTOCOL_DIR = Path("data/intake/status-sovereignty-rd-wave03-rd04-next-minimum-frontier-route-discovery-protocol")
PROTOCOL_PATH = PROTOCOL_DIR / "route-discovery-protocol.json"
CONTRACT_PATH = PROTOCOL_DIR / "route-query-contract.json"
FRONTIER_PATH = PROTOCOL_DIR / "frontier-selection.json"
CUSTODY_PATH = PROTOCOL_DIR / "predecessor-custody.json"
OUT = Path("/tmp/ssc-rd04-next-frontier-route-discovery-acquisition-v1")
BODY_LIMIT = 16 * 1024 * 1024
TIMEOUT_SECONDS = 35
USER_AGENT = "CliffordNumber-RD04RouteDiscovery/1.0 (+public-record-custody; no-source-admission)"
REDIRECT_CODES = {301, 302, 303, 307, 308}


def jload(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical_json(value))


def normalize_url(raw: str) -> str | None:
    try:
        raw = unescape(raw.strip().strip('"\'<>[](){}'))
        parts = urlsplit(raw)
        if parts.scheme.lower() not in {"http", "https"} or not parts.hostname:
            return None
        host = parts.hostname.lower().rstrip(".")
        port = parts.port
        netloc = host
        if port and not ((parts.scheme.lower() == "http" and port == 80) or (parts.scheme.lower() == "https" and port == 443)):
            netloc = f"{host}:{port}"
        path = parts.path or "/"
        return urlunsplit((parts.scheme.lower(), netloc, path, parts.query, ""))
    except Exception:
        return None


def host_of(url: str) -> str:
    return (urlsplit(url).hostname or "").lower().rstrip(".")


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: ANN001
        return None


OPENER = build_opener(NoRedirect)
SSL_CONTEXT = ssl.create_default_context()


@dataclass
class RequestResult:
    request_id: str
    requested_url: str
    final_url: str
    surface: str
    root_url: str | None
    terminal_state: str
    http_status: int | None
    redirect_chain: list[dict[str, Any]]
    headers: dict[str, str]
    body_path: str | None
    body_bytes: int
    body_sha256: str | None
    content_type: str | None
    error: str | None


request_cache: dict[str, RequestResult] = {}
request_order: list[str] = []


def fetch_once(url: str, *, surface: str, root_url: str | None) -> RequestResult:
    normalized = normalize_url(url)
    if normalized is None:
        raise AssertionError(f"invalid URL: {url!r}")
    if normalized in request_cache:
        return request_cache[normalized]

    sequence = len(request_order) + 1
    request_id = f"req-{sequence:03d}-{hashlib.sha256(normalized.encode()).hexdigest()[:12]}"
    current = normalized
    redirects: list[dict[str, Any]] = []
    terminal_state = "transport_error"
    status: int | None = None
    headers_out: dict[str, str] = {}
    body = b""
    body_path: str | None = None
    body_sha: str | None = None
    content_type: str | None = None
    error: str | None = None

    for redirect_index in range(5):
        req = Request(
            current,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "text/html,application/xhtml+xml,application/xml,application/pdf,text/plain,*/*;q=0.5",
                "Accept-Encoding": "identity",
                "Cache-Control": "no-cache",
            },
            method="GET",
        )
        response = None
        try:
            response = OPENER.open(req, timeout=TIMEOUT_SECONDS, context=SSL_CONTEXT)
        except TypeError:
            # Python's opener.open does not accept an explicit context; HTTPSHandler already uses default context.
            try:
                response = OPENER.open(req, timeout=TIMEOUT_SECONDS)
            except HTTPError as exc:
                response = exc
            except URLError as exc:
                error = f"{type(exc).__name__}: {exc}"
                terminal_state = "transport_error"
                break
            except Exception as exc:  # noqa: BLE001
                error = f"{type(exc).__name__}: {exc}"
                terminal_state = "transport_error"
                break
        except HTTPError as exc:
            response = exc
        except URLError as exc:
            error = f"{type(exc).__name__}: {exc}"
            terminal_state = "transport_error"
            break
        except Exception as exc:  # noqa: BLE001
            error = f"{type(exc).__name__}: {exc}"
            terminal_state = "transport_error"
            break

        assert response is not None
        status = int(getattr(response, "status", getattr(response, "code", 0)) or 0)
        headers_out = {str(k).lower(): str(v) for k, v in response.headers.items()}
        content_type = headers_out.get("content-type")

        if status in REDIRECT_CODES:
            location = response.headers.get("Location")
            if not location:
                terminal_state = "http_redirect_without_location"
                break
            next_url = normalize_url(urljoin(current, location))
            if next_url is None:
                terminal_state = "invalid_redirect_location"
                error = location
                break
            redirects.append({"status": status, "from": current, "to": next_url})
            if host_of(next_url) != host_of(current):
                terminal_state = "cross_host_redirect_refused"
                error = f"{host_of(current)} -> {host_of(next_url)}"
                current = next_url
                break
            if redirect_index >= 4:
                terminal_state = "redirect_limit_exceeded"
                current = next_url
                break
            current = next_url
            continue

        try:
            body = response.read(BODY_LIMIT + 1)
        except Exception as exc:  # noqa: BLE001
            error = f"body_read_error: {type(exc).__name__}: {exc}"
            terminal_state = "body_read_error"
            break
        if len(body) > BODY_LIMIT:
            body = body[:BODY_LIMIT]
            terminal_state = "body_limit_exceeded"
        elif 200 <= status < 300:
            terminal_state = "http_success"
        else:
            terminal_state = "http_non_success"
        body_sha = sha256_bytes(body)
        suffix = ".bin"
        lower_ct = (content_type or "").lower()
        if "html" in lower_ct:
            suffix = ".html"
        elif "xml" in lower_ct:
            suffix = ".xml"
        elif "json" in lower_ct:
            suffix = ".json"
        elif "text" in lower_ct or "robots" in current:
            suffix = ".txt"
        elif "pdf" in lower_ct or current.lower().split("?", 1)[0].endswith(".pdf"):
            suffix = ".pdf"
        rel = f"bodies/{request_id}{suffix}"
        target = OUT / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        body_path = rel
        break

    result = RequestResult(
        request_id=request_id,
        requested_url=normalized,
        final_url=current,
        surface=surface,
        root_url=root_url,
        terminal_state=terminal_state,
        http_status=status,
        redirect_chain=redirects,
        headers=dict(sorted(headers_out.items())),
        body_path=body_path,
        body_bytes=len(body),
        body_sha256=body_sha,
        content_type=content_type,
        error=error,
    )
    request_cache[normalized] = result
    request_order.append(normalized)
    write_json(OUT / "requests" / f"{request_id}.json", result.__dict__)
    return result


URL_RE = re.compile(r"https?://[^\s\"'<>]+", re.I)
HREF_RE = re.compile(r"(?:href|src)\s*=\s*[\"']([^\"']+)[\"']", re.I)
LOC_RE = re.compile(r"<loc>\s*([^<]+?)\s*</loc>", re.I)
SITEMAP_RE = re.compile(r"^\s*Sitemap:\s*(\S+)", re.I | re.M)


def extract_urls(base_url: str, body: bytes, content_type: str | None) -> list[str]:
    text = body.decode("utf-8", errors="replace")
    found: list[str] = []
    for raw in URL_RE.findall(text):
        n = normalize_url(raw.rstrip(".,;:)]}"))
        if n:
            found.append(n)
    for raw in HREF_RE.findall(text):
        n = normalize_url(urljoin(base_url, unescape(raw)))
        if n:
            found.append(n)
    for raw in LOC_RE.findall(text):
        n = normalize_url(unescape(raw))
        if n:
            found.append(n)
    for raw in SITEMAP_RE.findall(text):
        n = normalize_url(unescape(raw))
        if n:
            found.append(n)
    return sorted(set(found))


def tokens_for(obligation: dict[str, Any]) -> set[str]:
    stop = {"and", "or", "the", "state", "typed", "gap", "snap", "policy"}
    tokens: set[str] = set()
    for term in obligation["query_terms"]:
        for token in re.findall(r"[a-z0-9]+", term.lower()):
            if len(token) >= 4 and token not in stop:
                tokens.add(token)
    state_slug = obligation["state_id"].split("-")[-1].lower()
    tokens.add(state_slug)
    return tokens


def candidate_score(url: str, obligation: dict[str, Any]) -> tuple[int, int, str]:
    hay = url.lower().replace("-", " ").replace("_", " ").replace("/", " ")
    score = sum(1 for token in tokens_for(obligation) if token in hay)
    # Prefer PDF/manual/policy/waiver paths, then shorter stable URLs.
    bonus = sum(1 for token in ("manual", "policy", "waiver", "abawd", "verify", "verification", "eligibility", "snap", "pdf") if token in hay)
    return (score * 10 + bonus, -len(url), url)


def body_for(result: RequestResult) -> bytes:
    if not result.body_path:
        return b""
    return (OUT / result.body_path).read_bytes()


def main() -> int:
    protocol = jload(PROTOCOL_PATH)
    contract = jload(CONTRACT_PATH)
    frontier = jload(FRONTIER_PATH)
    custody = jload(CUSTODY_PATH)

    assert protocol["schema_version"] == "ssc-rd04-next-frontier-route-discovery-protocol@1"
    assert protocol["obligation_count"] == 20 == len(protocol["obligations"])
    assert protocol["maximum_total_discovery_requests"] == 120
    assert protocol["maximum_total_candidate_urls"] == 240
    assert contract["maximum_attempts_per_request"] == 1
    assert contract["maximum_redirects"] == 4
    assert contract["cross_host_redirects_allowed"] is False
    assert contract["result_spawned_source_fetches"] == 0
    assert contract["automatic_source_admission"] is False
    assert contract["automatic_field_classification"] is False
    assert frontier["terminal_cells_before"] == 218
    assert frontier["open_substantive_cells_before"] == 192
    assert frontier["selected_state_count"] == 5
    assert frontier["selected_substantive_cell_count"] == 20
    assert custody["canonical_rd04_merge"] == "a464dbbd96c365a7c040e17847486c5b3ba05c27"

    OUT.mkdir(parents=True, exist_ok=True)
    for source in (PROTOCOL_PATH, CONTRACT_PATH, FRONTIER_PATH, CUSTODY_PATH):
        target = OUT / "inputs" / source.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())

    # Exact repository-native routes are acquisition inputs. Shared URLs are fetched once,
    # then referenced from every bounded obligation that declared them.
    obligation_uses: dict[str, list[dict[str, Any]]] = {}
    for obligation in protocol["obligations"]:
        uses: list[dict[str, Any]] = []
        exact_urls = list(dict.fromkeys(obligation["repository_candidate_urls"]))
        assert len(exact_urls) <= obligation["maximum_candidate_urls"]
        assert len(exact_urls) <= obligation["maximum_discovery_requests"]
        for url in exact_urls:
            result = fetch_once(url, surface="repository_native_exact_url", root_url=None)
            uses.append({"surface": "repository_native_exact_url", "url": url, "request_id": result.request_id})
        obligation_uses[obligation["obligation_id"]] = uses

    # Bounded discovery surfaces are executed once per official root and shared across
    # the four Florida cells. No discovered candidate is fetched in this transaction.
    discovery_results_by_root: dict[str, list[RequestResult]] = {}
    discovery_obligations = [o for o in protocol["obligations"] if o["mode"] == "bounded_official_route_discovery"]
    for root in sorted({normalize_url(r) for o in discovery_obligations for r in o["official_roots"] if normalize_url(r)}):
        assert root is not None
        combined_terms = " ".join(sorted({term for o in discovery_obligations if root in [normalize_url(r) for r in o["official_roots"]] for term in o["query_terms"]}))
        surfaces = [
            ("official_root_robots_txt", urljoin(root, "robots.txt")),
            ("official_root_sitemap_xml", urljoin(root, "sitemap.xml")),
            ("official_site_search", urljoin(root, "search?search_api_fulltext=" + quote_plus(combined_terms))),
        ]
        assert len(surfaces) <= contract["maximum_discovery_requests_per_root"]
        results: list[RequestResult] = []
        for surface, url in surfaces:
            results.append(fetch_once(url, surface=surface, root_url=root))
        discovery_results_by_root[root] = results

    cells: list[dict[str, Any]] = []
    total_candidates = 0
    for obligation in protocol["obligations"]:
        candidate_rows: list[dict[str, Any]] = []
        seen: set[str] = set()
        for url in obligation["repository_candidate_urls"]:
            n = normalize_url(url)
            if n and n not in seen:
                result = request_cache[n]
                candidate_rows.append({
                    "url": n,
                    "candidate_origin": "repository_native_exact_url",
                    "transport_request_id": result.request_id,
                    "transport_terminal_state": result.terminal_state,
                    "http_status": result.http_status,
                    "body_sha256": result.body_sha256,
                    "admitted_source": False,
                    "field_classification": None,
                })
                seen.add(n)

        if obligation["mode"] == "bounded_official_route_discovery":
            discovered: set[str] = set()
            allowed_hosts = {host_of(root) for root in obligation["official_roots"]}
            for root_raw in obligation["official_roots"]:
                root = normalize_url(root_raw)
                if not root:
                    continue
                for result in discovery_results_by_root.get(root, []):
                    body = body_for(result)
                    for url in extract_urls(result.final_url, body, result.content_type):
                        if host_of(url) in allowed_hosts:
                            discovered.add(url)
            ranked = sorted(discovered, key=lambda u: candidate_score(u, obligation), reverse=True)
            for url in ranked:
                if url in seen:
                    continue
                score = candidate_score(url, obligation)[0]
                if score <= 0:
                    continue
                candidate_rows.append({
                    "url": url,
                    "candidate_origin": "bounded_official_discovery",
                    "transport_request_id": None,
                    "transport_terminal_state": "not_fetched_result_spawned_fetches_zero",
                    "http_status": None,
                    "body_sha256": None,
                    "discovery_score": score,
                    "admitted_source": False,
                    "field_classification": None,
                })
                seen.add(url)
                if len(candidate_rows) >= obligation["maximum_candidate_urls"]:
                    break

        assert len(candidate_rows) <= obligation["maximum_candidate_urls"]
        total_candidates += len(candidate_rows)
        cells.append({
            "obligation_id": obligation["obligation_id"],
            "state_id": obligation["state_id"],
            "field_id": obligation["field_id"],
            "mode": obligation["mode"],
            "declared_candidate_url_count": len(obligation["repository_candidate_urls"]),
            "terminal_candidate_url_count": len(candidate_rows),
            "source_admissions": 0,
            "field_classifications": 0,
            "terminalizes_field": False,
            "candidates": candidate_rows,
        })

    assert len(request_order) <= protocol["maximum_total_discovery_requests"]
    assert total_candidates <= protocol["maximum_total_candidate_urls"]
    assert len(cells) == 20
    assert sum(c["source_admissions"] for c in cells) == 0
    assert sum(c["field_classifications"] for c in cells) == 0

    request_ledger = {
        "schema_version": "ssc-rd04-next-frontier-route-discovery-request-ledger@1",
        "canonical_protocol_merge": "34583221f8d2485798fbe308241bf28fefd255ed",
        "execution_parent": os.environ.get("EXECUTION_PARENT"),
        "execution_head": os.environ.get("GITHUB_SHA"),
        "maximum_attempts_per_request": 1,
        "maximum_redirects": 4,
        "cross_host_redirects_allowed": False,
        "request_count": len(request_order),
        "requests": [request_cache[url].__dict__ for url in request_order],
    }
    candidate_ledger = {
        "schema_version": "ssc-rd04-next-frontier-route-discovery-candidate-ledger@1",
        "selected_state_ids": frontier["selected_state_ids"],
        "selected_field_ids": frontier["selected_field_ids"],
        "cell_count": len(cells),
        "candidate_url_count": total_candidates,
        "maximum_candidate_urls": protocol["maximum_total_candidate_urls"],
        "result_spawned_source_fetches": 0,
        "source_admissions": 0,
        "field_classifications": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "outside_human_dependency": False,
        "cells": cells,
    }
    execution_receipt = {
        "schema_version": "ssc-rd04-next-frontier-route-discovery-execution-receipt@1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "repository": os.environ.get("GITHUB_REPOSITORY"),
        "workflow_run": os.environ.get("GITHUB_RUN_ID"),
        "workflow_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
        "execution_branch": os.environ.get("GITHUB_REF_NAME"),
        "execution_head": os.environ.get("GITHUB_SHA"),
        "canonical_protocol_merge": "34583221f8d2485798fbe308241bf28fefd255ed",
        "canonical_rd04_merge": "a464dbbd96c365a7c040e17847486c5b3ba05c27",
        "selected_state_count": 5,
        "selected_field_count": 4,
        "obligation_count": 20,
        "request_count": len(request_order),
        "http_success_count": sum(1 for url in request_order if request_cache[url].terminal_state == "http_success"),
        "http_non_success_count": sum(1 for url in request_order if request_cache[url].terminal_state == "http_non_success"),
        "cross_host_redirect_refusal_count": sum(1 for url in request_order if request_cache[url].terminal_state == "cross_host_redirect_refused"),
        "transport_error_count": sum(1 for url in request_order if request_cache[url].terminal_state == "transport_error"),
        "candidate_url_count": total_candidates,
        "source_admissions": 0,
        "field_classifications": 0,
        "row_state_mutations": 0,
        "terminal_cells_before": 218,
        "terminal_cells_after": 218,
        "open_substantive_cells_before": 192,
        "open_substantive_cells_after": 192,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
    }
    write_json(OUT / "request-ledger.json", request_ledger)
    write_json(OUT / "candidate-ledger.json", candidate_ledger)
    write_json(OUT / "execution-receipt.json", execution_receipt)

    manifest_entries: list[dict[str, Any]] = []
    for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name not in {"manifest.json", "SHA256SUMS"}):
        data = path.read_bytes()
        manifest_entries.append({
            "path": path.relative_to(OUT).as_posix(),
            "bytes": len(data),
            "sha256": sha256_bytes(data),
        })
    combined = hashlib.sha256()
    for entry in manifest_entries:
        combined.update(entry["path"].encode("utf-8") + b"\0" + entry["sha256"].encode("ascii") + b"\n")
    manifest = {
        "schema_version": "ssc-rd04-next-frontier-route-discovery-artifact-manifest@1",
        "entry_count": len(manifest_entries),
        "entries": manifest_entries,
        "combined_sha256": combined.hexdigest(),
    }
    write_json(OUT / "manifest.json", manifest)
    sums = "".join(f"{entry['sha256']}  {entry['path']}\n" for entry in manifest_entries)
    (OUT / "SHA256SUMS").write_text(sums, encoding="utf-8")

    print(json.dumps(execution_receipt, indent=2, sort_keys=True))
    print(f"artifact_manifest_entries={len(manifest_entries)} combined_sha256={manifest['combined_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
