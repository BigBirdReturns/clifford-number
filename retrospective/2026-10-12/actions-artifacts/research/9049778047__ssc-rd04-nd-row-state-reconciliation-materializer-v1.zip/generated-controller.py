#!/usr/bin/env python3
from __future__ import annotations

import base64
import hashlib
import json
import lzma
import os
import pathlib
import shutil
import subprocess
import tarfile
import tempfile
import traceback
from typing import Any

REPO = pathlib.Path.cwd()
OUT = pathlib.Path(os.environ["OUT"])
PRODUCT_WORK = pathlib.Path(os.environ["PRODUCT_WORK"])
QUAL_WORK = pathlib.Path(os.environ["QUAL_WORK"])

CANONICAL_PARENT = os.environ["CANONICAL_PARENT"]
CANONICAL_PARENT_TREE = os.environ["CANONICAL_PARENT_TREE"]
BASE_BRANCH = os.environ["BASE_BRANCH"]
HEAD_BRANCH = os.environ["HEAD_BRANCH"]
NONWORKFLOW_BRANCH = os.environ["NONWORKFLOW_BRANCH"]
WORKFLOW_PATH = os.environ["WORKFLOW_PATH"]
CONTROLLER_PATH = os.environ["CONTROLLER_PATH"]
CONTROLLER_PAYLOAD_PATH = os.environ["CONTROLLER_PAYLOAD_PATH"]
SOURCE_PAYLOAD_PATH = os.environ["SOURCE_PAYLOAD_PATH"]
STANDING_WORKFLOW_CARRIER_PATH = os.environ["STANDING_WORKFLOW_CARRIER_PATH"]
TRIGGER_PATH = os.environ["TRIGGER_PATH"]
FINAL_WORKFLOW_PATH = os.environ["FINAL_WORKFLOW_PATH"]
PRODUCT_ROOT = os.environ["PRODUCT_ROOT"]

SOURCE_PATHS = [
    f"{PRODUCT_ROOT}/input-custody.json",
    f"{PRODUCT_ROOT}/row-state-decision.json",
    f"{PRODUCT_ROOT}/product-manifest.json",
    "docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md",
    "schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json",
    "test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js",
    "tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs",
    "tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs",
]
DERIVED_PATHS = [
    f"{PRODUCT_ROOT}/row-state-ledger.json",
    f"{PRODUCT_ROOT}/promoted-partial-field-matrix.json",
    f"{PRODUCT_ROOT}/remaining-open-field-census.json",
    f"{PRODUCT_ROOT}/row-state-summary.json",
    f"{PRODUCT_ROOT}/index.json",
]
PERMANENT_PATHS = [
    FINAL_WORKFLOW_PATH,
    f"{PRODUCT_ROOT}/input-custody.json",
    f"{PRODUCT_ROOT}/row-state-decision.json",
    f"{PRODUCT_ROOT}/row-state-ledger.json",
    f"{PRODUCT_ROOT}/promoted-partial-field-matrix.json",
    f"{PRODUCT_ROOT}/remaining-open-field-census.json",
    f"{PRODUCT_ROOT}/row-state-summary.json",
    f"{PRODUCT_ROOT}/index.json",
    f"{PRODUCT_ROOT}/product-manifest.json",
    "docs/milestones/ssc-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.md",
    "schemas/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.schema.json",
    "test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js",
    "tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs",
    "tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs",
]
NONWORKFLOW_PATHS = [p for p in PERMANENT_PATHS if p != FINAL_WORKFLOW_PATH]
CARRIER_BASE_PATHS = sorted([
    WORKFLOW_PATH,
    CONTROLLER_PATH,
    CONTROLLER_PAYLOAD_PATH,
    SOURCE_PAYLOAD_PATH,
    STANDING_WORKFLOW_CARRIER_PATH,
])

EXPECTED_SOURCE_B64_BYTES = 19_804
EXPECTED_SOURCE_B64_SHA256 = "ae8be1ee9f30575cdbc5d31bcad3a9d4238b23e85c5ad1c6125ad6f184883642"
EXPECTED_SOURCE_B64_GIT_BLOB = "fb8afd6507d1d5e8a016ce0858aaf5d01955da8a"
EXPECTED_SOURCE_XZ_BYTES = 14_852
EXPECTED_SOURCE_XZ_SHA256 = "4a735e9bc51ce471e39bfb3ded66f410735fe16b31123d7d5bdd80163fa01865"
EXPECTED_SOURCE_TAR_BYTES = 92_160
EXPECTED_SOURCE_TAR_SHA256 = "9b1ccf3e4799011ae968cbf4f5eb9e2118e5de254bfd2c80907930fd47f8bb87"
EXPECTED_STANDING_WORKFLOW_BYTES = 7_747
EXPECTED_STANDING_WORKFLOW_SHA256 = "25da2b10c5df34e508227a5b20cbde3515191c089de90a47506c77e4fc1eae40"
EXPECTED_STANDING_WORKFLOW_GIT_BLOB = "2b3fc9ee7487c2680aea16bf81796c21b784d63e"
EXPECTED_MANIFEST_SHA256 = "2fb1c4700d75471db82f28bd677ef14d7be72abf52dad26d4a2dc125440642e0"
EXPECTED_MANIFEST_GIT_BLOB = "c4046fccd195c37abe1acd99838b9a627e3ff5e9"
EXPECTED_MANIFEST_COMBINED_SHA256 = "cc636ffde05aad044008f75749163c39fad3e7d9b5109dd3b66cfe0c0b1b8883"
EXPECTED_MATRIX_BYTES = 499_646
EXPECTED_MATRIX_SHA256 = "54435248dcc17d4fa225868156a55f9d4c77fc2d6c9e9955366f1ed6253e464c"
EXPECTED_MATRIX_GIT_BLOB = "5738d59c2f578dc3b18c31f36d16b323d817a637"
EXPECTED_PREDECESSOR_MATRIX_GIT_BLOB = "c25a1ad8fdfe82f70f1ff71e61da6796be94c737"
EXPECTED_PROPOSED_ROW_STATE_SHA256 = "8107bfa8bcc247bfb02a8207d644c216e925ab89319ffce57b403f0e138c2139"
EXPECTED_RECONCILED_ND_ROW_SHA256 = "cbbd017c2eeb9ce10e1df8c372f095c3a1382387d5184225c1a566465e9dcd07"

PUBLISHED_COMMIT: str | None = None


def run(args: list[str], *, cwd: pathlib.Path = REPO, check: bool = True, env: dict[str, str] | None = None) -> str:
    proc = subprocess.run(
        args,
        cwd=cwd,
        env=env,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    if check and proc.returncode:
        raise RuntimeError(f"command failed ({proc.returncode}): {' '.join(args)}\n{proc.stdout}")
    return proc.stdout.strip()


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def exact_names(base: str, head: str, *, cwd: pathlib.Path = REPO) -> list[str]:
    text = run(["git", "diff", "--name-only", base, head], cwd=cwd)
    return sorted(line for line in text.splitlines() if line)


def exact_status(base: str, head: str, *, cwd: pathlib.Path = REPO) -> list[tuple[str, str]]:
    text = run(["git", "diff", "--name-status", base, head], cwd=cwd)
    rows: list[tuple[str, str]] = []
    for line in text.splitlines():
        if not line:
            continue
        status, path = line.split("\t", 1)
        rows.append((status, path))
    return sorted(rows)


def remote_head(branch: str, *, cwd: pathlib.Path = REPO) -> str | None:
    text = run(["git", "ls-remote", "--heads", "origin", f"refs/heads/{branch}"], cwd=cwd)
    return text.split()[0] if text else None


def write_checksums() -> None:
    rows = []
    for path in sorted(OUT.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS":
            continue
        rel = path.relative_to(OUT).as_posix()
        rows.append(f"{sha256(path.read_bytes())}  {rel}")
    (OUT / "SHA256SUMS").write_text("\n".join(rows) + "\n", encoding="utf-8")


def load_trigger() -> dict[str, Any]:
    trigger = json.loads((REPO / TRIGGER_PATH).read_text(encoding="utf-8"))
    expected_keys = {
        "schema_version", "canonical_parent", "carrier_base_commit", "controller_bytes", "controller_sha256",
        "controller_payload_bytes", "controller_payload_sha256", "controller_source_bytes", "controller_source_sha256",
        "source_base64_bytes", "source_base64_sha256", "source_xz_bytes", "source_xz_sha256",
        "source_tar_bytes", "source_tar_sha256", "standing_workflow_bytes", "standing_workflow_sha256",
        "standing_workflow_git_blob", "permanent_paths", "published_nonworkflow_paths", "matrix_updates",
        "row_state_mutations", "row_terminalizations", "field_terminalizations", "class_closed",
        "cumulative_ledger_effect", "outside_human_dependency",
    }
    if set(trigger) != expected_keys:
        raise RuntimeError("trigger key set mismatch")
    return trigger


def bind_carrier(trigger: dict[str, Any]) -> tuple[str, str]:
    head = run(["git", "rev-parse", "HEAD"])
    base = run(["git", "rev-parse", "HEAD^"])
    if head != os.environ["EVENT_HEAD_SHA"] or base != os.environ["EVENT_BASE_SHA"]:
        raise RuntimeError("pull-request event topology mismatch")
    if trigger["carrier_base_commit"] != base:
        raise RuntimeError("trigger base commit mismatch")
    if run(["git", "rev-parse", f"{base}^"]) != CANONICAL_PARENT:
        raise RuntimeError("carrier base parent mismatch")
    if run(["git", "rev-parse", f"{CANONICAL_PARENT}^{{tree}}"]) != CANONICAL_PARENT_TREE:
        raise RuntimeError("canonical parent tree mismatch")
    if run(["git", "rev-list", "--count", f"{CANONICAL_PARENT}..{base}"]) != "1":
        raise RuntimeError("carrier base commit denominator mismatch")
    if run(["git", "rev-list", "--count", f"{base}..{head}"]) != "1":
        raise RuntimeError("carrier trigger commit denominator mismatch")
    if exact_names(CANONICAL_PARENT, base) != CARRIER_BASE_PATHS:
        raise RuntimeError("carrier base path denominator mismatch")
    if exact_status(CANONICAL_PARENT, base) != [("A", p) for p in CARRIER_BASE_PATHS]:
        raise RuntimeError("carrier base must be addition-only")
    if exact_names(base, head) != [TRIGGER_PATH] or exact_status(base, head) != [("A", TRIGGER_PATH)]:
        raise RuntimeError("carrier trigger path denominator mismatch")
    run(["git", "diff", "--check", CANONICAL_PARENT, head])

    controller = (REPO / CONTROLLER_PATH).read_bytes()
    if len(controller) != trigger["controller_bytes"] or sha256(controller) != trigger["controller_sha256"]:
        raise RuntimeError("controller identity mismatch")
    return base, head


def bind_live_leases() -> None:
    run(["git", "fetch", "--no-tags", "--force", "origin", "+refs/heads/main:refs/remotes/origin/main"])
    if run(["git", "rev-parse", "origin/main"]) != CANONICAL_PARENT:
        raise RuntimeError("live main moved")
    if remote_head(NONWORKFLOW_BRANCH) is not None:
        raise RuntimeError("nonworkflow product branch already exists")


def extract_source(trigger: dict[str, Any]) -> pathlib.Path:
    payload = (REPO / SOURCE_PAYLOAD_PATH).read_bytes()
    if len(payload) != EXPECTED_SOURCE_B64_BYTES or sha256(payload) != EXPECTED_SOURCE_B64_SHA256 or git_blob(payload) != EXPECTED_SOURCE_B64_GIT_BLOB:
        raise RuntimeError("source base64 identity mismatch")
    if len(payload) != trigger["source_base64_bytes"] or sha256(payload) != trigger["source_base64_sha256"]:
        raise RuntimeError("trigger source base64 identity mismatch")
    try:
        compressed = base64.b64decode(payload, validate=True)
    except Exception as exc:
        raise RuntimeError("source base64 decode failed") from exc
    if len(compressed) != EXPECTED_SOURCE_XZ_BYTES or sha256(compressed) != EXPECTED_SOURCE_XZ_SHA256:
        raise RuntimeError("source XZ identity mismatch")
    if len(compressed) != trigger["source_xz_bytes"] or sha256(compressed) != trigger["source_xz_sha256"]:
        raise RuntimeError("trigger source XZ identity mismatch")
    archive = lzma.decompress(compressed)
    if len(archive) != EXPECTED_SOURCE_TAR_BYTES or sha256(archive) != EXPECTED_SOURCE_TAR_SHA256:
        raise RuntimeError("source tar identity mismatch")
    if len(archive) != trigger["source_tar_bytes"] or sha256(archive) != trigger["source_tar_sha256"]:
        raise RuntimeError("trigger source tar identity mismatch")

    source_dir = OUT / "source"
    source_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(suffix=".tar") as tmp:
        tmp.write(archive)
        tmp.flush()
        with tarfile.open(tmp.name, "r:") as tf:
            members = tf.getmembers()
            names = [m.name for m in members]
            if names != SOURCE_PATHS:
                raise RuntimeError("source tar path order or denominator mismatch")
            for member in members:
                pure = pathlib.PurePosixPath(member.name)
                if not member.isfile() or pure.is_absolute() or ".." in pure.parts:
                    raise RuntimeError(f"unsafe source tar member {member.name}")
                fileobj = tf.extractfile(member)
                if fileobj is None:
                    raise RuntimeError(f"missing source tar member bytes {member.name}")
                target = source_dir / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(fileobj.read())
    return source_dir


def prepare_full_product(source_dir: pathlib.Path, trigger: dict[str, Any]) -> tuple[str, str, dict[str, Any]]:
    if PRODUCT_WORK.exists():
        shutil.rmtree(PRODUCT_WORK)
    if QUAL_WORK.exists():
        shutil.rmtree(QUAL_WORK)
    run(["git", "worktree", "add", "--detach", str(PRODUCT_WORK), CANONICAL_PARENT])

    for rel in SOURCE_PATHS:
        target = PRODUCT_WORK / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_dir / rel, target)

    workflow_bytes = (REPO / STANDING_WORKFLOW_CARRIER_PATH).read_bytes()
    if len(workflow_bytes) != EXPECTED_STANDING_WORKFLOW_BYTES or sha256(workflow_bytes) != EXPECTED_STANDING_WORKFLOW_SHA256 or git_blob(workflow_bytes) != EXPECTED_STANDING_WORKFLOW_GIT_BLOB:
        raise RuntimeError("standing workflow identity mismatch")
    if (
        len(workflow_bytes) != trigger["standing_workflow_bytes"]
        or sha256(workflow_bytes) != trigger["standing_workflow_sha256"]
        or git_blob(workflow_bytes) != trigger["standing_workflow_git_blob"]
    ):
        raise RuntimeError("trigger standing workflow identity mismatch")
    workflow_target = PRODUCT_WORK / FINAL_WORKFLOW_PATH
    workflow_target.parent.mkdir(parents=True, exist_ok=True)
    workflow_target.write_bytes(workflow_bytes)

    builder = "tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs"
    validator = "tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs"
    tests = "test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js"
    generated_root = PRODUCT_WORK / PRODUCT_ROOT
    builder_log = run(["node", builder, "--out", str(generated_root)], cwd=PRODUCT_WORK)
    (OUT / "builder.json").write_text(builder_log + "\n", encoding="utf-8")
    validator_log = run(["node", validator, "--out", str(OUT / "validator.json")], cwd=PRODUCT_WORK)
    (OUT / "validator-stdout.json").write_text(validator_log + "\n", encoding="utf-8")
    test_log = run(["node", "--test", tests], cwd=PRODUCT_WORK)
    (OUT / "adversarial.log").write_text(test_log + "\n", encoding="utf-8")

    manifest_path = PRODUCT_WORK / f"{PRODUCT_ROOT}/product-manifest.json"
    manifest_bytes = manifest_path.read_bytes()
    if sha256(manifest_bytes) != EXPECTED_MANIFEST_SHA256 or git_blob(manifest_bytes) != EXPECTED_MANIFEST_GIT_BLOB:
        raise RuntimeError("manifest identity mismatch")
    manifest = json.loads(manifest_bytes)
    if manifest["permanent_paths"] != PERMANENT_PATHS or manifest["permanent_path_count"] != 14:
        raise RuntimeError("manifest permanent path inventory mismatch")
    if manifest["hashed_file_count"] != 13 or len(manifest["hashed_files"]) != 13:
        raise RuntimeError("manifest hashed file denominator mismatch")
    if manifest["combined_sha256"] != EXPECTED_MANIFEST_COMBINED_SHA256:
        raise RuntimeError("manifest combined digest mismatch")
    authority = manifest["authority_boundary"]
    expected_authority = {
        "source_requests": 0,
        "route_executions": 0,
        "source_admissions": 0,
        "field_terminalizations": 0,
        "matrix_updates": 1,
        "row_state_mutations": 1,
        "row_terminalizations": 1,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "outside_human_dependency": False,
    }
    if authority != expected_authority:
        raise RuntimeError("manifest authority boundary mismatch")

    hashed_paths = [row["path"] for row in manifest["hashed_files"]]
    if hashed_paths != [p for p in PERMANENT_PATHS if not p.endswith("product-manifest.json")]:
        raise RuntimeError("manifest hashed path inventory mismatch")
    digest_rows: list[str] = []
    for record in manifest["hashed_files"]:
        rel = record["path"]
        data = (PRODUCT_WORK / rel).read_bytes()
        actual = {
            "path": rel,
            "bytes": len(data),
            "sha256": sha256(data),
            "git_blob": git_blob(data),
        }
        if actual != record:
            raise RuntimeError(f"manifest file identity mismatch {rel}")
        digest_rows.append(f"{rel}\0{actual['sha256']}\0{actual['bytes']}\n")
    if sha256("".join(sorted(digest_rows)).encode("utf-8")) != manifest["combined_sha256"]:
        raise RuntimeError("manifest combined digest reproduction mismatch")

    matrix = (PRODUCT_WORK / f"{PRODUCT_ROOT}/promoted-partial-field-matrix.json").read_bytes()
    if len(matrix) != EXPECTED_MATRIX_BYTES or sha256(matrix) != EXPECTED_MATRIX_SHA256 or git_blob(matrix) != EXPECTED_MATRIX_GIT_BLOB:
        raise RuntimeError("promoted matrix identity mismatch")
    matrix_obj = json.loads(matrix)
    nd = next(row for row in matrix_obj["rows"] if row["unit_id"] == "US-STATE-ND")
    row_cell = next(cell for cell in nd["cells"] if cell["field_id"] == "field_and_row_terminal_state")
    if sha256(canonical(row_cell)) != EXPECTED_PROPOSED_ROW_STATE_SHA256:
        raise RuntimeError("proposed row-state cell identity mismatch")
    if sha256(canonical(nd)) != EXPECTED_RECONCILED_ND_ROW_SHA256:
        raise RuntimeError("reconciled North Dakota row identity mismatch")
    if nd["terminal_fields"] != 9 or nd["open_fields"] != 0 or nd["row_state"] != "terminal_fixed_public_record_obligation_complete":
        raise RuntimeError("North Dakota row terminal state mismatch")
    counts = matrix_obj["counts"]
    if not (
        counts["terminal_cells"] == 229
        and counts["still_open_cells"] == 221
        and counts["terminal_substantive_cells"] == 118
        and counts["still_open_substantive_cells"] == 182
        and counts["row_terminal_state_cells_terminal"] == 11
        and counts["row_terminal_state_cells_open"] == 39
        and counts["terminal_units"] == 11
        and counts["class_closed"] is False
    ):
        raise RuntimeError("promoted matrix count mismatch")

    predecessor_blob = run([
        "git", "rev-parse",
        f"{CANONICAL_PARENT}:data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-nd-current-public-record-gap-promotion/promoted-partial-field-matrix.json",
    ], cwd=PRODUCT_WORK)
    if predecessor_blob != EXPECTED_PREDECESSOR_MATRIX_GIT_BLOB:
        raise RuntimeError("canonical predecessor matrix blob mismatch")

    status = run(["git", "status", "--porcelain=v1", "--untracked-files=all"], cwd=PRODUCT_WORK)
    observed = sorted(line[3:] for line in status.splitlines() if line)
    if observed != sorted(PERMANENT_PATHS):
        raise RuntimeError("constructed full product working-tree denominator mismatch")

    run(["git", "add", "--", *PERMANENT_PATHS], cwd=PRODUCT_WORK)
    full_tree = run(["git", "write-tree"], cwd=PRODUCT_WORK)
    full_commit = commit_tree(
        full_tree,
        "Qualify RD-04 North Dakota derivative row-state reconciliation\n\n"
        "Construct the exact fourteen-path product, terminalize only the derivative North Dakota row-state cell, "
        "preserve all eight substantive cells and the class-open boundary, and bind one matrix update, one row-state mutation, and one row terminalization.",
        cwd=PRODUCT_WORK,
    )
    if exact_status(CANONICAL_PARENT, full_commit, cwd=PRODUCT_WORK) != [("A", p) for p in sorted(PERMANENT_PATHS)]:
        raise RuntimeError("qualified full product topology mismatch")
    return full_commit, full_tree, manifest


def commit_tree(tree: str, message: str, *, cwd: pathlib.Path) -> str:
    env = os.environ.copy()
    env.update({
        "GIT_AUTHOR_NAME": "BigBirdReturns",
        "GIT_AUTHOR_EMAIL": "219768509+BigBirdReturns@users.noreply.github.com",
        "GIT_COMMITTER_NAME": "BigBirdReturns",
        "GIT_COMMITTER_EMAIL": "219768509+BigBirdReturns@users.noreply.github.com",
    })
    proc = subprocess.run(
        ["git", "commit-tree", tree, "-p", CANONICAL_PARENT],
        cwd=cwd,
        env=env,
        input=message + "\n",
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if proc.returncode:
        raise RuntimeError(proc.stdout)
    commit = proc.stdout.strip()
    if run(["git", "rev-parse", f"{commit}^"] , cwd=cwd) != CANONICAL_PARENT:
        raise RuntimeError("constructed commit parent mismatch")
    return commit


def qualify_full_product(full_commit: str, full_tree: str) -> None:
    run(["git", "worktree", "add", "--detach", str(QUAL_WORK), full_commit])
    builder = "tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs"
    validator = "tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.mjs"
    tests = "test/status-sovereignty-rd-wave03-rd04-postpromotion-nd-row-state-reconciliation.test.js"
    (OUT / "qualification-tree.txt").write_text(full_tree + "\n", encoding="utf-8")
    (OUT / "qualification-commit.txt").write_text(full_commit + "\n", encoding="utf-8")
    post_builder = run(["node", builder, "--check"], cwd=QUAL_WORK)
    (OUT / "qualification-builder.json").write_text(post_builder + "\n", encoding="utf-8")
    post_validator = run(["node", validator, "--out", str(OUT / "qualification-validator.json")], cwd=QUAL_WORK)
    (OUT / "qualification-validator-stdout.json").write_text(post_validator + "\n", encoding="utf-8")
    post_tests = run(["node", "--test", tests], cwd=QUAL_WORK)
    (OUT / "qualification-adversarial.log").write_text(post_tests + "\n", encoding="utf-8")

    before = {rel: (QUAL_WORK / rel).read_bytes() for rel in PERMANENT_PATHS}
    release = run(["npm", "run", "release:check"], cwd=QUAL_WORK)
    (OUT / "release-check.log").write_text(release + "\n", encoding="utf-8")
    for rel, expected in before.items():
        if (QUAL_WORK / rel).read_bytes() != expected:
            raise RuntimeError(f"release gate changed permanent product file {rel}")
    run(["git", "reset", "--hard", full_commit], cwd=QUAL_WORK)
    run(["git", "clean", "-fdx"], cwd=QUAL_WORK)
    if run(["git", "status", "--porcelain"], cwd=QUAL_WORK):
        raise RuntimeError("qualification worktree did not return clean")
    if run(["git", "rev-parse", "HEAD^{tree}"], cwd=QUAL_WORK) != full_tree:
        raise RuntimeError("qualification tree drift")


def construct_nonworkflow(full_commit: str, full_tree: str) -> tuple[str, str]:
    index_path = OUT / "nonworkflow.index"
    if index_path.exists():
        index_path.unlink()
    env = os.environ.copy()
    env["GIT_INDEX_FILE"] = str(index_path)
    run(["git", "read-tree", full_commit], env=env)
    run(["git", "update-index", "--force-remove", "--", FINAL_WORKFLOW_PATH], env=env)
    nonworkflow_tree = run(["git", "write-tree"], env=env)
    nonworkflow_commit = commit_tree(
        nonworkflow_tree,
        "Materialize RD-04 North Dakota derivative row-state reconciliation nonworkflow product\n\n"
        "Publish the thirteen exact non-workflow paths of the qualified fourteen-path product. "
        "The independently qualified standing workflow remains under repository-authority custody.",
        cwd=REPO,
    )
    expected = [("A", p) for p in sorted(NONWORKFLOW_PATHS)]
    if exact_status(CANONICAL_PARENT, nonworkflow_commit) != expected:
        raise RuntimeError("nonworkflow product topology mismatch")
    if run(["git", "rev-parse", f"{nonworkflow_commit}^{{tree}}"]) != nonworkflow_tree:
        raise RuntimeError("nonworkflow tree mismatch")

    verify_index = OUT / "full-tree-reconstruction.index"
    if verify_index.exists():
        verify_index.unlink()
    verify_env = os.environ.copy()
    verify_env["GIT_INDEX_FILE"] = str(verify_index)
    run(["git", "read-tree", nonworkflow_commit], env=verify_env)
    run([
        "git", "update-index", "--add", "--cacheinfo",
        f"100644,{EXPECTED_STANDING_WORKFLOW_GIT_BLOB},{FINAL_WORKFLOW_PATH}",
    ], env=verify_env)
    reconstructed_full_tree = run(["git", "write-tree"], env=verify_env)
    if reconstructed_full_tree != full_tree:
        raise RuntimeError("full product tree reconstruction mismatch")
    return nonworkflow_commit, nonworkflow_tree


def publish_nonworkflow(nonworkflow_commit: str) -> None:
    global PUBLISHED_COMMIT
    bind_live_leases()
    run([
        "git", "push",
        f"--force-with-lease=refs/heads/{NONWORKFLOW_BRANCH}:",
        "origin", f"{nonworkflow_commit}:refs/heads/{NONWORKFLOW_BRANCH}",
    ])
    PUBLISHED_COMMIT = nonworkflow_commit
    if remote_head(NONWORKFLOW_BRANCH) != nonworkflow_commit:
        raise RuntimeError("nonworkflow branch publication observation mismatch")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    trigger = load_trigger()
    base, head = bind_carrier(trigger)
    bind_live_leases()
    source_dir = extract_source(trigger)
    full_commit, full_tree, manifest = prepare_full_product(source_dir, trigger)
    qualify_full_product(full_commit, full_tree)
    nonworkflow_commit, nonworkflow_tree = construct_nonworkflow(full_commit, full_tree)
    publish_nonworkflow(nonworkflow_commit)

    receipt = {
        "schema_version": "ssc-rd04-nd-row-state-reconciliation-materializer-receipt@1",
        "state": "published_qualified_nonworkflow_product",
        "canonical_parent": CANONICAL_PARENT,
        "canonical_parent_tree": CANONICAL_PARENT_TREE,
        "carrier_base": base,
        "carrier_head": head,
        "source_base64_bytes": EXPECTED_SOURCE_B64_BYTES,
        "source_base64_sha256": EXPECTED_SOURCE_B64_SHA256,
        "source_xz_bytes": EXPECTED_SOURCE_XZ_BYTES,
        "source_xz_sha256": EXPECTED_SOURCE_XZ_SHA256,
        "source_tar_bytes": EXPECTED_SOURCE_TAR_BYTES,
        "source_tar_sha256": EXPECTED_SOURCE_TAR_SHA256,
        "qualified_full_product_commit": full_commit,
        "qualified_full_product_tree": full_tree,
        "nonworkflow_product_commit": nonworkflow_commit,
        "nonworkflow_product_tree": nonworkflow_tree,
        "nonworkflow_branch": NONWORKFLOW_BRANCH,
        "permanent_path_count": 14,
        "published_nonworkflow_path_count": 13,
        "standing_workflow_git_blob": EXPECTED_STANDING_WORKFLOW_GIT_BLOB,
        "manifest_sha256": EXPECTED_MANIFEST_SHA256,
        "manifest_combined_sha256": EXPECTED_MANIFEST_COMBINED_SHA256,
        "promoted_matrix_bytes": EXPECTED_MATRIX_BYTES,
        "promoted_matrix_sha256": EXPECTED_MATRIX_SHA256,
        "promoted_matrix_git_blob": EXPECTED_MATRIX_GIT_BLOB,
        "proposed_row_state_cell_sha256": EXPECTED_PROPOSED_ROW_STATE_SHA256,
        "reconciled_north_dakota_row_sha256": EXPECTED_RECONCILED_ND_ROW_SHA256,
        "field_terminalizations": 0,
        "matrix_updates": 1,
        "row_state_mutations": 1,
        "row_terminalizations": 1,
        "terminal_cells_before": 228,
        "terminal_cells_after": 229,
        "terminal_units_before": 10,
        "terminal_units_after": 11,
        "north_dakota_before": "8/1",
        "north_dakota_after": "9/0",
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "outside_human_dependency": False,
        "manifest_authority_boundary": manifest["authority_boundary"],
    }
    (OUT / "materialization-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    for rel in [
        f"{PRODUCT_ROOT}/row-state-decision.json",
        f"{PRODUCT_ROOT}/row-state-ledger.json",
        f"{PRODUCT_ROOT}/row-state-summary.json",
        f"{PRODUCT_ROOT}/product-manifest.json",
    ]:
        target = OUT / "product" / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PRODUCT_WORK / rel, target)
    write_checksums()
    print(json.dumps(receipt, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        OUT.mkdir(parents=True, exist_ok=True)
        rollback = {"attempted": False, "deleted": False, "observed_head": None}
        try:
            if PUBLISHED_COMMIT is not None:
                rollback["attempted"] = True
                observed = remote_head(NONWORKFLOW_BRANCH)
                rollback["observed_head"] = observed
                if observed == PUBLISHED_COMMIT:
                    run(["git", "push", "origin", f":refs/heads/{NONWORKFLOW_BRANCH}"])
                    rollback["deleted"] = remote_head(NONWORKFLOW_BRANCH) is None
        except Exception as rollback_exc:
            rollback["error"] = str(rollback_exc)
        failure = {
            "schema_version": "ssc-rd04-nd-row-state-reconciliation-materializer-failure@1",
            "state": "failed_closed",
            "exception_type": type(exc).__name__,
            "exception": str(exc),
            "traceback": traceback.format_exc(),
            "canonical_parent": CANONICAL_PARENT,
            "nonworkflow_branch": NONWORKFLOW_BRANCH,
            "published_commit": PUBLISHED_COMMIT,
            "rollback": rollback,
        }
        (OUT / "failure.json").write_text(json.dumps(failure, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        write_checksums()
        raise
