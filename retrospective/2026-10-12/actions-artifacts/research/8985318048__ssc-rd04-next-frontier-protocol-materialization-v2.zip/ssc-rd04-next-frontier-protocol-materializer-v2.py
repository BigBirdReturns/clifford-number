from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import traceback
import urllib.parse
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

REPOSITORY = os.environ.get('GITHUB_REPOSITORY', 'BigBirdReturns/clifford-number')
CANONICAL_RD04_MERGE = 'a464dbbd96c365a7c040e17847486c5b3ba05c27'
PRODUCT_BRANCH = 'agent/ssc-rd-wave03-rd04-next-minimum-frontier-route-discovery-protocol-v1'
SLUG = 'status-sovereignty-rd-wave03-rd04-next-minimum-frontier-route-discovery-protocol'
DATA_DIR = f'data/intake/{SLUG}'
MATRIX_PATH = 'data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/promoted-partial-field-matrix.json'
OPEN_CENSUS_PATH = 'data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/remaining-open-field-census.json'
DERIVATIVE_FIELD = 'field_and_row_terminal_state'
OUT = Path('/tmp/ssc-rd04-next-frontier-protocol-v1')
WT = Path('/tmp/ssc-rd04-next-frontier-protocol-v1-worktree')

PERMANENT_PATHS = [
    f'{DATA_DIR}/frontier-selection.json',
    f'{DATA_DIR}/predecessor-custody.json',
    f'{DATA_DIR}/official-locator-inventory.json',
    f'{DATA_DIR}/route-query-contract.json',
    f'{DATA_DIR}/route-discovery-protocol.json',
    f'{DATA_DIR}/summary.json',
    f'{DATA_DIR}/product-manifest.json',
    f'docs/milestones/{SLUG}.md',
    f'schemas/{SLUG}.schema.json',
    f'test/{SLUG}.test.js',
    f'tools/build-{SLUG}.mjs',
    f'tools/validate-{SLUG}.mjs',
    'tools/acquisition/status-sovereignty-rd-wave03-rd04-next-frontier/plan-official-route-discovery.py',
]

STATE_NAMES = {
    'AL':'Alabama','AK':'Alaska','AZ':'Arizona','AR':'Arkansas','CA':'California','CO':'Colorado','CT':'Connecticut','DE':'Delaware','FL':'Florida','GA':'Georgia','HI':'Hawaii','ID':'Idaho','IL':'Illinois','IN':'Indiana','IA':'Iowa','KS':'Kansas','KY':'Kentucky','LA':'Louisiana','ME':'Maine','MD':'Maryland','MA':'Massachusetts','MI':'Michigan','MN':'Minnesota','MS':'Mississippi','MO':'Missouri','MT':'Montana','NE':'Nebraska','NV':'Nevada','NH':'New Hampshire','NJ':'New Jersey','NM':'New Mexico','NY':'New York','NC':'North Carolina','ND':'North Dakota','OH':'Ohio','OK':'Oklahoma','OR':'Oregon','PA':'Pennsylvania','RI':'Rhode Island','SC':'South Carolina','SD':'South Dakota','TN':'Tennessee','TX':'Texas','UT':'Utah','VT':'Vermont','VA':'Virginia','WA':'Washington','WV':'West Virginia','WI':'Wisconsin','WY':'Wyoming'
}


def run(args: list[str], cwd: Path | None = None, check: bool = True, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(args, cwd=str(cwd) if cwd else None, text=True, capture_output=True, env=env)
    with (OUT / 'run.log').open('a', encoding='utf-8') as fh:
        fh.write('$ ' + ' '.join(args) + '\n')
        fh.write(result.stdout)
        fh.write(result.stderr)
        fh.write(f'[exit {result.returncode}]\n')
    if check and result.returncode:
        raise RuntimeError(f'command failed ({result.returncode}): {args!r}')
    return result


def git(*args: str, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    return run(['git', *args], cwd=cwd, check=check)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def git_blob_bytes(data: bytes) -> str:
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


def dump(value: Any) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + '\n'


def walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def strings(value: Any) -> Iterable[str]:
    for node in walk(value):
        if isinstance(node, str):
            yield node


def load_records(path: Path) -> list[Any]:
    try:
        if path.suffix == '.json':
            return [json.loads(path.read_text(encoding='utf-8'))]
        if path.suffix == '.jsonl':
            return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]
    except Exception:
        return []
    return []


def official_host(host: str) -> bool:
    host = host.lower().rstrip('.')
    return host.endswith('.gov') or '.gov.' in host or host.endswith('.us') or host == 'fns.usda.gov'


def derive_frontier(root: Path) -> dict[str, Any]:
    matrix_path = root / MATRIX_PATH
    census_path = root / OPEN_CENSUS_PATH
    matrix = json.loads(matrix_path.read_text(encoding='utf-8'))
    census = json.loads(census_path.read_text(encoding='utf-8'))
    state_re = re.compile(r'^US-STATE-[A-Z]{2}$')
    field_re = re.compile(r'^[a-z][a-z0-9_]{3,}$')
    all_matrix_strings = list(strings(matrix))
    state_ids = sorted({s for s in all_matrix_strings if state_re.fullmatch(s)})
    contracts: list[tuple[str, ...]] = []
    for node in walk(matrix):
        if not isinstance(node, list) or len(node) != 9:
            continue
        values: list[str] = []
        for item in node:
            if isinstance(item, str) and field_re.fullmatch(item):
                values.append(item)
            elif isinstance(item, dict):
                value = next((item.get(key) for key in ('field_id','field_key','field','id','key','name') if isinstance(item.get(key), str)), None)
                if value and field_re.fullmatch(value):
                    values.append(value)
        if len(values) == 9 and len(set(values)) == 9 and DERIVATIVE_FIELD in values:
            contracts.append(tuple(values))
    if len(state_ids) != 50 or not contracts:
        raise RuntimeError(f'matrix contract recovery failed: states={len(state_ids)} contracts={len(contracts)}')
    field_ids = list(Counter(contracts).most_common(1)[0][0])
    state_set = set(state_ids)
    field_set = set(field_ids)
    pairs: set[tuple[str, str]] = set()

    def descend(node: Any, state: str | None = None, field: str | None = None) -> None:
        if isinstance(node, dict):
            scalars = [value for value in node.values() if isinstance(value, str)]
            states_here = [value for value in scalars if value in state_set]
            fields_here = [value for value in scalars if value in field_set]
            local_state = states_here[0] if len(states_here) == 1 else state
            local_field = fields_here[0] if len(fields_here) == 1 else field
            if local_state and local_field:
                pairs.add((local_state, local_field))
            for key, value in node.items():
                descend(value, key if key in state_set else local_state, key if key in field_set else local_field)
        elif isinstance(node, list):
            for value in node:
                descend(value, state, field)
        elif isinstance(node, str):
            local_state = node if node in state_set else state
            local_field = node if node in field_set else field
            if local_state and local_field:
                pairs.add((local_state, local_field))

    descend(census)
    by_state: dict[str, set[str]] = defaultdict(set)
    for state, field in pairs:
        by_state[state].add(field)
    substantive = {
        state: tuple(sorted(fields - {DERIVATIVE_FIELD}))
        for state, fields in by_state.items()
        if fields - {DERIVATIVE_FIELD}
    }
    if sum(len(fields) for fields in substantive.values()) != 192 or len(substantive) != 40:
        raise RuntimeError(f'open denominator drift: pairs={len(pairs)} substantive={sum(len(v) for v in substantive.values())} rows={len(substantive)}')
    minimum = min(len(fields) for fields in substantive.values())
    cohorts: dict[tuple[str, ...], list[str]] = defaultdict(list)
    for state, fields in substantive.items():
        if len(fields) == minimum:
            cohorts[fields].append(state)
    ranked = sorted(
        ((fields, tuple(sorted(states))) for fields, states in cohorts.items()),
        key=lambda item: (-len(item[1]), item[0], item[1]),
    )
    selected_fields, selected_states = ranked[0]
    return {
        'state_ids': state_ids,
        'field_ids': field_ids,
        'open_pairs': [{'state_id': state, 'field_id': field} for state, field in sorted(pairs)],
        'minimum': minimum,
        'minimum_cohorts': [
            {'field_ids': list(fields), 'state_ids': list(states), 'row_count': len(states)}
            for fields, states in ranked
        ],
        'selected_state_ids': list(selected_states),
        'selected_field_ids': list(selected_fields),
        'selected_state_count': len(selected_states),
        'selected_cell_count': len(selected_states) * len(selected_fields),
        'matrix_sha256': sha256_file(matrix_path),
        'open_census_sha256': sha256_file(census_path),
    }


def inventory_routes(root: Path, frontier: dict[str, Any]) -> dict[str, Any]:
    selected_states = frontier['selected_state_ids']
    selected_fields = frontier['selected_field_ids']
    state_names = {state: STATE_NAMES[state[-2:]] for state in selected_states}
    url_re = re.compile(r'https?://[^\s<>"\']+')
    rows: list[dict[str, Any]] = []
    scanned: list[Path] = []
    for top in ('data','docs','schemas','test','tools'):
        base = root / top
        if not base.exists():
            continue
        for path in base.rglob('*'):
            if path.is_file() and ('rd04' in str(path).lower() or 'rd-04' in str(path).lower()) and path.suffix.lower() in ('.json','.jsonl','.md','.mjs','.js','.py','.yml','.yaml'):
                scanned.append(path)
    for path in scanned:
        records = load_records(path)
        if records:
            for ordinal, record in enumerate(records, 1):
                for node in walk(record):
                    if not isinstance(node, dict):
                        continue
                    scalar_strings = set(strings(node))
                    states = [state for state in selected_states if state in scalar_strings or state_names[state] in scalar_strings]
                    fields = [field for field in selected_fields if field in scalar_strings]
                    urls = sorted({url.rstrip('.,);]') for text in scalar_strings for url in url_re.findall(text)})
                    if len(states) != 1 or not fields or not urls:
                        continue
                    route_id = next((node.get(key) for key in ('route_id','source_route_id','id','candidate_id') if isinstance(node.get(key), str)), None)
                    status_text = ' '.join(scalar_strings).lower()
                    for url in urls:
                        host = (urllib.parse.urlparse(url).hostname or '').lower()
                        rows.append({
                            'state_id': states[0],
                            'field_ids': sorted(fields),
                            'url': url,
                            'host': host,
                            'official_host': official_host(host),
                            'route_id': route_id,
                            'source_path': str(path.relative_to(root)),
                            'record_ordinal': ordinal,
                            'prior_capture_marker': any(token in status_text for token in ('captured','http_success','terminal_route','admitted')),
                            'prior_nonadmission_marker': any(token in status_text for token in ('not_admitted','rejected','transport_failure','not_publicly_recovered')),
                        })
        else:
            text = path.read_text(encoding='utf-8', errors='ignore')
            lowered = text.lower()
            urls = sorted({url.rstrip('.,);]') for url in url_re.findall(text)})
            if not urls:
                continue
            for state in selected_states:
                if state not in text and state_names[state].lower() not in lowered:
                    continue
                fields = [field for field in selected_fields if field in text]
                if not fields:
                    continue
                for url in urls:
                    host = (urllib.parse.urlparse(url).hostname or '').lower()
                    rows.append({
                        'state_id': state,
                        'field_ids': sorted(fields),
                        'url': url,
                        'host': host,
                        'official_host': official_host(host),
                        'route_id': None,
                        'source_path': str(path.relative_to(root)),
                        'record_ordinal': None,
                        'prior_capture_marker': False,
                        'prior_nonadmission_marker': False,
                    })
    unique: dict[tuple[Any, ...], dict[str, Any]] = {}
    for row in rows:
        key = (row['state_id'], tuple(row['field_ids']), row['url'], row['source_path'], row['route_id'])
        unique[key] = row
    rows = sorted(unique.values(), key=lambda row: (row['state_id'], row['url'], row['source_path']))
    coverage: dict[str, Any] = {}
    roots: dict[str, list[str]] = {}
    for state in selected_states:
        state_rows = [row for row in rows if row['state_id'] == state and row['official_host']]
        state_urls = sorted({row['url'] for row in state_rows})
        host_roots = sorted({f"{urllib.parse.urlparse(url).scheme}://{urllib.parse.urlparse(url).netloc}/" for url in state_urls if urllib.parse.urlparse(url).scheme and urllib.parse.urlparse(url).netloc})
        if not host_roots:
            raise RuntimeError(f'no repository-native official locator root for {state}')
        roots[state] = host_roots[:2]
        coverage[state] = {}
        for field in selected_fields:
            cell_rows = [row for row in state_rows if field in row['field_ids']]
            urls = sorted({row['url'] for row in cell_rows})
            fresh = sorted({row['url'] for row in cell_rows if not row['prior_capture_marker']})
            coverage[state][field] = {
                'official_repository_urls': urls,
                'uncaptured_repository_urls': fresh,
                'official_repository_url_count': len(urls),
                'uncaptured_repository_url_count': len(fresh),
            }
    return {
        'scanned_file_count': len(scanned),
        'route_rows': rows,
        'official_route_row_count': sum(1 for row in rows if row['official_host']),
        'state_official_roots': roots,
        'coverage': coverage,
    }


def query_terms(field_id: str) -> list[str]:
    explicit = {
        'operative_state_implementation_authority_and_version': ['SNAP state policy manual', 'operative implementation authority', 'effective policy version'],
        'abawd_or_work_requirement_waiver_state_and_governing_period': ['SNAP ABAWD waiver', 'work requirement waiver', 'waiver geography period'],
        'verification_evidence_and_staff_discretion_surface': ['SNAP verification policy', 'staff discretion verification', 'eligibility verification manual'],
        'screening_and_implementation_scope': ['SNAP screening implementation scope', 'eligibility screening policy'],
        'state_operative_implementation_authority': ['SNAP operative state authority', 'state implementation manual'],
        'waiver_or_equivalent_relief_path': ['SNAP waiver relief policy', 'work requirement relief'],
    }
    if field_id in explicit:
        return explicit[field_id]
    tokens = [token for token in field_id.split('_') if token not in {'and','or','the','state'}]
    return ['SNAP ' + ' '.join(tokens), 'state SNAP policy ' + ' '.join(tokens[:4])]


def write_authored_inputs(root: Path, frontier: dict[str, Any], inventory: dict[str, Any], live_main: str, successor_paths: list[str]) -> None:
    data_dir = root / DATA_DIR
    data_dir.mkdir(parents=True, exist_ok=True)
    selection = {
        'object_type': 'frontier_selection',
        'schema_version': 'ssc-rd04-next-frontier-route-discovery-protocol@1',
        'wave_id': 'SSC-RD-W03',
        'lane_id': 'RD-04',
        'class_id': 'RD-04-C02',
        'issue': 1017,
        'canonical_rd04_merge': CANONICAL_RD04_MERGE,
        'live_main_parent': live_main,
        'state_denominator': 50,
        'field_denominator_per_state': 9,
        'terminal_cells_before': 218,
        'open_cells_before': 232,
        'open_substantive_cells_before': 192,
        'open_state_rows_before': 40,
        'minimum_open_substantive_cells_per_row': frontier['minimum'],
        'minimum_cohorts': frontier['minimum_cohorts'],
        'selection_rule': 'minimum positive substantive-cell count; then largest exact field-signature cohort; then lexicographic field signature and state IDs',
        'selected_state_ids': frontier['selected_state_ids'],
        'selected_field_ids': frontier['selected_field_ids'],
        'selected_state_count': frontier['selected_state_count'],
        'selected_substantive_cell_count': frontier['selected_cell_count'],
        'derivative_row_state_cells_excluded': frontier['selected_state_count'],
        'class_closed': False,
        'outside_human_dependency': False,
    }
    predecessor = {
        'object_type': 'predecessor_custody',
        'schema_version': 'ssc-rd04-next-frontier-route-discovery-protocol@1',
        'canonical_merge': CANONICAL_RD04_MERGE,
        'canonical_merge_tree': git('rev-parse', f'{CANONICAL_RD04_MERGE}^{{tree}}', cwd=root).stdout.strip(),
        'matrix_path': MATRIX_PATH,
        'matrix_sha256': frontier['matrix_sha256'],
        'open_census_path': OPEN_CENSUS_PATH,
        'open_census_sha256': frontier['open_census_sha256'],
        'live_main_parent': live_main,
        'successor_paths_since_canonical_rd04_merge': successor_paths,
        'rd04_successor_overlap_count': 0,
        'terminal_cells': 218,
        'open_cells': 232,
        'open_substantive_cells': 192,
        'terminal_units': 10,
        'open_units': 40,
    }
    inventory_object = {
        'object_type': 'official_locator_inventory',
        'schema_version': 'ssc-rd04-next-frontier-route-discovery-protocol@1',
        'selected_state_ids': frontier['selected_state_ids'],
        'selected_field_ids': frontier['selected_field_ids'],
        'scanned_repository_files': inventory['scanned_file_count'],
        'official_route_rows': inventory['official_route_row_count'],
        'state_official_roots': inventory['state_official_roots'],
        'coverage': inventory['coverage'],
        'inventory_effect': 'candidate_route_custody_only',
        'automatic_source_admission': False,
        'automatic_field_classification': False,
    }
    field_terms = {field: query_terms(field) for field in frontier['selected_field_ids']}
    query_contract = {
        'object_type': 'route_query_contract',
        'schema_version': 'ssc-rd04-next-frontier-route-discovery-protocol@1',
        'selected_state_ids': frontier['selected_state_ids'],
        'selected_field_ids': frontier['selected_field_ids'],
        'field_query_terms': field_terms,
        'allowed_discovery_surfaces': ['repository_native_exact_url', 'official_root_robots_txt', 'official_root_sitemap_xml', 'official_site_search'],
        'maximum_official_roots_per_state': 2,
        'maximum_discovery_requests_per_root': 3,
        'maximum_candidate_urls_per_cell': 12,
        'maximum_attempts_per_request': 1,
        'maximum_redirects': 4,
        'result_spawned_source_fetches': 0,
        'cross_host_redirects_allowed': False,
        'automatic_source_admission': False,
        'automatic_field_classification': False,
        'outside_human_dependency': False,
    }
    (data_dir / 'frontier-selection.json').write_text(dump(selection), encoding='utf-8')
    (data_dir / 'predecessor-custody.json').write_text(dump(predecessor), encoding='utf-8')
    (data_dir / 'official-locator-inventory.json').write_text(dump(inventory_object), encoding='utf-8')
    (data_dir / 'route-query-contract.json').write_text(dump(query_contract), encoding='utf-8')


def builder_source() -> str:
    return textwrap.dedent(f"""\
        import fs from 'node:fs';
        import path from 'node:path';
        import process from 'node:process';

        const ROOT = process.cwd();
        const DATA = {json.dumps(DATA_DIR)};
        const read = name => JSON.parse(fs.readFileSync(path.join(ROOT, DATA, name), 'utf8'));
        const stable = value => JSON.stringify(value, null, 2) + '\\n';

        export function buildObjects() {{
          const selection = read('frontier-selection.json');
          const predecessor = read('predecessor-custody.json');
          const inventory = read('official-locator-inventory.json');
          const query = read('route-query-contract.json');
          const obligations = [];
          let fixedRouteCells = 0;
          let discoveryCells = 0;
          for (const stateId of selection.selected_state_ids) {{
            for (const fieldId of selection.selected_field_ids) {{
              const cell = inventory.coverage[stateId][fieldId];
              const exact = [...new Set(cell.uncaptured_repository_urls)].sort().slice(0, query.maximum_candidate_urls_per_cell);
              const mode = exact.length >= 2 ? 'fixed_repository_routes' : 'bounded_official_route_discovery';
              if (mode === 'fixed_repository_routes') fixedRouteCells += 1; else discoveryCells += 1;
              obligations.push({{
                obligation_id: `rd04-route-${{stateId.slice(-2).toLowerCase()}}-${{fieldId}}`,
                state_id: stateId,
                field_id: fieldId,
                mode,
                official_roots: inventory.state_official_roots[stateId],
                repository_candidate_urls: exact,
                query_terms: query.field_query_terms[fieldId],
                maximum_candidate_urls: query.maximum_candidate_urls_per_cell,
                maximum_discovery_requests: query.maximum_official_roots_per_state * query.maximum_discovery_requests_per_root,
                automatic_source_admission: false,
                automatic_field_classification: false,
                terminalizes_field: false,
              }});
            }}
          }}
          const protocol = {{
            object_type: 'route_discovery_protocol',
            schema_version: 'ssc-rd04-next-frontier-route-discovery-protocol@1',
            wave_id: 'SSC-RD-W03', lane_id: 'RD-04', class_id: 'RD-04-C02', issue: 1017,
            selected_state_ids: selection.selected_state_ids,
            selected_field_ids: selection.selected_field_ids,
            selected_substantive_cell_count: selection.selected_substantive_cell_count,
            obligations,
            obligation_count: obligations.length,
            fixed_repository_route_cells: fixedRouteCells,
            bounded_official_route_discovery_cells: discoveryCells,
            maximum_total_discovery_requests: obligations.reduce((sum, item) => sum + item.maximum_discovery_requests, 0),
            maximum_total_candidate_urls: obligations.reduce((sum, item) => sum + item.maximum_candidate_urls, 0),
            source_requests_executed: 0,
            source_admissions: 0,
            field_mutations: 0,
            row_state_mutations: 0,
            class_closed: false,
            cumulative_ledger_effect: 'none',
            outside_human_dependency: false,
            publication_effect: 'none', adoption_effect: 'none', graph_effect: 'none',
          }};
          const summary = {{
            object_type: 'summary',
            schema_version: 'ssc-rd04-next-frontier-route-discovery-protocol@1',
            canonical_rd04_merge: selection.canonical_rd04_merge,
            live_main_parent: selection.live_main_parent,
            selected_state_count: selection.selected_state_count,
            selected_field_count: selection.selected_field_ids.length,
            selected_substantive_cell_count: selection.selected_substantive_cell_count,
            derivative_row_state_cells_excluded: selection.derivative_row_state_cells_excluded,
            protocol_obligations: protocol.obligation_count,
            fixed_repository_route_cells: fixedRouteCells,
            bounded_official_route_discovery_cells: discoveryCells,
            source_requests_executed: 0,
            source_admissions: 0,
            field_mutations: 0,
            row_state_mutations: 0,
            terminal_cells_before: predecessor.terminal_cells,
            open_substantive_cells_before: predecessor.open_substantive_cells,
            class_closed: false,
            outside_human_dependency: false,
            cumulative_ledger_effect: 'none', publication_effect: 'none', adoption_effect: 'none', graph_effect: 'none',
          }};
          return {{protocol, summary}};
        }}

        export function writeObjects() {{
          const {{protocol, summary}} = buildObjects();
          fs.writeFileSync(path.join(ROOT, DATA, 'route-discovery-protocol.json'), stable(protocol));
          fs.writeFileSync(path.join(ROOT, DATA, 'summary.json'), stable(summary));
        }}

        export function checkObjects() {{
          const {{protocol, summary}} = buildObjects();
          for (const [name, value] of [['route-discovery-protocol.json', protocol], ['summary.json', summary]]) {{
            const actual = fs.readFileSync(path.join(ROOT, DATA, name), 'utf8');
            const expected = stable(value);
            if (actual !== expected) throw new Error(`${{name}} is not deterministic`);
          }}
        }}

        const mode = process.argv[2] || '--check';
        if (mode === '--write') writeObjects();
        else if (mode === '--check') checkObjects();
        else throw new Error(`unknown mode: ${{mode}}`);
        console.log(`rd04_next_frontier_protocol_build=${{mode === '--write' ? 'written' : 'clean'}}`);
    """)


def validator_source() -> str:
    return textwrap.dedent(f"""\
        import fs from 'node:fs';
        import path from 'node:path';
        import process from 'node:process';
        import crypto from 'node:crypto';
        import {{fileURLToPath}} from 'node:url';

        const DATA = {json.dumps(DATA_DIR)};
        const PATHS = {json.dumps(PERMANENT_PATHS)};
        const assert = (condition, message) => {{ if (!condition) throw new Error(message); }};
        const unique = values => new Set(values).size === values.length;
        const official = raw => {{
          const host = new URL(raw).hostname.toLowerCase();
          return host.endsWith('.gov') || host.includes('.gov.') || host.endsWith('.us') || host === 'fns.usda.gov';
        }};
        const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');

        export function loadObjects(root=process.cwd()) {{
          const read = name => JSON.parse(fs.readFileSync(path.join(root, DATA, name), 'utf8'));
          return {{
            selection: read('frontier-selection.json'), predecessor: read('predecessor-custody.json'),
            inventory: read('official-locator-inventory.json'), query: read('route-query-contract.json'),
            protocol: read('route-discovery-protocol.json'), summary: read('summary.json'),
          }};
        }}

        export function validateObjects(o) {{
          const s=o.selection,p=o.predecessor,i=o.inventory,q=o.query,r=o.protocol,m=o.summary;
          assert(s.object_type==='frontier_selection','selection type');
          assert(s.canonical_rd04_merge==={json.dumps(CANONICAL_RD04_MERGE)},'canonical RD-04 merge');
          assert(s.state_denominator===50 && s.field_denominator_per_state===9,'matrix denominator');
          assert(s.terminal_cells_before===218 && s.open_cells_before===232,'cell denominator');
          assert(s.open_substantive_cells_before===192 && s.open_state_rows_before===40,'open denominator');
          assert(s.selected_state_count===s.selected_state_ids.length && s.selected_state_count>0,'selected state count');
          assert(unique(s.selected_state_ids) && unique(s.selected_field_ids),'selection uniqueness');
          assert(!s.selected_field_ids.includes('field_and_row_terminal_state'),'derivative exclusion');
          assert(s.selected_substantive_cell_count===s.selected_state_ids.length*s.selected_field_ids.length,'selected cell arithmetic');
          assert(s.derivative_row_state_cells_excluded===s.selected_state_ids.length,'derivative cell arithmetic');
          assert(s.class_closed===false && s.outside_human_dependency===false,'selection authority');
          assert(p.canonical_merge===s.canonical_rd04_merge && p.live_main_parent===s.live_main_parent,'predecessor binding');
          assert(p.rd04_successor_overlap_count===0,'successor overlap');
          assert(p.terminal_cells===218 && p.open_cells===232 && p.open_substantive_cells===192,'predecessor counts');
          assert(i.selected_state_ids.join('\\0')===s.selected_state_ids.join('\\0'),'inventory states');
          assert(i.selected_field_ids.join('\\0')===s.selected_field_ids.join('\\0'),'inventory fields');
          for (const state of s.selected_state_ids) {{
            assert(Array.isArray(i.state_official_roots[state]) && i.state_official_roots[state].length>0 && i.state_official_roots[state].length<=2,'official roots');
            for (const root of i.state_official_roots[state]) assert(official(root),'nonofficial root');
            for (const field of s.selected_field_ids) {{
              const cell=i.coverage[state][field]; assert(cell,'missing inventory cell');
              for (const url of [...cell.official_repository_urls,...cell.uncaptured_repository_urls]) assert(official(url),'nonofficial candidate URL');
            }}
          }}
          assert(q.maximum_official_roots_per_state===2 && q.maximum_discovery_requests_per_root===3,'request bounds');
          assert(q.maximum_candidate_urls_per_cell===12 && q.maximum_attempts_per_request===1,'candidate bounds');
          assert(q.result_spawned_source_fetches===0 && q.cross_host_redirects_allowed===false,'discovery boundaries');
          assert(q.automatic_source_admission===false && q.automatic_field_classification===false && q.outside_human_dependency===false,'query authority');
          assert(r.obligation_count===s.selected_substantive_cell_count && r.obligations.length===r.obligation_count,'obligation denominator');
          const expected=new Set(s.selected_state_ids.flatMap(state=>s.selected_field_ids.map(field=>`${{state}}\\0${{field}}`)));
          const actual=new Set();
          for (const obligation of r.obligations) {{
            const key=`${{obligation.state_id}}\\0${{obligation.field_id}}`; assert(expected.has(key),'out-of-scope obligation'); assert(!actual.has(key),'duplicate obligation'); actual.add(key);
            assert(['fixed_repository_routes','bounded_official_route_discovery'].includes(obligation.mode),'obligation mode');
            assert(obligation.maximum_candidate_urls===12 && obligation.maximum_discovery_requests<=6,'obligation bounds');
            assert(obligation.automatic_source_admission===false && obligation.automatic_field_classification===false && obligation.terminalizes_field===false,'obligation authority');
            for (const url of obligation.official_roots) assert(official(url),'obligation root host');
            for (const url of obligation.repository_candidate_urls) assert(official(url),'obligation candidate host');
            if (obligation.mode==='fixed_repository_routes') assert(obligation.repository_candidate_urls.length>=2,'fixed route denominator');
          }}
          assert(actual.size===expected.size,'obligation cross product');
          assert(r.source_requests_executed===0 && r.source_admissions===0 && r.field_mutations===0 && r.row_state_mutations===0,'protocol effects');
          assert(r.class_closed===false && r.cumulative_ledger_effect==='none' && r.outside_human_dependency===false,'protocol class authority');
          assert(r.publication_effect==='none' && r.adoption_effect==='none' && r.graph_effect==='none','protocol external effects');
          assert(m.protocol_obligations===r.obligation_count && m.selected_substantive_cell_count===s.selected_substantive_cell_count,'summary arithmetic');
          assert(m.source_requests_executed===0 && m.field_mutations===0 && m.class_closed===false && m.outside_human_dependency===false,'summary authority');
          return true;
        }}

        export function validateProduct(root=process.cwd()) {{
          const objects=loadObjects(root); validateObjects(objects);
          const manifest=JSON.parse(fs.readFileSync(path.join(root,DATA,'product-manifest.json'),'utf8'));
          assert(manifest.object_type==='product_manifest','manifest type');
          assert(manifest.permanent_path_count===PATHS.length,'manifest path count');
          assert(manifest.entries.length===PATHS.length-1,'manifest self exclusion');
          for (const entry of manifest.entries) {{
            const data=fs.readFileSync(path.join(root,entry.path));
            assert(data.length===entry.bytes,`byte drift ${{entry.path}}`);
            assert(sha256(data)===entry.sha256,`hash drift ${{entry.path}}`);
          }}
          return true;
        }}

        if (process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {{
          validateProduct();
          const s=loadObjects().summary;
          console.log(`rd04_next_frontier_protocol_validation=pass states=${{s.selected_state_count}} cells=${{s.selected_substantive_cell_count}} obligations=${{s.protocol_obligations}}`);
        }}
    """)


def test_source() -> str:
    return textwrap.dedent(f"""\
        import assert from 'node:assert/strict';
        import {{loadObjects,validateObjects}} from '../tools/validate-{SLUG}.mjs';
        const base=loadObjects();
        const clone=value=>structuredClone(value);
        let refusals=0;
        const reject=mutate=>{{const value=clone(base);mutate(value);assert.throws(()=>validateObjects(value));refusals+=1;}};
        reject(o=>o.selection.state_denominator=49);
        reject(o=>o.selection.field_denominator_per_state=8);
        reject(o=>o.selection.terminal_cells_before=219);
        reject(o=>o.selection.open_substantive_cells_before=191);
        reject(o=>o.selection.class_closed=true);
        reject(o=>o.selection.outside_human_dependency=true);
        reject(o=>o.predecessor.rd04_successor_overlap_count=1);
        reject(o=>o.query.maximum_attempts_per_request=2);
        reject(o=>o.query.result_spawned_source_fetches=1);
        reject(o=>o.query.cross_host_redirects_allowed=true);
        reject(o=>o.query.automatic_source_admission=true);
        reject(o=>o.query.outside_human_dependency=true);
        reject(o=>o.protocol.source_requests_executed=1);
        reject(o=>o.protocol.source_admissions=1);
        reject(o=>o.protocol.field_mutations=1);
        reject(o=>o.protocol.class_closed=true);
        reject(o=>o.protocol.graph_effect='candidate');
        for (let index=0;index<base.protocol.obligations.length;index+=1) {{
          reject(o=>o.protocol.obligations.splice(index,1));
          reject(o=>o.protocol.obligations[index].automatic_source_admission=true);
          reject(o=>o.protocol.obligations[index].automatic_field_classification=true);
          reject(o=>o.protocol.obligations[index].terminalizes_field=true);
          reject(o=>o.protocol.obligations[index].maximum_candidate_urls=13);
          reject(o=>o.protocol.obligations[index].maximum_discovery_requests=7);
          reject(o=>o.protocol.obligations[index].official_roots[0]='https://example.com/');
        }}
        console.log(`rd04_next_frontier_protocol_adversarial_refusals=${{refusals}}`);
    """)


def planner_source() -> str:
    return textwrap.dedent(f"""\
        #!/usr/bin/env python3
        from __future__ import annotations
        import argparse, json
        from pathlib import Path

        PROTOCOL = Path({DATA_DIR!r}) / 'route-discovery-protocol.json'

        def main() -> int:
            parser=argparse.ArgumentParser(description='Plan the bounded RD-04 official-route discovery transaction.')
            parser.add_argument('--execute', action='store_true', help='refused: execution requires a separate checksum-bound acquisition transaction')
            parser.add_argument('--json', action='store_true')
            args=parser.parse_args()
            protocol=json.loads(PROTOCOL.read_text())
            if args.execute:
                raise SystemExit('execution_refused: this permanent tool is plan-only; create a separate bounded acquisition carrier')
            plan={{
                'schema_version':'ssc-rd04-next-frontier-route-discovery-plan@1',
                'obligation_count':protocol['obligation_count'],
                'maximum_total_discovery_requests':protocol['maximum_total_discovery_requests'],
                'maximum_total_candidate_urls':protocol['maximum_total_candidate_urls'],
                'source_requests_executed':0,
                'automatic_source_admission':False,
                'automatic_field_classification':False,
                'outside_human_dependency':False,
                'obligations':protocol['obligations'],
            }}
            if args.json: print(json.dumps(plan,indent=2))
            else:
                print(f"obligations={{plan['obligation_count']}} max_requests={{plan['maximum_total_discovery_requests']}} max_candidates={{plan['maximum_total_candidate_urls']}}")
            return 0
        if __name__=='__main__': raise SystemExit(main())
    """)


def infer_schema(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return {
            'type': 'object',
            'required': list(value.keys()),
            'properties': {key: infer_schema(child) for key, child in value.items()},
            'additionalProperties': False,
        }
    if isinstance(value, list):
        item_schema = infer_schema(value[0]) if value else {}
        return {'type': 'array', 'items': item_schema}
    if isinstance(value, bool):
        return {'type': 'boolean'}
    if isinstance(value, int):
        return {'type': 'integer'}
    if isinstance(value, float):
        return {'type': 'number'}
    if value is None:
        return {'type': 'null'}
    return {'type': 'string'}


def write_product_support(root: Path) -> None:
    tools = root / 'tools'
    tests = root / 'test'
    docs = root / 'docs/milestones'
    schemas = root / 'schemas'
    runner = root / 'tools/acquisition/status-sovereignty-rd-wave03-rd04-next-frontier'
    for directory in (tools, tests, docs, schemas, runner):
        directory.mkdir(parents=True, exist_ok=True)
    (tools / f'build-{SLUG}.mjs').write_text(builder_source(), encoding='utf-8')
    (tools / f'validate-{SLUG}.mjs').write_text(validator_source(), encoding='utf-8')
    (tests / f'{SLUG}.test.js').write_text(test_source(), encoding='utf-8')
    planner = runner / 'plan-official-route-discovery.py'
    planner.write_text(planner_source(), encoding='utf-8')
    planner.chmod(0o755)
    (docs / f'{SLUG}.md').write_text(textwrap.dedent(f"""\
        # SSC RD Wave 03 — RD-04 next minimum-frontier route-discovery protocol

        This workflow-free product freezes the deterministic next minimum cohort after canonical merge `{CANONICAL_RD04_MERGE}`. It preserves exact predecessor matrix and open-census custody, inventories only repository-native official locators, and establishes bounded route-discovery obligations for the selected substantive cells.

        The product executes no request, admits no source, classifies no field, terminalizes no derivative row state, closes no residual class, and changes no cumulative ledger. A repository URL, search result, sitemap entry, or official locator remains candidate route custody until a separate acquisition and adjudication transaction validates the exact response and source semantics.

        Missing public records are not policy absence, implementation absence, waiver absence, event absence, unanimity, nonparticipation, or person-level absence. Outside-human dependency remains false. Publication, adoption, and graph effects remain none.
    """), encoding='utf-8')


def write_schema_and_manifest(root: Path) -> None:
    data_dir = root / DATA_DIR
    data_names = ['frontier-selection.json','predecessor-custody.json','official-locator-inventory.json','route-query-contract.json','route-discovery-protocol.json','summary.json']
    objects = [json.loads((data_dir / name).read_text(encoding='utf-8')) for name in data_names]
    schema = {
        '$schema': 'https://json-schema.org/draft/2020-12/schema',
        '$id': f'{SLUG}.schema.json',
        'title': 'SSC RD-04 next minimum-frontier route-discovery protocol objects',
        'oneOf': [infer_schema(value) for value in objects],
    }
    schema_path = root / f'schemas/{SLUG}.schema.json'
    schema_path.write_text(dump(schema), encoding='utf-8')
    manifest_path = data_dir / 'product-manifest.json'
    entries = []
    for relative in PERMANENT_PATHS:
        if relative.endswith('/product-manifest.json'):
            continue
        path = root / relative
        data = path.read_bytes()
        entries.append({'path': relative, 'bytes': len(data), 'sha256': sha256_bytes(data), 'git_blob': git_blob_bytes(data), 'mode': '100755' if os.access(path, os.X_OK) else '100644'})
    manifest = {
        'object_type': 'product_manifest',
        'schema_version': 'ssc-rd04-next-frontier-route-discovery-protocol@1',
        'permanent_path_count': len(PERMANENT_PATHS),
        'manifest_self_excluded': True,
        'entries': entries,
        'combined_sha256': sha256_bytes(('\n'.join(f"{entry['sha256']}  {entry['path']}" for entry in entries) + '\n').encode()),
        'transport_paths': 0,
        'outside_human_dependency': False,
    }
    manifest_path.write_text(dump(manifest), encoding='utf-8')


def validate_schema(root: Path) -> None:
    import jsonschema
    schema = json.loads((root / f'schemas/{SLUG}.schema.json').read_text())
    validator = jsonschema.Draft202012Validator(schema)
    data_dir = root / DATA_DIR
    count = 0
    for name in ('frontier-selection.json','predecessor-custody.json','official-locator-inventory.json','route-query-contract.json','route-discovery-protocol.json','summary.json'):
        validator.validate(json.loads((data_dir / name).read_text()))
        count += 1
    if count != 6:
        raise RuntimeError('closed schema denominator drift')


def report_issue(receipt: dict[str, Any], success: bool) -> None:
    body = OUT / 'issue-comment.md'
    if success:
        body.write_text(textwrap.dedent(f"""\
            RD-04 next minimum-frontier route-discovery protocol materialized successfully.

            ```text
            live_main_parent: {receipt['live_main_parent']}
            product_head: {receipt['product_head']}
            product_tree: {receipt['product_tree']}
            product_branch: {receipt['product_branch']}
            permanent_paths: {receipt['permanent_path_count']}
            selected_states: {' '.join(receipt['selected_state_ids'])}
            selected_fields: {' '.join(receipt['selected_field_ids'])}
            selected_substantive_cells: {receipt['selected_substantive_cell_count']}
            protocol_obligations: {receipt['protocol_obligations']}
            fixed_repository_route_cells: {receipt['fixed_repository_route_cells']}
            bounded_official_route_discovery_cells: {receipt['bounded_official_route_discovery_cells']}
            adversarial_refusals: {receipt['adversarial_refusals']}
            source_requests_executed: 0
            source_admissions: 0
            field_mutations: 0
            class_closed: false
            outside_human_dependency: false
            receipt_sha256: {sha256_file(OUT/'materialization-receipt.json')}
            ```

            The product branch moved only after deterministic construction, closed-schema validation, adversarial refusals, no-magic-human, the complete repository release gate, clean replay, exact path custody, current-main disjointness, and the branch lease passed. It is protocol-only and requires a separate bounded acquisition transaction before any request or evidentiary effect.
        """), encoding='utf-8')
    else:
        body.write_text('RD-04 next minimum-frontier route-discovery protocol materialization failed closed. No product or additional authority is represented.\n\n```text\n' + (OUT/'run.log').read_text(errors='replace')[-12000:] + '\n```\n', encoding='utf-8')
    token = os.environ.get('GH_TOKEN') or os.environ.get('GITHUB_TOKEN')
    if token:
        env = os.environ.copy(); env['GH_TOKEN'] = token
        run(['gh','issue','comment','1017','--repo',REPOSITORY,'--body-file',str(body)], check=False, env=env)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'run.log').write_text('', encoding='utf-8')
    receipt: dict[str, Any] = {'schema_version': 'ssc-rd04-next-frontier-protocol-materialization@1', 'status': 'running'}
    try:
        git('fetch','--force','origin','main')
        live_main = git('rev-parse','origin/main').stdout.strip()
        git('merge-base','--is-ancestor',CANONICAL_RD04_MERGE,live_main)
        successor = git('diff','--name-only',CANONICAL_RD04_MERGE,live_main).stdout.splitlines()
        overlap = [path for path in successor if re.search(r'(^|/)(status-sovereignty-rd-wave03-rd04|ssc-rd04|ssc-residual-wave03/closures/RD-04-C02)', path)]
        if overlap:
            raise RuntimeError(f'RD-04 successor overlap: {overlap}')
        if WT.exists():
            shutil.rmtree(WT)
        git('worktree','add','--detach',str(WT),live_main)
        frontier = derive_frontier(WT)
        inventory = inventory_routes(WT, frontier)
        write_authored_inputs(WT, frontier, inventory, live_main, successor)
        write_product_support(WT)
        run(['node',f'tools/build-{SLUG}.mjs','--write'],cwd=WT)
        write_schema_and_manifest(WT)
        # Exact path and mode census before commit.
        actual = sorted(str(path.relative_to(WT)) for path in WT.rglob('*') if path.is_file() and str(path.relative_to(WT)) in PERMANENT_PATHS)
        if actual != sorted(PERMANENT_PATHS):
            raise RuntimeError(f'permanent path mismatch: {actual}')
        git('config','user.name','github-actions[bot]',cwd=WT)
        git('config','user.email','41898282+github-actions[bot]@users.noreply.github.com',cwd=WT)
        git('add','--',*PERMANENT_PATHS,cwd=WT)
        staged = git('diff','--cached','--name-only',cwd=WT).stdout.splitlines()
        if sorted(staged) != sorted(PERMANENT_PATHS):
            raise RuntimeError(f'staged path mismatch: {staged}')
        git('commit','-m','Freeze RD-04 next minimum-frontier route-discovery protocol',cwd=WT)
        product_head = git('rev-parse','HEAD',cwd=WT).stdout.strip()
        product_tree = git('rev-parse','HEAD^{tree}',cwd=WT).stdout.strip()
        if git('rev-parse','HEAD^',cwd=WT).stdout.strip() != live_main:
            raise RuntimeError('product parent drift')
        # Focused and closed-schema gates.
        run(['node','--check',f'tools/build-{SLUG}.mjs'],cwd=WT)
        run(['node','--check',f'tools/validate-{SLUG}.mjs'],cwd=WT)
        run(['node','--check',f'test/{SLUG}.test.js'],cwd=WT)
        run(['python','-m','py_compile','tools/acquisition/status-sovereignty-rd-wave03-rd04-next-frontier/plan-official-route-discovery.py'],cwd=WT)
        run(['node',f'tools/build-{SLUG}.mjs','--check'],cwd=WT)
        run(['node',f'tools/validate-{SLUG}.mjs'],cwd=WT)
        validate_schema(WT)
        test_result = run(['node',f'test/{SLUG}.test.js'],cwd=WT)
        match = re.search(r'adversarial_refusals=(\d+)', test_result.stdout)
        if not match:
            raise RuntimeError('missing adversarial refusal count')
        adversarial_refusals = int(match.group(1))
        run(['node','tools/validate-no-magic-human-gate.mjs'],cwd=WT)
        git('diff','--check','HEAD^','HEAD',cwd=WT)
        # Complete repository release gate on the exact product commit.
        run(['npm','run','release:check'],cwd=WT)
        git('reset','--hard','HEAD',cwd=WT)
        git('clean','-fdx',cwd=WT)
        # Deterministic clean replay.
        run(['node',f'tools/build-{SLUG}.mjs','--write'],cwd=WT)
        run(['node',f'tools/build-{SLUG}.mjs','--check'],cwd=WT)
        run(['node',f'tools/validate-{SLUG}.mjs'],cwd=WT)
        run(['node',f'test/{SLUG}.test.js'],cwd=WT)
        run(['node','tools/validate-no-magic-human-gate.mjs'],cwd=WT)
        git('diff','--check',cwd=WT)
        git('diff','--exit-code',cwd=WT)
        if git('status','--porcelain=v1','--untracked-files=all',cwd=WT).stdout.strip():
            raise RuntimeError('dirty clean replay')
        # Exact target-branch lease and publication.
        remote = git('ls-remote','--heads','origin',f'refs/heads/{PRODUCT_BRANCH}',cwd=WT).stdout.strip()
        if remote:
            old = remote.split()[0]
            if old != live_main:
                raise RuntimeError(f'product branch lease drift: {old} != {live_main}')
            push = ['git','push','origin',f'HEAD:refs/heads/{PRODUCT_BRANCH}',f'--force-with-lease=refs/heads/{PRODUCT_BRANCH}:{old}']
        else:
            push = ['git','push','origin',f'HEAD:refs/heads/{PRODUCT_BRANCH}']
        run(push,cwd=WT)
        summary = json.loads((WT / DATA_DIR / 'summary.json').read_text())
        receipt.update({
            'status':'complete', 'live_main_parent':live_main, 'product_head':product_head, 'product_tree':product_tree,
            'product_branch':PRODUCT_BRANCH, 'permanent_path_count':len(PERMANENT_PATHS), 'permanent_paths':PERMANENT_PATHS,
            'selected_state_ids':frontier['selected_state_ids'], 'selected_field_ids':frontier['selected_field_ids'],
            'selected_substantive_cell_count':frontier['selected_cell_count'], 'protocol_obligations':summary['protocol_obligations'],
            'fixed_repository_route_cells':summary['fixed_repository_route_cells'],
            'bounded_official_route_discovery_cells':summary['bounded_official_route_discovery_cells'],
            'adversarial_refusals':adversarial_refusals, 'source_requests_executed':0, 'source_admissions':0,
            'field_mutations':0, 'row_state_mutations':0, 'class_closed':False, 'outside_human_dependency':False,
            'cumulative_ledger_effect':'none', 'publication_effect':'none', 'adoption_effect':'none', 'graph_effect':'none',
        })
        (OUT/'materialization-receipt.json').write_text(dump(receipt),encoding='utf-8')
        report_issue(receipt,True)
        return 0
    except Exception as exc:
        receipt.update({'status':'failed_closed','error':repr(exc),'traceback':traceback.format_exc()})
        (OUT/'materialization-receipt.json').write_text(dump(receipt),encoding='utf-8')
        report_issue(receipt,False)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
