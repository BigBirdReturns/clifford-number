#!/usr/bin/env bash
set -Eeuo pipefail

PARENT="$(git rev-parse HEAD^)"
PARENT_TREE="$(git rev-parse "$PARENT^{tree}")"
export PARENT PARENT_TREE
SOURCE_COMMIT='46036c01eaba31bdb18045307fe3ebcb67d576a6'
SOURCE_TREE='0ffec7018bcfc038a73cd280970f783d12a5c222'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-regenerator-v2.yml'
CARRIER_BRANCH='agent/schoolhouse-legal-identity-current-frontier-regenerator-v2'
PRODUCT_BRANCH='agent/schoolhouse-legal-identity-current-frontier-product-v1'
EXPORT_ARTIFACT='9011399743'
EXPORT_ZIP_BYTES='1918341'
EXPORT_ZIP_SHA256='0009dc40ae1c9be74e4b89c7fd4deb05e8eec3bc5f3fd8b2a88a7dc74e96c28e'
SOURCE_TAR_BYTES='706192'
SOURCE_TAR_SHA256='6d2d25325570c28648ca70cf30f9608622e95da078a9c8ec40d9f951eeeda3e2'
BUNDLE_BYTES='36304'
BUNDLE_SHA256='f48a146eed3fe9d2025a46dd25e9da6f3b4ab901f4a4bf58b6d4fb09d451016c'
BUNDLE_BLOBS=(
  '48b226ba325b14362c285bffed2da5e1b4545a7a'
  '344e1375f07ccb28d3b8c7de1539f779eb4524be'
  '2fc71dd95438d35dea6bfa566d53a606e16a4679'
  '5ce8cbd62babb96f2be6df51cc9596bf64195872'
)
BUNDLE_CHUNK_BYTES=(10000 10000 10000 6304)
BUNDLE_CHUNK_SHA256=(
  '119795baa73810e986a2624cdfcd28bb59f2e3b53dea4689fb417bbbab6c2fa3'
  'c03394dec522b2467e6116e39d35d0e2e90b795e1c3a56a2f7bb6125d610ab6c'
  '5df46e0a92e139bf63dbc76b5b7f2f494e0f22b954df224c260ae7a5a2774857'
  '409da1ac4fdcbf93f0b26d47aa2a031bf11b6df73db9d8b8ba6e57d9981ed442'
)
PERMANENT_PATHS=(
  'data/intake/bvvc-defense-capital/acquisition-frontier.json'
  'data/intake/bvvc-defense-capital/manifest.json'
  'data/intake/bvvc-defense-capital/schoolhouse.json'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/canonical-slice-manifest.jsonl'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/frontier-reconciliation.json'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/next-source-gate.json'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/product-manifest.json'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/source-custody.json'
  'data/intake/schoolhouse-legal-identity-current-frontier-v1/source-lanes.json'
  'docs/milestones/schoolhouse-legal-identity-current-frontier-v1.md'
  'tools/validate-schoolhouse-legal-identity-current-frontier.py'
)

WORK="$RUNNER_TEMP/schoolhouse-current-frontier-regenerator-v2"
RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-regenerator-v2-receipt"
rm -rf "$WORK" "$RECEIPT"
mkdir -p "$WORK/export" "$WORK/source-slice" "$WORK/chunks" "$RECEIPT"
printf 'initializing\n' > "$RECEIPT/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\noutside_human_dependency=false\n' > "$RECEIPT/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  printf '%s\n' "$rc" > "$RECEIPT/EXIT_CODE"
  if test -d "$WORK"; then
    find "$WORK" -maxdepth 2 -type f \( -name '*.log' -o -name '*summary*.json' -o -name '*paths*' -o -name '*status*' \) -exec cp --parents {} "$RECEIPT"/ \; 2>/dev/null || true
  fi
  (
    cd "$RECEIPT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-carrier-and-live-main\n' > "$RECEIPT/STAGE"
test "${GITHUB_REF_NAME:-}" = "$CARRIER_BRANCH" || test "${GITHUB_HEAD_REF:-}" = "$CARRIER_BRANCH"
test "$(git rev-parse HEAD^)" = "$PARENT"
test "$(git rev-list --count "$PARENT"..HEAD)" = '1'
mapfile -t carrier_paths < <(git diff --name-only "$PARENT"..HEAD)
test "${#carrier_paths[@]}" -eq 1
test "${carrier_paths[0]}" = "$WORKFLOW"
git diff --check "$PARENT"..HEAD
git fetch --no-tags origin main
test "$(git rev-parse origin/main)" = "$PARENT"
test "$(git rev-parse "$PARENT^{tree}")" = "$PARENT_TREE"
test "$(git rev-parse "$SOURCE_COMMIT^{tree}")" = "$SOURCE_TREE"
git merge-base --is-ancestor "$SOURCE_COMMIT" "$PARENT"
if git ls-remote --exit-code --heads origin "refs/heads/$PRODUCT_BRANCH" >/dev/null 2>&1; then
  printf 'target product branch already exists\n' >&2
  exit 1
fi

printf 'authenticating-export\n' > "$RECEIPT/STAGE"
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$EXPORT_ARTIFACT" > "$WORK/export-metadata.json"
python - "$WORK/export-metadata.json" <<'PY'
from pathlib import Path
import json, sys
m=json.loads(Path(sys.argv[1]).read_text())
assert m['id'] == 9011399743
assert m['name'] == 'schoolhouse-legal-identity-frontier-export-46036c-v3'
assert m['size_in_bytes'] == 1918341
assert m['expired'] is False
assert m['digest'] == 'sha256:0009dc40ae1c9be74e4b89c7fd4deb05e8eec3bc5f3fd8b2a88a7dc74e96c28e'
assert m['workflow_run']['id'] == 31223901158
PY
gh api "repos/$GITHUB_REPOSITORY/actions/runs/31223901158" > "$WORK/export-run.json"
python - "$WORK/export-run.json" <<'PY'
from pathlib import Path
import json, sys
r=json.loads(Path(sys.argv[1]).read_text())
assert r['id'] == 31223901158
assert r['head_sha'] == 'bf374b46e3eff3d4936cc97e37e9bfdfec91bd6c'
assert r['status'] == 'completed'
assert r['conclusion'] == 'success'
PY
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$EXPORT_ARTIFACT/zip" > "$WORK/export.zip"
test "$(stat -c%s "$WORK/export.zip")" = "$EXPORT_ZIP_BYTES"
test "$(sha256sum "$WORK/export.zip" | cut -d' ' -f1)" = "$EXPORT_ZIP_SHA256"
unzip -q "$WORK/export.zip" -d "$WORK/export"
(
  cd "$WORK/export"
  sha256sum -c SHA256SUMS > "$WORK/export-sha256.log"
)
test "$(stat -c%s "$WORK/export/schoolhouse-legal-identity-frontier-46036c.tar.xz")" = "$SOURCE_TAR_BYTES"
test "$(sha256sum "$WORK/export/schoolhouse-legal-identity-frontier-46036c.tar.xz" | cut -d' ' -f1)" = "$SOURCE_TAR_SHA256"
tar -xJf "$WORK/export/schoolhouse-legal-identity-frontier-46036c.tar.xz" -C "$WORK/source-slice"
test "$(find "$WORK/source-slice" -type f | wc -l)" = '233'

printf 'authenticating-regenerator-bundle\n' > "$RECEIPT/STAGE"
if test -n "${SCHOOLHOUSE_REGENERATOR_BUNDLE_PATH:-}"; then
  test -f "$SCHOOLHOUSE_REGENERATOR_BUNDLE_PATH"
  cp "$SCHOOLHOUSE_REGENERATOR_BUNDLE_PATH" "$WORK/regenerator-bundle.tar.xz"
else
  for index in "${!BUNDLE_BLOBS[@]}"; do
    printf -v suffix '%02d' "$index"
    chunk="$WORK/chunks/chunk-$suffix"
    gh api "repos/$GITHUB_REPOSITORY/git/blobs/${BUNDLE_BLOBS[$index]}" --jq .content | tr -d '\n' | base64 --decode > "$chunk"
    test "$(stat -c%s "$chunk")" = "${BUNDLE_CHUNK_BYTES[$index]}"
    test "$(sha256sum "$chunk" | cut -d' ' -f1)" = "${BUNDLE_CHUNK_SHA256[$index]}"
  done
  cat "$WORK"/chunks/chunk-* > "$WORK/regenerator-bundle.tar.xz"
fi
test "$(stat -c%s "$WORK/regenerator-bundle.tar.xz")" = "$BUNDLE_BYTES"
test "$(sha256sum "$WORK/regenerator-bundle.tar.xz" | cut -d' ' -f1)" = "$BUNDLE_SHA256"
tar -xJf "$WORK/regenerator-bundle.tar.xz" -C "$WORK"
(
  cd "$WORK"
  sha256sum -c SHA256SUMS > "$WORK/bundle-sha256.log"
)
python -m py_compile "$WORK/generate_schoolhouse_frontier.py"

printf 'generating-and-validating-product\n' > "$RECEIPT/STAGE"
SCHOOLHOUSE_WORK_ROOT="$WORK" \
SCHOOLHOUSE_PRODUCT_PARENT="$PARENT" \
SCHOOLHOUSE_PRODUCT_PARENT_TREE="$PARENT_TREE" \
python "$WORK/generate_schoolhouse_frontier.py" > "$WORK/generation-summary.json"
python -m py_compile "$WORK/product/tools/validate-schoolhouse-legal-identity-current-frontier.py"
rm -rf "$WORK/product/tools/__pycache__"
python "$WORK/product/tools/validate-schoolhouse-legal-identity-current-frontier.py" \
  --root "$WORK/product" \
  --source-export-root "$WORK/source-slice" \
  --self-test > "$WORK/focused-validation.log"

test "$(find "$WORK/product" -type f | wc -l)" = '11'
printf '%s\n' "${PERMANENT_PATHS[@]}" | sort > "$WORK/expected-product-paths"
find "$WORK/product" -type f -printf '%P\n' | sort > "$WORK/actual-product-paths"
diff -u "$WORK/expected-product-paths" "$WORK/actual-product-paths"

printf 'replaying-product-deterministically\n' > "$RECEIPT/STAGE"
REPLAY="$WORK/replay"
mkdir -p "$REPLAY"
cp "$WORK/generate_schoolhouse_frontier.py" "$REPLAY/"
cp -a "$WORK/product-template-partial" "$REPLAY/"
ln -s "$WORK/export" "$REPLAY/export"
ln -s "$WORK/source-slice" "$REPLAY/source-slice"
SCHOOLHOUSE_WORK_ROOT="$REPLAY" \
SCHOOLHOUSE_PRODUCT_PARENT="$PARENT" \
SCHOOLHOUSE_PRODUCT_PARENT_TREE="$PARENT_TREE" \
python "$REPLAY/generate_schoolhouse_frontier.py" > "$WORK/replay-summary.json"
rm -rf "$REPLAY/product/tools/__pycache__"
diff -qr "$WORK/product" "$REPLAY/product" > "$WORK/deterministic-replay.log"

printf 'constructing-one-commit-product\n' > "$RECEIPT/STAGE"
git worktree add --detach "$WORK/repo" "$PARENT"
for path in "${PERMANENT_PATHS[@]}"; do
  mkdir -p "$WORK/repo/$(dirname "$path")"
  cp "$WORK/product/$path" "$WORK/repo/$path"
done
chmod 0755 "$WORK/repo/tools/validate-schoolhouse-legal-identity-current-frontier.py"
(
  cd "$WORK/repo"
  git add -- "${PERMANENT_PATHS[@]}"
  git diff --cached --check
  git diff --cached --name-status > "$WORK/product-name-status"
)
cat > "$WORK/expected-product-name-status" <<'EOF'
M	data/intake/bvvc-defense-capital/acquisition-frontier.json
M	data/intake/bvvc-defense-capital/manifest.json
M	data/intake/bvvc-defense-capital/schoolhouse.json
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/canonical-slice-manifest.jsonl
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/frontier-reconciliation.json
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/next-source-gate.json
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/product-manifest.json
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/source-custody.json
A	data/intake/schoolhouse-legal-identity-current-frontier-v1/source-lanes.json
A	docs/milestones/schoolhouse-legal-identity-current-frontier-v1.md
A	tools/validate-schoolhouse-legal-identity-current-frontier.py
EOF
diff -u "$WORK/expected-product-name-status" "$WORK/product-name-status"

test "$(grep -c '^M' "$WORK/product-name-status")" = '3'
test "$(grep -c '^A' "$WORK/product-name-status")" = '8'
! grep -q '^.[[:space:]]\.github/workflows/' "$WORK/product-name-status"

printf 'running-complete-product-gates\n' > "$RECEIPT/STAGE"
(
  cd "$WORK/repo"
  python tools/validate-schoolhouse-legal-identity-current-frontier.py \
    --root . \
    --source-export-root "$WORK/source-slice" \
    --self-test > "$WORK/staged-focused-validation.log"
  node tools/validate-bvvc-defense-capital.mjs > "$WORK/bvvc-validation.log"
  node tools/validate-no-magic-human-gate.mjs > "$WORK/no-magic-human-validator.log"
  node test/no-magic-human-gate.test.js > "$WORK/no-magic-human-test.log"
  npm run release:check > "$WORK/release-check.log" 2>&1
  git diff --check
  test -z "$(git diff --name-only)"
  git diff --cached --name-status > "$WORK/product-name-status-after-gates"
)
diff -u "$WORK/product-name-status" "$WORK/product-name-status-after-gates"

printf 'committing-and-proving-product\n' > "$RECEIPT/STAGE"
(
  cd "$WORK/repo"
  git config user.name 'School.House current-frontier regenerator'
  git config user.email 'actions@users.noreply.github.com'
  git commit -m 'Reconcile the current School.House legal-identity frontier' > "$WORK/commit.log"
  PRODUCT_COMMIT="$(git rev-parse HEAD)"
  PRODUCT_TREE="$(git rev-parse HEAD^{tree})"
  test "$(git rev-parse HEAD^)" = "$PARENT"
  test "$(git rev-list --count "$PARENT"..HEAD)" = '1'
  git diff --name-status "$PARENT"..HEAD > "$WORK/committed-name-status"
  diff -u "$WORK/expected-product-name-status" "$WORK/committed-name-status"
  python tools/validate-schoolhouse-legal-identity-current-frontier.py --self-test > "$WORK/committed-focused-validation.log"
  git show --format= --binary HEAD -- "${PERMANENT_PATHS[@]}" | sha256sum | cut -d' ' -f1 > "$WORK/product-patch-sha256"
  printf '%s\n' "$PRODUCT_COMMIT" > "$WORK/PRODUCT_COMMIT"
  printf '%s\n' "$PRODUCT_TREE" > "$WORK/PRODUCT_TREE"
  git push origin "HEAD:refs/heads/$PRODUCT_BRANCH" > "$WORK/push.log" 2>&1
)

printf 'sealing-receipt\n' > "$RECEIPT/STAGE"
python - "$WORK" "$RECEIPT/receipt.json" <<'PY'
from pathlib import Path
import hashlib, json, sys
work=Path(sys.argv[1]); out=Path(sys.argv[2]); product=work/'product'
paths=(work/'actual-product-paths').read_text().splitlines()
rows=[]
for rel in paths:
    p=product/rel; data=p.read_bytes()
    rows.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':'100755' if rel=='tools/validate-schoolhouse-legal-identity-current-frontier.py' else '100644'})
receipt={
  'schema_version':'schoolhouse-legal-identity-current-frontier-regenerator-receipt@1',
  'state':'complete',
  'carrier_head':__import__('os').environ['GITHUB_SHA'],
  'carrier_parent':__import__('os').environ['PARENT'],
  'carrier_paths':1,
  'product_branch':'agent/schoolhouse-legal-identity-current-frontier-product-v1',
  'product_commit':(work/'PRODUCT_COMMIT').read_text().strip(),
  'product_tree':(work/'PRODUCT_TREE').read_text().strip(),
  'product_parent':__import__('os').environ['PARENT'],
  'permanent_paths':11,
  'modified_paths':3,
  'added_paths':8,
  'workflow_paths':0,
  'source_export':{'workflow_run':31223901158,'artifact':9011399743,'zip_sha256':'0009dc40ae1c9be74e4b89c7fd4deb05e8eec3bc5f3fd8b2a88a7dc74e96c28e','source_files':233},
  'source_lanes':23,
  'central_projection_lanes':15,
  'post_cutoff_lanes':8,
  'active_source_leases':0,
  'candidate_successors':0,
  'adversarial_refusals':15,
  'identity_admissions':0,
  'relationship_admissions':0,
  'negative_existence_claims':0,
  'outside_human_dependency':False,
  'publication_effect':'none',
  'adoption_effect':'none',
  'graph_effect':'none',
  'public_schoolhouse_legal_identity':'unresolved',
  'deterministic_replay':'pass',
  'focused_validation':'pass',
  'bvvc_validation':'pass',
  'no_magic_human':'pass',
  'release_check':'pass',
  'files':rows,
}
out.write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
PY
cp "$WORK/generation-summary.json" "$RECEIPT/"
cp "$WORK/replay-summary.json" "$RECEIPT/"
cp "$WORK/product-name-status" "$RECEIPT/"
cp "$WORK/product-patch-sha256" "$RECEIPT/"
printf 'complete\n' > "$RECEIPT/STAGE"
