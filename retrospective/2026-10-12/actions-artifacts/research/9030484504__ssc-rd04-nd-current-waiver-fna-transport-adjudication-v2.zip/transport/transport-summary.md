# RD-04 North Dakota current-waiver FNA four-route transport

Fixed routes: 4
Physical requests: 6
HTTP successes: 3
HTTP non-successes: 1
Transport errors: 0
Followed redirects: 2
Refused redirects: 0
Captured final body bytes: 194453

Transport creates no source admission, field classification, matrix update, row transition, class closure, publication, adoption, or graph effect.
