<!-- m04g-global-orbit-proof:30826684691 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30826684691
- Head: `fb45f08ee0b7103b0f06cf206f68ac4bcbb0e17d`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `4/10` (`0.4`)
- Content success: `4/10` (`0.4`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/2`
- Proof SHA-256: `3d3826630aba95d7637dd1559d3f927cd339e6bd59aa0e061bc013ee85fb89ab`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
