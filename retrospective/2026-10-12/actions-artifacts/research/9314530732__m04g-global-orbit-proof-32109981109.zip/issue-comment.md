<!-- m04g-global-orbit-proof:32109981109 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32109981109
- Head: `cd4af78e4be5988bff81194a6150471d811e38b6`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `18/25` (`0.72`)
- Content success: `16/25` (`0.64`)
- Metadata only: `2`
- Failed: `7`
- Healthy basins: `0/5`
- Proof SHA-256: `8122bd47820b265a39b32d501513dd65718616ad04fce6009812a4bd8d1ee249`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
