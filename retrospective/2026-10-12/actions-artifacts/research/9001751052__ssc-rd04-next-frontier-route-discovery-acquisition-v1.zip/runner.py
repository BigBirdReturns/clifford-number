from __future__ import annotations

import hashlib
import html
import json
import os
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
from collections import defaultdict
from pathlib import Path
from typing import Any

OUT = Path(os.environ["OUT"])
PROTOCOL_DIR = Path(os.environ["PROTOCOL_DIR"])
PROTOCOL_MERGE = os.environ["PROTOCOL_MERGE"]
CARRIER_PARENT = os.environ["CARRIER_PARENT"]
LIVE_MAIN = os.environ["LIVE_MAIN"]
HEAD_SHA = os.environ["HEAD_SHA"]
HEAD_PARENT = os.environ["HEAD_PARENT"]

EXPECTED_STATES = [
    "US-STATE-FL",
    "US-STATE-MT",
    "US-STATE-ND",
    "US-STATE-OR",
    "US-STATE-WI",
]
EXPECTED_FIELDS = [
    "abawd_or_work_requirement_waiver_state_and_governing_period",
    "implementation_effective_date_or_typed_gap",
    "operative_state_implementation_authority_and_version",
    "verification_evidence_and_staff_discretion_surface",
]
ALLOWED_HOST = "www.fna.usda.gov"
EXACT_URL = "https://www.fna.usda.gov/snap-directory-entry/florida"
MAX_REDIRECTS = 4
MAX_BODY_BYTES = 8 * 1024 * 1024
USER_AGENT = "clifford-number-rd04-route-discovery/1.0 (bounded public-record research)"

def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def canonical_json(value: Any) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")

def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canonical_json(value))

def read_json(name: str) -> Any:
    return json.loads((PROTOCOL_DIR / name).read_text(encoding="utf-8"))

protocol = read_json("route-discovery-protocol.json")
query_contract = read_json("route-query-contract.json")
locator_inventory = read_json("official-locator-inventory.json")
frontier = read_json("frontier-selection.json")
summary = read_json("summary.json")
product_manifest = read_json("product-manifest.json")
assert product_manifest["combined_sha256"] == "f27663bb5c025bf012695bdb83a0d051174dd80e27cab88cfa1cd49e1f240fa8"

assert protocol["selected_state_ids"] == EXPECTED_STATES
assert protocol["selected_field_ids"] == EXPECTED_FIELDS
assert protocol["selected_substantive_cell_count"] == 20
assert protocol["obligation_count"] == 20
assert protocol["fixed_repository_route_cells"] == 16
assert protocol["bounded_official_route_discovery_cells"] == 4
assert protocol["maximum_total_discovery_requests"] == 120
assert protocol["maximum_total_candidate_urls"] == 240
assert protocol["source_requests_executed"] == 0
assert protocol["source_admissions"] == 0
assert protocol["field_mutations"] == 0
assert protocol["row_state_mutations"] == 0
assert protocol["class_closed"] is False
assert protocol["outside_human_dependency"] is False

assert query_contract["selected_state_ids"] == EXPECTED_STATES
assert query_contract["selected_field_ids"] == EXPECTED_FIELDS
assert query_contract["allowed_discovery_surfaces"] == [
    "repository_native_exact_url",
    "official_root_robots_txt",
    "official_root_sitemap_xml",
    "official_site_search",
]
assert query_contract["maximum_official_roots_per_state"] == 2
assert query_contract["maximum_discovery_requests_per_root"] == 3
assert query_contract["maximum_candidate_urls_per_cell"] == 12
assert query_contract["maximum_attempts_per_request"] == 1
assert query_contract["maximum_redirects"] == MAX_REDIRECTS
assert query_contract["result_spawned_source_fetches"] == 0
assert query_contract["cross_host_redirects_allowed"] is False
assert query_contract["automatic_source_admission"] is False
assert query_contract["automatic_field_classification"] is False
assert query_contract["outside_human_dependency"] is False

assert frontier["selected_state_ids"] == EXPECTED_STATES
assert frontier["selected_field_ids"] == EXPECTED_FIELDS
assert frontier["selected_substantive_cell_count"] == 20
assert frontier["terminal_cells_before"] == 218
assert frontier["open_substantive_cells_before"] == 192
assert frontier["derivative_row_state_cells_excluded"] == 5

assert summary["protocol_obligations"] == 20
assert summary["fixed_repository_route_cells"] == 16
assert summary["bounded_official_route_discovery_cells"] == 4
assert summary["source_requests_executed"] == 0
assert summary["source_admissions"] == 0
assert summary["field_mutations"] == 0
assert summary["row_state_mutations"] == 0

assert locator_inventory["selected_state_ids"] == EXPECTED_STATES
assert locator_inventory["selected_field_ids"] == EXPECTED_FIELDS
assert locator_inventory["state_official_roots"]["US-STATE-FL"] == ["https://www.fna.usda.gov/"]
for field_id in EXPECTED_FIELDS:
    coverage = locator_inventory["coverage"]["US-STATE-FL"][field_id]
    assert coverage["uncaptured_repository_urls"] == [EXACT_URL]

bounded = [row for row in protocol["obligations"] if row["mode"] == "bounded_official_route_discovery"]
fixed = [row for row in protocol["obligations"] if row["mode"] == "fixed_repository_routes"]
assert len(bounded) == 4
assert len(fixed) == 16
assert {row["state_id"] for row in bounded} == {"US-STATE-FL"}
assert [row["field_id"] for row in bounded] == EXPECTED_FIELDS
for row in bounded:
    assert row["official_roots"] == ["https://www.fna.usda.gov/"]
    assert row["repository_candidate_urls"] == [EXACT_URL]
    assert row["maximum_candidate_urls"] == 12
    assert row["maximum_discovery_requests"] == 6
    assert row["automatic_source_admission"] is False
    assert row["automatic_field_classification"] is False
    assert row["terminalizes_field"] is False

protocol_custody = {
    "schema_version": "ssc-rd04-next-frontier-route-discovery-acquisition-custody@1",
    "protocol_merge": PROTOCOL_MERGE,
    "carrier_parent": CARRIER_PARENT,
    "carrier_head": HEAD_SHA,
    "observed_head_parent": HEAD_PARENT,
    "live_main_at_execution": LIVE_MAIN,
    "protocol_product_manifest_combined_sha256": product_manifest["combined_sha256"],
    "files": {
        "frontier-selection.json": {
            "git_blob": "91b46dc3a7f0b07eab52b7ff6d72479283865212",
            "sha256": "8820c52d4e082e38ee4d29fa8473cc2c6039c46dc6fe35e94a444782af7cecef",
        },
        "official-locator-inventory.json": {
            "git_blob": "7c70af86d659e031bdfa8272cac4acc787783d93",
            "sha256": "bf76d6c896354fbf46e94a63212ea66413a37359f87ea2ed14b5e9e6e3decd04",
        },
        "route-query-contract.json": {
            "git_blob": "d462416eba18d65c993a038d38619c27bac55cd6",
            "sha256": "762907f4ecf945961c9a5463a70131449601fb5fc6c0116bb915ec618e7c3f83",
        },
        "route-discovery-protocol.json": {
            "git_blob": "35e09035659d54060547e84ab29d5ba440402b2c",
            "sha256": "b0d9fa6250f59260b1899cad782ca507a7b3ff1fb88c1265c1ec8a753d252ca7",
        },
        "summary.json": {
            "git_blob": "c00e4af7f39f2b441a63b09d0b2c3ab395e02966",
            "sha256": "af95434dde35207dc652548e1964efc23e500bca0ef5a0ccab51cbad3cd512c8",
        },
    },
    "selected_state_ids": EXPECTED_STATES,
    "selected_field_ids": EXPECTED_FIELDS,
    "selected_substantive_cells": 20,
    "bounded_obligations_executed": 4,
    "fixed_obligations_not_requested": 16,
    "outside_human_dependency": False,
    "source_admissions": 0,
    "field_mutations": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
}
write_json(OUT / "protocol-custody.json", protocol_custody)

request_plan = {
    "schema_version": "ssc-rd04-next-frontier-route-discovery-request-plan@1",
    "official_root": "https://www.fna.usda.gov/",
    "allowed_host": ALLOWED_HOST,
    "maximum_requests_for_root": 3,
    "maximum_attempts_per_request": 1,
    "maximum_redirects": MAX_REDIRECTS,
    "cross_host_redirects_allowed": False,
    "maximum_body_bytes_per_request": MAX_BODY_BYTES,
    "result_spawned_source_fetches": 0,
    "requests": [
        {
            "request_id": "RD04-NF-DISCOVERY-001",
            "surface": "repository_native_exact_url",
            "url": EXACT_URL,
        },
        {
            "request_id": "RD04-NF-DISCOVERY-002",
            "surface": "official_root_robots_txt",
            "url": "https://www.fna.usda.gov/robots.txt",
        },
        {
            "request_id": "RD04-NF-DISCOVERY-003",
            "surface": "official_root_sitemap_xml",
            "url": "https://www.fna.usda.gov/sitemap.xml",
        },
    ],
}
write_json(OUT / "request-plan.json", request_plan)

class CrossHostRedirect(RuntimeError):
    def __init__(self, old_url: str, new_url: str):
        super().__init__(f"cross-host redirect refused: {old_url} -> {new_url}")
        self.old_url = old_url
        self.new_url = new_url

class TooManyRedirects(RuntimeError):
    pass

class SameHostRedirect(urllib.request.HTTPRedirectHandler):
    def __init__(self) -> None:
        super().__init__()
        self.redirects: list[dict[str, Any]] = []

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        resolved = urllib.parse.urljoin(req.full_url, newurl)
        old_host = (urllib.parse.urlsplit(req.full_url).hostname or "").lower()
        new_parts = urllib.parse.urlsplit(resolved)
        new_host = (new_parts.hostname or "").lower()
        if new_parts.scheme != "https" or old_host != ALLOWED_HOST or new_host != ALLOWED_HOST:
            raise CrossHostRedirect(req.full_url, resolved)
        self.redirects.append({"status": code, "from": req.full_url, "to": resolved})
        if len(self.redirects) > MAX_REDIRECTS:
            raise TooManyRedirects(f"more than {MAX_REDIRECTS} redirects")
        return super().redirect_request(req, fp, code, msg, headers, resolved)

def normalize_url(raw: str, base_url: str) -> str | None:
    raw = html.unescape(raw.strip().strip("\"'()[]{}<>.,;"))
    if not raw or raw.startswith(("#", "mailto:", "tel:", "javascript:", "data:")):
        return None
    absolute = urllib.parse.urljoin(base_url, raw)
    parts = urllib.parse.urlsplit(absolute)
    host = (parts.hostname or "").lower()
    if parts.scheme != "https" or host != ALLOWED_HOST:
        return None
    port = f":{parts.port}" if parts.port and parts.port != 443 else ""
    path = re.sub(r"/{2,}", "/", parts.path or "/")
    return urllib.parse.urlunsplit(("https", host + port, path, parts.query, ""))

def extract_urls(body: bytes, base_url: str) -> set[str]:
    text = body.decode("utf-8", errors="replace")
    raw_values: set[str] = set()
    for match in re.finditer(r"""(?is)(?:href|src)\s*=\s*["']([^"']+)["']""", text):
        raw_values.add(match.group(1))
    for match in re.finditer(r"""(?is)<loc>\s*([^<\s]+)\s*</loc>""", text):
        raw_values.add(match.group(1))
    for match in re.finditer(r"""https://[^\s"'<>]+""", text):
        raw_values.add(match.group(0))
    result = set()
    for raw in raw_values:
        normalized = normalize_url(raw, base_url)
        if normalized:
            result.add(normalized)
    return result

def request_one(row: dict[str, Any]) -> tuple[dict[str, Any], bytes]:
    request_id = row["request_id"]
    url = row["url"]
    parts = urllib.parse.urlsplit(url)
    assert parts.scheme == "https"
    assert (parts.hostname or "").lower() == ALLOWED_HOST
    redirect_handler = SameHostRedirect()
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        redirect_handler,
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),
    )
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml,text/plain;q=0.9,*/*;q=0.1",
            "Accept-Encoding": "identity",
        },
        method="GET",
    )
    body = b""
    receipt: dict[str, Any] = {
        "request_id": request_id,
        "surface": row["surface"],
        "requested_url": url,
        "attempts": 1,
        "maximum_attempts": 1,
        "maximum_redirects": MAX_REDIRECTS,
        "cross_host_redirects_allowed": False,
        "redirects": redirect_handler.redirects,
        "source_admitted": False,
        "field_classified": False,
        "result_spawned_source_fetches": 0,
    }
    try:
        with opener.open(request, timeout=30) as response:
            body = response.read(MAX_BODY_BYTES + 1)
            truncated = len(body) > MAX_BODY_BYTES
            if truncated:
                body = body[:MAX_BODY_BYTES]
            final_url = response.geturl()
            final_parts = urllib.parse.urlsplit(final_url)
            if final_parts.scheme != "https" or (final_parts.hostname or "").lower() != ALLOWED_HOST:
                raise CrossHostRedirect(url, final_url)
            receipt.update({
                "terminal_state": "terminal_http_response",
                "http_status": int(response.status),
                "final_url": final_url,
                "redirects": redirect_handler.redirects,
                "content_type": response.headers.get("Content-Type"),
                "content_length_header": response.headers.get("Content-Length"),
                "etag": response.headers.get("ETag"),
                "last_modified": response.headers.get("Last-Modified"),
                "body_bytes": len(body),
                "body_sha256": sha256_bytes(body),
                "body_truncated": truncated,
            })
    except CrossHostRedirect as exc:
        receipt.update({
            "terminal_state": "terminal_cross_host_redirect_refused",
            "http_status": None,
            "final_url": exc.old_url,
            "refused_redirect_target": exc.new_url,
            "redirects": redirect_handler.redirects,
            "body_bytes": 0,
            "body_sha256": sha256_bytes(b""),
            "body_truncated": False,
        })
    except TooManyRedirects:
        receipt.update({
            "terminal_state": "terminal_redirect_limit_exceeded",
            "http_status": None,
            "final_url": url,
            "redirects": redirect_handler.redirects,
            "body_bytes": 0,
            "body_sha256": sha256_bytes(b""),
            "body_truncated": False,
        })
    except urllib.error.HTTPError as exc:
        body = exc.read(MAX_BODY_BYTES + 1)
        truncated = len(body) > MAX_BODY_BYTES
        if truncated:
            body = body[:MAX_BODY_BYTES]
        final_url = exc.geturl()
        final_host = (urllib.parse.urlsplit(final_url).hostname or "").lower()
        if final_host != ALLOWED_HOST:
            raise CrossHostRedirect(url, final_url)
        receipt.update({
            "terminal_state": "terminal_http_non_success",
            "http_status": int(exc.code),
            "final_url": final_url,
            "redirects": redirect_handler.redirects,
            "content_type": exc.headers.get("Content-Type"),
            "content_length_header": exc.headers.get("Content-Length"),
            "etag": exc.headers.get("ETag"),
            "last_modified": exc.headers.get("Last-Modified"),
            "body_bytes": len(body),
            "body_sha256": sha256_bytes(body),
            "body_truncated": truncated,
        })
    except Exception as exc:
        receipt.update({
            "terminal_state": "terminal_transport_failure",
            "http_status": None,
            "final_url": url,
            "redirects": redirect_handler.redirects,
            "error_type": type(exc).__name__,
            "error": str(exc),
            "body_bytes": 0,
            "body_sha256": sha256_bytes(b""),
            "body_truncated": False,
        })
        body = b""
    return receipt, body

request_receipts: list[dict[str, Any]] = []
response_manifest: list[dict[str, Any]] = []
discovered_by_surface: dict[str, set[str]] = defaultdict(set)
for request_row in request_plan["requests"]:
    receipt, body = request_one(request_row)
    response_path = OUT / "responses" / f"{receipt['request_id']}.bin"
    response_path.write_bytes(body)
    receipt["response_path"] = str(response_path.relative_to(OUT))
    assert receipt["body_sha256"] == sha256_bytes(body)
    request_receipts.append(receipt)
    response_manifest.append({
        "request_id": receipt["request_id"],
        "path": receipt["response_path"],
        "bytes": len(body),
        "sha256": sha256_bytes(body),
        "terminal_state": receipt["terminal_state"],
        "http_status": receipt["http_status"],
        "final_url": receipt["final_url"],
    })
    base_url = receipt.get("final_url") or request_row["url"]
    for candidate in extract_urls(body, base_url):
        discovered_by_surface[receipt["surface"]].add(candidate)

assert len(request_receipts) == 3
assert all(row["attempts"] == 1 for row in request_receipts)
assert all(row["result_spawned_source_fetches"] == 0 for row in request_receipts)
assert all(row["source_admitted"] is False for row in request_receipts)
assert all(row["field_classified"] is False for row in request_receipts)

with (OUT / "request-ledger.jsonl").open("w", encoding="utf-8") as handle:
    for row in request_receipts:
        handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")
write_json(OUT / "response-manifest.json", {
    "schema_version": "ssc-rd04-next-frontier-route-discovery-response-manifest@1",
    "responses": response_manifest,
})

field_keywords = {
    "abawd_or_work_requirement_waiver_state_and_governing_period": [
        "abawd", "waiver", "work-requirement", "work_requirement", "time-limit", "time_limit",
    ],
    "implementation_effective_date_or_typed_gap": [
        "effective", "implementation", "date", "notice",
    ],
    "operative_state_implementation_authority_and_version": [
        "manual", "policy", "handbook", "rule", "authority", "version",
    ],
    "verification_evidence_and_staff_discretion_surface": [
        "verification", "evidence", "eligibility", "worker", "staff", "discretion",
    ],
}
all_discovered: dict[str, set[str]] = defaultdict(set)
for surface, urls in discovered_by_surface.items():
    for candidate in urls:
        all_discovered[candidate].add(surface)

candidate_rows: list[dict[str, Any]] = []
for obligation in bounded:
    field_id = obligation["field_id"]
    scored: list[tuple[int, str, list[str]]] = []
    for candidate, origins in all_discovered.items():
        lowered = candidate.lower()
        score = sum(1 for keyword in field_keywords[field_id] if keyword in lowered)
        if candidate == EXACT_URL:
            score += 100
        elif "/snap" in lowered or "food" in lowered:
            score += 1
        if score > 0:
            scored.append((score, candidate, sorted(origins)))
    if EXACT_URL not in {candidate for _, candidate, _ in scored}:
        scored.append((100, EXACT_URL, ["repository_native_exact_url"]))
    scored.sort(key=lambda item: (-item[0], item[1]))
    for ordinal, (score, candidate, origins) in enumerate(scored[:12], 1):
        candidate_rows.append({
            "obligation_id": obligation["obligation_id"],
            "state_id": obligation["state_id"],
            "field_id": field_id,
            "candidate_ordinal": ordinal,
            "candidate_url": candidate,
            "candidate_host": ALLOWED_HOST,
            "relevance_score": score,
            "discovery_surfaces": origins,
            "candidate_only": True,
            "source_admitted": False,
            "field_classified": False,
            "terminalizes_field": False,
            "result_spawned_source_fetches": 0,
        })

assert len({row["obligation_id"] for row in candidate_rows}) == 4
assert all(1 <= row["candidate_ordinal"] <= 12 for row in candidate_rows)
assert all(row["candidate_host"] == ALLOWED_HOST for row in candidate_rows)
assert all(row["source_admitted"] is False for row in candidate_rows)
assert all(row["field_classified"] is False for row in candidate_rows)
with (OUT / "candidate-route-ledger.jsonl").open("w", encoding="utf-8") as handle:
    for row in candidate_rows:
        handle.write(json.dumps(row, sort_keys=True, ensure_ascii=False) + "\n")

state_counts = defaultdict(int)
for row in request_receipts:
    state_counts[row["terminal_state"]] += 1
unique_candidate_urls = sorted({row["candidate_url"] for row in candidate_rows})
acquisition_summary = {
    "schema_version": "ssc-rd04-next-frontier-route-discovery-acquisition-summary@1",
    "protocol_merge": PROTOCOL_MERGE,
    "carrier_parent": CARRIER_PARENT,
    "carrier_head": HEAD_SHA,
    "live_main_at_execution": LIVE_MAIN,
    "selected_state_ids": EXPECTED_STATES,
    "selected_field_ids": EXPECTED_FIELDS,
    "selected_substantive_cells": 20,
    "bounded_discovery_obligations": 4,
    "fixed_repository_route_obligations_not_requested": 16,
    "planned_requests": 3,
    "request_attempts": 3,
    "terminal_request_receipts": 3,
    "request_terminal_states": dict(sorted(state_counts.items())),
    "response_bodies_preserved": 3,
    "candidate_route_rows": len(candidate_rows),
    "unique_candidate_urls": len(unique_candidate_urls),
    "maximum_candidate_urls_per_cell": 12,
    "result_spawned_source_fetches": 0,
    "source_admissions": 0,
    "field_mutations": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
}
write_json(OUT / "summary.json", acquisition_summary)

readme = f"""# RD-04 next-frontier bounded route discovery

This artifact executed only the four Florida `bounded_official_route_discovery`
obligations from canonical protocol `{PROTOCOL_MERGE}`.

It made three one-attempt requests to the one frozen official root, preserved every
terminal response, and retained same-host URLs as candidate routes only. It did not
fetch discovered candidates, admit a source, classify a field, mutate the matrix,
terminalize a row, close RD-04-C02, or change the cumulative ledger.

```text
request attempts:                  3
terminal request receipts:         3
fixed-route obligations requested: 0 / 16
result-spawned source fetches:      0
source admissions:                 0
field / row mutations:             0 / 0
outside-human dependency:          false
publication / adoption / graph:    none / none / none
```
"""
(OUT / "README.md").write_text(
    "\n".join(line.strip() for line in readme.strip().splitlines()) + "\n",
    encoding="utf-8",
)

checksum_paths = sorted(
    path for path in OUT.rglob("*")
    if path.is_file() and path.name not in {"SHA256SUMS", "RUNNER_EXIT_CODE", "run.log"}
)
(OUT / "SHA256SUMS").write_text(
    "".join(
        f"{sha256_bytes(path.read_bytes())}  {path.relative_to(OUT)}\n"
        for path in checksum_paths
    ),
    encoding="utf-8",
)
(OUT / "RUNNER_EXIT_CODE").write_text("0\n", encoding="utf-8")
print(json.dumps(acquisition_summary, indent=2, sort_keys=True))
