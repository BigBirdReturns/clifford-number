# The Arcadia Formation: analysis

Case `arcadia-field-autopsy` (FA-2026-0714-ARC1), as of 2026-07-14.

Standing boundary: no wrongdoing is alleged anywhere in this analysis.
Sequence, adjacency, shared incentives, and cultural practice are not
coordination. Structural convergence is the null hypothesis throughout, and
nothing here aggregates on ethnicity, religion, ancestry, or national origin.

## 1. What the relayed conversation inventory suggested, then research re-derived

The exact conversation transcript is not in the case bundle. A relayed
nineteen-item inventory preserved the subjects and claims attributed to it;
that reconstruction suggested several structural readings that independent
research later supported or narrowed:

- The two-racetrack distinction (1907 Baldwin track vs. 1934 Santa Anita
  Park) — including the author's own mid-conversation self-correction —
  matches the record exactly (con-01).
- The wartime layer: Santa Anita Assembly Center (1942, peak 18,719, horse
  stalls) followed by Army use (con-02).
- Baldwin as the one actor among the documented regimes in this reconstruction
  who held every listed control layer at once —
  land, water endowment, rail access, townsite, mayoralty, vice licensing —
  for 1903–1909 (con-03).
- The physical substrate: alluvial-fan aquifers, mountain-stream recharge,
  the Raymond fault as a groundwater barrier, the 1944 adjudication (con-04,
  refined).
- The deep sequence: documented public planning long preceded the train and
  today's private development (clm-gp-2010, clm-rda); the asserted 1993 title
  itself remains unresolved (con-10).
- Its own late walkback from "master plan" to "formation" — which is where
  the comparative evidence actually lands (con-08).

## 2. What was independently re-derived

The following principal historical facts were re-derived against public receipts:
the rancho grant chain; the 1875 Baldwin purchase ($200,000); the 1885 rail
right-of-way; the 1903 incorporation; both racetracks with day-precision
opening dates; the 1936 Chandler-syndicate sale; the assembly center and Camp
Santa Anita; the 1944 Raymond Basin adjudication (California's first); the
Stronach lineage from 1998; the Redevelopment Agency (1968) and Central
Project Area (1973); the Downtown 2000 street reconstruction; Measure R
(2008); the 2010 General Plan that placed a Downtown Mixed-Use district
around a station "planned at" First and Santa Clara 5.5 years before opening;
the 2016 station opening; the DMU zoning ladder (2016 code, 2022 Housing
Element, 2024 rezonings); each named downtown project with entitlement dates;
the DAIA's nonprofit and assessment-district forms; and the current First
Avenue scope. The case now carries 100 receipt records representing 99 unique
web locators. New receipt-v2 records are search-linked and declare durability;
the inherited receipt set still contains URL-only provenance debt.

## 3. What was corrected or contradicted

- **"1993 Downtown Revitalization Strategy"** — unresolved. No document by
  that title surfaced in the bounded online search; the independently
  documented machinery begins with the 1968/1973 redevelopment apparatus and
  includes the "Downtown 2000" program (con-10).
- **First Avenue's current construction** — arterial pavement rehabilitation
  plus pedestrian bulb-outs (Huntington to Duarte, south of the core), Prop
  C/STPL-funded, no water-main scope. The full utility/streetscape rebuild of
  First was the earlier Downtown 2000 era (con-12).
- **The First/Huntington/Valencia policy geometry** — unsupported on the
  inspected adopted-plan surfaces, not globally rejected; the plan universe
  was not exhaustive (con-13).
- **DAIA's powers** — the audit reversed the case's own earlier correction.
  An official City staff report states property owners approved the Community
  Benefits District in 2013, documents assessment revenue and bylaw
  allocations, and identifies the City as a member paying assessments on five
  parcels plus recurring in-kind support. DAIA is also a 501(c)(3); those are
  compatible forms, not mutually exclusive explanations (con-11, af-r01).
- **Alexan on church/city land** — corrected. Alexan Azalea replaced private
  commercial buildings and surface parking; Alexan Arroyo sits on a former
  private school. The city-held church site (21 Morlan Place) connects to the
  Rusnak dealership deal, not to any Alexan (con-05).
- **Repeat intermediaries** — bounded. Studio One Eleven repeats within the
  four inspected project records and within Trammell Crow's two projects;
  the sample does not establish that no cross-developer repeat exists (con-06).
- **Pre-station "patient ownership"** — unresolved. The retrieved 2024
  purchase post-dates opening, while the county deed chronology has not been
  searched completely (con-07).
- **Erik Wahl's Positive Investments role** — a December 2023 federal filing
  supplies the missing source-explicit title: Asset Manager. This resolves the
  title at that date, not unbounded tenure or corporate-officer status
  (clm-wahl-pi, af-r02).
- **Raymond fault** — refined: a complete barrier only at its western end;
  much of Arcadia pumps the Main San Gabriel Basin (con-04).

All corrections preserve the original observations in `observations.jsonl`;
the validator fails if any corrected claim disappears.

## 4. What remains interpretive

Four hypotheses are preserved with `graph_effect: none` (hypotheses.jsonl):
geomantic siting logic as a shaping force (hyp-01), the ley-line/"mana-sieve"
energy reading (hyp-02), orientation intent behind the First Avenue works
(hyp-03), and the single-controlling-man frame (hyp-04). The documented
material record adjacent to hyp-01 is real but scoped: LA Times-reported feng
shui-informed siting with named designers in the mansion market; peer-reviewed
4/8 address premia in a comparable market (Vancouver); one feng-shui-master
groundbreaking date in Tacoma. No inspected receipt connects geomantic advice to the named
downtown projects (con-14, a coverage absence, not a disproof). Ley lines are
a Western esoteric tradition, not part of the practices documented in this
market. None of this becomes ethnic command, conspiracy, or a supernatural
claim.

## 5. What remains unsearched, partial, unavailable, or unresolved

Twenty-one coverage entries (coverage.jsonl): 20 partially searched and one
intentionally not searched. Access blocks are preserved inside the partial
rows rather than being laundered into whole-topic unavailability.
The load-bearing open surfaces are:
recorder deed-party images and pre-2016 parcel chronology (cov-02/cov-10) —
the live facts under the pre-positioning question; the
DAIA's original enabling and renewal instruments (cov-08); the direct CA SOS
record for Positive Investments is now resolved, while its self-claimed 1976
founding and broader officer history remain partial (cov-03); Erik Wahl's title
tenure beyond the dated filing; and the original conversation transcript (cov-01, open because
only the repo and GitHub issues were searched). Santa Anita Wash completion
dates are now bounded to January 1959 and January 1960 by official reports;
Le Méridien now has bounded evidence of an EB-5 component, while legal vehicles,
amounts, petition status, Hilton corroboration, and other projects remain open.
"Mary's"/"René" referents remain out of
scope under the redaction policy.

## 6. The actual temporal control structure

Thirteen distinct regimes (chronology.json), never collapsed: Tongva
landscape → mission/rancho → **Baldwin's consolidated control (1875–1909, the
only single-actor era represented in this reconstruction)** → inheritance and subdivision (1909–1947) → Turf
Club and successor private track operation (1933–present, Stronach from 1998)
→ wartime federal control (1942–1945) → adjudicated-water suburbanization and
postwar channelization (1944–) → redevelopment and rail planning (1968–2016)
→ assessment-funded Community Benefits District era (2012–) → transit
activation (2016) → documented acquisition/assembly
(2016–) → entitlement and construction (2016–) → present street
reconstruction (2025–). Every event and role in the case names its regime.
"Connected to Arcadia" appears nowhere as a predicate.

## 7. The strongest repeat intermediaries

Bounded by the inspected project sample. Studio One Eleven repeats across
both inspected TCR projects; the reported TCR/Positive Investments JV connects
the development parties; and Erik Wahl has two source-explicit roles—DAIA
president and Positive Investments Asset Manager at least in December 2023.
The City's planning/redevelopment apparatus is the recurring institution.
The person-level Ben Zhang join is now specifically corroborated across the
Town Center/New World applicant interface and bounded DAIA filings (FY2022–
FY2025). That correction does not collapse the organizations: Arcadia Town
Center, LLC and the New World variants remain distinct labels pending a legal
crosswalk. Nor does the join establish who authored, authorized, or caused
DAIA's Town Center support letter. The current sample neither establishes nor
excludes a broader cross-developer professional repeat.

## 8. Whether private positioning preceded or followed public de-risking

In the currently dated sample, documented private transactions follow public
de-risking:
planning (1968/1973/2010) → funding (2008) → construction (2010) → opening
(2016) → the earliest retrieved Alexan owner snapshot (2018) → institutional entitlements
(2022–2025) → reported JV land purchase (2024). Comparable corridors show the
same broad stages with different actors, and California policy actively
promotes station-area development. Assessor histories now bound post-opening
transaction chronology but do not name parties; Arcadia's pre-opening ownership
sequence remains unresolved because recorder deed images are incomplete. The sample
cannot support a universal timing claim.

## 9. What public value was created and who appears positioned to capture it

Created: tax-increment-funded downtown reconstruction (Downtown 2000-era
streetscape, water system, facades), a Measure R-funded rail line and
station with a 300-space public structure, DMU upzoning (60 ft / 80 du/acre,
parking reductions), housing-element rezonings, and current Prop C/ARPA
street and streetscape work. Positioned to capture the uplift: owners of
station-adjacent land at entitlement time — documented instances are the
TCR/Positive Investments JV (319 units), Elite Real Estate Holdings (Derby,
with a zone change), distinct official Arcadia Town Center and New World
applicant interfaces (five-parcel assembly; not legally joined), DPP
Arcadia (57 Wheeler), and the Chateau Group hotel. Capture through lawful
channels — buying, entitling, building — with the value-capture asymmetry
itself being a control question, not a settled finding: public works and
private development gains coexist with an active assessment-funded district
and City membership in that district. The racetrack feeds back
into public capital via pari-mutuel revenue to the city's Capital Outlay
Fund — a documented spectacle-to-infrastructure loop.

## 10. The reusable formation signature and the new evidence trails

`sig-place-formation-v1` (data/signatures/formation-signatures.json): public
infrastructure → entitlement expansion → assessment/intermediary governance →
patient ownership → parcel assembly → institutional developer → concentrated
uplift, with optional signals (inherited water/land regime, spectacle
infrastructure, transit activation, public-realm regularization, recurring
intermediaries, culturally informed orientation/timing, displacement/value-
capture asymmetry). Expansion produces bounded candidate searches only —
`graph_effect: none`, `promotes_to: candidate_only` — and the validator fails
any trail that tries to promote a match into a finding. Ten trails are now
emitted into the general research fan-out
(trails.jsonl): deed chronology, DAIA instruments, Monrovia and Duarte
controls, the K Line control, geomantic-mechanism statements, Wahl's title,
station cost share, EB-5, and transcript recovery. None is terminal. The same
signature expands a neutral Monrovia/Duarte/Azusa control universe into
bounded, candidate-only tasks, making the formation signature executable
rather than ornamental.

## Closing note

The current bounded record supports a multi-regime formation reading, not a mastermind: thirteen control
regimes, one man who held every documented layer concurrently — a century
ago — and several core stages that recur in Monrovia, Pasadena, and Azusa with
different actors and different governance mechanisms. Pasadena's PBID overlaps
its station neighborhood; Monrovia's Old Town BID does not cover Station Square;
Azusa's inspected record centers planning and development agreements. Deed-level
and statewide-denominator gaps remain open rather than being generalized. The hypotheses that
would make it more than that are preserved, searchable, and graph-inert
until receipts say otherwise.
