<!-- m04g-global-orbit-proof:32140568158 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32140568158
- Head: `b8d966f8d0cae43d3a132bb84731cad32647b1f9`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `5/10` (`0.5`)
- Content success: `5/10` (`0.5`)
- Metadata only: `0`
- Failed: `5`
- Healthy basins: `0/2`
- Proof SHA-256: `063d8b5f0736050a6b05ccefdec5d9e318a085f63b60f98ccc10877078c020ff`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
