import json
import re
import subprocess
from pathlib import Path

json_paths = [
    'build/axm-identity.json',
    'build/build-hop-report.json',
    'build/hop-graph.json',
    'build/migration-summary.json',
    'build/receipt-graph.json',
    'build/scores.json',
    'build/scout-report.json',
    'build/surface-graph.json',
]
markdown_paths = [
    'build/migration-review.md',
    'build/scout-report.md',
]
paths = json_paths + markdown_paths
iso = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$')

raw = subprocess.check_output(['git', 'worktree', 'list', '--porcelain'], text=True)
worktrees = [
    Path(line.removeprefix('worktree '))
    for line in raw.splitlines()
    if line.startswith('worktree ')
]
if not worktrees:
    raise SystemExit('registered worktree denominator is zero')

def head_bytes(root: Path, path: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(root), 'show', f'HEAD:{path}'])

def normalize_markdown(raw_bytes: bytes, label: str) -> bytes:
    text = raw_bytes.decode('utf-8')
    lines = text.splitlines(keepends=True)
    indexes = [i for i, line in enumerate(lines) if line.startswith('Generated: ')]
    if len(indexes) != 1:
        raise SystemExit(f'{label}: Generated-line denominator drift: {len(indexes)}')
    index = indexes[0]
    stamp = lines[index][len('Generated: '):].rstrip('\r\n')
    if not iso.fullmatch(stamp):
        raise SystemExit(f'{label}: malformed generated timestamp: {stamp!r}')
    ending = '\r\n' if lines[index].endswith('\r\n') else '\n' if lines[index].endswith('\n') else ''
    lines[index] = 'Generated: <normalized>' + ending
    return ''.join(lines).encode('utf-8')

restored_roots = []
for root in worktrees:
    if not all((root / path).is_file() for path in paths):
        continue
    changed = []
    for path in paths:
        before = head_bytes(root, path)
        after = (root / path).read_bytes()
        if before == after:
            continue
        if path.endswith('.json'):
            old = json.loads(before)
            new = json.loads(after)
            if not isinstance(old, dict) or not isinstance(new, dict):
                raise SystemExit(f'{root}:{path}: expected top-level JSON objects')
            if set(old) != set(new) or 'generated' not in old:
                raise SystemExit(f'{root}:{path}: JSON structure changed outside timestamp')
            if not isinstance(old['generated'], str) or not iso.fullmatch(old['generated']):
                raise SystemExit(f'{root}:{path}: malformed HEAD generated timestamp')
            if not isinstance(new['generated'], str) or not iso.fullmatch(new['generated']):
                raise SystemExit(f'{root}:{path}: malformed worktree generated timestamp')
            old['generated'] = '<normalized>'
            new['generated'] = '<normalized>'
            if old != new:
                raise SystemExit(f'{root}:{path}: substantive generated product drift')
        else:
            if normalize_markdown(before, f'{root}:{path}') != normalize_markdown(after, f'{root}:{path}'):
                raise SystemExit(f'{root}:{path}: substantive markdown generated product drift')
        changed.append(path)
    if len(changed) not in (0, 10):
        raise SystemExit(f'{root}: generated timestamp drift denominator: {len(changed)} {changed}')
    if changed:
        subprocess.run(
            ['git', '-C', str(root), 'restore', '--staged', '--worktree', '--', *changed],
            check=True,
        )
        restored_roots.append(str(root))

print(json.dumps({
    'registered_worktrees': len(worktrees),
    'restored_worktrees': restored_roots,
    'generated_timestamp_paths_per_restore': 10,
}, sort_keys=True))
