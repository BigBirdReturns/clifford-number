from pathlib import Path
import hashlib, json

root = Path.cwd()
receipts_dir = root / 'receipts/topology'
receipts_dir.mkdir(parents=True, exist_ok=True)

DOCS = {
    'articles': {
        'receipt_id': 'companies-house-electric-twin-articles-2025-09-12',
        'path': 'receipts/topology/companies-house-electric-twin-articles-2025-09-12.md',
        'token': 'MzQ4MjEzNzAyN2FkaXF6a2N4',
        'source_published_at': '2025-09-23',
        'event_date': '2025-09-12',
        'pdf_sha256': '84a0363d5e2b8075c3d68cf06c769e0e20cf98164f1b7bc48283c473e1dc3bae',
        'pages': 71,
        'label': 'Companies House — Electric Twin articles adopted 12 Sep 2025',
    },
    'resolutions': {
        'receipt_id': 'companies-house-electric-twin-written-resolutions-2025-09-12',
        'path': 'receipts/topology/companies-house-electric-twin-written-resolutions-2025-09-12.md',
        'token': 'WUVCTVcwSFZhZGlxemtjeA',
        'source_published_at': '2025-09-23',
        'event_date': '2025-09-12',
        'pdf_sha256': '4be21af31cd198d2ce0778b6822affb8521285f4a6635c3e59ea8b246e4c94f9',
        'pages': 16,
        'label': 'Companies House — Electric Twin written resolutions dated 12 Sep 2025',
    },
    'sh01_16': {
        'receipt_id': 'companies-house-electric-twin-sh01-seed2-2025-09-16',
        'path': 'receipts/topology/companies-house-electric-twin-sh01-seed2-2025-09-16.md',
        'token': 'MzQ4MjU1OTUyN2FkaXF6a2N4',
        'source_published_at': '2025-09-24',
        'event_date': '2025-09-16',
        'pdf_sha256': 'd5bf1925b668d74f14db174b7d1e8466331b98de0f2712e95893ad2612e52cb8',
        'pages': 4,
        'filing_code': 'XEBSKAZE',
        'label': 'Companies House — Electric Twin SH01 Seed 2 allotment, 16 Sep 2025',
    },
    'sh01_17': {
        'receipt_id': 'companies-house-electric-twin-sh01-seed2-2025-09-17',
        'path': 'receipts/topology/companies-house-electric-twin-sh01-seed2-2025-09-17.md',
        'token': 'MzQ4MjcxNDczNGFkaXF6a2N4',
        'source_published_at': '2025-09-25',
        'event_date': '2025-09-17',
        'pdf_sha256': '968c309927a7ccc3eb503af7afd9fccb179808de85bbe00966af53848106ed74',
        'pages': 4,
        'filing_code': 'XEBVCAMW',
        'label': 'Companies House — Electric Twin SH01 Seed 2 allotment, 17 Sep 2025',
    },
    'sh01_26': {
        'receipt_id': 'companies-house-electric-twin-sh01-seed2-2025-09-26',
        'path': 'receipts/topology/companies-house-electric-twin-sh01-seed2-2025-09-26.md',
        'token': 'MzQ4Mjk5NzQ3NGFkaXF6a2N4',
        'source_published_at': '2025-09-29',
        'event_date': '2025-09-26',
        'pdf_sha256': '960efdcefac74efbd0fad48bcf2a1724eab7bfa5a5719a43f2d373ffaa5e274d',
        'pages': 4,
        'filing_code': 'XEC3EZXL',
        'label': 'Companies House — Electric Twin SH01 Seed 2 allotment, 26 Sep 2025',
    },
    'sh08': {
        'receipt_id': 'companies-house-electric-twin-sh08-seed1-2025-09-16',
        'path': 'receipts/topology/companies-house-electric-twin-sh08-seed1-2025-09-16.md',
        'token': 'MzQ4MjYzOTEyOGFkaXF6a2N4',
        'source_published_at': '2025-09-25',
        'event_date': '2025-09-16',
        'pdf_sha256': '6d16dc98745a3bc9c0a1b498c8ad6fb70d1d68ddb924796b50ab0c7913198738',
        'pages': 2,
        'label': 'Companies House — Electric Twin SH08 Seed 1 redesignation, 16 Sep 2025',
    },
    'sh10': {
        'receipt_id': 'companies-house-electric-twin-sh10-rights-2025-09-12',
        'path': 'receipts/topology/companies-house-electric-twin-sh10-rights-2025-09-12.md',
        'token': 'MzQ4MjUyMzM1NGFkaXF6a2N4',
        'source_published_at': '2025-09-24',
        'event_date': '2025-09-12',
        'pdf_sha256': '64dfc352383793e504d74906c000424d985cfde432cfb81ced58f9e1e8b20cb9',
        'pages': 4,
        'label': 'Companies House — Electric Twin SH10 rights variation, 12 Sep 2025',
    },
}

base_url = 'https://find-and-update.company-information.service.gov.uk/company/15173006/filing-history'
for d in DOCS.values():
    d['source_url'] = f"{base_url}/{d['token']}/document?download=0&format=pdf"

contents = {}
contents['articles'] = f"""# Electric Twin articles adopted 12 September 2025

- Source URL: {DOCS['articles']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Adopted by special resolution: 2025-09-12
- Filed: 2025-09-23
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['articles']['pdf_sha256']}`
- Source PDF pages: 71

## Source-bounded observations

The filed articles identify Alexander Cooper and Ben Warner as the Founders. They define Atomico as Atomico Venture VI SCSp and Atomico Venture VI (Parallel) S.C.A., SICAV-RAIF, together with permitted transferees holding shares, and define LocalGlobe as LocalGlobe XII, L.P., together with permitted transferees holding shares.

Article 25 limits the board to five directors unless the company determines otherwise by ordinary resolution with prior Founder Majority consent. Founder Majority may appoint a majority of the directors then appointed. While Atomico and its permitted transferees hold equity shares, Atomico may appoint and maintain one director and may appoint one non-voting board observer who may speak and receive board papers. While LocalGlobe and its permitted transferees hold equity shares, LocalGlobe may appoint and maintain one director. Article 25.6 permits directors and the investor observer, at their request, to serve on board committees and on boards or committees of subsidiary undertakings.

Article 27 states that the initial quorum for a directors' meeting is three directors and must include at least one Investor Director if one is appointed. If the meeting lacks a quorum, it is adjourned; if the adjourned meeting still lacks a quorum after half an hour, it proceeds. The articles therefore create an investor-presence requirement for the initial meeting, not an unconditional permanent veto over every board meeting.

Article 13 gives each Major Investor a pro rata first offer over New Securities unless Investor Majority Consent permits otherwise, subject to stated exceptions. The articles define a Major Investor as an Investor holding at least 78,251 Equity Shares with permitted transferees, adjusted for reorganisations. They define the Seed 2 Preferred Preference Amount as £9.267 per share. Articles 5 and 6 place Seed Preferred holders ahead of Ordinary holders in the liquidation and exit waterfall for the greater of the applicable Preference Amount and the as-converted Ordinary distribution.

The articles also require Investor Majority Consent for specified actions including purchases of the company's own shares and distributions of available profits. Other provisions refer to a Shareholders' Agreement and Subscription Agreement that are not included in this Companies House filing.

## Boundaries

The articles establish instrument-level rights and conditional appointment powers. They do not establish that any right was exercised, identify the recipients of the September Seed 2 allotments, prove beneficial ownership, disclose the unfiled Shareholders' Agreement or Subscription Agreement, or identify Ben Blume as the Atomico or LocalGlobe appointee. The named investor rights must remain separate from the officer-register evidence for his directorship.
"""

contents['resolutions'] = f"""# Electric Twin written resolutions dated 12 September 2025

- Source URL: {DOCS['resolutions']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Circulation date: 2025-09-12
- Filed: 2025-09-23
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['resolutions']['pdf_sha256']}`
- Source PDF pages: 16

## Source-bounded observations

The filed written resolutions authorize the directors to allot shares or grant rights to subscribe for or convert securities into shares up to an aggregate nominal amount of £1.197496. The authority expires on the fifth anniversary of the circulation date unless renewed, varied, or revoked, while allowing completion of pre-expiry offers or agreements. The resolution substitutes for prior unused section 551 authorities.

The special resolutions adopt replacement articles, waive or disapply pre-emption rights for allotments and rights issued under that authority, and authorize redesignation of up to 741,051 ordinary shares of £0.000001 each into the same number of Seed 1 Preferred shares of £0.000001 each with the rights in the new articles.

The signature pages identify the following eligible members for the written resolutions as at 12 September 2025:

1. Alexander Cooper.
2. Ben Warner.
3. LocalGlobe XII, L.P., acting through Phoenix Court Fund Management Limited.
4. Ankush Kamal Kant Shah.
5. SLL Investconsult GmbH.
6. Mercuri II LP, acting through Mercuri GP LLP.
7. Milltown Ventures Limited.
8. Thomas Raymond Le Feuvre Pocock.
9. Frederick Sayers.
10. Varun Chandra.
11. Robert Cranborne.
12. Shan Drummond.
13. Eric Ralph Salama.
14. GC&H Investments, L.P., acting through GC&H Investment Management, LLC.

The document footer describes the package as the Electric Twin Ltd Seed 2 Financing Shareholder Resolutions.

## Boundaries

The signatory pages establish eligible-member status for these written resolutions. They do not identify the recipients of any particular Seed 2 allotment, prove beneficial ownership after the transaction, or state that Atomico held shares on 12 September. The resolutions create allotment authority and adopt governance instruments; they do not independently establish the transaction closing date, cash received, or the later public round total.
"""

contents['sh01_16'] = f"""# Electric Twin SH01 Seed 2 allotment dated 16 September 2025

- Source URL: {DOCS['sh01_16']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Companies House filing code: `{DOCS['sh01_16']['filing_code']}`
- Allotment date: 2025-09-16
- Received for filing: 2025-09-24
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['sh01_16']['pdf_sha256']}`
- Source PDF pages: 4

## Source-bounded observations

The SH01 records 604,294 Seed 2 Preferred shares allotted on 16 September 2025. Each share has nominal value £0.000001, amount paid £9.267, amount unpaid £0, and the form states that no shares were allotted other than for cash.

The filed post-allotment statement of capital reports 2,849,119 Ordinary shares and 604,294 Seed 2 Preferred shares, for 3,453,413 shares in total, aggregate nominal value £3.453413, and aggregate unpaid amount £0.

## Boundaries

The SH01 does not identify the allottees. The field labelled amount paid is a filed per-share field; multiplying it by the allotted quantity is arithmetic, not independent evidence of cash received, settlement, beneficial ownership, or equivalence to the later company-announced round. The statement does not yet display the separately filed Seed 1 redesignation dated the same day.
"""

contents['sh01_17'] = f"""# Electric Twin SH01 Seed 2 allotment dated 17 September 2025

- Source URL: {DOCS['sh01_17']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Companies House filing code: `{DOCS['sh01_17']['filing_code']}`
- Allotment date: 2025-09-17
- Received for filing: 2025-09-25
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['sh01_17']['pdf_sha256']}`
- Source PDF pages: 4

## Source-bounded observations

The SH01 records 86,327 Seed 2 Preferred shares allotted on 17 September 2025. Each share has nominal value £0.000001, amount paid £9.267, amount unpaid £0, and the form states that no shares were allotted other than for cash.

The filed post-allotment statement of capital reports 2,108,068 Ordinary shares, 741,051 Seed 1 Preferred shares, and 690,621 Seed 2 Preferred shares, for 3,539,740 shares in total, aggregate nominal value £3.53974, and aggregate unpaid amount £0.

## Boundaries

The SH01 does not identify the allottees. It establishes filed class and capital mechanics, not cash received, beneficial ownership, investor control, or which announced investor received which shares.
"""

contents['sh01_26'] = f"""# Electric Twin SH01 Seed 2 allotment dated 26 September 2025

- Source URL: {DOCS['sh01_26']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Companies House filing code: `{DOCS['sh01_26']['filing_code']}`
- Allotment date: 2025-09-26
- Received for filing: 2025-09-29
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['sh01_26']['pdf_sha256']}`
- Source PDF pages: 4

## Source-bounded observations

The SH01 records 48,559 Seed 2 Preferred shares allotted on 26 September 2025. Each share has nominal value £0.000001, amount paid £9.267, amount unpaid £0, and the form states that no shares were allotted other than for cash.

The filed post-allotment statement of capital reports 2,108,068 Ordinary shares, 741,051 Seed 1 Preferred shares, and 739,180 Seed 2 Preferred shares, for 3,588,299 shares in total, aggregate nominal value £3.588299, and aggregate unpaid amount £0.

## Boundaries

The SH01 does not identify the allottees. The final Seed 2 total reconciles the three filed allotment quantities, but the forms do not establish that the three allotments are coterminous with the later company-announced $10 million round, identify beneficial owners, or prove cash settlement.
"""

contents['sh08'] = f"""# Electric Twin SH08 Seed 1 redesignation dated 16 September 2025

- Source URL: {DOCS['sh08']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Assignment date: 2025-09-16
- Filed: 2025-09-25
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['sh08']['pdf_sha256']}`
- Source PDF pages: 2

## Source-bounded observations

The SH08 records that 741,051 existing Ordinary shares of £0.000001 each were redesignated on 16 September 2025 as 741,051 Seed 1 Preferred shares of £0.000001 each. The form is signed on behalf of the company by W Edwards for CC Secretaries Limited.

## Boundaries

The SH08 establishes the class redesignation and date. It does not identify the holders of the redesignated shares, the consideration for the redesignation, or any transfer of beneficial ownership.
"""

contents['sh10'] = f"""# Electric Twin SH10 rights variation dated 12 September 2025

- Source URL: {DOCS['sh10']['source_url']}
- Publisher: Companies House
- Company: ELECTRIC TWIN LTD
- Company number: 15173006
- Rights-variation date: 2025-09-12
- Filed: 2025-09-24
- Retrieved: 2026-08-11
- Evidence class: official
- Source PDF SHA-256: `{DOCS['sh10']['pdf_sha256']}`
- Source PDF pages: 4

## Source-bounded observations

The SH10 states that Ordinary shares retain full rights regarding voting and dividends. On a liquidation or return of capital, the form records the same distribution order later reproduced in the SH01 statements: one penny in aggregate to any Deferred class; then Seed Preferred holders receive the greater of the applicable Preference Amount and the as-converted Ordinary distribution, with pro rata allocation by aggregate Preference Amount if assets are insufficient; then the residual balance goes to Ordinary holders pro rata.

The form records 12 September 2025 as the date of variation and is signed on behalf of the company by W Edwards for CC Secretaries Limited.

## Boundaries

The SH10 records class-right particulars. It does not identify particular Seed Preferred holders, quantify any person's ownership, establish that a liquidation or exit occurred, or supply the unfiled Subscription Agreement or Shareholders' Agreement.
"""

for key, text in contents.items():
    path = root / DOCS[key]['path']
    path.write_text(text, encoding='utf-8')

# Append receipts deterministically after the current final row.
receipts_path = root / 'data/ledger/receipts.jsonl'
receipts = [json.loads(line) for line in receipts_path.read_text().splitlines() if line.strip()]
existing = {r['receipt_id'] for r in receipts}
for key in ['resolutions','articles','sh10','sh08','sh01_16','sh01_17','sh01_26']:
    d = DOCS[key]
    if d['receipt_id'] in existing:
        raise SystemExit(f"duplicate receipt {d['receipt_id']}")
    extract_hash = hashlib.sha256((root / d['path']).read_bytes()).hexdigest()
    note_map = {
        'resolutions': 'Official written-resolution extract for the Seed 2 financing authority, replacement articles, pre-emption disapplication, Seed 1 redesignation authority, and eligible-member signatures. Eligible-member status is not allottee identity.',
        'articles': 'Official articles extract for founder, Atomico, LocalGlobe, Investor Majority, Major Investor, board, pre-emption, and preference rights. Conditional rights are not evidence that they were exercised.',
        'sh10': 'Official class-rights variation extract. It records rights, not holder identity or an actual exit.',
        'sh08': 'Official Seed 1 class-redesignation extract. It does not identify the holders of the redesignated shares.',
        'sh01_16': 'Official SH01 extract for the 16 September Seed 2 allotment. The form does not identify allottees or prove cash settlement.',
        'sh01_17': 'Official SH01 extract for the 17 September Seed 2 allotment. The form does not identify allottees or prove cash settlement.',
        'sh01_26': 'Official SH01 extract for the 26 September Seed 2 allotment and final filed Seed 2 total. The form does not identify allottees or prove round equivalence.',
    }
    row = {
        'receipt_id': d['receipt_id'],
        'label': d['label'],
        'source_type': 'official_source_extract',
        'evidence_class': 'official',
        'path': d['path'],
        'source_url': d['source_url'],
        'publisher': 'Companies House',
        'source_published_at': d['source_published_at'],
        'event_date': d['event_date'],
        'retrieved_at': '2026-08-11',
        'source_document_id': d['token'],
        'source_pdf_sha256': d['pdf_sha256'],
        'source_pdf_pages': d['pages'],
        'notes': note_map[key],
        'archive': {
            'method': 'in_repo_content_hash',
            'ref': f'sha256:{extract_hash}',
            'captured': '2026-08-11',
            'checked': '2026-08-11',
            'note': 'Hash covers the in-repo structured extract; source_url and source_pdf_sha256 preserve the exact official document route and acquired PDF digest.'
        }
    }
    if 'filing_code' in d:
        row['source_filing_code'] = d['filing_code']
    receipts.append(row)
receipts_path.write_text('\n'.join(json.dumps(r, separators=(',', ':'), ensure_ascii=False) for r in receipts) + '\n')

# Add two bounded, non-hop surfaces.
surfaces_path = root / 'data/ledger/surfaces.jsonl'
surfaces = [json.loads(line) for line in surfaces_path.read_text().splitlines() if line.strip()]
new_surfaces = [
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'surface_label': 'Electric Twin Seed 2 governance instrument adoption, 12 September 2025',
        'surface_type': 'employment_investment_surface',
        'secondary_surface_types': ['surface_factory_capital_layer'],
        'hop_eligible': False,
        'scorable': True,
        'status': 'official_corporate_governance_instrument',
        'bounded_by': [
            '12 September 2025 written resolutions',
            'replacement articles adopted on 12 September 2025',
            'Companies House SH10 rights-variation notice'
        ],
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'receipt_ids': [
            DOCS['resolutions']['receipt_id'],
            DOCS['articles']['receipt_id'],
            DOCS['sh10']['receipt_id']
        ],
        'notes': 'Non-hop corporate governance surface. It preserves founder and named investor rights created by the filed instrument without converting conditional appointment powers, eligible-member signatures, or a later officer appointment into exercised control, allottee identity, beneficial ownership, interpersonal adjacency, coordination, or wrongdoing.'
    },
    {
        'surface_id': 'electric-twin-seed2-capital-actions-2025-09-16-2025-09-26',
        'surface_label': 'Electric Twin Seed 1 redesignation and Seed 2 allotment sequence, 16–26 September 2025',
        'surface_type': 'employment_investment_surface',
        'secondary_surface_types': ['surface_factory_capital_layer'],
        'hop_eligible': False,
        'scorable': True,
        'status': 'official_corporate_capital_sequence_allottees_unidentified',
        'bounded_by': [
            '16 September 2025 SH08 Seed 1 redesignation',
            '16, 17, and 26 September 2025 SH01 Seed 2 allotments',
            'final filed statement of capital containing 739,180 Seed 2 Preferred shares'
        ],
        'time_start': '2025-09-16',
        'time_end': '2025-09-26',
        'receipt_ids': [
            DOCS['sh08']['receipt_id'],
            DOCS['sh01_16']['receipt_id'],
            DOCS['sh01_17']['receipt_id'],
            DOCS['sh01_26']['receipt_id']
        ],
        'notes': 'Non-hop issuer-action surface. The official forms establish class, quantity, per-share paid and unpaid fields, cash-only status, and resulting capital. They do not name allottees, so no investor or actor participant is added and the sequence creates no adjacency or ownership finding.'
    }
]
existing_surfaces = {s['surface_id'] for s in surfaces}
for s in new_surfaces:
    if s['surface_id'] in existing_surfaces:
        raise SystemExit(f"duplicate surface {s['surface_id']}")
# insert immediately after the Ben Blume appointment surface for locality
out = []
inserted = False
for s in surfaces:
    out.append(s)
    if s['surface_id'] == 'electric-twin-ben-blume-director-appointment-2025-09-12':
        out.extend(new_surfaces)
        inserted = True
if not inserted:
    raise SystemExit('Ben Blume surface insertion anchor missing')
surfaces_path.write_text('\n'.join(json.dumps(s, separators=(',', ':'), ensure_ascii=False) for s in out) + '\n')

# Participation rows. Governance rights are instrument-specific; capital allottees remain absent.
participation_path = root / 'data/ledger/participation.jsonl'
parts = [json.loads(line) for line in participation_path.read_text().splitlines() if line.strip()]
new_parts = [
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'participant_type': 'organization',
        'organization_id': 'electric-twin',
        'role': 'company adopting the Seed 2 financing governance instrument',
        'participation_type': 'issuer_governance_instrument',
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['resolutions']['receipt_id'], DOCS['articles']['receipt_id'], DOCS['sh10']['receipt_id']]
    },
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'participant_type': 'actor',
        'actor_id': 'alex-cooper',
        'role': 'Founder named in the articles; Founder Majority appointment rights',
        'participation_type': 'founder_instrument_rights_holder',
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['resolutions']['receipt_id'], DOCS['articles']['receipt_id']]
    },
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'participant_type': 'actor',
        'actor_id': 'ben-warner',
        'role': 'Founder named in the articles; Founder Majority appointment rights',
        'participation_type': 'founder_instrument_rights_holder',
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['resolutions']['receipt_id'], DOCS['articles']['receipt_id']]
    },
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'participant_type': 'organization',
        'organization_id': 'atomico',
        'role': 'conditional right to appoint one director and one non-voting board observer while holding Equity Shares with permitted transferees',
        'participation_type': 'instrument_named_investor_rights_holder',
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['articles']['receipt_id']]
    },
    {
        'surface_id': 'electric-twin-seed2-governance-instrument-2025-09-12',
        'participant_type': 'organization',
        'organization_id': 'localglobe',
        'role': 'conditional right to appoint one director while holding Equity Shares with permitted transferees',
        'participation_type': 'instrument_named_investor_rights_holder',
        'time_start': '2025-09-12',
        'time_end': '2025-09-12',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['resolutions']['receipt_id'], DOCS['articles']['receipt_id']]
    },
    {
        'surface_id': 'electric-twin-seed2-capital-actions-2025-09-16-2025-09-26',
        'participant_type': 'organization',
        'organization_id': 'electric-twin',
        'role': 'issuer filing the Seed 1 redesignation and Seed 2 allotment returns',
        'participation_type': 'issuer_capital_action',
        'time_start': '2025-09-16',
        'time_end': '2025-09-26',
        'evidence_class': 'official',
        'receipt_ids': [DOCS['sh08']['receipt_id'], DOCS['sh01_16']['receipt_id'], DOCS['sh01_17']['receipt_id'], DOCS['sh01_26']['receipt_id']]
    }
]
out = []
inserted = False
for p in parts:
    out.append(p)
    if p.get('surface_id') == 'electric-twin-ben-blume-director-appointment-2025-09-12' and p.get('participant_type') == 'organization':
        out.extend(new_parts)
        inserted = True
if not inserted:
    raise SystemExit('participation insertion anchor missing')
participation_path.write_text('\n'.join(json.dumps(p, separators=(',', ':'), ensure_ascii=False) for p in out) + '\n')

# Canonical, source-bounded claims.
claims_path = root / 'data/ledger/claims.jsonl'
claims = [json.loads(line) for line in claims_path.read_text().splitlines() if line.strip()]
new_claims = [
    {
        'claim_id': 'electric-twin-seed2-written-resolutions-2025-09-12',
        'text': 'Electric Twin written resolutions dated 12 September 2025 authorized allotments or subscription/conversion rights up to aggregate nominal £1.197496, adopted replacement articles, disapplied pre-emption rights for allotments under that authority, and authorized redesignation of up to 741,051 ordinary shares as Seed 1 Preferred.',
        'receipt_ids': [DOCS['resolutions']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': ['alex-cooper', 'ben-warner'],
        'organization_ids': ['electric-twin', 'localglobe', 'mercuri'],
        'surface_ids': ['electric-twin-seed2-governance-instrument-2025-09-12'],
        'date': '2025-09-12'
    },
    {
        'claim_id': 'electric-twin-seed2-board-rights-2025-09-12',
        'text': 'Electric Twin articles adopted 12 September 2025 cap the board at five absent an ordinary resolution with Founder Majority consent, give Founder Majority the right to appoint a board majority, give Atomico a conditional right to appoint one director and one non-voting observer while it and permitted transferees hold equity, and give LocalGlobe a conditional right to appoint one director while it and permitted transferees hold equity.',
        'receipt_ids': [DOCS['articles']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': ['alex-cooper', 'ben-warner'],
        'organization_ids': ['electric-twin', 'atomico', 'localglobe'],
        'surface_ids': ['electric-twin-seed2-governance-instrument-2025-09-12'],
        'date': '2025-09-12'
    },
    {
        'claim_id': 'electric-twin-seed2-investor-rights-2025-09-12',
        'text': 'The adopted articles require an initial board quorum of three including at least one Investor Director if appointed, give Major Investors pro rata first-offer rights over New Securities unless Investor Majority Consent permits otherwise, define the Seed 2 Preferred Preference Amount as £9.267 per share, and place Seed Preferred holders ahead of Ordinary holders in the liquidation and exit waterfall for the greater of the applicable preference amount and the as-converted Ordinary distribution.',
        'receipt_ids': [DOCS['articles']['receipt_id'], DOCS['sh10']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': [],
        'organization_ids': ['electric-twin', 'atomico', 'localglobe'],
        'surface_ids': ['electric-twin-seed2-governance-instrument-2025-09-12'],
        'date': '2025-09-12'
    },
    {
        'claim_id': 'electric-twin-seed1-redesignation-2025-09-16',
        'text': 'Electric Twin form SH08 records the redesignation on 16 September 2025 of 741,051 Ordinary shares of £0.000001 each as 741,051 Seed 1 Preferred shares of £0.000001 each.',
        'receipt_ids': [DOCS['sh08']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': [],
        'organization_ids': ['electric-twin'],
        'surface_ids': ['electric-twin-seed2-capital-actions-2025-09-16-2025-09-26'],
        'date': '2025-09-16'
    },
    {
        'claim_id': 'electric-twin-seed2-allotment-sequence-2025-09',
        'text': 'Electric Twin SH01 returns record 604,294 Seed 2 Preferred shares allotted on 16 September, 86,327 on 17 September, and 48,559 on 26 September 2025, each at nominal value £0.000001, amount paid £9.267, amount unpaid £0, and cash-only status; the final filed statement of capital contains 739,180 Seed 2 Preferred shares.',
        'receipt_ids': [DOCS['sh01_16']['receipt_id'], DOCS['sh01_17']['receipt_id'], DOCS['sh01_26']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': [],
        'organization_ids': ['electric-twin'],
        'surface_ids': ['electric-twin-seed2-capital-actions-2025-09-16-2025-09-26'],
        'date': '2025-09-26'
    },
    {
        'claim_id': 'electric-twin-seed2-allottees-unidentified-2025-09',
        'text': 'The three Electric Twin SH01 returns identify the issuer, dates, class, quantities, nominal value, amount paid and unpaid, cash status, and resulting capital, but do not identify the recipients of the allotted shares.',
        'receipt_ids': [DOCS['sh01_16']['receipt_id'], DOCS['sh01_17']['receipt_id'], DOCS['sh01_26']['receipt_id']],
        'evidence_class': 'official',
        'actor_ids': [],
        'organization_ids': ['electric-twin'],
        'surface_ids': ['electric-twin-seed2-capital-actions-2025-09-16-2025-09-26'],
        'date': '2025-09-26'
    }
]
existing_claims = {c['claim_id'] for c in claims}
for c in new_claims:
    if c['claim_id'] in existing_claims:
        raise SystemExit(f"duplicate claim {c['claim_id']}")
claims.extend(new_claims)
claims_path.write_text('\n'.join(json.dumps(c, separators=(',', ':'), ensure_ascii=False) for c in claims) + '\n')

# Add compiler regression coverage and receipt-graph claim lookup.
compiler_path = root / 'test/compiler.test.js'
compiler = compiler_path.read_text()
compiler = compiler.replace(
    "const migration = JSON.parse(fs.readFileSync('build/migration-summary.json', 'utf8'));\n",
    "const migration = JSON.parse(fs.readFileSync('build/migration-summary.json', 'utf8'));\nconst receiptGraph = JSON.parse(fs.readFileSync('build/receipt-graph.json', 'utf8'));\n",
    1
)
compiler = compiler.replace(
    "const receipt = id => ledgerReceipts.find(row => row.receipt_id === id);\n",
    "const receipt = id => ledgerReceipts.find(row => row.receipt_id === id);\nconst claim = id => receiptGraph.claims.find(row => row.claim_id === id);\n",
    1
)
anchor = "// The previously undisclosed $4m pre-seed remains undated and has no promoted participant surface.\n"
block = """// September 2025 corporate filings preserve governance rights and capital mechanics without inventing allottees.
const electricTwinGovernance = surf('electric-twin-seed2-governance-instrument-2025-09-12');
assert.ok(electricTwinGovernance, 'the September governance instrument must compile');
assert.equal(electricTwinGovernance.hop_eligible, false);
assert.equal(electricTwinGovernance.time_start, '2025-09-12');
assert.equal(electricTwinGovernance.time_end, '2025-09-12');
assert.deepEqual(
  electricTwinGovernance.participants.filter(part => part.participant_type === 'actor').map(part => part.actor_id).sort(),
  ['alex-cooper', 'ben-warner']
);
assert.deepEqual(
  electricTwinGovernance.participants.filter(part => part.participant_type === 'organization').map(part => part.organization_id).sort(),
  ['atomico', 'electric-twin', 'localglobe']
);
assert.ok(!hop.edges.some(edge => edge.surfaces.some(basis => basis.surface_id === electricTwinGovernance.surface_id)),
  'the governance instrument must never create actor adjacency');

const electricTwinCapitalActions = surf('electric-twin-seed2-capital-actions-2025-09-16-2025-09-26');
assert.ok(electricTwinCapitalActions, 'the September capital-action sequence must compile');
assert.equal(electricTwinCapitalActions.hop_eligible, false);
assert.deepEqual(
  electricTwinCapitalActions.participants.map(part => part.organization_id ?? part.actor_id),
  ['electric-twin'],
  'unidentified allottees must not be manufactured as participants'
);
assert.ok(!hop.edges.some(edge => edge.surfaces.some(basis => basis.surface_id === electricTwinCapitalActions.surface_id)),
  'issuer-only capital actions must never create actor adjacency');

const articlesReceipt = receipt('companies-house-electric-twin-articles-2025-09-12');
const resolutionsReceipt = receipt('companies-house-electric-twin-written-resolutions-2025-09-12');
const sh01Seed2Sixteen = receipt('companies-house-electric-twin-sh01-seed2-2025-09-16');
const sh01Seed2Seventeen = receipt('companies-house-electric-twin-sh01-seed2-2025-09-17');
const sh01Seed2TwentySix = receipt('companies-house-electric-twin-sh01-seed2-2025-09-26');
const sh08Seed1 = receipt('companies-house-electric-twin-sh08-seed1-2025-09-16');
const sh10Rights = receipt('companies-house-electric-twin-sh10-rights-2025-09-12');
for (const row of [articlesReceipt, resolutionsReceipt, sh01Seed2Sixteen, sh01Seed2Seventeen, sh01Seed2TwentySix, sh08Seed1, sh10Rights]) {
  assert.ok(row, 'every September filing must have a canonical receipt');
  assert.equal(row.evidence_class, 'official');
  assert.match(row.source_pdf_sha256, /^[0-9a-f]{64}$/);
  assert.equal(row.publisher, 'Companies House');
}
assert.equal(articlesReceipt.event_date, '2025-09-12');
assert.equal(articlesReceipt.source_published_at, '2025-09-23');
assert.equal(resolutionsReceipt.event_date, '2025-09-12');
assert.equal(sh01Seed2Sixteen.source_filing_code, 'XEBSKAZE');
assert.equal(sh01Seed2Seventeen.source_filing_code, 'XEBVCAMW');
assert.equal(sh01Seed2TwentySix.source_filing_code, 'XEC3EZXL');
assert.equal(sh08Seed1.event_date, '2025-09-16');
assert.equal(sh10Rights.event_date, '2025-09-12');

assert.ok(claim('electric-twin-seed2-board-rights-2025-09-12'));
assert.ok(claim('electric-twin-seed2-investor-rights-2025-09-12'));
assert.ok(claim('electric-twin-seed2-allotment-sequence-2025-09'));
const unidentifiedAllottees = claim('electric-twin-seed2-allottees-unidentified-2025-09');
assert.ok(unidentifiedAllottees);
assert.deepEqual(unidentifiedAllottees.actor_ids, []);
assert.deepEqual(unidentifiedAllottees.organization_ids, ['electric-twin']);
assert.ok(!unidentifiedAllottees.text.match(/Atomico|LocalGlobe|Mercuri|Samos|Andreessen|Henderson|Salama|Shinner|Mosley/),
  'the SH01 non-identification claim must not smuggle the announced roster into the filed allotments');

const benBlumeGovernanceParticipant = electricTwinGovernance.participants.find(part => part.actor_id === 'ben-blume');
assert.equal(benBlumeGovernanceParticipant, undefined,
  'the articles do not identify Ben Blume as an Atomico or LocalGlobe appointee');

"""
if anchor not in compiler:
    raise SystemExit('compiler insertion anchor missing')
compiler = compiler.replace(anchor, block + anchor, 1)
compiler_path.write_text(compiler)

# Extend the release fixture's Electric Twin surface-factory list and assert graph inertness.
validator_path = root / 'tools/validate-release.mjs'
validator = validator_path.read_text()
old = "for (const sid of ['electric-twin-incorporation-2023-09-28', 'electric-twin-ben-warner-director-tenure-2023-09-28', 'electric-twin-alex-cooper-director-tenure-2023-09-28', 'electric-twin-ethics-board-2026', 'electric-twin-seed-round-2026-02-11', 'electric-twin-ben-blume-director-appointment-2025-09-12', 'electric-twin-newsuk-synthetic-audience', 'gartner-synthetic-population-category-2026']) {"
new = "for (const sid of ['electric-twin-incorporation-2023-09-28', 'electric-twin-ben-warner-director-tenure-2023-09-28', 'electric-twin-alex-cooper-director-tenure-2023-09-28', 'electric-twin-ethics-board-2026', 'electric-twin-seed-round-2026-02-11', 'electric-twin-ben-blume-director-appointment-2025-09-12', 'electric-twin-seed2-governance-instrument-2025-09-12', 'electric-twin-seed2-capital-actions-2025-09-16-2025-09-26', 'electric-twin-newsuk-synthetic-audience', 'gartner-synthetic-population-category-2026']) {"
if old not in validator:
    raise SystemExit('validator fixture anchor missing')
validator = validator.replace(old, new, 1)
release_anchor = "// Regression fixture 3: Simon Case governance continuity.\n"
release_block = """assert(surfaceById.get('electric-twin-seed2-governance-instrument-2025-09-12')?.hop_eligible === false,
  'Electric Twin September governance instrument must remain non-hop');
assert(surfaceById.get('electric-twin-seed2-capital-actions-2025-09-16-2025-09-26')?.hop_eligible === false,
  'Electric Twin September capital actions must remain non-hop');
for (const sid of ['electric-twin-seed2-governance-instrument-2025-09-12', 'electric-twin-seed2-capital-actions-2025-09-16-2025-09-26']) {
  assert(!hopGraph.edges.some(edge => edge.surfaces.some(basis => basis.surface_id === sid)),
    `Electric Twin filing surface ${sid} must never create a hop`);
}
const septemberCapitalParts = sourcePartsBySurface.get('electric-twin-seed2-capital-actions-2025-09-16-2025-09-26') ?? [];
assert(septemberCapitalParts.length === 1 && septemberCapitalParts[0].organization_id === 'electric-twin',
  'unidentified September allottees must not become canonical participants');

"""
if release_anchor not in validator:
    raise SystemExit('release insertion anchor missing')
validator = validator.replace(release_anchor, release_block + release_anchor, 1)
validator_path.write_text(validator)

# Reconcile the checked cross-corpus map's bounded canonical inventory snapshot.
public_interest_map_path = root / 'data/research/clifford-cross-corpus-public-interest-map.json'
public_interest_map = public_interest_map_path.read_text()
old_inventory = '"surfaces": 19,\n      "participations": 180,\n      "receipts": 36,'
new_inventory = '"surfaces": 21,\n      "participations": 186,\n      "receipts": 43,'
if public_interest_map.count(old_inventory) != 1:
    raise SystemExit('cross-corpus canonical inventory anchor missing')
public_interest_map_path.write_text(public_interest_map.replace(old_inventory, new_inventory, 1))

print('materialized September 2025 filing product')
