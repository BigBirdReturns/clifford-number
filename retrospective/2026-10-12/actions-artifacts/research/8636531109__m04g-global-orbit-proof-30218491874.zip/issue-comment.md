<!-- m04g-global-orbit-proof:30218491874 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30218491874
- Head: `0f517f497eed8c8a9d7f1f83c5c0688a509ea41f`
- Event: `push`
- Classes: `all`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `63/96` (`0.6562`)
- Content success: `60/96` (`0.625`)
- Metadata only: `3`
- Failed: `33`
- Healthy basins: `9/12`
- Proof SHA-256: `e7fdf2a37b6e920055295f272c276682953dd8570b7c002862979a85bb10f628`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 8 | 7 | 7 | 0 | 1 | `true` |
| `G02-NORTH-AMERICA` | 8 | 5 | 5 | 0 | 3 | `true` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 8 | 5 | 5 | 0 | 3 | `true` |
| `G04-EU-CONTINENTAL` | 8 | 6 | 6 | 0 | 2 | `true` |
| `G05-UK-IRELAND-NORDICS` | 8 | 7 | 7 | 0 | 1 | `true` |
| `G06-EASTERN-EUROPE-EURASIA` | 8 | 6 | 5 | 1 | 2 | `true` |
| `G07-MENA` | 8 | 4 | 3 | 1 | 4 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 8 | 6 | 6 | 0 | 2 | `true` |
| `G09-SOUTH-ASIA` | 8 | 4 | 3 | 1 | 4 | `false` |
| `G10-EAST-ASIA` | 8 | 4 | 4 | 0 | 4 | `true` |
| `G11-SOUTHEAST-ASIA` | 8 | 6 | 6 | 0 | 2 | `true` |
| `G12-OCEANIA-PACIFIC` | 8 | 3 | 3 | 0 | 5 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
