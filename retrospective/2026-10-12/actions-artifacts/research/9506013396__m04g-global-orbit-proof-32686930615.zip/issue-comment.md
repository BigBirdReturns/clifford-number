<!-- m04g-global-orbit-proof:32686930615 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32686930615
- Head: `bd66952df64b7eef2e673af724e922ad3f6a719a`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `18/24` (`0.75`)
- Content success: `18/24` (`0.75`)
- Metadata only: `0`
- Failed: `6`
- Healthy basins: `0/12`
- Proof SHA-256: `9204313a2c1f21df2ecb4f793336ec82208bb35ceb435315e10c720c46936de2`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 2 | 2 | 0 | 0 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
