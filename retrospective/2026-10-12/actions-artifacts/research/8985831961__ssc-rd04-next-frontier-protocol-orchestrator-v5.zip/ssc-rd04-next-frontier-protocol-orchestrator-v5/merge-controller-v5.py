from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import textwrap
import traceback
from pathlib import Path
from typing import Any

REPOSITORY = os.environ.get('GITHUB_REPOSITORY', 'BigBirdReturns/clifford-number')
OWNER = REPOSITORY.split('/', 1)[0]
PRODUCT_BRANCH = 'agent/ssc-rd-wave03-rd04-next-minimum-frontier-route-discovery-protocol-v1'
SLUG = 'status-sovereignty-rd-wave03-rd04-next-minimum-frontier-route-discovery-protocol'
DATA_DIR = f'data/intake/{SLUG}'
OUT = Path('/tmp/ssc-rd04-next-frontier-protocol-merge-v2')
WT = Path('/tmp/ssc-rd04-next-frontier-protocol-merge-v2-worktree')


def run(args: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(args, cwd=str(cwd) if cwd else None, text=True, capture_output=True, env=os.environ.copy())
    with (OUT / 'run.log').open('a', encoding='utf-8') as fh:
        fh.write('$ ' + ' '.join(args) + '\n')
        fh.write(result.stdout)
        fh.write(result.stderr)
        fh.write(f'[exit {result.returncode}]\n')
    if check and result.returncode:
        raise RuntimeError(f'command failed ({result.returncode}): {args!r}')
    return result


def git(*args: str, cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess[str]:
    return run(['git', *args], cwd=cwd, check=check)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def report(success: bool, receipt: dict[str, Any]) -> None:
    body = OUT / 'issue-comment.md'
    if success:
        body.write_text(textwrap.dedent(f"""\
            RD-04 next minimum-frontier route-discovery protocol merged canonically.

            ```text
            pull_request: {receipt['pull_request']}
            canonical_parent: {receipt['canonical_parent']}
            product_head: {receipt['product_head']}
            product_tree: {receipt['product_tree']}
            canonical_merge: {receipt['canonical_merge']}
            permanent_paths: {receipt['permanent_path_count']}
            selected_states: {' '.join(receipt['selected_state_ids'])}
            selected_fields: {' '.join(receipt['selected_field_ids'])}
            selected_substantive_cells: {receipt['selected_substantive_cell_count']}
            protocol_obligations: {receipt['protocol_obligations']}
            fixed_repository_route_cells: {receipt['fixed_repository_route_cells']}
            bounded_official_route_discovery_cells: {receipt['bounded_official_route_discovery_cells']}
            closed_schema_objects: {receipt['closed_schema_objects']}
            adversarial_refusals: {receipt['adversarial_refusals']}
            complete_release_gate: pass
            clean_deterministic_replay: pass
            source_requests_executed: 0
            source_admissions: 0
            field_mutations: 0
            row_state_mutations: 0
            class_closed: false
            outside_human_dependency: false
            receipt_sha256: {sha256(OUT/'merge-receipt.json')}
            ```

            The canonical product is workflow-free and protocol-only. RD-04-C02 and the cumulative ledger remain open. The next authorized transaction is the separately checksum-bound route-discovery acquisition defined by this protocol.
        """), encoding='utf-8')
    else:
        tail = (OUT / 'run.log').read_text(encoding='utf-8', errors='replace')[-16000:] if (OUT / 'run.log').exists() else receipt.get('traceback', '')
        body.write_text('RD-04 next minimum-frontier protocol merge controller failed closed.\n\n```text\n' + tail + '\n```\n\nNo canonical merge or additional authority is represented.\n', encoding='utf-8')
    run(['gh', 'issue', 'comment', '1017', '--repo', REPOSITORY, '--body-file', str(body)], check=False)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / 'run.log').write_text('', encoding='utf-8')
    receipt: dict[str, Any] = {'schema_version': 'ssc-rd04-next-frontier-protocol-merge@2', 'status': 'running'}
    try:
        git('fetch', '--force', 'origin', '+refs/heads/main:refs/remotes/origin/main', f'+refs/heads/{PRODUCT_BRANCH}:refs/remotes/origin/{PRODUCT_BRANCH}')
        product_head = git('rev-parse', f'origin/{PRODUCT_BRANCH}').stdout.strip()
        product_parent = git('rev-parse', f'{product_head}^').stdout.strip()
        product_tree = git('rev-parse', f'{product_head}^{{tree}}').stdout.strip()
        live_main = git('rev-parse', 'origin/main').stdout.strip()
        if product_parent != live_main:
            raise RuntimeError(f'product parent is stale: {product_parent} != {live_main}')
        if int(git('rev-list', '--count', f'{product_parent}..{product_head}').stdout.strip()) != 1:
            raise RuntimeError('product is not exactly one commit over main')

        prs = json.loads(run(['gh', 'api', f'repos/{REPOSITORY}/pulls?state=open&head={OWNER}:{PRODUCT_BRANCH}&per_page=100']).stdout)
        if len(prs) != 1:
            raise RuntimeError(f'expected one open product PR, found {len(prs)}')
        pr = prs[0]
        pr_number = int(pr['number'])
        if pr['head']['sha'] != product_head or pr['base']['ref'] != 'main':
            raise RuntimeError('PR head/base lease drift')

        name_status = git('diff', '--name-status', product_parent, product_head).stdout.splitlines()
        if len(name_status) != 13 or any(not line.startswith('A\t') for line in name_status):
            raise RuntimeError(f'product path topology mismatch: {name_status}')
        paths = sorted(line.split('\t', 1)[1] for line in name_status)
        if any(re.search(r'(^|/)(\.transport|\.trigger)(/|$)|(^|/)\.github/workflows/', path) for path in paths):
            raise RuntimeError('transport or workflow path in permanent product')
        (OUT / 'paths.txt').write_text('\n'.join(paths) + '\n', encoding='utf-8')

        if WT.exists():
            shutil.rmtree(WT)
        git('worktree', 'add', '--detach', str(WT), product_head)
        run(['node', '--check', f'tools/build-{SLUG}.mjs'], cwd=WT)
        run(['node', '--check', f'tools/validate-{SLUG}.mjs'], cwd=WT)
        run(['node', '--check', f'test/{SLUG}.test.js'], cwd=WT)
        run(['python', '-m', 'py_compile', 'tools/acquisition/status-sovereignty-rd-wave03-rd04-next-frontier/plan-official-route-discovery.py'], cwd=WT)
        run(['node', f'tools/build-{SLUG}.mjs', '--check'], cwd=WT)
        run(['node', f'tools/validate-{SLUG}.mjs'], cwd=WT)

        import jsonschema
        schema = json.loads((WT / f'schemas/{SLUG}.schema.json').read_text())
        validator = jsonschema.Draft202012Validator(schema)
        data_dir = WT / DATA_DIR
        for name in ('frontier-selection.json','predecessor-custody.json','official-locator-inventory.json','route-query-contract.json','route-discovery-protocol.json','summary.json'):
            validator.validate(json.loads((data_dir / name).read_text()))

        adversarial = run(['node', f'test/{SLUG}.test.js'], cwd=WT)
        match = re.search(r'adversarial_refusals=(\d+)', adversarial.stdout)
        if not match:
            raise RuntimeError('missing adversarial refusal count')
        adversarial_refusals = int(match.group(1))
        run(['python', 'tools/acquisition/status-sovereignty-rd-wave03-rd04-next-frontier/plan-official-route-discovery.py', '--json'], cwd=WT)
        run(['node', 'tools/validate-no-magic-human-gate.mjs'], cwd=WT)
        git('diff', '--check', cwd=WT)
        git('diff', '--exit-code', cwd=WT)
        if git('status', '--porcelain=v1', '--untracked-files=all', cwd=WT).stdout.strip():
            raise RuntimeError('dirty product before release gate')
        run(['npm', 'run', 'release:check'], cwd=WT)
        git('reset', '--hard', 'HEAD', cwd=WT)
        git('clean', '-fdx', cwd=WT)
        run(['node', f'tools/build-{SLUG}.mjs', '--write'], cwd=WT)
        run(['node', f'tools/build-{SLUG}.mjs', '--check'], cwd=WT)
        run(['node', f'tools/validate-{SLUG}.mjs'], cwd=WT)
        run(['node', f'test/{SLUG}.test.js'], cwd=WT)
        run(['node', 'tools/validate-no-magic-human-gate.mjs'], cwd=WT)
        git('diff', '--check', cwd=WT)
        git('diff', '--exit-code', cwd=WT)
        if git('status', '--porcelain=v1', '--untracked-files=all', cwd=WT).stdout.strip():
            raise RuntimeError('dirty deterministic replay')

        # Recheck all mutable leases immediately before merge.
        git('fetch', '--force', 'origin', '+refs/heads/main:refs/remotes/origin/main', f'+refs/heads/{PRODUCT_BRANCH}:refs/remotes/origin/{PRODUCT_BRANCH}')
        if git('rev-parse', 'origin/main').stdout.strip() != live_main:
            raise RuntimeError('main moved during qualification')
        if git('rev-parse', f'origin/{PRODUCT_BRANCH}').stdout.strip() != product_head:
            raise RuntimeError('product branch moved during qualification')
        refreshed = json.loads(run(['gh', 'api', f'repos/{REPOSITORY}/pulls/{pr_number}']).stdout)
        if refreshed['state'] != 'open' or refreshed['head']['sha'] != product_head or refreshed['base']['sha'] != live_main:
            raise RuntimeError('PR moved during qualification')

        run(['gh', 'pr', 'ready', str(pr_number), '--repo', REPOSITORY], check=False)
        merge = json.loads(run([
            'gh', 'api', '--method', 'PUT', f'repos/{REPOSITORY}/pulls/{pr_number}/merge',
            '-f', 'merge_method=merge',
            '-f', 'commit_title=SSC RD Wave 03: freeze next minimum-frontier route-discovery protocol',
            '-f', 'commit_message=Merge the exact one-parent, thirteen-path workflow-free protocol after independent closed-schema, adversarial, no-magic-human, complete release, clean replay, path, parent, branch, and PR-head gates passed. Execute no source request, admit no source, mutate no field or row state, leave RD-04-C02 and the cumulative ledger open, and create no outside-human, publication, adoption, or graph effect.',
        ]).stdout)
        (OUT / 'merge-api.json').write_text(json.dumps(merge, indent=2) + '\n', encoding='utf-8')
        if merge.get('merged') is not True:
            raise RuntimeError(f'merge refused: {merge}')
        merge_sha = merge['sha']
        git('fetch', '--force', 'origin', 'main')
        if git('rev-parse', 'origin/main').stdout.strip() != merge_sha:
            raise RuntimeError('canonical main does not equal merge receipt')
        parents = git('show', '-s', '--format=%P', merge_sha).stdout.strip().split()
        if parents != [live_main, product_head]:
            raise RuntimeError(f'merge parent drift: {parents}')
        if git('rev-parse', f'{merge_sha}^{{tree}}').stdout.strip() != product_tree:
            raise RuntimeError('merge tree drift')
        git('diff', '--exit-code', product_head, merge_sha)

        selection = json.loads((WT / DATA_DIR / 'frontier-selection.json').read_text())
        summary = json.loads((WT / DATA_DIR / 'summary.json').read_text())
        receipt.update({
            'status': 'complete',
            'pull_request': pr_number,
            'canonical_parent': live_main,
            'product_head': product_head,
            'product_tree': product_tree,
            'canonical_merge': merge_sha,
            'permanent_path_count': 13,
            'permanent_paths': paths,
            'selected_state_ids': selection['selected_state_ids'],
            'selected_field_ids': selection['selected_field_ids'],
            'selected_substantive_cell_count': selection['selected_substantive_cell_count'],
            'protocol_obligations': summary['protocol_obligations'],
            'fixed_repository_route_cells': summary['fixed_repository_route_cells'],
            'bounded_official_route_discovery_cells': summary['bounded_official_route_discovery_cells'],
            'closed_schema_objects': 6,
            'adversarial_refusals': adversarial_refusals,
            'focused_validation': 'pass',
            'no_magic_human': 'pass',
            'complete_release_gate': 'pass',
            'clean_deterministic_replay': 'pass',
            'source_requests_executed': 0,
            'source_admissions': 0,
            'field_mutations': 0,
            'row_state_mutations': 0,
            'class_closed': False,
            'outside_human_dependency': False,
            'cumulative_ledger_effect': 'none',
            'publication_effect': 'none',
            'adoption_effect': 'none',
            'graph_effect': 'none',
        })
        (OUT / 'merge-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
        report(True, receipt)
        return 0
    except Exception as exc:
        receipt.update({'status': 'failed_closed', 'error': repr(exc), 'traceback': traceback.format_exc()})
        (OUT / 'merge-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
        report(False, receipt)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
