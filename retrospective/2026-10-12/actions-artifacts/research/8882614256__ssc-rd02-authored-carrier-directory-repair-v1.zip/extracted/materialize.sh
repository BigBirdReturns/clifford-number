#!/usr/bin/env bash
set -Eeuo pipefail

EXPECTED_MAIN='ef70f7ad406c518f4b640ca4641c5a0f045a0d8d'
SOURCE_BRANCH='agent/ssc-rd-wave02-rd02-license-leverage'
SOURCE_HEAD='c78d243ee3d5c5c9b6c09e4b620bd3192b5e25a1'
TARGET_BRANCH='agent/ssc-rd02-wave02-terminal-license-leverage'
ARTIFACT_ID='8875282216'
ARTIFACT_BYTES='2087027'
ARTIFACT_SHA256='63e1fc4bea63b2d00b8fbbe4b8f585edd2e76a3c380445305c2a7997cf166a67'
CAPTURE_ROOT='data/intake/status-sovereignty-rd-wave02-rd02-license-leverage/source-custody/fixed-source-capture-v1'
EXECUTION_RECEIPT='data/intake/status-sovereignty-rd-wave02-rd02-license-leverage/fixed-source-capture-execution-receipt.json'
WORKFLOW_PATH='.github/workflows/status-sovereignty-rd-wave02-rd02-license-leverage.yml'
CARRIER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RECEIPT_DIR='/tmp/ssc-rd02-terminal-receipt-v1'

rm -rf "$RECEIPT_DIR"
mkdir -p "$RECEIPT_DIR"
step='initialize'

finish() {
  rc=$?
  set +e
  trap - EXIT
  printf '%s\n' "$rc" > "$RECEIPT_DIR/exit-code.txt"
  printf '%s\n' "$step" > "$RECEIPT_DIR/final-step.txt"
  git rev-parse HEAD > "$RECEIPT_DIR/head.txt" 2>&1 || true
  git rev-parse 'HEAD^{tree}' > "$RECEIPT_DIR/tree.txt" 2>&1 || true
  git status --porcelain=v1 --untracked-files=all > "$RECEIPT_DIR/status.txt" 2>&1 || true
  git diff --name-status "$EXPECTED_MAIN" HEAD > "$RECEIPT_DIR/name-status.txt" 2>&1 || true
  git diff --name-only "$EXPECTED_MAIN" HEAD | sort > "$RECEIPT_DIR/paths.txt" 2>&1 || true
  git ls-remote --heads origin refs/heads/main > "$RECEIPT_DIR/remote-main.txt" 2>&1 || true
  git ls-remote --heads origin "refs/heads/$SOURCE_BRANCH" > "$RECEIPT_DIR/remote-source.txt" 2>&1 || true
  git ls-remote --heads origin "refs/heads/$TARGET_BRANCH" > "$RECEIPT_DIR/remote-target.txt" 2>&1 || true
  OUT="$RECEIPT_DIR" RC="$rc" STEP="$step" EXPECTED_MAIN="$EXPECTED_MAIN" SOURCE_HEAD="$SOURCE_HEAD" TARGET_BRANCH="$TARGET_BRANCH" python - <<'PY'
import hashlib, json, os
from pathlib import Path
out = Path(os.environ['OUT'])
def read(name):
    p = out / name
    return p.read_text().strip() if p.exists() else None
receipt = {
    'schema_version': 'ssc-rd02-wave02-terminal-materialization@1',
    'run': int(os.environ.get('GITHUB_RUN_ID', '0')),
    'attempt': int(os.environ.get('GITHUB_RUN_ATTEMPT', '0')),
    'exit_code': int(os.environ['RC']),
    'final_step': os.environ['STEP'],
    'main_first_parent': os.environ['EXPECTED_MAIN'],
    'source_second_parent': os.environ['SOURCE_HEAD'],
    'target_branch': os.environ['TARGET_BRANCH'],
    'integration_commit': read('integration-commit.txt'),
    'integration_tree': read('integration-tree.txt'),
    'qualified_commit': read('qualified-commit.txt'),
    'qualified_tree': read('qualified-tree.txt'),
    'qualified_workflow_blob': read('qualified-workflow-blob.txt'),
    'nonworkflow_commit': read('nonworkflow-commit.txt'),
    'nonworkflow_tree': read('nonworkflow-tree.txt'),
    'permanent_paths_qualified': 47,
    'permanent_paths_published_before_workflow_composition': 46,
    'transport_paths': 0,
    'cohort_rows': 18,
    'required_fields': 180,
    'terminal_fields': 180,
    'closed_rows': 18,
    'terminal_state': 'bounded_source_restricted',
    'adversarial_mutations_refused': 122,
    'outside_human_dependency': False,
    'external_contacts': 0,
    'external_reviews': 0,
    'reviewed_disposition_changed': False,
    'complete_compact_finding': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
for path in sorted(out.iterdir()):
    if path.is_file() and not path.name.endswith('.sha256'):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        (out / f'{path.name}.sha256').write_text(f'{digest}  {path.name}\n')
PY
  exit "$rc"
}
trap finish EXIT

step='verify-exact-main-source-and-empty-target-leases'
test "$(git rev-parse HEAD)" = "$EXPECTED_MAIN"
test "$(git ls-remote --heads origin refs/heads/main | cut -f1)" = "$EXPECTED_MAIN"
test -z "$(git ls-remote --heads origin "refs/heads/$TARGET_BRANCH")"
git fetch origin "+refs/heads/$SOURCE_BRANCH:refs/remotes/origin/$SOURCE_BRANCH"
test "$(git rev-parse "origin/$SOURCE_BRANCH")" = "$SOURCE_HEAD"
test "$(git ls-remote --heads origin "refs/heads/$SOURCE_BRANCH" | cut -f1)" = "$SOURCE_HEAD"

step='create-two-parent-source-integration'
git config user.name 'github-actions[bot]'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
mapfile -t SOURCE_PATHS < "$CARRIER_DIR/source-paths.txt"
git checkout "$SOURCE_HEAD" -- "${SOURCE_PATHS[@]}"
git diff --cached --name-only "$EXPECTED_MAIN" | sort > "$RECEIPT_DIR/integration-paths.txt"
sort "$CARRIER_DIR/source-paths.txt" > "$RECEIPT_DIR/expected-integration-paths.txt"
cmp "$RECEIPT_DIR/expected-integration-paths.txt" "$RECEIPT_DIR/integration-paths.txt"
test -z "$(git diff --cached --name-status "$EXPECTED_MAIN" | awk '$1 != "A" {print}')"
integration_tree="$(git write-tree)"
integration_commit="$(printf '%s\n' 'Integrate exact RD-02 field-matrix lineage over current main' | git commit-tree "$integration_tree" -p "$EXPECTED_MAIN" -p "$SOURCE_HEAD")"
git reset --hard "$integration_commit"
test "$(git rev-list --parents -n 1 HEAD)" = "$integration_commit $EXPECTED_MAIN $SOURCE_HEAD"
printf '%s\n' "$integration_commit" > "$RECEIPT_DIR/integration-commit.txt"
printf '%s\n' "$integration_tree" > "$RECEIPT_DIR/integration-tree.txt"

step='recover-and-verify-fixed-source-artifact'
rm -rf /tmp/rd02-fixed-capture /tmp/rd02-fixed-capture.zip
mkdir -p /tmp/rd02-fixed-capture
curl --fail --silent --show-error --location \
  -H "Authorization: Bearer ${GH_TOKEN}" \
  -H 'Accept: application/vnd.github+json' \
  -H 'X-GitHub-Api-Version: 2022-11-28' \
  "https://api.github.com/repos/BigBirdReturns/clifford-number/actions/artifacts/${ARTIFACT_ID}/zip" \
  --output /tmp/rd02-fixed-capture.zip
test "$(wc -c < /tmp/rd02-fixed-capture.zip | tr -d ' ')" = "$ARTIFACT_BYTES"
test "$(sha256sum /tmp/rd02-fixed-capture.zip | awk '{print $1}')" = "$ARTIFACT_SHA256"
unzip -q /tmp/rd02-fixed-capture.zip -d /tmp/rd02-fixed-capture
CAPTURE_DIR=/tmp/rd02-fixed-capture CAPTURE_MANIFEST_SHA='7ad0486832b496d3fa8242cf4ea927e9a45ff3add7005eb5736ec01aec6f977f' python - <<'PY'
import hashlib, json, os
from pathlib import Path
root = Path(os.environ['CAPTURE_DIR'])
manifest = json.loads((root / 'manifest.json').read_text())
assert manifest['entry_count'] == 29
assert len(manifest['entries']) == 29
assert manifest['combined_sha256'] == os.environ['CAPTURE_MANIFEST_SHA']
seen = set()
for entry in manifest['entries']:
    rel = entry['path']
    assert rel not in seen
    seen.add(rel)
    path = root / rel
    data = path.read_bytes()
    assert len(data) == entry['bytes'], rel
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], rel
combined = hashlib.sha256('\n'.join(f"{row['sha256']}  {row['path']}" for row in manifest['entries']).encode()).hexdigest()
assert combined == manifest['combined_sha256']
assert len([p for p in root.rglob('*') if p.is_file()]) == 30
PY
rm -rf "$CAPTURE_ROOT"
mkdir -p "$CAPTURE_ROOT"
cp -a /tmp/rd02-fixed-capture/. "$CAPTURE_ROOT/"
test "$(sha256sum "$CAPTURE_ROOT/inputs/field-matrix.json" | awk '{print $1}')" = 'f5fbd295998740a1f27f06581c6539d681fe30e8c18a029254eeea7cddb8ffbc'
test "$(sha256sum "$CAPTURE_ROOT/inputs/parent-record.json" | awk '{print $1}')" = 'c856caa5406ae49e150b2151848273b01e400edd14019eda468d9b0fd7a2c446'

step='write-exact-execution-receipt'
mkdir -p "$(dirname "$EXECUTION_RECEIPT")"
cat > "$EXECUTION_RECEIPT" <<'JSON'
{
  "schema_version": "ssc-rd02-wave02-fixed-source-capture-execution-receipt@1",
  "wave_id": "SSC-RD-W02",
  "class_id": "RD-02-C04",
  "issue": 787,
  "source_matrix_head": "c78d243ee3d5c5c9b6c09e4b620bd3192b5e25a1",
  "workflow_run": 30863653791,
  "job_id": 91850755921,
  "artifact_id": 8875282216,
  "artifact_name": "ssc-rd02-wave02-fixed-source-capture-v1",
  "artifact_zip_sha256": "63e1fc4bea63b2d00b8fbbe4b8f585edd2e76a3c380445305c2a7997cf166a67",
  "manifest_entry_count": 29,
  "manifest_combined_sha256": "7ad0486832b496d3fa8242cf4ea927e9a45ff3add7005eb5736ec01aec6f977f",
  "counts": {
    "source_routes": 5,
    "request_attempts": 5,
    "transport_successes": 4,
    "bounded_http_non_successes": 1,
    "bounded_transport_failures": 0,
    "result_spawned_requests": 0
  },
  "authority": {
    "outside_human_dependency": false,
    "external_contacts": 0,
    "external_reviews": 0,
    "substantive_adjudication_performed_by_capture": false,
    "class_closed_by_capture": false,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none"
  }
}
JSON

step='install-authored-surfaces-and-build-terminal-product'
(cd "$CARRIER_DIR/authored" && sha256sum --check "$CARRIER_DIR/authored-sha256.txt")
cp -a "$CARRIER_DIR/authored/." .
node --check tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs
node --check tools/validate-status-sovereignty-rd-wave02-rd02-license-leverage.mjs
node --check test/status-sovereignty-rd-wave02-rd02-license-leverage.test.js
node tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs --write

step='verify-exact-forty-seven-path-product'
mapfile -t EXPECTED_PATHS < "$CARRIER_DIR/expected-paths.txt"
git add -- "${EXPECTED_PATHS[@]}"
git diff --cached --name-only "$EXPECTED_MAIN" | sort > "$RECEIPT_DIR/qualified-paths.txt"
cmp "$CARRIER_DIR/expected-paths.txt" "$RECEIPT_DIR/qualified-paths.txt"
test "$(wc -l < "$RECEIPT_DIR/qualified-paths.txt" | tr -d ' ')" = '47'
test -z "$(git diff --cached --name-status "$EXPECTED_MAIN" | awk '$1 != "A" {print}')"
git diff --cached --check

step='commit-qualified-full-product'
git commit -m 'Close RD-02 fund-level license and leverage chronology'
qualified_commit="$(git rev-parse HEAD)"
qualified_tree="$(git rev-parse 'HEAD^{tree}')"
qualified_workflow_blob="$(git rev-parse "HEAD:$WORKFLOW_PATH")"
printf '%s\n' "$qualified_commit" > "$RECEIPT_DIR/qualified-commit.txt"
printf '%s\n' "$qualified_tree" > "$RECEIPT_DIR/qualified-tree.txt"
printf '%s\n' "$qualified_workflow_blob" > "$RECEIPT_DIR/qualified-workflow-blob.txt"
test "$(git diff --name-only "$EXPECTED_MAIN" "$qualified_commit" | sort | wc -l | tr -d ' ')" = '47'
git diff --name-only "$EXPECTED_MAIN" "$qualified_commit" | sort > "$RECEIPT_DIR/qualified-committed-paths.txt"
cmp "$CARRIER_DIR/expected-paths.txt" "$RECEIPT_DIR/qualified-committed-paths.txt"
test -z "$(git diff --name-status "$EXPECTED_MAIN" "$qualified_commit" | awk '$1 != "A" {print}')"

step='focused-terminal-qualification'
node tools/acquisition/status-sovereignty-rd-wave02-rd02/build-field-matrix.mjs
node tools/acquisition/status-sovereignty-rd-wave02-rd02/validate-field-matrix.mjs
node test/status-sovereignty-rd-wave02-rd02-field-matrix.test.js
node tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs --check
node tools/validate-status-sovereignty-rd-wave02-rd02-license-leverage.mjs
node test/status-sovereignty-rd-wave02-rd02-license-leverage.test.js
node tools/validate-no-magic-human-gate.mjs
git diff --exit-code

step='complete-repository-release-gate'
npm run release:check

step='deterministic-clean-replay'
git reset --hard "$qualified_commit"
git clean -fdx
node tools/acquisition/status-sovereignty-rd-wave02-rd02/build-field-matrix.mjs
node tools/acquisition/status-sovereignty-rd-wave02-rd02/validate-field-matrix.mjs
node test/status-sovereignty-rd-wave02-rd02-field-matrix.test.js
node tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs --check
node tools/validate-status-sovereignty-rd-wave02-rd02-license-leverage.mjs
node test/status-sovereignty-rd-wave02-rd02-license-leverage.test.js
node tools/validate-no-magic-human-gate.mjs
git diff --exit-code
test -z "$(git status --porcelain=v1 --untracked-files=all)"

step='create-exact-nonworkflow-publication-commit'
git reset --hard "$integration_commit"
git clean -fdx
mapfile -t NONWORKFLOW_PATHS < "$CARRIER_DIR/expected-nonworkflow-paths.txt"
git checkout "$qualified_commit" -- "${NONWORKFLOW_PATHS[@]}"
git add -- "${NONWORKFLOW_PATHS[@]}"
git commit -m 'Publish RD-02 terminal product without standing workflow'
nonworkflow_commit="$(git rev-parse HEAD)"
nonworkflow_tree="$(git rev-parse 'HEAD^{tree}')"
printf '%s\n' "$nonworkflow_commit" > "$RECEIPT_DIR/nonworkflow-commit.txt"
printf '%s\n' "$nonworkflow_tree" > "$RECEIPT_DIR/nonworkflow-tree.txt"
git diff --name-only "$EXPECTED_MAIN" "$nonworkflow_commit" | sort > "$RECEIPT_DIR/nonworkflow-paths.txt"
cmp "$CARRIER_DIR/expected-nonworkflow-paths.txt" "$RECEIPT_DIR/nonworkflow-paths.txt"
test "$(wc -l < "$RECEIPT_DIR/nonworkflow-paths.txt" | tr -d ' ')" = '46'
test -z "$(git diff --name-status "$EXPECTED_MAIN" "$nonworkflow_commit" | awk '$1 != "A" {print}')"
test ! -e "$WORKFLOW_PATH"
node tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs --check
node tools/validate-status-sovereignty-rd-wave02-rd02-license-leverage.mjs
node test/status-sovereignty-rd-wave02-rd02-license-leverage.test.js
node tools/validate-no-magic-human-gate.mjs
git diff --exit-code

step='final-main-source-and-target-leases'
test "$(git ls-remote --heads origin refs/heads/main | cut -f1)" = "$EXPECTED_MAIN"
test "$(git ls-remote --heads origin "refs/heads/$SOURCE_BRANCH" | cut -f1)" = "$SOURCE_HEAD"
test -z "$(git ls-remote --heads origin "refs/heads/$TARGET_BRANCH")"

step='publish-forty-six-path-nonworkflow-product'
git push origin "HEAD:refs/heads/$TARGET_BRANCH"
test "$(git ls-remote --heads origin "refs/heads/$TARGET_BRANCH" | cut -f1)" = "$nonworkflow_commit"

step='materialization-complete'
trap - EXIT
finish
