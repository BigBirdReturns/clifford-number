# SSC RD‑02 Wave 02 — terminal fund-level license-and-leverage closure

RD‑02‑C04 closes the bounded public-record acquisition obligation for the fund-level Green Light, license, leverage commitment, draw, fee, covenant, and amendment chronology of the immutable eighteen-row first SBICCT cohort.

The terminal state is `bounded_source_restricted`. Seventeen public legal-vehicle identities are terminal through the fixed official source set; the eighteenth identity remains deliberately withheld under SBA policy. Neither source restriction nor an unrecovered row-level term is converted into nonoccurrence, zero, denial, or an adverse disposition.

## Immutable denominator

```text
cohort rows:                              18
publicly named rows:                      17
withheld rows:                             1
required fields per row:                 10
required field denominator:             180
terminal fields:                         180
closed rows:                              18
```

The exact eighteen-row membership and order remain frozen from the first-cohort parent execution. The withheld row remains an affirmative denominator member and may not be silently removed, relabeled as unsuccessful, or replaced with a named row.

## Label custody

The Wave‑02 constitution and Issue #787 say `fund-level Green Light, license, leverage commitment, draw, fee, covenant, and amendment chronology`. The historical seed omits the qualifier `fund-level`. Both strings remain exact. The reconciliation `constitution_adds_fund_level_qualifier_while_seed_label_is_retained_exact` records the mismatch without rewriting either historical object.

## Fixed official-source protocol

```text
fixed source routes:                       5
request attempts:                          5
transport successes:                       4
bounded HTTP non-successes:                1
bounded transport failures:                0
result-spawned requests:                    0
source-custody manifest entries:           29
```

The fixed routes cover the canonical SBA, Department of Defense, Office of Strategic Capital, and SBA-directory sources already bound by the field matrix. Four routes returned successful official responses; one Department of Defense route returned bounded HTTP 403. The protocol did not crawl linked objects, widen the route denominator after reading results, contact any person, or request external review.

A successful transport is not an admission that every row-level term is present. HTTP 403 is not record absence, no license, no leverage, no draw, no covenant, or noncompliance.

## Terminal field states

```text
observed:                                  67
identity_withheld_under_policy:             1
source_restricted:                          7
source_unavailable_after_fixed_protocol:  105
                                           ---
terminal fields:                           180
```

The fixed record preserves all eighteen initial states, fourteen later license states, seven exact Green Light-to-directory-license transitions, seventeen public identities, and the one withheld identity state.

No row-level leverage commitment amount, actual SBA-guaranteed leverage draw, complete fee or pricing schedule, complete covenant and remedy stack, or amendment/waiver/suspension/surrender/termination chronology is invented. Program ceilings, general eligibility, directory presence, and license status remain analytically separate from a fund-specific commitment or draw.

## Closure effect

```text
terminal state:                     bounded_source_restricted
class closed:                       true
atlas before promotion:             37 open / 5 closed
atlas after promotion:              36 open / 6 closed
selected Wave-02 attempts terminal:  6 / 6 after promotion
```

This closes only RD‑02‑C04’s fixed public-record acquisition obligation. Promotion will complete the six selected Wave‑02 class attempts, but it will not close the canonical forty-two-class residual denominator: thirty-six classes remain open.

## Authority ceiling

```text
outside-human dependency:          false
external contacts/reviews:          0 / 0
reviewed disposition changes:       0
complete-compact finding:          false
capital-conversion finding:        false
favoritism/extraction findings:    false / false
coordination/common purpose:       false / false
graph/publication/adoption:         none / none / none
```
