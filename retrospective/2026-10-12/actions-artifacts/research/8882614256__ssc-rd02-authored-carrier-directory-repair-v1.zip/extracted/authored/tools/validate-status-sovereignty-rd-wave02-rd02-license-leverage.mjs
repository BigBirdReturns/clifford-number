#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  ROOT, MATRIX_PATH, PARENT_PATH, SEED_PATH, CONSTITUTION_PATH, CURRENT_LEDGER_PATH,
  EXECUTION_RECEIPT_PATH, CAPTURE_ROOT, PRODUCT_ROOT, CLOSURE_REFERENCE_PATH,
  CLASS_LABEL, SEED_LABEL, LABEL_RECONCILIATION, TERMINAL_STATE, SOURCE_HEAD,
  MATRIX_BLOB_SHA, MATRIX_SHA256, PARENT_SHA256, CAPTURE_ARTIFACT_SHA256,
  CAPTURE_MANIFEST_SHA256, CAPTURE_MANIFEST_ENTRIES, REQUIRED_FIELDS, deriveProduct
} from './build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs';

export const SCHEMA_PATH = 'schemas/status-sovereignty-rd-wave02-rd02-license-leverage.schema.json';
const abs = (root, rel) => path.join(root, rel);
const readBytes = (root, rel) => fs.readFileSync(abs(root, rel));
const readJson = (root, rel) => JSON.parse(readBytes(root, rel).toString('utf8'));
const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const equal = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const same = (actual, expected, message) => ok(equal(actual, expected), message);
const unique = (values, message) => ok(new Set(values).size === values.length, message);

export function readBundle(root = ROOT) {
  return {
    matrix: readJson(root, MATRIX_PATH),
    parent: readJson(root, PARENT_PATH),
    seed: readJson(root, SEED_PATH),
    constitution: readJson(root, CONSTITUTION_PATH),
    current: readJson(root, CURRENT_LEDGER_PATH),
    execution: readJson(root, EXECUTION_RECEIPT_PATH),
    protocol: readJson(root, `${CAPTURE_ROOT}/protocol.json`),
    captureIndex: readJson(root, `${CAPTURE_ROOT}/capture-index.json`),
    captureManifest: readJson(root, `${CAPTURE_ROOT}/manifest.json`),
    terminal: readJson(root, `${PRODUCT_ROOT}/terminal-field-matrix.json`),
    receipt: readJson(root, `${PRODUCT_ROOT}/class-receipt.json`),
    summary: readJson(root, `${PRODUCT_ROOT}/summary.json`),
    manifest: readJson(root, `${PRODUCT_ROOT}/manifest.json`),
    closure: readJson(root, CLOSURE_REFERENCE_PATH),
    schema: readJson(root, SCHEMA_PATH)
  };
}

function allFalse(value, keys, label) {
  for (const key of keys) ok(value?.[key] === false, `${label}.${key} escalated`);
}
function allNone(value, keys, label) {
  for (const key of keys) ok(value?.[key] === 'none', `${label}.${key} escalated`);
}
function validateAuthority(value, label) {
  ok(value?.outside_human_dependency === false, `${label}.outside_human_dependency changed`);
  ok(value?.external_contacts === 0 && value?.external_reviews === 0, `${label}.external participation changed`);
  allFalse(value, ['reviewed_disposition_changed','complete_compact_finding','favoritism_finding','extraction_finding','coordination_finding','common_purpose_finding'], label);
  allNone(value, ['graph_effect','publication_effect','adoption_effect'], label);
}

function validateCaptureBytes(root, manifest) {
  ok(manifest.entry_count === CAPTURE_MANIFEST_ENTRIES && manifest.entries.length === CAPTURE_MANIFEST_ENTRIES, 'capture manifest denominator changed');
  ok(manifest.combined_sha256 === CAPTURE_MANIFEST_SHA256, 'capture manifest digest changed');
  unique(manifest.entries.map((row) => row.path), 'duplicate capture path');
  for (const entry of manifest.entries) {
    ok(!path.isAbsolute(entry.path) && !entry.path.split('/').includes('..'), `${entry.path}: unsafe capture path`);
    const bytes = readBytes(root, `${CAPTURE_ROOT}/${entry.path}`);
    ok(bytes.length === entry.bytes, `${entry.path}: capture byte count changed`);
    ok(sha256(bytes) === entry.sha256, `${entry.path}: capture digest changed`);
  }
  const combined = sha256(Buffer.from(manifest.entries.map((row) => `${row.sha256}  ${row.path}`).join('\n'), 'utf8'));
  ok(combined === manifest.combined_sha256, 'capture manifest recomputation changed');
}

export function validateCurrentAtlasCustody(current, productManifest = null) {
  ok(current?.counts?.canonical_residual_classes === 42, 'current atlas denominator changed');
  for (const key of [
    'outside_human_dependencies','external_contacts','external_reviews','reviewed_disposition_changes',
    'complete_compact_findings','racial_order_findings','prevalence_findings','coordination_findings',
    'common_purpose_findings','graph_effects','publication_effects','adoption_effects'
  ]) ok(current.counts[key] === 0, `current atlas ${key} changed`);
  ok(current.current_result.outside_human_dependency === false && current.current_result.project_blocking === false, 'current atlas dependency changed');
  allNone(current.current_result, ['graph_effect','publication_effect','adoption_effect'], 'current atlas');

  const promoted = current.promoted_class_receipts.map((row) => row.class_id);
  const open = current.selected_classes_open.map((row) => row.class_id);
  const rd02 = current.promoted_class_receipts.find((row) => row.class_id === 'RD-02-C04');
  const pre =
    current.authority === 'five_terminal_class_receipts_promoted_without_cross_lane_empirical_authority' &&
    current.counts.terminal_class_receipts === 5 &&
    current.counts.classes_closed_this_wave === 5 &&
    current.counts.closed_residual_classes === 5 &&
    current.counts.open_residual_classes === 37 &&
    current.counts.label_reconciliations === 2 &&
    current.current_result.terminal_state === 'five_of_forty_two_residual_classes_closed_one_selected_attempt_open' &&
    current.current_result.all_six_selected_classes_closed === false &&
    current.current_result.wave_complete === false &&
    equal(promoted, ['RD-04-C01','RD-05-C03','RD-01-C03','RD-06-C01','RD-03-C04']) &&
    equal(open, ['RD-02-C04']) &&
    rd02 === undefined;
  const post =
    current.authority === 'six_terminal_class_receipts_promoted_without_cross_lane_empirical_authority' &&
    current.counts.terminal_class_receipts === 6 &&
    current.counts.classes_closed_this_wave === 6 &&
    current.counts.closed_residual_classes === 6 &&
    current.counts.open_residual_classes === 36 &&
    current.counts.label_reconciliations === 3 &&
    current.current_result.terminal_state === 'six_of_forty_two_residual_classes_closed_all_selected_attempts_terminal' &&
    current.current_result.classes_closed === 6 &&
    current.current_result.classes_open === 36 &&
    current.current_result.all_six_selected_classes_closed === true &&
    current.current_result.wave_complete === true &&
    equal(promoted, ['RD-04-C01','RD-05-C03','RD-01-C03','RD-06-C01','RD-03-C04','RD-02-C04']) &&
    equal(open, []) &&
    rd02?.source_pr === 802 &&
    /^[0-9a-f]{40}$/.test(rd02?.merge_commit || '') &&
    rd02?.constitutional_exact_label === CLASS_LABEL &&
    rd02?.receipt_class_label === CLASS_LABEL &&
    rd02?.labels_exact_match === false &&
    rd02?.label_reconciliation === LABEL_RECONCILIATION &&
    rd02?.terminal_state === TERMINAL_STATE &&
    rd02?.class_closed === true &&
    rd02?.closure_reference_path === CLOSURE_REFERENCE_PATH &&
    rd02?.class_receipt_path === `${PRODUCT_ROOT}/class-receipt.json` &&
    /^[0-9a-f]{64}$/.test(rd02?.manifest_combined_sha256 || '') &&
    (!productManifest || rd02.manifest_combined_sha256 === productManifest);
  ok(pre || post, 'current atlas is neither exact RD-02 pre-promotion nor post-promotion custody');
  return pre ? 'pre_promotion' : 'post_promotion';
}

export function validateProductShape(bundle) {
  const { terminal, receipt, summary, manifest, closure, execution, protocol, captureIndex, captureManifest, matrix, parent, seed, constitution, schema } = bundle;
  ok(schema.$schema === 'https://json-schema.org/draft/2020-12/schema' && schema.additionalProperties === false, 'schema root changed');
  ok(schema.properties.schema_version.const === terminal.schema_version, 'schema identity changed');
  ok(schema.properties.rows.minItems === 18 && schema.properties.rows.maxItems === 18, 'schema row denominator changed');
  ok(schema.properties.required_fields.const.length === 10, 'schema field denominator changed');
  const schemaCounts = schema.properties.counts.properties;
  ok(schemaCounts.rows.const === 18 && schemaCounts.publicly_named_rows.const === 17 && schemaCounts.withheld_rows.const === 1, 'schema row-state counts changed');
  ok(schemaCounts.required_fields_per_row.const === 10 && schemaCounts.required_fields.const === 180, 'schema field counts changed');
  ok(schemaCounts.observed_fields.const === 67 && schemaCounts.identity_withheld_fields.const === 1, 'schema observed/withheld counts changed');
  ok(schemaCounts.source_restricted_fields.const === 7 && schemaCounts.source_unavailable_after_fixed_protocol_fields.const === 105, 'schema restricted/unavailable counts changed');
  ok(schemaCounts.terminal_fields.const === 180 && schemaCounts.closed_rows.const === 18, 'schema terminal counts changed');
  ok(schemaCounts.source_routes.const === 5 && schemaCounts.request_attempts.const === 5 && schemaCounts.transport_successes.const === 4 && schemaCounts.bounded_http_non_successes.const === 1, 'schema route counts changed');

  ok(terminal.schema_version === 'ssc-rd-wave02-rd02-license-leverage-terminal-matrix@1', 'terminal schema changed');
  ok(terminal.class_id === 'RD-02-C04' && terminal.issue === 787 && terminal.lane_id === 'RD-02', 'terminal identity changed');
  ok(terminal.class_label === CLASS_LABEL && terminal.status === 'eighteen_row_license_and_leverage_chronology_terminal_bounded_source_restricted', 'terminal label or status changed');
  ok(terminal.source_product.source_matrix_head === SOURCE_HEAD && terminal.source_product.historical_field_matrix_sha256 === MATRIX_SHA256 && terminal.source_product.historical_field_matrix_blob_sha === MATRIX_BLOB_SHA, 'matrix custody changed');
  ok(terminal.source_product.parent_sha256 === PARENT_SHA256, 'parent custody changed');
  ok(terminal.source_product.fixed_capture_artifact_sha256 === CAPTURE_ARTIFACT_SHA256 && terminal.source_product.fixed_capture_manifest_combined_sha256 === CAPTURE_MANIFEST_SHA256, 'capture custody changed');
  ok(terminal.source_product.seed_label_exact_match === false && terminal.source_product.seed_label_reconciliation === LABEL_RECONCILIATION, 'label custody changed');
  same(terminal.required_fields, REQUIRED_FIELDS, 'terminal field list changed');

  ok(Array.isArray(terminal.rows) && terminal.rows.length === 18, 'eighteen rows required');
  same(terminal.rows.map((row) => row.row), Array.from({ length: 18 }, (_, index) => index + 1), 'row order changed');
  unique(terminal.rows.map((row) => row.legal_vehicle), 'row identity duplicated');
  same(terminal.rows.map((row) => row.legal_vehicle), matrix.rows.map((row) => row.legal_vehicle), 'matrix/terminal membership changed');
  for (const row of terminal.rows) {
    same(Object.keys(row.fields), REQUIRED_FIELDS, `${row.row}: field membership changed`);
    ok(Object.values(row.fields).every((field) => field.fixed_protocol_complete === true && field.terminal_for_class_closure === true), `${row.row}: nonterminal field`);
    ok(row.row_result.fixed_protocol_executed === true && row.row_result.terminal_fields === 10 && row.row_result.required_fields === 10 && row.row_result.row_closed === true, `${row.row}: row closure changed`);
  }
  const withheld = terminal.rows[17];
  ok(withheld.row === 18 && withheld.identity_state === 'identity_withheld_under_policy', 'withheld row changed');
  ok(withheld.fields.legal_vehicle_or_withheld_state_label.state === 'identity_withheld_under_policy', 'withheld identity state changed');
  for (const name of REQUIRED_FIELDS.slice(2, 9)) ok(withheld.fields[name].state === 'source_restricted', `withheld ${name} state changed`);
  for (const row of terminal.rows.slice(0, 17)) {
    for (const name of REQUIRED_FIELDS.slice(3, 9)) ok(row.fields[name].state === 'source_unavailable_after_fixed_protocol', `${row.row}.${name}: unavailable state changed`);
  }
  same(terminal.rows.slice(3, 10).map((row) => row.fields.later_license_state_and_date.value.directory_vintage_year), [2025,2026,2025,2025,2025,2025,2025], 'directory transition vintages changed');
  ok(terminal.rows.slice(10, 17).every((row) => row.fields.later_license_state_and_date.value.state === 'licensed_in_first_cohort'), 'initial licensed rows changed');

  same(terminal.counts, receipt.counts, 'receipt counts differ');
  same(terminal.counts, summary.counts, 'summary counts differ');
  same(terminal.counts, {
    rows:18, publicly_named_rows:17, withheld_rows:1, required_fields_per_row:10, required_fields:180,
    observed_fields:67, identity_withheld_fields:1, source_restricted_fields:7,
    source_unavailable_after_fixed_protocol_fields:105, terminal_fields:180, closed_rows:18,
    initially_green_light_named_rows:10, initially_licensed_named_rows:7, withheld_green_light_rows:1,
    later_license_states_observed:14, green_light_to_later_directory_license_transitions_observed:7,
    source_routes:5, request_attempts:5, transport_successes:4, bounded_http_non_successes:1,
    bounded_transport_failures:0, result_spawned_requests:0, external_contacts:0, external_reviews:0
  }, 'terminal counts changed');

  ok(terminal.current_result.terminal_state === TERMINAL_STATE && terminal.current_result.class_closed === true, 'terminal result changed');
  ok(terminal.current_result.exact_eighteen_row_denominator_preserved === true && terminal.current_result.all_required_fields_terminal === true && terminal.current_result.withheld_identity_preserved === true, 'denominator or withheld custody changed');
  ok(terminal.current_result.row_level_leverage_commitments_observed === 0 && terminal.current_result.row_level_actual_draws_observed === 0 && terminal.current_result.complete_fee_pricing_covenant_and_amendment_chronologies_observed === 0, 'unobserved terms promoted');
  allFalse(terminal.current_result, ['capital_conversion_finding','favoritism_finding','extraction_finding','coordination_finding','common_purpose_finding','complete_compact_finding','reviewed_disposition_changed','project_blocking'], 'terminal result');
  allNone(terminal.current_result, ['publication_effect','adoption_effect','graph_effect'], 'terminal result');
  for (const [key, value] of Object.entries(terminal.boundaries)) {
    if (key.endsWith('_effect')) ok(value === 'none', `${key} changed`);
    else ok(value === false, `${key} weakened`);
  }
  validateAuthority(terminal.authority, 'terminal authority');

  ok(receipt.class_label === CLASS_LABEL && receipt.terminal_state === TERMINAL_STATE && receipt.class_closed === true, 'receipt result changed');
  ok(receipt.label_custody.constitutional_class_label === CLASS_LABEL && receipt.label_custody.seed_closure_target === SEED_LABEL && receipt.label_custody.labels_exact_match === false && receipt.label_custody.reconciliation === LABEL_RECONCILIATION, 'receipt label custody changed');
  same(receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_rd06_and_rd03, { canonical_classes:42, open_before:37, closed_before:5, open_after:36, closed_after:6 }, 'receipt atlas effect changed');
  validateAuthority(receipt.authority, 'receipt authority');
  same(summary.current_result, terminal.current_result, 'summary result changed');
  same(summary.boundaries, terminal.boundaries, 'summary boundaries changed');
  validateAuthority(summary.authority, 'summary authority');

  ok(manifest.schema_version === 'ssc-rd-wave02-rd02-license-leverage-manifest@1' && manifest.entries.length === 3, 'product manifest changed');
  same(manifest.entries.map((row) => row.path), ['class-receipt.json','summary.json','terminal-field-matrix.json'], 'product manifest paths changed');
  ok(closure.child_issue === 787 && closure.source_pr === 802 && closure.class_id === 'RD-02-C04' && closure.terminal_state === TERMINAL_STATE && closure.class_closed === true, 'closure changed');
  ok(closure.product.manifest_combined_sha256 === manifest.combined_sha256, 'closure manifest binding changed');
  ok(closure.execution.artifact_zip_sha256 === CAPTURE_ARTIFACT_SHA256 && closure.execution.capture_manifest_combined_sha256 === CAPTURE_MANIFEST_SHA256, 'closure capture binding changed');
  validateAuthority(closure.authority, 'closure authority');

  ok(execution.workflow_run === 30863653791 && execution.job_id === 91850755921 && execution.artifact_id === 8875282216, 'execution custody changed');
  ok(execution.artifact_zip_sha256 === CAPTURE_ARTIFACT_SHA256 && execution.manifest_combined_sha256 === CAPTURE_MANIFEST_SHA256, 'execution digest changed');
  ok(protocol.unit_denominator === 18 && protocol.required_field_denominator === 180 && protocol.source_route_denominator === 5, 'protocol denominator changed');
  ok(captureIndex.routes.length === 5 && captureIndex.counts.transport_successes === 4 && captureIndex.counts.bounded_http_non_successes === 1, 'capture index changed');
  ok(captureManifest.entry_count === 29 && captureManifest.combined_sha256 === CAPTURE_MANIFEST_SHA256, 'capture manifest changed');
  ok(matrix.class_id === 'RD-02-C04' && matrix.rows.length === 18, 'matrix identity changed');
  ok(parent.execution_id === 'SSC-RD02-SBICCT-01', 'parent identity changed');
  ok(seed.closure_target === SEED_LABEL, 'seed label changed');
  ok(constitution.lane_attempts.find((row) => row.class_id === 'RD-02-C04')?.exact_label === CLASS_LABEL, 'constitutional label changed');
  return bundle;
}

function validateProductManifestBytes(root, manifest) {
  for (const entry of manifest.entries) {
    const bytes = readBytes(root, `${PRODUCT_ROOT}/${entry.path}`);
    ok(bytes.length === entry.bytes, `${entry.path}: product byte count changed`);
    ok(sha256(bytes) === entry.sha256, `${entry.path}: product digest changed`);
  }
  const combined = sha256(Buffer.from(manifest.entries.map((row) => `${row.path}\0${row.bytes}\0${row.sha256}\n`).join(''), 'utf8'));
  ok(combined === manifest.combined_sha256, 'product manifest recomputation changed');
}

function validateGitCustody(root) {
  const inside = spawnSync('git', ['rev-parse','--is-inside-work-tree'], { cwd: root, encoding: 'utf8' });
  if (inside.status !== 0) return;
  const tracked = spawnSync('git', ['ls-files'], { cwd: root, encoding: 'utf8' }).stdout.split('\n').filter(Boolean);
  ok(!tracked.some((rel) => rel.includes('temporary-ssc-rd02') || rel.startsWith('.rd02-terminal/')), 'temporary RD-02 transport retained');
  const matrixBlob = spawnSync('git', ['rev-parse', `${SOURCE_HEAD}:${MATRIX_PATH}`], { cwd: root, encoding: 'utf8' });
  ok(matrixBlob.status === 0 && matrixBlob.stdout.trim() === MATRIX_BLOB_SHA, 'historical RD-02 matrix blob changed');
  const ancestor = spawnSync('git', ['merge-base','--is-ancestor', SOURCE_HEAD, 'HEAD'], { cwd: root, encoding: 'utf8' });
  ok(ancestor.status === 0, 'RD-02 source head is not an ancestor');
}

export function validateProduct(root = ROOT) {
  const bundle = readBundle(root);
  validateCaptureBytes(root, bundle.captureManifest);
  validateProductShape(bundle);
  validateProductManifestBytes(root, bundle.manifest);
  const derived = deriveProduct(root);
  same(bundle.terminal, derived.terminal, 'terminal differs from deterministic derivation');
  same(bundle.receipt, derived.receipt, 'receipt differs from deterministic derivation');
  same(bundle.summary, derived.summary, 'summary differs from deterministic derivation');
  validateCurrentAtlasCustody(bundle.current, bundle.manifest.combined_sha256);
  validateGitCustody(root);
  return bundle;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const bundle = validateProduct(ROOT);
  console.log(`RD-02 terminal product validated: ${bundle.terminal.counts.terminal_fields}/180 fields terminal; ${bundle.terminal.counts.closed_rows}/18 rows closed`);
}
