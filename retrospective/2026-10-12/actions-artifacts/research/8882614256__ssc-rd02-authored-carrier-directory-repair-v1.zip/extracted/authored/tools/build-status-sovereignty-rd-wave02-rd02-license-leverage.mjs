#!/usr/bin/env node
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const MATRIX_PATH = 'data/intake/status-sovereignty-rd-wave02-rd02-license-leverage/field-matrix.json';
export const PARENT_PATH = 'data/intake/status-sovereignty-rd02-sbicct-state-transitions.json';
export const SEED_PATH = 'data/project/ssc-residual-wave02/seeds/RD-02-C04.json';
export const CONSTITUTION_PATH = 'data/research/status-sovereignty-residual-denominator-wave-02-constitution.json';
export const CURRENT_LEDGER_PATH = 'data/research/status-sovereignty-residual-denominator-wave-02-current.json';
export const EXECUTION_RECEIPT_PATH = 'data/intake/status-sovereignty-rd-wave02-rd02-license-leverage/fixed-source-capture-execution-receipt.json';
export const CAPTURE_ROOT = 'data/intake/status-sovereignty-rd-wave02-rd02-license-leverage/source-custody/fixed-source-capture-v1';
export const PRODUCT_ROOT = 'data/research/status-sovereignty-rd-wave02-rd02-license-leverage';
export const CLOSURE_REFERENCE_PATH = 'data/project/ssc-residual-wave02/closures/RD-02-C04.json';

export const CLASS_LABEL = 'fund-level Green Light, license, leverage commitment, draw, fee, covenant, and amendment chronology';
export const SEED_LABEL = 'Green Light, license, leverage commitment, draw, fee, covenant, and amendment chronology';
export const LABEL_RECONCILIATION = 'constitution_adds_fund_level_qualifier_while_seed_label_is_retained_exact';
export const TERMINAL_STATE = 'bounded_source_restricted';
export const SOURCE_HEAD = 'c78d243ee3d5c5c9b6c09e4b620bd3192b5e25a1';
export const MATRIX_BLOB_SHA = '241cb73b9248c6312726b29cd69d750064e6f0eb';
export const MATRIX_SHA256 = 'f5fbd295998740a1f27f06581c6539d681fe30e8c18a029254eeea7cddb8ffbc';
export const PARENT_SHA256 = 'c856caa5406ae49e150b2151848273b01e400edd14019eda468d9b0fd7a2c446';
export const CAPTURE_ARTIFACT_SHA256 = '63e1fc4bea63b2d00b8fbbe4b8f585edd2e76a3c380445305c2a7997cf166a67';
export const CAPTURE_MANIFEST_SHA256 = '7ad0486832b496d3fa8242cf4ea927e9a45ff3add7005eb5736ec01aec6f977f';
export const CAPTURE_MANIFEST_ENTRIES = 29;

export const REQUIRED_FIELDS = [
  'legal_vehicle_or_withheld_state_label',
  'initial_state_and_date',
  'later_license_state_and_date',
  'leveraged_or_non_leveraged_license_state',
  'public_leverage_commitment_amount_and_date',
  'actual_sba_guaranteed_leverage_draw_amount_and_date',
  'fee_and_pricing_terms',
  'covenants_and_remedies',
  'amendments_waivers_suspension_surrender_or_termination',
  'source_identities_and_exact_custody'
];

const abs = (root, rel) => path.join(root, rel);
const readBytes = (root, rel) => fs.readFileSync(abs(root, rel));
const readJson = (root, rel) => JSON.parse(readBytes(root, rel).toString('utf8'));
const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const ok = (condition, message) => { if (!condition) throw new Error(message); };
const same = (actual, expected, message) => ok(JSON.stringify(actual) === JSON.stringify(expected), message);
const jsonBytes = (value) => Buffer.from(`${JSON.stringify(value, null, 2)}\n`, 'utf8');

function authority() {
  return {
    outside_human_dependency: false,
    external_contacts: 0,
    external_reviews: 0,
    reviewed_disposition_changed: false,
    complete_compact_finding: false,
    favoritism_finding: false,
    extraction_finding: false,
    coordination_finding: false,
    common_purpose_finding: false,
    graph_effect: 'none',
    publication_effect: 'none',
    adoption_effect: 'none'
  };
}

function terminalField(state, value, sourceIds, captureSourceIds, note) {
  return {
    state,
    value,
    source_ids: [...sourceIds],
    fixed_capture_source_ids: [...captureSourceIds],
    note,
    fixed_protocol_complete: true,
    terminal_for_class_closure: true
  };
}

function unavailable(captureSourceIds, note, sourceIds = [], value = null) {
  return terminalField('source_unavailable_after_fixed_protocol', value, sourceIds, captureSourceIds, note);
}

function restricted(captureSourceIds, note, value = null) {
  return terminalField('source_restricted', value, [], captureSourceIds, note);
}

function validateInputs(root) {
  const matrix = readJson(root, MATRIX_PATH);
  const parent = readJson(root, PARENT_PATH);
  const seed = readJson(root, SEED_PATH);
  const constitution = readJson(root, CONSTITUTION_PATH);
  const current = readJson(root, CURRENT_LEDGER_PATH);
  const execution = readJson(root, EXECUTION_RECEIPT_PATH);
  const protocol = readJson(root, `${CAPTURE_ROOT}/protocol.json`);
  const captureIndex = readJson(root, `${CAPTURE_ROOT}/capture-index.json`);
  const captureManifest = readJson(root, `${CAPTURE_ROOT}/manifest.json`);

  ok(matrix.schema_version === 'ssc-rd-wave02-rd02-license-leverage-field-matrix@1', 'RD-02 matrix schema changed');
  ok(matrix.class_id === 'RD-02-C04' && matrix.issue === 787, 'RD-02 matrix identity changed');
  ok(matrix.denominator_contract.rows === 18 && matrix.rows.length === 18, 'RD-02 row denominator changed');
  ok(matrix.denominator_contract.publicly_named_rows === 17 && matrix.denominator_contract.withheld_rows === 1, 'RD-02 identity denominator changed');
  same(matrix.required_fields, REQUIRED_FIELDS, 'RD-02 field denominator changed');
  ok(matrix.rows.every((row, index) => row.row === index + 1), 'RD-02 row order changed');
  ok(new Set(matrix.rows.map((row) => row.legal_vehicle)).size === 18, 'RD-02 legal-vehicle identities changed or duplicated');
  ok(parent.execution_id === 'SSC-RD02-SBICCT-01' && parent.cohort_rows.length === 18, 'RD-02 parent identity changed');
  same(parent.cohort_rows.map((row) => row.legal_vehicle), matrix.rows.map((row) => row.legal_vehicle), 'RD-02 parent/matrix membership changed');
  ok(seed.class_id === 'RD-02-C04' && seed.child_issue === 787 && seed.closure_target === SEED_LABEL, 'RD-02 seed identity or label changed');
  const attempt = constitution.lane_attempts.find((row) => row.class_id === 'RD-02-C04');
  ok(attempt?.issue === 787 && attempt?.exact_label === CLASS_LABEL, 'RD-02 constitutional label changed');

  ok(current.authority === 'five_terminal_class_receipts_promoted_without_cross_lane_empirical_authority', 'RD-02 pre-promotion ledger authority changed');
  same(current.promoted_class_receipts.map((row) => row.class_id), ['RD-04-C01','RD-05-C03','RD-01-C03','RD-06-C01','RD-03-C04'], 'RD-02 pre-promotion receipt order changed');
  same(current.selected_classes_open.map((row) => row.class_id), ['RD-02-C04'], 'RD-02 must be sole selected class open');
  ok(current.counts.closed_residual_classes === 5 && current.counts.open_residual_classes === 37, 'RD-02 pre-promotion atlas arithmetic changed');
  ok(current.current_result.wave_complete === false && current.current_result.all_six_selected_classes_closed === false, 'RD-02 pre-promotion wave state changed');

  ok(execution.workflow_run === 30863653791 && execution.job_id === 91850755921 && execution.artifact_id === 8875282216, 'RD-02 execution receipt identity changed');
  ok(execution.artifact_zip_sha256 === CAPTURE_ARTIFACT_SHA256 && execution.manifest_combined_sha256 === CAPTURE_MANIFEST_SHA256, 'RD-02 execution receipt digest changed');
  ok(execution.manifest_entry_count === CAPTURE_MANIFEST_ENTRIES, 'RD-02 execution manifest count changed');
  ok(protocol.class_id === 'RD-02-C04' && protocol.unit_denominator === 18 && protocol.required_fields_per_unit === 10 && protocol.required_field_denominator === 180, 'RD-02 protocol denominator changed');
  ok(protocol.source_route_denominator === 5 && protocol.result_spawned_requests === 0 && protocol.denominator_widening_after_results === false, 'RD-02 fixed-source protocol changed');
  ok(captureIndex.counts.source_routes === 5 && captureIndex.counts.request_attempts === 5, 'RD-02 capture route counts changed');
  ok(captureIndex.counts.transport_successes === 4 && captureIndex.counts.bounded_http_non_successes === 1 && captureIndex.counts.bounded_transport_failures === 0, 'RD-02 capture transport states changed');
  ok(captureIndex.routes.length === 5, 'RD-02 capture route membership changed');
  same(captureIndex.routes.map((row) => row.source_id), ['SSC-RD02-S001','SSC-RD02-S002','SSC-RD02-S003','SSC-RD02-S004','SSC-RD02-S005'], 'RD-02 capture source order changed');
  ok(captureManifest.entry_count === CAPTURE_MANIFEST_ENTRIES && captureManifest.entries.length === CAPTURE_MANIFEST_ENTRIES, 'RD-02 capture manifest denominator changed');
  ok(captureManifest.combined_sha256 === CAPTURE_MANIFEST_SHA256, 'RD-02 capture manifest digest changed');
  ok(sha256(readBytes(root, MATRIX_PATH)) === MATRIX_SHA256, 'RD-02 matrix exact bytes changed');
  ok(sha256(readBytes(root, PARENT_PATH)) === PARENT_SHA256, 'RD-02 parent exact bytes changed');
  return { matrix, parent, seed, constitution, current, execution, protocol, captureIndex, captureManifest };
}

function terminalizeRow(row) {
  const withheld = row.identity_state === 'identity_withheld_under_policy';
  const matrixFields = row.fields;
  const preserve = (fieldName, captureSourceIds) => terminalField(
    matrixFields[fieldName].state,
    matrixFields[fieldName].value,
    matrixFields[fieldName].source_ids,
    captureSourceIds,
    matrixFields[fieldName].note
  );
  const fields = {
    legal_vehicle_or_withheld_state_label: preserve('legal_vehicle_or_withheld_state_label', ['SSC-RD02-S002','SSC-RD02-S003']),
    initial_state_and_date: preserve('initial_state_and_date', ['SSC-RD02-S002','SSC-RD02-S003']),
    later_license_state_and_date: matrixFields.later_license_state_and_date.state === 'observed'
      ? preserve('later_license_state_and_date', ['SSC-RD02-S002','SSC-RD02-S003','SSC-RD02-S005'])
      : withheld
        ? restricted(['SSC-RD02-S002','SSC-RD02-S003','SSC-RD02-S005'], 'The cohort identity remains withheld under SBA policy, so a later row-specific license disposition cannot be assigned without defeating the frozen restriction.')
        : unavailable(['SSC-RD02-S002','SSC-RD02-S003','SSC-RD02-S005'], 'The fixed official source set produced no exact later-license disposition for this named row. Nonappearance is not proof of nonlicensure.'),
    leveraged_or_non_leveraged_license_state: withheld
      ? restricted(['SSC-RD02-S004','SSC-RD02-S005'], 'The withheld identity prevents assignment of a row-specific leveraged or non-leveraged license state.')
      : unavailable(['SSC-RD02-S004','SSC-RD02-S005'], 'Program-level leverage eligibility and the existence of non-leveraged licenses do not establish this fund’s row-specific leverage authority.'),
    public_leverage_commitment_amount_and_date: withheld
      ? restricted(['SSC-RD02-S004'], 'The withheld identity prevents assignment of a row-specific public leverage commitment.')
      : unavailable(['SSC-RD02-S004'], 'The fixed official source set contains no fund-specific leverage commitment amount or date. The program ceiling is not a row-level commitment.'),
    actual_sba_guaranteed_leverage_draw_amount_and_date: withheld
      ? restricted(['SSC-RD02-S004'], 'The withheld identity prevents assignment of a row-specific SBA-guaranteed leverage draw.')
      : unavailable(['SSC-RD02-S004'], 'No actual fund-specific SBA-guaranteed leverage draw amount or date was recovered. License, eligibility, and commitment are not draw.'),
    fee_and_pricing_terms: withheld
      ? restricted(['SSC-RD02-S004'], 'The withheld identity prevents assignment of row-specific fees and pricing terms.')
      : unavailable(['SSC-RD02-S004'], 'No row-specific fee, pricing, discount, or cost-of-capital schedule was recovered from the fixed official source set.'),
    covenants_and_remedies: withheld
      ? restricted(['SSC-RD02-S004'], 'The withheld identity prevents assignment of row-specific covenants and remedies.')
      : unavailable(['SSC-RD02-S004'], 'No row-specific covenant, reporting, default, cure, enforcement, or remedy schedule was recovered from the fixed official source set.'),
    amendments_waivers_suspension_surrender_or_termination: withheld
      ? restricted(['SSC-RD02-S004','SSC-RD02-S005'], 'The withheld identity prevents assignment of a row-specific amendment, waiver, suspension, surrender, or termination chronology.')
      : unavailable(['SSC-RD02-S004','SSC-RD02-S005'], 'No row-specific amendment, waiver, suspension, surrender, or termination record was recovered. Unrecovered is not nonoccurrence.'),
    source_identities_and_exact_custody: terminalField(
      'observed',
      {
        source_matrix_head: SOURCE_HEAD,
        historical_field_matrix_path: MATRIX_PATH,
        historical_field_matrix_blob_sha: MATRIX_BLOB_SHA,
        historical_field_matrix_sha256: MATRIX_SHA256,
        parent_path: PARENT_PATH,
        parent_sha256: PARENT_SHA256,
        seed_path: SEED_PATH,
        fixed_capture_root: CAPTURE_ROOT,
        fixed_capture_artifact_sha256: CAPTURE_ARTIFACT_SHA256,
        fixed_capture_manifest_sha256: CAPTURE_MANIFEST_SHA256,
        fixed_capture_manifest_entries: CAPTURE_MANIFEST_ENTRIES,
        source_routes: 5,
        request_attempts: 5,
        result_spawned_requests: 0
      },
      matrixFields.source_identities_and_exact_custody.source_ids,
      ['SSC-RD02-S001','SSC-RD02-S002','SSC-RD02-S003','SSC-RD02-S004','SSC-RD02-S005'],
      'Exact matrix, parent, seed, capture artifact, manifest, and fixed-route custody is retained. This custody does not convert unavailable row-level terms into zero or absence.'
    )
  };
  return {
    row: row.row,
    legal_vehicle: row.legal_vehicle,
    identity_state: row.identity_state,
    parent_state: row.parent_state,
    fields,
    row_result: {
      fixed_protocol_executed: true,
      terminal_fields: 10,
      required_fields: 10,
      row_closed: true,
      terminal_state: withheld ? 'bounded_identity_withheld_under_policy' : 'bounded_source_unavailable'
    }
  };
}

function boundaries() {
  return {
    green_light_is_license: false,
    license_is_leverage_commitment_or_draw: false,
    directory_presence_is_successful_investment: false,
    program_ceiling_is_fund_commitment: false,
    leverage_eligibility_is_actual_draw: false,
    unrecovered_amount_is_zero: false,
    unrecovered_record_is_nonoccurrence: false,
    withheld_identity_is_negative_disposition: false,
    source_restriction_is_event_absence: false,
    fixed_protocol_completion_is_complete_compact: false,
    functional_convergence_is_coordination_or_common_purpose: false,
    outside_human_dependency: false,
    graph_effect: 'none',
    publication_effect: 'none',
    adoption_effect: 'none'
  };
}

export function deriveProduct(root = ROOT) {
  const inputs = validateInputs(root);
  const rows = inputs.matrix.rows.map(terminalizeRow);
  const allFields = rows.flatMap((row) => Object.values(row.fields));
  const counts = {
    rows: 18,
    publicly_named_rows: 17,
    withheld_rows: 1,
    required_fields_per_row: 10,
    required_fields: 180,
    observed_fields: allFields.filter((field) => field.state === 'observed').length,
    identity_withheld_fields: allFields.filter((field) => field.state === 'identity_withheld_under_policy').length,
    source_restricted_fields: allFields.filter((field) => field.state === 'source_restricted').length,
    source_unavailable_after_fixed_protocol_fields: allFields.filter((field) => field.state === 'source_unavailable_after_fixed_protocol').length,
    terminal_fields: allFields.filter((field) => field.terminal_for_class_closure === true).length,
    closed_rows: rows.filter((row) => row.row_result.row_closed === true).length,
    initially_green_light_named_rows: 10,
    initially_licensed_named_rows: 7,
    withheld_green_light_rows: 1,
    later_license_states_observed: rows.filter((row) => row.fields.later_license_state_and_date.state === 'observed').length,
    green_light_to_later_directory_license_transitions_observed: 7,
    source_routes: 5,
    request_attempts: 5,
    transport_successes: 4,
    bounded_http_non_successes: 1,
    bounded_transport_failures: 0,
    result_spawned_requests: 0,
    external_contacts: 0,
    external_reviews: 0
  };
  same(counts, {
    rows: 18,
    publicly_named_rows: 17,
    withheld_rows: 1,
    required_fields_per_row: 10,
    required_fields: 180,
    observed_fields: 67,
    identity_withheld_fields: 1,
    source_restricted_fields: 7,
    source_unavailable_after_fixed_protocol_fields: 105,
    terminal_fields: 180,
    closed_rows: 18,
    initially_green_light_named_rows: 10,
    initially_licensed_named_rows: 7,
    withheld_green_light_rows: 1,
    later_license_states_observed: 14,
    green_light_to_later_directory_license_transitions_observed: 7,
    source_routes: 5,
    request_attempts: 5,
    transport_successes: 4,
    bounded_http_non_successes: 1,
    bounded_transport_failures: 0,
    result_spawned_requests: 0,
    external_contacts: 0,
    external_reviews: 0
  }, 'RD-02 terminal counts changed');

  const currentResult = {
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    exact_eighteen_row_denominator_preserved: true,
    all_required_fields_terminal: true,
    later_license_states_observed: 14,
    row_level_leverage_commitments_observed: 0,
    row_level_actual_draws_observed: 0,
    complete_fee_pricing_covenant_and_amendment_chronologies_observed: 0,
    withheld_identity_preserved: true,
    capital_conversion_finding: false,
    favoritism_finding: false,
    extraction_finding: false,
    coordination_finding: false,
    common_purpose_finding: false,
    complete_compact_finding: false,
    reviewed_disposition_changed: false,
    project_blocking: false,
    publication_effect: 'none',
    adoption_effect: 'none',
    graph_effect: 'none'
  };

  const terminal = {
    schema_version: 'ssc-rd-wave02-rd02-license-leverage-terminal-matrix@1',
    wave_id: 'SSC-RD-W02',
    lane_id: 'RD-02',
    class_id: 'RD-02-C04',
    issue: 787,
    as_of: '2026-08-04',
    class_label: CLASS_LABEL,
    status: 'eighteen_row_license_and_leverage_chronology_terminal_bounded_source_restricted',
    source_product: {
      source_matrix_head: SOURCE_HEAD,
      historical_field_matrix_path: MATRIX_PATH,
      historical_field_matrix_blob_sha: MATRIX_BLOB_SHA,
      historical_field_matrix_sha256: MATRIX_SHA256,
      parent_path: PARENT_PATH,
      parent_sha256: PARENT_SHA256,
      seed_path: SEED_PATH,
      seed_label: SEED_LABEL,
      constitutional_label: CLASS_LABEL,
      seed_label_exact_match: false,
      seed_label_reconciliation: LABEL_RECONCILIATION,
      execution_receipt_path: EXECUTION_RECEIPT_PATH,
      fixed_capture_root: CAPTURE_ROOT,
      fixed_capture_artifact_sha256: CAPTURE_ARTIFACT_SHA256,
      fixed_capture_manifest_combined_sha256: CAPTURE_MANIFEST_SHA256,
      fixed_capture_manifest_entries: CAPTURE_MANIFEST_ENTRIES
    },
    denominator_contract: inputs.matrix.denominator_contract,
    required_fields: REQUIRED_FIELDS,
    rows,
    counts,
    current_result: currentResult,
    boundaries: boundaries(),
    authority: authority()
  };

  const receipt = {
    schema_version: 'ssc-rd-wave02-rd02-license-leverage-class-receipt@1',
    wave_id: 'SSC-RD-W02',
    lane_id: 'RD-02',
    class_id: 'RD-02-C04',
    issue: 787,
    class_label: CLASS_LABEL,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    label_custody: {
      constitutional_class_label: CLASS_LABEL,
      seed_closure_target: SEED_LABEL,
      labels_exact_match: false,
      reconciliation: LABEL_RECONCILIATION
    },
    closure_basis: [
      'the immutable eighteen-row first-cohort denominator remains complete and ordered, including the withheld eighteenth row',
      'initial Green Light and licensed states remain distinct from later exact directory license observations',
      'the fixed five-route official-source protocol is terminal and generated no result-spawned requests',
      'all 180 required fields are terminally typed without inventing commitments, draws, fees, covenants, amendments, waivers, repayments, losses, or public recovery',
      'the withheld identity remains source restricted rather than silently removed or assigned a negative disposition'
    ],
    counts,
    residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_rd06_and_rd03: {
      canonical_classes: 42,
      open_before: 37,
      closed_before: 5,
      open_after: 36,
      closed_after: 6
    },
    source_custody: terminal.source_product,
    current_result: currentResult,
    boundaries: terminal.boundaries,
    authority: authority()
  };

  const summary = {
    schema_version: 'ssc-rd-wave02-rd02-license-leverage-summary@1',
    wave_id: 'SSC-RD-W02',
    lane_id: 'RD-02',
    class_id: 'RD-02-C04',
    issue: 787,
    class_label: CLASS_LABEL,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    counts,
    current_result: currentResult,
    boundaries: terminal.boundaries,
    authority: authority()
  };
  return { terminal, receipt, summary };
}

function buildArtifacts(root = ROOT) {
  const { terminal, receipt, summary } = deriveProduct(root);
  const productBytes = new Map([
    ['class-receipt.json', jsonBytes(receipt)],
    ['summary.json', jsonBytes(summary)],
    ['terminal-field-matrix.json', jsonBytes(terminal)]
  ]);
  const entries = [...productBytes.entries()].map(([entryPath, bytes]) => ({ path: entryPath, bytes: bytes.length, sha256: sha256(bytes) }));
  const combinedSha256 = sha256(Buffer.from(entries.map((row) => `${row.path}\0${row.bytes}\0${row.sha256}\n`).join(''), 'utf8'));
  const manifest = {
    schema_version: 'ssc-rd-wave02-rd02-license-leverage-manifest@1',
    entries,
    combined_sha256: combinedSha256
  };
  const closure = {
    schema_version: 'ssc-residual-denominator-wave02-class-closure-reference@1',
    wave_issue: 785,
    child_issue: 787,
    source_pr: 802,
    lane_id: 'RD-02',
    class_id: 'RD-02-C04',
    constitutional_exact_label: CLASS_LABEL,
    receipt_class_label: CLASS_LABEL,
    labels_exact_match: false,
    label_reconciliation: LABEL_RECONCILIATION,
    terminal_state: TERMINAL_STATE,
    class_closed: true,
    residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_rd06_and_rd03: receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_rd06_and_rd03,
    product: {
      class_receipt_path: `${PRODUCT_ROOT}/class-receipt.json`,
      terminal_field_matrix_path: `${PRODUCT_ROOT}/terminal-field-matrix.json`,
      summary_path: `${PRODUCT_ROOT}/summary.json`,
      manifest_path: `${PRODUCT_ROOT}/manifest.json`,
      manifest_combined_sha256: combinedSha256
    },
    execution: {
      workflow_run: 30863653791,
      job_id: 91850755921,
      artifact_id: 8875282216,
      artifact_zip_sha256: CAPTURE_ARTIFACT_SHA256,
      manifest_entry_count: CAPTURE_MANIFEST_ENTRIES,
      capture_manifest_combined_sha256: CAPTURE_MANIFEST_SHA256,
      execution_receipt_path: EXECUTION_RECEIPT_PATH
    },
    authority: authority()
  };
  return {
    terminal,
    receipt,
    summary,
    manifest,
    closure,
    files: new Map([
      [`${PRODUCT_ROOT}/class-receipt.json`, jsonBytes(receipt)],
      [`${PRODUCT_ROOT}/summary.json`, jsonBytes(summary)],
      [`${PRODUCT_ROOT}/terminal-field-matrix.json`, jsonBytes(terminal)],
      [`${PRODUCT_ROOT}/manifest.json`, jsonBytes(manifest)],
      [CLOSURE_REFERENCE_PATH, jsonBytes(closure)]
    ])
  };
}

export function writeProduct(root = ROOT) {
  const built = buildArtifacts(root);
  for (const [rel, bytes] of built.files) {
    fs.mkdirSync(path.dirname(abs(root, rel)), { recursive: true });
    fs.writeFileSync(abs(root, rel), bytes);
  }
  return built;
}

export function checkProduct(root = ROOT) {
  const built = buildArtifacts(root);
  for (const [rel, expected] of built.files) {
    const observed = readBytes(root, rel);
    ok(observed.equals(expected), `${rel}: committed product differs from deterministic derivation`);
  }
  return built;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const mode = process.argv[2] || '--write';
  if (mode === '--write') {
    const built = writeProduct(ROOT);
    console.log(`wrote RD-02 terminal product: ${built.terminal.counts.terminal_fields}/180 fields terminal; 18/18 rows closed`);
  } else if (mode === '--check') {
    const built = checkProduct(ROOT);
    console.log(`RD-02 terminal product: ${built.terminal.counts.terminal_fields}/180 fields terminal; ${built.terminal.counts.source_unavailable_after_fixed_protocol_fields} unavailable; ${built.terminal.counts.source_restricted_fields} restricted`);
  } else {
    throw new Error(`unknown mode: ${mode}`);
  }
}
