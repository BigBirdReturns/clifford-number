#!/usr/bin/env node
import assert from 'node:assert/strict';
import {
  PRODUCT_ROOT, CLASS_LABEL, TERMINAL_STATE, CLOSURE_REFERENCE_PATH, LABEL_RECONCILIATION
} from '../tools/build-status-sovereignty-rd-wave02-rd02-license-leverage.mjs';
import {
  readBundle, validateProduct, validateProductShape, validateCurrentAtlasCustody
} from '../tools/validate-status-sovereignty-rd-wave02-rd02-license-leverage.mjs';

const clone = (value) => structuredClone(value);
validateProduct();
const bundle = readBundle();
assert.equal(validateCurrentAtlasCustody(bundle.current, bundle.manifest.combined_sha256), 'pre_promotion');

const post = clone(bundle.current);
post.authority = 'six_terminal_class_receipts_promoted_without_cross_lane_empirical_authority';
post.promoted_class_receipts.push({
  lane_id:'RD-02', class_id:'RD-02-C04', issue:787, source_pr:802,
  merge_commit:'2'.repeat(40), constitutional_exact_label:CLASS_LABEL,
  receipt_class_label:CLASS_LABEL, labels_exact_match:false,
  label_reconciliation:LABEL_RECONCILIATION, terminal_state:TERMINAL_STATE,
  closure_reference_path:CLOSURE_REFERENCE_PATH,
  class_receipt_path:`${PRODUCT_ROOT}/class-receipt.json`,
  manifest_combined_sha256:bundle.manifest.combined_sha256, class_closed:true
});
post.selected_classes_open = [];
post.counts.terminal_class_receipts = 6;
post.counts.classes_closed_this_wave = 6;
post.counts.closed_residual_classes = 6;
post.counts.open_residual_classes = 36;
post.counts.label_reconciliations = 3;
post.current_result.terminal_state = 'six_of_forty_two_residual_classes_closed_all_selected_attempts_terminal';
post.current_result.classes_closed = 6;
post.current_result.classes_open = 36;
post.current_result.closed_class_ids = [...post.current_result.closed_class_ids, 'RD-02-C04'];
post.current_result.open_selected_class_ids = [];
post.current_result.all_six_selected_classes_closed = true;
post.current_result.wave_complete = true;
assert.equal(validateCurrentAtlasCustody(post, bundle.manifest.combined_sha256), 'post_promotion');

const mutations = [
  ['terminal schema', b => { b.terminal.schema_version = 'bad'; }],
  ['terminal class', b => { b.terminal.class_id = 'RD-03-C04'; }],
  ['terminal issue', b => { b.terminal.issue = 788; }],
  ['terminal lane', b => { b.terminal.lane_id = 'RD-03'; }],
  ['terminal label', b => { b.terminal.class_label = 'partial'; }],
  ['terminal status', b => { b.terminal.status = 'open'; }],
  ['source head', b => { b.terminal.source_product.source_matrix_head = '0'.repeat(40); }],
  ['matrix sha', b => { b.terminal.source_product.historical_field_matrix_sha256 = '0'.repeat(64); }],
  ['matrix blob', b => { b.terminal.source_product.historical_field_matrix_blob_sha = '0'.repeat(40); }],
  ['parent sha', b => { b.terminal.source_product.parent_sha256 = '0'.repeat(64); }],
  ['capture artifact', b => { b.terminal.source_product.fixed_capture_artifact_sha256 = '0'.repeat(64); }],
  ['capture manifest', b => { b.terminal.source_product.fixed_capture_manifest_combined_sha256 = '0'.repeat(64); }],
  ['seed reconciliation', b => { b.terminal.source_product.seed_label_reconciliation = 'none'; }],
  ['field list', b => { b.terminal.required_fields.reverse(); }],
  ['remove row', b => { b.terminal.rows.pop(); }],
  ['duplicate row number', b => { b.terminal.rows[1].row = 1; }],
  ['duplicate vehicle', b => { b.terminal.rows[1].legal_vehicle = b.terminal.rows[0].legal_vehicle; }],
  ['row order', b => { b.terminal.rows.reverse(); }],
  ['remove field', b => { delete b.terminal.rows[0].fields.covenants_and_remedies; }],
  ['field protocol false', b => { b.terminal.rows[0].fields.initial_state_and_date.fixed_protocol_complete = false; }],
  ['field terminal false', b => { b.terminal.rows[0].fields.initial_state_and_date.terminal_for_class_closure = false; }],
  ['row protocol false', b => { b.terminal.rows[0].row_result.fixed_protocol_executed = false; }],
  ['row reopened', b => { b.terminal.rows[0].row_result.row_closed = false; }],
  ['row field count', b => { b.terminal.rows[0].row_result.terminal_fields = 9; }],
  ['withheld row moved', b => { b.terminal.rows[17].row = 17; }],
  ['withheld identity erased', b => { b.terminal.rows[17].identity_state = 'publicly_named'; }],
  ['withheld label promoted', b => { b.terminal.rows[17].fields.legal_vehicle_or_withheld_state_label.state = 'observed'; }],
  ['withheld later promoted', b => { b.terminal.rows[17].fields.later_license_state_and_date.state = 'observed'; }],
  ['withheld draw promoted', b => { b.terminal.rows[17].fields.actual_sba_guaranteed_leverage_draw_amount_and_date.state = 'observed'; }],
  ['named leverage promoted', b => { b.terminal.rows[0].fields.leveraged_or_non_leveraged_license_state.state = 'observed'; }],
  ['named commitment promoted', b => { b.terminal.rows[0].fields.public_leverage_commitment_amount_and_date.state = 'observed'; }],
  ['named draw promoted', b => { b.terminal.rows[0].fields.actual_sba_guaranteed_leverage_draw_amount_and_date.state = 'observed'; }],
  ['named fee promoted', b => { b.terminal.rows[0].fields.fee_and_pricing_terms.state = 'observed'; }],
  ['named covenant promoted', b => { b.terminal.rows[0].fields.covenants_and_remedies.state = 'observed'; }],
  ['named amendment promoted', b => { b.terminal.rows[0].fields.amendments_waivers_suspension_surrender_or_termination.state = 'observed'; }],
  ['directory vintage', b => { b.terminal.rows[3].fields.later_license_state_and_date.value.directory_vintage_year = 2024; }],
  ['licensed cohort state', b => { b.terminal.rows[10].fields.later_license_state_and_date.value.state = 'licensed_directory_observed'; }],
  ['row count', b => { b.terminal.counts.rows = 17; }],
  ['named count', b => { b.terminal.counts.publicly_named_rows = 16; }],
  ['withheld count', b => { b.terminal.counts.withheld_rows = 0; }],
  ['required count', b => { b.terminal.counts.required_fields = 179; }],
  ['observed count', b => { b.terminal.counts.observed_fields = 68; }],
  ['identity count', b => { b.terminal.counts.identity_withheld_fields = 0; }],
  ['restricted count', b => { b.terminal.counts.source_restricted_fields = 6; }],
  ['unavailable count', b => { b.terminal.counts.source_unavailable_after_fixed_protocol_fields = 104; }],
  ['terminal count', b => { b.terminal.counts.terminal_fields = 179; }],
  ['closed rows', b => { b.terminal.counts.closed_rows = 17; }],
  ['later licenses', b => { b.terminal.counts.later_license_states_observed = 15; }],
  ['transition count', b => { b.terminal.counts.green_light_to_later_directory_license_transitions_observed = 8; }],
  ['route count', b => { b.terminal.counts.source_routes = 4; }],
  ['attempt count', b => { b.terminal.counts.request_attempts = 6; }],
  ['transport count', b => { b.terminal.counts.transport_successes = 5; }],
  ['http non-success count', b => { b.terminal.counts.bounded_http_non_successes = 0; }],
  ['spawned request', b => { b.terminal.counts.result_spawned_requests = 1; }],
  ['class reopened', b => { b.terminal.current_result.class_closed = false; }],
  ['denominator lost', b => { b.terminal.current_result.exact_eighteen_row_denominator_preserved = false; }],
  ['nonterminal result', b => { b.terminal.current_result.all_required_fields_terminal = false; }],
  ['commitment invented', b => { b.terminal.current_result.row_level_leverage_commitments_observed = 1; }],
  ['draw invented', b => { b.terminal.current_result.row_level_actual_draws_observed = 1; }],
  ['terms complete', b => { b.terminal.current_result.complete_fee_pricing_covenant_and_amendment_chronologies_observed = 1; }],
  ['withheld lost', b => { b.terminal.current_result.withheld_identity_preserved = false; }],
  ['capital conversion', b => { b.terminal.current_result.capital_conversion_finding = true; }],
  ['favoritism', b => { b.terminal.current_result.favoritism_finding = true; }],
  ['extraction', b => { b.terminal.current_result.extraction_finding = true; }],
  ['coordination', b => { b.terminal.current_result.coordination_finding = true; }],
  ['common purpose', b => { b.terminal.current_result.common_purpose_finding = true; }],
  ['publication', b => { b.terminal.current_result.publication_effect = 'published'; }],
  ['green light boundary', b => { b.terminal.boundaries.green_light_is_license = true; }],
  ['license boundary', b => { b.terminal.boundaries.license_is_leverage_commitment_or_draw = true; }],
  ['directory boundary', b => { b.terminal.boundaries.directory_presence_is_successful_investment = true; }],
  ['ceiling boundary', b => { b.terminal.boundaries.program_ceiling_is_fund_commitment = true; }],
  ['eligibility boundary', b => { b.terminal.boundaries.leverage_eligibility_is_actual_draw = true; }],
  ['zero boundary', b => { b.terminal.boundaries.unrecovered_amount_is_zero = true; }],
  ['nonoccurrence boundary', b => { b.terminal.boundaries.unrecovered_record_is_nonoccurrence = true; }],
  ['withheld disposition boundary', b => { b.terminal.boundaries.withheld_identity_is_negative_disposition = true; }],
  ['source absence boundary', b => { b.terminal.boundaries.source_restriction_is_event_absence = true; }],
  ['terminal contact', b => { b.terminal.authority.external_contacts = 1; }],
  ['terminal review', b => { b.terminal.authority.external_reviews = 1; }],
  ['receipt reopened', b => { b.receipt.class_closed = false; }],
  ['receipt state', b => { b.receipt.terminal_state = 'evidence_complete'; }],
  ['receipt label', b => { b.receipt.class_label = 'partial'; }],
  ['receipt reconciliation', b => { b.receipt.label_custody.reconciliation = 'none'; }],
  ['receipt atlas', b => { b.receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_rd06_and_rd03.open_after = 35; }],
  ['summary count', b => { b.summary.counts.rows = 17; }],
  ['summary result', b => { b.summary.current_result.class_closed = false; }],
  ['manifest remove', b => { b.manifest.entries.pop(); }],
  ['manifest path', b => { b.manifest.entries[0].path = 'other.json'; }],
  ['closure issue', b => { b.closure.child_issue = 788; }],
  ['closure PR', b => { b.closure.source_pr = 803; }],
  ['closure state', b => { b.closure.terminal_state = 'evidence_complete'; }],
  ['closure manifest', b => { b.closure.product.manifest_combined_sha256 = '0'.repeat(64); }],
  ['closure artifact', b => { b.closure.execution.artifact_zip_sha256 = '0'.repeat(64); }],
  ['execution run', b => { b.execution.workflow_run = 1; }],
  ['execution artifact', b => { b.execution.artifact_zip_sha256 = '0'.repeat(64); }],
  ['protocol rows', b => { b.protocol.unit_denominator = 17; }],
  ['protocol fields', b => { b.protocol.required_field_denominator = 179; }],
  ['capture route removed', b => { b.captureIndex.routes.pop(); }],
  ['capture successes', b => { b.captureIndex.counts.transport_successes = 5; }],
  ['capture manifest entries', b => { b.captureManifest.entry_count = 28; }],
  ['matrix class', b => { b.matrix.class_id = 'RD-03-C04'; }],
  ['parent identity', b => { b.parent.execution_id = 'OTHER'; }],
  ['seed label', b => { b.seed.closure_target = 'other'; }],
  ['constitution label', b => { b.constitution.lane_attempts.find(r => r.class_id === 'RD-02-C04').exact_label = 'other'; }],
  ['schema open', b => { b.schema.additionalProperties = true; }],
  ['schema denominator', b => { b.schema.properties.rows.maxItems = 19; }],
  ['schema state count', b => { b.schema.properties.counts.properties.source_unavailable_after_fixed_protocol_fields.const = 104; }]
];
for (const [name, mutate] of mutations) {
  const candidate = clone(bundle);
  mutate(candidate);
  assert.throws(() => validateProductShape(candidate), undefined, name);
}

const custodyMutations = [
  ['pre closed count', v => { v.counts.closed_residual_classes = 6; }],
  ['pre open count', v => { v.counts.open_residual_classes = 36; }],
  ['pre RD02 removed', v => { v.selected_classes_open = []; }],
  ['pre label count', v => { v.counts.label_reconciliations = 3; }],
  ['pre wave complete', v => { v.current_result.wave_complete = true; }],
  ['pre graph', v => { v.current_result.graph_effect = 'edge'; }],
  ['post merge', v => { v.promoted_class_receipts[5].merge_commit = 'bad'; }],
  ['post manifest', v => { v.promoted_class_receipts[5].manifest_combined_sha256 = '0'.repeat(64); }],
  ['post reconciliation', v => { v.promoted_class_receipts[5].label_reconciliation = 'none'; }],
  ['post exact label flag', v => { v.promoted_class_receipts[5].labels_exact_match = true; }],
  ['post reopened', v => { v.selected_classes_open.push({ lane_id:'RD-02', class_id:'RD-02-C04' }); }],
  ['post state', v => { v.promoted_class_receipts[5].terminal_state = 'evidence_complete'; }],
  ['post order', v => { v.promoted_class_receipts.reverse(); }],
  ['post wave incomplete', v => { v.current_result.wave_complete = false; }],
  ['post selected incomplete', v => { v.current_result.all_six_selected_classes_closed = false; }],
  ['post effect', v => { v.counts.external_reviews = 1; }]
];
for (const [name, mutate] of custodyMutations) {
  const candidate = clone(name.startsWith('post') ? post : bundle.current);
  mutate(candidate);
  assert.throws(() => validateCurrentAtlasCustody(candidate, bundle.manifest.combined_sha256), undefined, name);
}
console.log(`RD-02 terminal adversarial suite: ${mutations.length + custodyMutations.length} mutations refused`);
