# RD-04 North Dakota FY2026 archive range current-main rebind

The checksum-complete range correction in artifact 9041062191 is rebound to canonical parent 8482b941aa0b1ecac685ab6ca98bba80ed80c5ee. The only intervening canonical change repairs one unrelated cross-corpus crawl-gap map. The RD-04 matrix blob and North Dakota waiver cell are unchanged. The field remains open, and exactly one unexecuted MI-NM archive-origin route is authorized.
