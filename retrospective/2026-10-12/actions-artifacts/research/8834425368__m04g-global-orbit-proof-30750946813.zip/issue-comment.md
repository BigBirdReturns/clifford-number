<!-- m04g-global-orbit-proof:30750946813 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30750946813
- Head: `3bd46186c2b70ae08e68a5888b9030d445239cfa`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `2/2`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `5/10` (`0.5`)
- Content success: `5/10` (`0.5`)
- Metadata only: `0`
- Failed: `5`
- Healthy basins: `0/2`
- Proof SHA-256: `5fbc9da8bfff61685076f3126182379a2e05daff6bd501d3c7196ca06d77ab1b`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G02-NORTH-AMERICA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
