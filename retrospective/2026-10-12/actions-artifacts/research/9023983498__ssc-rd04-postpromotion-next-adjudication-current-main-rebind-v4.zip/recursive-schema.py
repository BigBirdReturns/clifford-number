import json
from pathlib import Path
from jsonschema import Draft202012Validator
schema=json.loads(Path('schemas/status-sovereignty-rd-wave03-rd04-postpromotion-next-adjudication.schema.json').read_text())
Draft202012Validator.check_schema(schema)
validator=Draft202012Validator(schema)
root=Path('data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-next-adjudication')
names=['capture-custody.json','source-adjudications.json','field-adjudications.json','promotion-candidate-protocol.json','adjudication-summary.json','index.json','product-manifest.json']
for name in names:
    value=json.loads((root/name).read_text())
    errors=sorted(validator.iter_errors(value),key=lambda e:list(e.path))
    if errors: raise SystemExit(f'{name}: {errors[0].message} at {list(errors[0].path)}')
print(f'recursive_schema_validation=pass objects={len(names)}')
