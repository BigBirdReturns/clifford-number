RD-04 MF8 immutable archive measurement completed.

```text
workflow_run: 31153823642
carrier_head: f564918f8f6ff1da80bf6f230ea7ee479261bed7
actual_archive_bytes: 15010
actual_archive_sha256: 376f1803fb4d462235cff1d0f4b2258940822ecf1b357a3bbb243b6c0be83d63
actual_archive_git_blob: ba4ddfa57771ce747c365dfa04998fb1c18cb4b3
claimed_archive_bytes: 20748
claimed_archive_sha256: 3afa1a777dab75415cafc8a4b317a10771de0f5eb74ccbef5a18f6b4ae5c208f
claimed_archive_git_blob: ba4ddfa57771ce747c365dfa04998fb1c18cb4b3
xz_integrity: fail
tar_extraction: not_attempted
members: 0
```

This receipt diagnoses transport only. It creates no protocol, evidence, matrix, field, row, class, ledger, publication, adoption, or graph authority.
