# Times ExplorAItion preference-custody admission

**Status:** bounded_deployment_admitted_effect_unresolved

**Real-world evidence state:** bounded_deployment_and_workflow_receipts

**Graph effect:** none

> Times ExplorAItion is a reciprocally confirmed synthetic-audience deployment with supported screening, acceleration, and supplementation uses plus one vendor-attributed bounded partial substitution. Public material does not yet preserve the real exposure, outcome, feedback, counterfactual, subgroup, standing, or version lineage required for a performative-effect, preference-change, authorization, or current-validation conclusion.

## Deployment

- Publisher: News UK / Times Media
- Product: Times ExplorAItion
- Vendor: Electric Twin
- Public launch: 2026-04-27
- Deployment state: reciprocally_confirmed_publisher_and_vendor
- Decision authority: News UK and Times teams

## Bounded workflow classification

- Screening and acceleration: supported
- Supplementation: supported
- Bounded partial substitution: vendor_claimed_for_parenting_channel_qualitative_work
- Full replacement: not_demonstrated
- Organization-wide substitution: not_demonstrated
- Automated decision authority: not_described

## Nine-control admission

### PC-01: exposure_policy_confounding

- State: unresolved
- Supported observations: 1
- Missing evidence fields: 4
- Allowed conclusion: no preference-identification conclusion from later engagement

### PC-02: option_set_starvation

- State: partial
- Supported observations: 1
- Missing evidence fields: 4
- Allowed conclusion: documented selected outputs do not identify the complete preference set

### PC-03: observational_equivalence

- State: unresolved
- Supported observations: 1
- Missing evidence fields: 4
- Allowed conclusion: behavioral fit does not identify the mechanism

### PC-04: attrition_and_refusal_censoring

- State: unresolved
- Supported observations: 0
- Missing evidence fields: 5
- Allowed conclusion: no population-support or preference-change conclusion

### PC-05: subgroup_response_capacity_and_burden

- State: unresolved
- Supported observations: 0
- Missing evidence fields: 5
- Allowed conclusion: aggregate accuracy does not identify subgroup parity or acceptable burden

### PC-06: authority_laundering_and_nonbinding_consultation

- State: not_established
- Supported observations: 2
- Missing evidence fields: 5
- Allowed conclusion: deployment evidence does not establish public authorization

### PC-07: agenda_formation_and_collective_option_generation

- State: partial
- Supported observations: 1
- Missing evidence fields: 5
- Allowed conclusion: selected creative or product outputs do not identify a public agenda

### PC-08: negotiated_package_formation_and_collective_bargaining

- State: not_established
- Supported observations: 0
- Missing evidence fields: 6
- Allowed conclusion: no collective-agreement conclusion

### PC-09: model_metric_policy_and_validation_succession

- State: partial
- Supported observations: 3
- Missing evidence fields: 6
- Allowed conclusion: vendor-reported score does not establish current deployment continuity or policy consequence validity

## Performative path

- Synthetic output informed a candidate intervention: partial_supported
- Real population exposure: unresolved
- Post-intervention outcome: unresolved
- Feedback reuse: unresolved
- Counterfactual: unresolved
- Performative effect: not_established
- Preference change: not_established

## Admission verdict

- Deployment confirmed: true
- Screening and acceleration supported: true
- Supplementation supported: true
- Bounded partial substitution vendor-claimed: true
- Full replacement demonstrated: false
- Performative effect supported: false
- Preference change supported: false
- Public authorization supported: false
- Current validation continuity supported: false

## Allowed publication claims

- Times ExplorAItion is reciprocally confirmed by publisher and vendor public materials.
- The public workflow record supports screening, acceleration, and supplementation uses.
- Electric Twin attributes one bounded compression of qualitative fieldwork to the parenting-channel workflow while stating that other inputs remained.
- Full replacement, organization-wide substitution, automated decision authority, performative effect, preference change, public authorization, collective agreement, and current validation continuity are not established by the present public packet.

## Required next evidence

- publisher-side protocol for each named decision
- complete considered and rejected option set
- attributed approval owner and decision timestamp
- real exposure assignment and eligible population
- untreated or alternate-treatment counterfactual
- post-launch outcomes by evidence class
- feedback reuse in later modeling ranking targeting or planning
- baseline retained exit complaint and nonresponse denominators
- subgroup outcomes error and burden
- deployment-specific runtime metric policy and validation lineage
- affected-public standing correction and remedy route

## Prohibited inferences

- Do not infer that News UK or Electric Twin changed audience preferences.
- Do not infer manipulation from advertiser access or pre-testing.
- Do not infer full replacement from one vendor-attributed qualitative-workflow compression.
- Do not infer public authorization from publisher or customer decision authority.
- Do not infer absence of standing correction or remedy merely because launch material does not describe it.
- Do not treat the vendor-reported 92-percent holdout result as independently reproduced or current across later runtime metric or policy changes.
- Do not create a graph hop score chain actor profile allegation or publication sentence from this packet.
