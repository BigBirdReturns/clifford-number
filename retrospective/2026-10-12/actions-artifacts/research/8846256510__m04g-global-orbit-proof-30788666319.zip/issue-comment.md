<!-- m04g-global-orbit-proof:30788666319 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/30788666319
- Head: `0aa65b5feaa9cc7a025905177f7e8732cc0e7330`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `17/24` (`0.7083`)
- Content success: `17/24` (`0.7083`)
- Metadata only: `0`
- Failed: `7`
- Healthy basins: `0/12`
- Proof SHA-256: `984626eb4711e7fe18d814f6a21c989beded3bec76a29f1986301cf9e93030cb`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 2 | 2 | 0 | 0 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
