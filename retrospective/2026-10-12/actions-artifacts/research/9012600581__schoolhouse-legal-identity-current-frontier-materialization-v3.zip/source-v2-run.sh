set -Eeuo pipefail
CARRIER_BASE='1e52a58be874538509d6c0d3c06adc12fc53cad7'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v2.yml'
SOURCE_BRANCH='agent/schoolhouse-legal-identity-current-frontier-materializer-v1'
SOURCE_HEAD='901c16b0a8f32bfe2a83c4e0d619d3168cd668ff'
SOURCE_WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v1.yml'
SOURCE_WORKFLOW_BLOB='3bf838822ea34a8d5c6b69d7af37be9969f8891f'
SOURCE_PAYLOAD='.github/materializers/schoolhouse-current-frontier-v1'
RECOVERED_PAYLOAD="$RUNNER_TEMP/schoolhouse-current-frontier-recovered-payload-v2"
SOURCE_CONTROLLER="$RUNNER_TEMP/schoolhouse-current-frontier-materializer-v1-source.sh"
PATCHED_CONTROLLER="$RUNNER_TEMP/schoolhouse-current-frontier-materializer-v2.sh"
PATCH_RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-controller-repair-v2.json"
RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v2"
SOURCE_CONTROLLER_BYTES='20456'
SOURCE_CONTROLLER_SHA256='7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd'
PATCHED_CONTROLLER_BYTES='20059'
PATCHED_CONTROLLER_SHA256='cfef9a73fc32139eae644d3089e893a336ad7dc5b5c8e83e9c767946bc822b7d'
rm -rf "$RECOVERED_PAYLOAD" "$RECEIPT"
mkdir -p "$RECOVERED_PAYLOAD" "$RECEIPT"
printf 'initializing-v2-repair\n' > "$RECEIPT/REPAIR-STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\n' > "$RECEIPT/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  mkdir -p "$RECEIPT"
  if test -f "$PATCH_RECEIPT"; then
    cp "$PATCH_RECEIPT" "$RECEIPT/controller-repair.json"
  fi
  printf '%s\n' "$rc" > "$RECEIPT/REPAIR_BOOTSTRAP_EXIT_CODE"
  (
    cd "$RECEIPT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-one-workflow-wrapper-and-source-carrier\n' > "$RECEIPT/REPAIR-STAGE"
git fetch --no-tags origin main "$SOURCE_BRANCH"
test "$(git rev-parse HEAD^)" = "$CARRIER_BASE"
test "$(git rev-list --count "$CARRIER_BASE"..HEAD)" = '1'
mapfile -t WRAPPER_PATHS < <(git diff --name-only "$CARRIER_BASE"..HEAD)
test "${#WRAPPER_PATHS[@]}" -eq 1
test "${WRAPPER_PATHS[0]}" = "$WORKFLOW"
git diff --check "$CARRIER_BASE"..HEAD
test "$(git rev-parse "origin/$SOURCE_BRANCH")" = "$SOURCE_HEAD"
test "$(git rev-parse "$SOURCE_HEAD:$SOURCE_WORKFLOW")" = "$SOURCE_WORKFLOW_BLOB"
test "$(git rev-list --count "$CARRIER_BASE".."$SOURCE_HEAD")" = '13'

cat > "$RUNNER_TEMP/expected-schoolhouse-frontier-v1-carrier-paths" <<'EOF_SOURCE_PATHS'
.github/materializers/schoolhouse-current-frontier-v1/controller-00
.github/materializers/schoolhouse-current-frontier-v1/controller-01
.github/materializers/schoolhouse-current-frontier-v1/controller-02
.github/materializers/schoolhouse-current-frontier-v1/controller-03
.github/materializers/schoolhouse-current-frontier-v1/controller-04
.github/materializers/schoolhouse-current-frontier-v1/part-00
.github/materializers/schoolhouse-current-frontier-v1/part-01
.github/materializers/schoolhouse-current-frontier-v1/part-02
.github/materializers/schoolhouse-current-frontier-v1/part-03
.github/materializers/schoolhouse-current-frontier-v1/part-04
.github/materializers/schoolhouse-current-frontier-v1/part-05
.github/materializers/schoolhouse-current-frontier-v1/part-06
.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v1.yml
EOF_SOURCE_PATHS
sort -o "$RUNNER_TEMP/expected-schoolhouse-frontier-v1-carrier-paths" \
  "$RUNNER_TEMP/expected-schoolhouse-frontier-v1-carrier-paths"
git diff --name-only "$CARRIER_BASE".."$SOURCE_HEAD" | sort \
  > "$RECEIPT/source-carrier-paths.txt"
diff -u "$RUNNER_TEMP/expected-schoolhouse-frontier-v1-carrier-paths" \
  "$RECEIPT/source-carrier-paths.txt"

printf 'recovering-and-authenticating-source-controller-and-payload\n' > "$RECEIPT/REPAIR-STAGE"
CONTROLLER_SIZES=(5000 5000 5000 5000 456)
CONTROLLER_SHA256=(
  ec8b175c1473fd9f7f7c893a495269df2dfd440e4960f9d74487d706c14060f9
  8e69b377c4a4208bded118d4b8477a9ceac6ef35e66931455816ce786a1e54e2
  f764d261b300f0062345e7df8c5a6d530455560896094b405df87520f7be618f
  79b2e68a76dc3ff0d13ec8c30cbedc8c41cbb8c5fc01cd95d94c2dbd513af2ee
  0bdb8068c48e536d5d6698be2bc58031af338bedd7cb2231148e959af4170f68
)
PAYLOAD_SIZES=(10000 10000 10000 10000 10000 10000 5880)
PAYLOAD_SHA256=(
  e932c87c3204e01fc208e6c2e3e46b86e255d42d57dadd1360e65f80269ae12b
  f814e46666d96edaf076c6d8b992310e66baa62cc58622083955e38b7752e6d2
  a2c3a61652bde254bb66dd7e27546bfd2c3bc078220aae89aa7ebbca482fda89
  55b32a2d8c045e8cb2f2eebb565b70a5a3155b84746b05ac4895438487887f2f
  ce1a3e3f3c19cd97215580d8f0fd1f7548c633828f468d0f0949a891fc8639c8
  116a5d7864e3557b40ee4a4f35c466c6e0e82b13fc14d4326841dd86e2772a04
  22a59c63b9aeea9f8a27febcaf5a0b12d34a07fc7c5340c1142825e0ec53339d
)

for index in "${!CONTROLLER_SIZES[@]}"; do
  printf -v suffix '%02d' "$index"
  path="$RECOVERED_PAYLOAD/controller-$suffix"
  git show "$SOURCE_HEAD:$SOURCE_PAYLOAD/controller-$suffix" > "$path"
  test "$(stat -c%s "$path")" = "${CONTROLLER_SIZES[$index]}"
  test "$(sha256sum "$path" | cut -d' ' -f1)" = "${CONTROLLER_SHA256[$index]}"
done
for index in "${!PAYLOAD_SIZES[@]}"; do
  printf -v suffix '%02d' "$index"
  path="$RECOVERED_PAYLOAD/part-$suffix"
  git show "$SOURCE_HEAD:$SOURCE_PAYLOAD/part-$suffix" > "$path"
  test "$(stat -c%s "$path")" = "${PAYLOAD_SIZES[$index]}"
  test "$(sha256sum "$path" | cut -d' ' -f1)" = "${PAYLOAD_SHA256[$index]}"
done
cat "$RECOVERED_PAYLOAD"/controller-{00,01,02,03,04} > "$SOURCE_CONTROLLER"
test "$(stat -c%s "$SOURCE_CONTROLLER")" = "$SOURCE_CONTROLLER_BYTES"
test "$(sha256sum "$SOURCE_CONTROLLER" | cut -d' ' -f1)" = "$SOURCE_CONTROLLER_SHA256"
bash -n "$SOURCE_CONTROLLER"

printf 'applying-seven-exact-controller-repairs\n' > "$RECEIPT/REPAIR-STAGE"
python - "$SOURCE_CONTROLLER" "$PATCHED_CONTROLLER" "$PATCH_RECEIPT" \
  "$SOURCE_HEAD" "$SOURCE_WORKFLOW_BLOB" "$WORKFLOW" "$RECOVERED_PAYLOAD" <<'PY_REPAIR'
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import sys

(
    source_path,
    output_path,
    receipt_path,
    source_head,
    source_workflow_blob,
    wrapper_workflow,
    recovered_payload,
) = sys.argv[1:]
source = Path(source_path).read_text(encoding='utf-8')
assert len(source.encode()) == 20456
assert hashlib.sha256(source.encode()).hexdigest() == (
    '7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd'
)

old_topology = '''git merge-base --is-ancestor "$CARRIER_BASE" "$BASE"
test "$(git rev-list --count "$CARRIER_BASE"..HEAD)" = '13'
cat > "$WORK/expected-carrier-paths" <<EOF_CARRIER
$WORKFLOW
$PAYLOAD/part-00
$PAYLOAD/part-01
$PAYLOAD/part-02
$PAYLOAD/part-03
$PAYLOAD/part-04
$PAYLOAD/part-05
$PAYLOAD/part-06
$PAYLOAD/controller-00
$PAYLOAD/controller-01
$PAYLOAD/controller-02
$PAYLOAD/controller-03
$PAYLOAD/controller-04
EOF_CARRIER
sort -o "$WORK/expected-carrier-paths" "$WORK/expected-carrier-paths"
git diff --name-only "$CARRIER_BASE"..HEAD | sort > "$RECEIPT/carrier-paths.txt"
diff -u "$WORK/expected-carrier-paths" "$RECEIPT/carrier-paths.txt"
git diff --check "$CARRIER_BASE"..HEAD'''
new_topology = '''git merge-base --is-ancestor "$CARRIER_BASE" "$BASE"
test "$(git rev-list --count "$CARRIER_BASE"..HEAD)" = '1'
printf '%s\\n' "$WORKFLOW" > "$WORK/expected-carrier-paths"
git diff --name-only "$CARRIER_BASE"..HEAD | sort > "$RECEIPT/carrier-paths.txt"
diff -u "$WORK/expected-carrier-paths" "$RECEIPT/carrier-paths.txt"
git diff --check "$CARRIER_BASE"..HEAD'''

replacements = [
    (
        "WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v1.yml'",
        f"WORKFLOW='{wrapper_workflow}'",
        'wrapper_workflow_path',
    ),
    (
        "PAYLOAD='.github/materializers/schoolhouse-current-frontier-v1'",
        f'PAYLOAD="{recovered_payload}"',
        'recovered_payload_path',
    ),
    (
        'WORK="$RUNNER_TEMP/schoolhouse-current-frontier-materializer-v1"',
        'WORK="$RUNNER_TEMP/schoolhouse-current-frontier-materializer-v2"',
        'work_namespace',
    ),
    (
        'RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v1"',
        'RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v2"',
        'receipt_namespace',
    ),
    (old_topology, new_topology, 'one_workflow_carrier_topology'),
    (
        'test "$(jq -r .workflow_run.head_sha "$WORK/export-metadata.json")" = "$EXPORT_HEAD"\n',
        '',
        'remove_redundant_artifact_metadata_head_assertion',
    ),
    (
        "'carrier_commit_count':13,'carrier_path_count':13",
        "'carrier_commit_count':1,'carrier_path_count':1",
        'materialization_receipt_carrier_counts',
    ),
]
repaired = source
applied = []
for old, new, name in replacements:
    count = repaired.count(old)
    assert count == 1, (name, count)
    repaired = repaired.replace(old, new)
    applied.append(name)

assert '.workflow_run.head_sha' not in repaired
assert repaired.count(wrapper_workflow) == 1
assert repaired.count(recovered_payload) == 1
assert len(repaired.encode()) == 20059
repaired_sha256 = hashlib.sha256(repaired.encode()).hexdigest()
assert repaired_sha256 == 'cfef9a73fc32139eae644d3089e893a336ad7dc5b5c8e83e9c767946bc822b7d'
Path(output_path).write_text(repaired, encoding='utf-8')
Path(output_path).chmod(0o755)
value = {
    'schema_version': 'schoolhouse-current-frontier-controller-repair@2',
    'state': 'complete',
    'source_head': source_head,
    'source_workflow_blob': source_workflow_blob,
    'source_controller_bytes': 20456,
    'source_controller_sha256': '7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd',
    'repaired_controller_bytes': 20059,
    'repaired_controller_sha256': repaired_sha256,
    'exact_repairs': applied,
    'repair_count': len(applied),
    'product_payload_changes': 0,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
Path(receipt_path).write_text(
    json.dumps(value, indent=2, sort_keys=True) + '\n',
    encoding='utf-8',
)
print('controller_repair=pass exact_repairs=7 product_payload_changes=0')
PY_REPAIR
test "$(stat -c%s "$PATCHED_CONTROLLER")" = "$PATCHED_CONTROLLER_BYTES"
test "$(sha256sum "$PATCHED_CONTROLLER" | cut -d' ' -f1)" = "$PATCHED_CONTROLLER_SHA256"
bash -n "$PATCHED_CONTROLLER"

printf 'executing-repaired-materializer\n' > "$RECEIPT/REPAIR-STAGE"
bash "$PATCHED_CONTROLLER"
printf 'complete\n' > "$RECEIPT/REPAIR-STAGE"

