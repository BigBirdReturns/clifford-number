<!-- m04g-global-orbit-proof:31469945957 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31469945957
- Head: `9510310129c3aab44f8b5b187430a3ede005b7b4`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `16/25` (`0.64`)
- Content success: `14/25` (`0.56`)
- Metadata only: `2`
- Failed: `9`
- Healthy basins: `0/5`
- Proof SHA-256: `7ca740bb3d83783e5161a01525fada2ea236aba108c99c7a9b3ea4dd497b0433`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G07-MENA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 3 | 3 | 0 | 2 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
