# RD-04 North Dakota fixed-protocol candidate validation

Two exact candidates validate against the two still-open cells. The separate projected product performs one field terminalization, one row terminalization, two matrix updates, and one row-state mutation. This carrier applies none of them and authorizes no request.
