#!/usr/bin/env bash
set -Eeuo pipefail

OUT=/tmp/ssc-rd04-five-state-promotion-current-main-materializer-v3
WORKTREE=/tmp/ssc-rd04-five-state-promotion-current-main-worktree-v2
PRODUCT=/tmp/ssc-rd04-five-state-promotion-current-main-product-v2
CHUNKS="$OUT/chunks"
rm -rf "$OUT" "$WORKTREE" "$PRODUCT"
mkdir -p "$OUT" "$PRODUCT" "$CHUNKS"
trap 'status=$?; printf "exit_code=%s\nfailure_line=%s\nfailure_command=%s\n" "$status" "${BASH_LINENO[0]:-unknown}" "${BASH_COMMAND:-unknown}" > "$OUT/failure.txt"; exit "$status"' ERR
exec > >(tee "$OUT/materialization.log") 2>&1

: "${CURRENT_PARENT:?}"
: "${OLD_PRODUCT_PARENT:?}"
: "${SOURCE_BRANCH:?}"
: "${SOURCE_COMMIT:?}"
: "${PRODUCT_BRANCH:?}"
: "${CARRIER_PATH:?}"
: "${ARCHIVE_BYTES:?}"
: "${ARCHIVE_SHA256:?}"
: "${CARRIER_HEAD:?}"
: "${GITHUB_REPOSITORY:?}"
: "${GITHUB_RUN_ID:?}"

printf '%s\n' bind-exact-carrier > "$OUT/current-gate.txt"
test "$(git rev-parse HEAD)" = "$CARRIER_HEAD"
test "$(git rev-parse HEAD^)" = "$CURRENT_PARENT"
test "$(git rev-list --count "$CURRENT_PARENT"..HEAD)" = 1
test "$(git diff --name-only "$CURRENT_PARENT" HEAD)" = "$CARRIER_PATH"
git diff --check "$CURRENT_PARENT" HEAD

git fetch --force --no-tags origin \
  "refs/heads/main:refs/remotes/origin/main" \
  "refs/heads/$SOURCE_BRANCH:refs/remotes/origin/$SOURCE_BRANCH"
test "$(git rev-parse refs/remotes/origin/main)" = "$CURRENT_PARENT"
test "$(git rev-parse refs/remotes/origin/$SOURCE_BRANCH)" = "$SOURCE_COMMIT"
git merge-base --is-ancestor "$OLD_PRODUCT_PARENT" "$CURRENT_PARENT"
if git ls-remote --exit-code --heads origin "$PRODUCT_BRANCH" >/dev/null 2>&1; then
  echo "product branch already exists: $PRODUCT_BRANCH" >&2
  exit 1
fi

cat > "$OUT/chunk-paths.txt" <<'EOF'
.tmp/ssc-rd04-five-state-promotion-materializer/payload-00.b64
.tmp/ssc-rd04-five-state-promotion-materializer/payload-01.b64
.tmp/ssc-rd04-five-state-promotion-materializer/payload-02.b64
.tmp/ssc-rd04-five-state-promotion-materializer/payload-03.b64
.tmp/ssc-rd04-five-state-promotion-materializer/payload-04.b64
EOF
cat > "$OUT/chunk-sha256.txt" <<'EOF'
d3e7ee9c26dfe557ec08458a7b9fc284f07de0cb8bf5095aee6edc9e0bdc309b  chunks/payload-00.b64
a80195e6feb31bee4202e6b1fa9cc45ab28d79061957a61ccfd5a5fedfe7a6a6  chunks/payload-01.b64
949cc89ba9a35fff63283a5ebc010262b8cf36694a5effea02d59d221d4c9af1  chunks/payload-02.b64
d9a450cc508cbe6eda74b078972d1b90e391bf1d592492668197f143a98087da  chunks/payload-03.b64
a3d2630960e55c8f2f27114c22d1dd4be7ca70c02b44f4a36428e93b76f8a6a3  chunks/payload-04.b64
EOF

printf '%s\n' reconstruct-exact-product > "$OUT/current-gate.txt"
while IFS= read -r path; do
  git show "$SOURCE_COMMIT:$path" > "$CHUNKS/$(basename "$path")"
done < "$OUT/chunk-paths.txt"
(cd "$OUT" && sha256sum -c chunk-sha256.txt)
cat "$CHUNKS"/payload-*.b64 | base64 -d > "$OUT/product.tar.xz"
test "$(stat -c %s "$OUT/product.tar.xz")" = "$ARCHIVE_BYTES"
test "$(sha256sum "$OUT/product.tar.xz" | awk '{print $1}')" = "$ARCHIVE_SHA256"
xz -t "$OUT/product.tar.xz"
tar -xJf "$OUT/product.tar.xz" -C "$PRODUCT"

cat > "$OUT/product-paths.txt" <<'EOF'
.github/workflows/status-sovereignty-rd-wave03-rd04-five-state-promotion.yml
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/cell-promotion-ledger.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/index.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/product-manifest.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promoted-partial-field-matrix.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-decisions.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-input-custody.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-summary.json
data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/remaining-open-field-census.json
docs/milestones/ssc-rd-wave03-rd04-five-state-promotion.md
schemas/status-sovereignty-rd-wave03-rd04-five-state-promotion.schema.json
test/status-sovereignty-rd-wave03-rd04-five-state-promotion.test.js
tools/build-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
EOF
cat > "$OUT/product-sha256.txt" <<'EOF'
4313cd204c0159a1fbbee09829a88621908f0a517f7472aea9a72924e572fd77  .github/workflows/status-sovereignty-rd-wave03-rd04-five-state-promotion.yml
9c8785b51a3c753d593fa07ea9aef49de7534fbec305c2b785e53ec1e97303b0  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/cell-promotion-ledger.json
7c76c7782dc118f8e94500a5eeca08c95d411c467dd2e251b6024e21baf1f33d  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/index.json
516806153ddca774b695a85f162bd18134e5f5d722a7b34a23384141ae25fe27  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/product-manifest.json
46885a3fedfabb0fb6154500982d8234dc4fa67834f8d000f5749ec15914705c  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promoted-partial-field-matrix.json
df55121a68fe602488be77b87359533749e3ccefc20c20802081f3b60eb3a107  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-decisions.json
bef82827ba54e4edcc5c3676abf32fa2ef91171bd02e23c8dcfa16b556e5f5db  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-input-custody.json
89cef0ab5aeafdcf12fa12fce00c4e819be0ba9e1f6b1f1a6a26ad56c50c34c9  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/promotion-summary.json
ce1581ad8d8e7f0f9fbdb02b4e7510d6b7505825d91c4d97c08b60d9c8ac7ad0  data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion/remaining-open-field-census.json
f51043a4d647e8575b3e841da64fdd37866ea8407b24662c8d7555267031f43f  docs/milestones/ssc-rd-wave03-rd04-five-state-promotion.md
ab80ff2eae1d283c089743d977712d78907f9104b557b5ce72dc43f355ac8809  schemas/status-sovereignty-rd-wave03-rd04-five-state-promotion.schema.json
8bf490d4cf6cef3379e48919ceb62f7b0a0994d1de031d7c106078172b1d4d23  test/status-sovereignty-rd-wave03-rd04-five-state-promotion.test.js
db53d0ca1b5bcba07eccd5b0979a38d87e81a0e307d3fd62259f41da617749ff  tools/build-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
d5d7f573cf3a14c505b30b73cd2664b0e2db235213c0a137e90b6af8a8817ba8  tools/validate-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
EOF

printf '%s\n' verify-product-and-current-main-disjointness > "$OUT/current-gate.txt"
(cd "$PRODUCT" && find . -type f -printf '%P\n' | LC_ALL=C sort) > "$OUT/actual-product-paths.txt"
diff -u "$OUT/product-paths.txt" "$OUT/actual-product-paths.txt"
(cd "$PRODUCT" && sha256sum -c "$OUT/product-sha256.txt")
while IFS= read -r path; do
  ! git cat-file -e "$CURRENT_PARENT:$path" 2>/dev/null
done < "$OUT/product-paths.txt"
git diff --name-only "$OLD_PRODUCT_PARENT" "$CURRENT_PARENT" | LC_ALL=C sort > "$OUT/current-main-drift-paths.txt"
comm -12 "$OUT/product-paths.txt" "$OUT/current-main-drift-paths.txt" > "$OUT/current-main-overlap.txt"
test ! -s "$OUT/current-main-overlap.txt"

printf '%s\n' qualify-product > "$OUT/current-gate.txt"
git worktree add --detach "$WORKTREE" "$CURRENT_PARENT"
cp -a "$PRODUCT"/. "$WORKTREE"/
cd "$WORKTREE"
node --check tools/build-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
node --check tools/validate-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
node --check test/status-sovereignty-rd-wave03-rd04-five-state-promotion.test.js
node tools/build-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
sha256sum -c "$OUT/product-sha256.txt"
python -m pip install --disable-pip-version-check --quiet jsonschema==4.25.1
python - <<'PY'
import json
from pathlib import Path
from jsonschema import Draft202012Validator
schema = json.loads(Path('schemas/status-sovereignty-rd-wave03-rd04-five-state-promotion.schema.json').read_text())
validator = Draft202012Validator(schema)
root = Path('data/intake/status-sovereignty-rd-wave03-rd04-five-state-promotion')
paths = sorted(root.glob('*.json'))
assert len(paths) == 8, len(paths)
for path in paths:
    errors = sorted(validator.iter_errors(json.loads(path.read_text())), key=lambda error: list(error.path))
    if errors:
        raise SystemExit(f'{path}: {errors[0].message} at {list(errors[0].path)}')
print('recursive_schema_validation=pass objects=8')
PY
node tools/validate-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs | tee "$OUT/product-validator.log"
node test/status-sovereignty-rd-wave03-rd04-five-state-promotion.test.js | tee "$OUT/product-adversarial.log"
node tools/validate-no-magic-human-gate.mjs | tee "$OUT/no-magic-human-validator.log"
node test/no-magic-human-gate.test.js | tee "$OUT/no-magic-human-adversarial.log"
npm run release:check | tee "$OUT/release-check.log"
node tools/build-status-sovereignty-rd-wave03-rd04-five-state-promotion.mjs
sha256sum -c "$OUT/product-sha256.txt"

printf '%s\n' create-exact-candidate > "$OUT/current-gate.txt"
git add --pathspec-from-file="$OUT/product-paths.txt"
git diff --cached --name-only | LC_ALL=C sort > "$OUT/staged-paths.txt"
diff -u "$OUT/product-paths.txt" "$OUT/staged-paths.txt"
test "$(git diff --cached --name-only | wc -l | tr -d ' ')" = 14
test -z "$(git diff --cached --diff-filter=MD --name-only)"
test "$(git diff --cached --name-status | awk '$1 != "A" {print}' | wc -l | tr -d ' ')" = 0
TREE=$(git write-tree)
export GIT_AUTHOR_NAME='github-actions[bot]'
export GIT_AUTHOR_EMAIL='41898282+github-actions[bot]@users.noreply.github.com'
export GIT_COMMITTER_NAME="$GIT_AUTHOR_NAME"
export GIT_COMMITTER_EMAIL="$GIT_AUTHOR_EMAIL"
export GIT_AUTHOR_DATE='2026-08-08T03:42:15Z'
export GIT_COMMITTER_DATE="$GIT_AUTHOR_DATE"
COMMIT=$(printf '%s\n' 'Promote exact RD-04 five-state bounded findings' | git commit-tree "$TREE" -p "$CURRENT_PARENT")
test "$(git rev-parse "$COMMIT^")" = "$CURRENT_PARENT"
git diff --name-only "$CURRENT_PARENT" "$COMMIT" | LC_ALL=C sort > "$OUT/candidate-paths.txt"
diff -u "$OUT/product-paths.txt" "$OUT/candidate-paths.txt"
test -z "$(git diff --diff-filter=MD --name-only "$CURRENT_PARENT" "$COMMIT")"
git push origin "$COMMIT:refs/heads/$PRODUCT_BRANCH"
test "$(git ls-remote --heads origin "$PRODUCT_BRANCH" | awk '{print $1}')" = "$COMMIT"

printf '%s\n' complete > "$OUT/current-gate.txt"
export TREE COMMIT
python - <<'PY'
import hashlib, json, os
from pathlib import Path
out = Path('/tmp/ssc-rd04-five-state-promotion-current-main-materializer-v3')
receipt = {
  'schema_version': 'ssc-rd04-five-state-promotion-current-main-materialization@3',
  'state': 'complete',
  'workflow_run': int(os.environ['GITHUB_RUN_ID']),
  'carrier_head': os.environ['CARRIER_HEAD'],
  'canonical_parent': os.environ['CURRENT_PARENT'],
  'old_product_parent': os.environ['OLD_PRODUCT_PARENT'],
  'source_branch': os.environ['SOURCE_BRANCH'],
  'source_commit': os.environ['SOURCE_COMMIT'],
  'archive_bytes': int(os.environ['ARCHIVE_BYTES']),
  'archive_sha256': os.environ['ARCHIVE_SHA256'],
  'product_branch': os.environ['PRODUCT_BRANCH'],
  'product_commit': os.environ['COMMIT'],
  'product_tree': os.environ['TREE'],
  'permanent_paths': 14,
  'modified_paths': 0,
  'deleted_paths': 0,
  'terminal_cells_before': 218,
  'terminal_cells_after': 222,
  'still_open_cells_after': 228,
  'terminal_substantive_cells_after': 112,
  'still_open_substantive_cells_after': 188,
  'terminal_units_after': 10,
  'open_units_after': 40,
  'field_terminalizations': 4,
  'row_state_mutations': 0,
  'class_closed': False,
  'cumulative_ledger_effect': 'none',
  'source_requests': 0,
  'outside_human_dependency': False,
  'publication_effect': 'none',
  'adoption_effect': 'none',
  'graph_effect': 'none',
  'complete_release_gate': 'pass',
  'clean_replay': 'pass',
}
payload = json.dumps(receipt, indent=2, sort_keys=True) + '\n'
(out / 'receipt.json').write_text(payload)
(out / 'receipt.sha256').write_text(hashlib.sha256(payload.encode()).hexdigest() + '  receipt.json\n')
PY
find "$OUT" -maxdepth 1 -type f ! -name SHA256SUMS -printf '%f\n' | LC_ALL=C sort | while IFS= read -r name; do
  sha256sum "$OUT/$name"
done | sed "s#  $OUT/#  #" > "$OUT/SHA256SUMS"
(cd "$OUT" && sha256sum -c SHA256SUMS)
