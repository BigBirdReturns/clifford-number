# RD-04 North Dakota FY 2025 response anchor adjudication

- State: `North Dakota`
- Anchor: `FY 2025 Waiver - FNA Response (.pdf)`
- Displayed date: `6/18/2025`
- Exact href: `/sites/default/files/resource-files/nd-abawd-response-fy2025.pdf`
- Resolved URL: `https://www.fna.usda.gov/sites/default/files/resource-files/nd-abawd-response-fy2025.pdf`
- Source role: official response-index locator only
- Field disposition: hold open until the exact PDF is captured and reviewed page-completely
- Source requests in this adjudication: 0
- Matrix updates: 0
