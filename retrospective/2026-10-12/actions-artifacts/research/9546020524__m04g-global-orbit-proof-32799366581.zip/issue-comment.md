<!-- m04g-global-orbit-proof:32799366581 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32799366581
- Head: `cbae0350ff0433578f9f9cf41cbdcfa7d620f02d`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `4/4`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `8/20` (`0.4`)
- Content success: `7/20` (`0.35`)
- Metadata only: `1`
- Failed: `12`
- Healthy basins: `0/4`
- Proof SHA-256: `9f7e8c357a79e00b4aa3232be5b8e18116fb4dd4160661065f57904d6f17dc3c`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G09-SOUTH-ASIA` | 5 | 1 | 0 | 1 | 4 | `false` |
| `G10-EAST-ASIA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G11-SOUTHEAST-ASIA` | 5 | 3 | 3 | 0 | 2 | `false` |
| `G12-OCEANIA-PACIFIC` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
