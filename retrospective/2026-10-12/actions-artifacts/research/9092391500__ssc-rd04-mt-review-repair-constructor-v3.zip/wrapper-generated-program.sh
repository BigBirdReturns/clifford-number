export CANONICAL_PARENT=0840358962621b0be3db6864ecec763327f35903
export CANONICAL_PARENT_TREE=38023f86bcc27527f9db8da9622bada00b3de542
export SOURCE_PRODUCT=85fad4f736a3639444edd2c522a67316dbade480
export SOURCE_PRODUCT_TREE=5a27b91e3ce26f2435cb2df16915062f2c5d1801
export CARRIER_HEAD=ef73e44017cb95569b7876a37cb2bc3b4ef90e45
export CARRIER_BRANCH=agent/ssc-rd04-mt-promotion-review-repair-materializer-v1
export CARRIER_ROOT=.tmp/rd04-mt-promotion-review-repair-v1
export REPAIRED_WORKFLOW_XZ_SHA256=b22dab603a46888c581ccedda7a616995298e9155f290a87707893a4195ae2ba
export REPAIRED_WORKFLOW_SHA256=05caa14cb4fe6fa094f6cd24a636188db37f3702fadad601c14d5494727800d4
export PRODUCT_ROOT=data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation
export PRODUCT_WORKFLOW=.github/workflows/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.yml
export SCHEMA_PATH=schemas/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.schema.json
export MANIFEST_PATH=data/intake/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation/product-manifest.json
export PRODUCT_AUTHOR_NAME=github-actions\[bot\]
export PRODUCT_AUTHOR_EMAIL=41898282+github-actions\[bot\]@users.noreply.github.com
export PRODUCT_AUTHOR_DATE=2026-08-11T04:00:00+00:00
export PRODUCT_COMMITTER_NAME=github-actions\[bot\]
export PRODUCT_COMMITTER_EMAIL=41898282+github-actions\[bot\]@users.noreply.github.com
export PRODUCT_COMMITTER_DATE=2026-08-11T04:00:00+00:00
export PRODUCT_MESSAGE=Repair\ Montana\ promotion\ exact-object\ and\ schema\ admission
export OUT=/tmp/rd04-mt-review-repair-constructor-v3
export WORK=/tmp/rd04-mt-review-repair-constructor-v3-work
set -Eeuo pipefail
rm -rf "$OUT" "$WORK"
mkdir -p "$OUT" "$WORK"
printf '%s\n' authenticate > "$OUT/STAGE"

fail_closed() {
  rc=$?
  export FAILURE_RC="$rc"
  export FAILURE_LINE="${BASH_LINENO[0]:-0}"
  export FAILURE_COMMAND="${BASH_COMMAND:-unknown}"
  mkdir -p "$OUT"
  python - <<'PY' || true
import json, os
from pathlib import Path
out = Path(os.environ['OUT'])
stage = (out / 'STAGE').read_text().strip() if (out / 'STAGE').exists() else 'unknown'
(out / 'failure.json').write_text(json.dumps({
    'state': 'failed_closed',
    'stage': stage,
    'exit_code': int(os.environ.get('FAILURE_RC', '1')),
    'line': int(os.environ.get('FAILURE_LINE', '0')),
    'command': os.environ.get('FAILURE_COMMAND', 'unknown'),
    'canonical_parent': os.environ['CANONICAL_PARENT'],
    'source_product': os.environ['SOURCE_PRODUCT'],
    'carrier_head': os.environ['CARRIER_HEAD'],
    'source_requests': 0,
    'route_executions': 0,
    'remote_ref_updates': 0,
    'canonical_effects': 0,
}, indent=2) + '\n')
PY
  (cd "$OUT" && find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS) || true
  exit "$rc"
}
trap fail_closed ERR

HEAD_SHA=74d4e9bdb338bc1d2a5c7e922e5196dfb1df9aed
BASE_SHA=9510310129c3aab44f8b5b187430a3ede005b7b4
test "$(git rev-parse HEAD)" = "$HEAD_SHA"
git fetch --no-tags --force origin '+refs/heads/main:refs/remotes/origin/main'
test "$(git rev-parse refs/remotes/origin/main)" = "$BASE_SHA"
git merge-base --is-ancestor "$CANONICAL_PARENT" "$BASE_SHA"
test "$(git rev-parse "$CANONICAL_PARENT^{tree}")" = "$CANONICAL_PARENT_TREE"
test "$(git show -s --format='%P' "$SOURCE_PRODUCT")" = "$CANONICAL_PARENT"
test "$(git rev-parse "$SOURCE_PRODUCT^{tree}")" = "$SOURCE_PRODUCT_TREE"
git fetch --no-tags --force origin "+refs/heads/$CARRIER_BRANCH:refs/remotes/origin/$CARRIER_BRANCH"
test "$(git rev-parse "refs/remotes/origin/$CARRIER_BRANCH")" = "$CARRIER_HEAD"

git show "$CARRIER_HEAD:$CARRIER_ROOT/repaired-workflow.xz.b64" > /tmp/repaired-workflow.xz.b64
base64 -d /tmp/repaired-workflow.xz.b64 > /tmp/repaired-workflow.xz
test "$(sha256sum /tmp/repaired-workflow.xz | cut -d' ' -f1)" = "$REPAIRED_WORKFLOW_XZ_SHA256"
xz -t /tmp/repaired-workflow.xz
xz -dc /tmp/repaired-workflow.xz > /tmp/repaired-workflow.yml
test "$(sha256sum /tmp/repaired-workflow.yml | cut -d' ' -f1)" = "$REPAIRED_WORKFLOW_SHA256"
ruby -e "require 'yaml'; YAML.load_file(ARGV.fetch(0)); puts 'yaml_ok'" /tmp/repaired-workflow.yml > "$OUT/repaired-workflow-yaml.txt"

printf '%s\n' reconstruct > "$OUT/STAGE"
git worktree add --detach "$WORK/repo" "$CANONICAL_PARENT"
cd "$WORK/repo"
mapfile -t PATHS < <(git show "$SOURCE_PRODUCT:$MANIFEST_PATH" | jq -r '.permanent_paths[]')
test "${#PATHS[@]}" = 14
test "$(printf '%s\n' "${PATHS[@]}" | LC_ALL=C sort -u | wc -l | tr -d ' ')" = 14
git checkout "$SOURCE_PRODUCT" -- "${PATHS[@]}"
cp /tmp/repaired-workflow.yml "$PRODUCT_WORKFLOW"

python - <<'PY'
from __future__ import annotations
import hashlib, json, os
from pathlib import Path

root = Path.cwd()
schema_path = root / os.environ['SCHEMA_PATH']
manifest_path = root / os.environ['MANIFEST_PATH']
product_root = root / os.environ['PRODUCT_ROOT']
schema = json.loads(schema_path.read_text(encoding='utf-8'))
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
docs = {
    'inputCustody': json.loads((product_root / 'input-custody.json').read_text()),
    'rowStateDecision': json.loads((product_root / 'row-state-decision.json').read_text()),
    'rowStateLedger': json.loads((product_root / 'row-state-ledger.json').read_text()),
    'promotedMatrix': json.loads((product_root / 'promoted-partial-field-matrix.json').read_text()),
    'remainingOpenCensus': json.loads((product_root / 'remaining-open-field-census.json').read_text()),
    'rowStateSummary': json.loads((product_root / 'row-state-summary.json').read_text()),
    'productIndex': json.loads((product_root / 'index.json').read_text()),
}

def kind(value):
    if value is None: return 'null'
    if isinstance(value, bool): return 'boolean'
    if isinstance(value, int) and not isinstance(value, bool): return 'integer'
    if isinstance(value, float): return 'number'
    if isinstance(value, str): return 'string'
    if isinstance(value, list): return 'array'
    if isinstance(value, dict): return 'object'
    raise TypeError(type(value))

def infer_many(values):
    if not values:
        return {'type': 'null'}
    groups = {}
    for value in values:
        groups.setdefault(kind(value), []).append(value)
    if len(groups) > 1:
        return {'anyOf': [infer_many(group) for _, group in sorted(groups.items())]}
    value_type = next(iter(groups))
    typed_values = groups[value_type]
    if value_type == 'object':
        all_keys = sorted(set().union(*(value.keys() for value in typed_values)))
        required = [key for key in all_keys if all(key in value for value in typed_values)]
        properties = {key: infer_many([value[key] for value in typed_values if key in value]) for key in all_keys}
        return {'type': 'object', 'additionalProperties': False, 'required': required, 'properties': properties}
    if value_type == 'array':
        lengths = [len(value) for value in typed_values]
        output = {'type': 'array', 'minItems': min(lengths), 'maxItems': max(lengths)}
        if len(typed_values) == 1 and 0 < len(typed_values[0]) <= 32 and all(kind(item) not in ('array', 'object') for item in typed_values[0]):
            output['prefixItems'] = [infer_many([item]) for item in typed_values[0]]
            output['items'] = False
            return output
        flattened = [item for value in typed_values for item in value]
        output['items'] = infer_many(flattened) if flattened else False
        return output
    unique = []
    seen = set()
    for value in typed_values:
        key = json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)
        if key not in seen:
            seen.add(key)
            unique.append(value)
    if len(unique) == 1:
        return {'const': unique[0]}
    if len(unique) <= 64 and sum(len(json.dumps(value, ensure_ascii=False)) for value in unique) <= 8192:
        return {'type': value_type, 'enum': unique}
    return {'type': value_type}

for definition, value in docs.items():
    schema['$defs'][definition] = infer_many([value])

hashed_paths = [row['path'] for row in manifest['hashed_files']]
expected_hashed_paths = [path for path in manifest['permanent_paths'] if path != os.environ['MANIFEST_PATH']]
if hashed_paths != expected_hashed_paths:
    raise SystemExit('source manifest hashed-file order is not the permanent-path order')
schema['$defs']['productManifest'] = {
    'type': 'object',
    'additionalProperties': False,
    'required': [
        'schema_version', 'permanent_path_count', 'hashed_file_count',
        'permanent_paths', 'hashed_files', 'combined_sha256', 'authority_boundary'
    ],
    'properties': {
        'schema_version': {'const': 'ssc-rd04-mt-row-state-reconciliation-manifest@1'},
        'permanent_path_count': {'const': 14},
        'hashed_file_count': {'const': 13},
        'permanent_paths': {
            'type': 'array', 'minItems': 14, 'maxItems': 14,
            'prefixItems': [{'const': path} for path in manifest['permanent_paths']],
            'items': False,
        },
        'hashed_files': {
            'type': 'array', 'minItems': 13, 'maxItems': 13,
            'prefixItems': [
                {
                    'type': 'object',
                    'additionalProperties': False,
                    'required': ['path', 'bytes', 'sha256', 'git_blob'],
                    'properties': {
                        'path': {'const': path},
                        'bytes': {'type': 'integer', 'minimum': 1},
                        'sha256': {'$ref': '#/$defs/sha256'},
                        'git_blob': {'$ref': '#/$defs/gitBlob'},
                    },
                }
                for path in hashed_paths
            ],
            'items': False,
        },
        'combined_sha256': {'$ref': '#/$defs/sha256'},
        'authority_boundary': {'$ref': '#/$defs/authorityBoundary'},
    },
}

def empty_nodes(value, path='$', inside_const=False):
    rows = []
    if isinstance(value, dict):
        if not value and not inside_const:
            rows.append(path)
        for key, child in value.items():
            rows.extend(empty_nodes(child, f'{path}.{key}', inside_const or key == 'const'))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(empty_nodes(child, f'{path}[{index}]', inside_const))
    return rows

empties = empty_nodes(schema)
if empties:
    raise SystemExit('empty public schema nodes: ' + ','.join(empties[:10]))
schema_path.write_text(json.dumps(schema, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def sha256(data): return hashlib.sha256(data).hexdigest()
def git_blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
records = []
for relative in manifest['permanent_paths']:
    if relative == os.environ['MANIFEST_PATH']:
        continue
    data = (root / relative).read_bytes()
    records.append({'path': relative, 'bytes': len(data), 'sha256': sha256(data), 'git_blob': git_blob(data)})
manifest['hashed_files'] = records
manifest['hashed_file_count'] = len(records)
joined = ''.join(sorted(f"{row['path']}\0{row['sha256']}\0{row['bytes']}\n" for row in records)).encode()
manifest['combined_sha256'] = sha256(joined)
manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
PY

test "$(git diff --name-only --diff-filter=A "$CANONICAL_PARENT" | LC_ALL=C sort)" = "$(printf '%s\n' "${PATHS[@]}" | LC_ALL=C sort)"
test -z "$(git diff --name-only --diff-filter=MDTCRUXB "$CANONICAL_PARENT")"
git diff --check "$CANONICAL_PARENT"
ruby -e "require 'yaml'; YAML.load_file(ARGV.fetch(0)); puts 'yaml_ok'" "$PRODUCT_WORKFLOW" > "$OUT/product-workflow-yaml.txt"

printf '%s\n' construct > "$OUT/STAGE"
git add -- "${PATHS[@]}"
test "$(git diff --cached --name-only --diff-filter=A "$CANONICAL_PARENT" | LC_ALL=C sort)" = "$(printf '%s\n' "${PATHS[@]}" | LC_ALL=C sort)"
test -z "$(git diff --cached --name-only --diff-filter=MDTCRUXB "$CANONICAL_PARENT")"
git config user.name "$PRODUCT_COMMITTER_NAME"
git config user.email "$PRODUCT_COMMITTER_EMAIL"
GIT_AUTHOR_NAME="$PRODUCT_AUTHOR_NAME" \
GIT_AUTHOR_EMAIL="$PRODUCT_AUTHOR_EMAIL" \
GIT_AUTHOR_DATE="$PRODUCT_AUTHOR_DATE" \
GIT_COMMITTER_NAME="$PRODUCT_COMMITTER_NAME" \
GIT_COMMITTER_EMAIL="$PRODUCT_COMMITTER_EMAIL" \
GIT_COMMITTER_DATE="$PRODUCT_COMMITTER_DATE" \
  git commit -m "$PRODUCT_MESSAGE"
LOCAL_PRODUCT_COMMIT="$(git rev-parse HEAD)"
LOCAL_PRODUCT_TREE="$(git rev-parse 'HEAD^{tree}')"
test "$(git show -s --format='%P' HEAD)" = "$CANONICAL_PARENT"
test "$(git rev-list --count "$CANONICAL_PARENT"..HEAD)" = 1

printf '%s\n' qualify > "$OUT/STAGE"
node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.mjs --out "$OUT/generated" | tee "$OUT/builder.json"
for name in row-state-ledger.json promoted-partial-field-matrix.json remaining-open-field-census.json row-state-summary.json index.json; do
  cmp "$OUT/generated/$name" "$PRODUCT_ROOT/$name"
done
node tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.mjs --out "$OUT/validator.json"
node --test test/status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.test.js | tee "$OUT/adversarial.log"

python - <<'PY' > "$OUT/schema-validation.txt"
import copy, json, os
from pathlib import Path
from jsonschema import Draft202012Validator
root = Path(os.environ['PRODUCT_ROOT'])
schema = json.load(open(os.environ['SCHEMA_PATH']))
manifest = json.load(open(root / 'product-manifest.json'))
instance = {
    'schema_version': 'ssc-rd04-mt-row-state-reconciliation-schema@1',
    'product_contract': {
        'canonical_parent': os.environ['CANONICAL_PARENT'],
        'canonical_parent_tree': os.environ['CANONICAL_PARENT_TREE'],
        'permanent_path_count': 14,
        'hashed_file_count': 13,
        'matrix_transition': {
            'predecessor_sha256': '9f9dc05a057396056771bb566c44e9c3779d8ef6b0d2c078f7ffff11d9c7e6cb',
            'promoted_sha256': '12e52344af0c8ec3d845b6f05f8a20014fa84504d10dbc9ee0674d37715abe1d',
            'changed_rows': 1,
            'changed_cells': 1,
            'substantive_cells_changed': 0,
            'terminal_units_before': 11,
            'terminal_units_after': 12,
            'class_closed': False,
        },
        'authority_boundary': manifest['authority_boundary'],
    },
    'document_schemas': {
        'input_custody': json.load(open(root / 'input-custody.json')),
        'row_state_decision': json.load(open(root / 'row-state-decision.json')),
        'row_state_ledger': json.load(open(root / 'row-state-ledger.json')),
        'promoted_matrix': json.load(open(root / 'promoted-partial-field-matrix.json')),
        'remaining_open_census': json.load(open(root / 'remaining-open-field-census.json')),
        'row_state_summary': json.load(open(root / 'row-state-summary.json')),
        'index': json.load(open(root / 'index.json')),
        'product_manifest': manifest,
    },
}
Draft202012Validator.check_schema(schema)
validator = Draft202012Validator(schema)
validator.validate(instance)
def reject(label, mutate):
    candidate = copy.deepcopy(instance)
    mutate(candidate)
    if not list(validator.iter_errors(candidate)):
        raise AssertionError(f'public schema accepted {label}')
reject('corrupt ledger mutation count', lambda x: x['document_schemas']['row_state_ledger'].__setitem__('row_state_mutation_count', 'corrupt'))
reject('null ledger transition', lambda x: x['document_schemas']['row_state_ledger'].__setitem__('transition', None))
reject('altered matrix row state', lambda x: x['document_schemas']['promoted_matrix']['rows'][25].__setitem__('row_state', 'corrupt'))
reject('mistyped matrix counts', lambda x: x['document_schemas']['promoted_matrix']['counts'].__setitem__('terminal_cells', '230'))
reject('altered census count', lambda x: x['document_schemas']['remaining_open_census'].__setitem__('open_cell_count', 219))
reject('altered census cell ordinal', lambda x: x['document_schemas']['remaining_open_census']['open_cells'][0].__setitem__('field_ordinal', 'corrupt'))
reject('altered summary units', lambda x: x['document_schemas']['row_state_summary']['counts'].__setitem__('terminal_units', 13))
reject('null summary counts', lambda x: x['document_schemas']['row_state_summary'].__setitem__('counts', None))
reject('altered index effects', lambda x: x['document_schemas']['index']['counts'].__setitem__('substantive_field_terminalizations', 1))
reject('duplicate manifest path', lambda x: x['document_schemas']['product_manifest']['hashed_files'][0].__setitem__('path', x['document_schemas']['product_manifest']['hashed_files'][1]['path']))
def empty_nodes(value, path='$', inside_const=False):
    rows = []
    if isinstance(value, dict):
        if not value and not inside_const:
            rows.append(path)
        for key, child in value.items():
            rows.extend(empty_nodes(child, f'{path}.{key}', inside_const or key == 'const'))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            rows.extend(empty_nodes(child, f'{path}[{index}]', inside_const))
    return rows
empties = empty_nodes(schema)
if empties:
    raise AssertionError(f'empty public schema nodes: {empties[:10]}')
print('draft_2020_12_schema_and_all_eight_documents_ok negative_refusals=10 empty_schema_nodes=0 manifest_paths_exact=13')
PY

npm run release:check > "$OUT/release-check.log" 2>&1
git reset --hard "$LOCAL_PRODUCT_COMMIT"
git clean -fdx
test -z "$(git status --porcelain)"
node tools/build-status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.mjs --check > "$OUT/post-release-builder.json"
node tools/validate-status-sovereignty-rd-wave03-rd04-postpromotion-mt-row-state-reconciliation.mjs --out "$OUT/post-release-validator.json"
cmp "$OUT/validator.json" "$OUT/post-release-validator.json"

printf '%s\n' archive-qualified-local-object > "$OUT/STAGE"
export LOCAL_PRODUCT_COMMIT LOCAL_PRODUCT_TREE HEAD_SHA BASE_SHA
mkdir -p "$OUT/product"
git archive --format=tar HEAD "${PATHS[@]}" | tar -xf - -C "$OUT/product"
printf '%s\n' "${PATHS[@]}" > "$OUT/product-paths.txt"
git show -s --format='%H%n%P%n%T%n%an%n%ae%n%aI%n%cn%n%ce%n%cI%n%B' HEAD > "$OUT/local-product-commit.txt"
git cat-file -p "$LOCAL_PRODUCT_COMMIT" > "$OUT/local-product-commit-object.txt"
python - <<'PY'
import hashlib, json, os
from pathlib import Path

root = Path.cwd()
out = Path(os.environ['OUT'])
manifest = json.load(open(os.environ['MANIFEST_PATH']))
receipt = {
    'state': 'qualified_local_product_object_built',
    'canonical_parent': os.environ['CANONICAL_PARENT'],
    'canonical_parent_tree': os.environ['CANONICAL_PARENT_TREE'],
    'source_product': os.environ['SOURCE_PRODUCT'],
    'carrier_head': os.environ['CARRIER_HEAD'],
    'materializer_head': os.environ['HEAD_SHA'],
    'live_main_at_construction': os.environ['BASE_SHA'],
    'local_product_commit': os.environ['LOCAL_PRODUCT_COMMIT'],
    'product_tree': os.environ['LOCAL_PRODUCT_TREE'],
    'workflow_sha256': hashlib.sha256((root / os.environ['PRODUCT_WORKFLOW']).read_bytes()).hexdigest(),
    'schema_sha256': hashlib.sha256((root / os.environ['SCHEMA_PATH']).read_bytes()).hexdigest(),
    'manifest_sha256': hashlib.sha256((root / os.environ['MANIFEST_PATH']).read_bytes()).hexdigest(),
    'combined_sha256': manifest['combined_sha256'],
    'permanent_path_count': len(manifest['permanent_paths']),
    'hashed_file_count': len(manifest['hashed_files']),
    'schema_negative_refusals': 10,
    'empty_schema_nodes': 0,
    'manifest_paths_exact': 13,
    'remote_ref_updates': 0,
    'source_requests': 0,
    'route_executions': 0,
    'canonical_effects': 0,
    'outside_human_dependency': False,
}
if receipt['permanent_path_count'] != 14 or receipt['hashed_file_count'] != 13:
    raise SystemExit('qualified product denominator drift')
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
PY
printf '%s\n' complete > "$OUT/STAGE"
(cd "$OUT" && find . -type f ! -name SHA256SUMS -print0 | LC_ALL=C sort -z | xargs -0 sha256sum > SHA256SUMS && sha256sum -c SHA256SUMS)
