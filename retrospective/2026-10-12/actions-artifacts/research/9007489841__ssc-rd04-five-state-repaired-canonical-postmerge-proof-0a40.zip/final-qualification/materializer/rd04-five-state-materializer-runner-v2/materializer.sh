#!/usr/bin/env bash
set -Eeuo pipefail

OUT=/tmp/rd04-five-state-source-field-materializer
PRODUCT_BRANCH='agent/ssc-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication-v1'
ARCHIVE_SHA256='db341e88a3dbcb4679c87f1bb3591f09fad3c9161d5e4941bb8d950ebd647de3'
FILESET_SHA256='a3fbe2bbd6edab9079b1213b3fefa7d034657fb19e6a12ca84cd7f3c2dbe7426'
SUCCESS=false
BOUND_PARENT=''
PRODUCT_HEAD=''
PRODUCT_TREE=''
FAILED_LINE=''
FAILED_COMMAND=''

on_err() {
  FAILED_LINE=${BASH_LINENO[0]:-unknown}
  FAILED_COMMAND=${BASH_COMMAND:-unknown}
}
trap on_err ERR

finish() {
  local rc=$?
  set +e
  mkdir -p "$OUT"
  local body="$OUT/comment.md"
  if [[ "$rc" -eq 0 && "$SUCCESS" == true && -f "$OUT/receipt.json" ]]; then
    {
      echo 'RD-04 five-state source-field adjudication materialized successfully.'
      echo
      echo '```json'
      cat "$OUT/receipt.json"
      echo '```'
      echo
      echo 'The product freezes four bounded promotion candidates and eleven follow-up routes without changing the 218/450 matrix.'
    } > "$body"
  else
    {
      echo 'RD-04 five-state source-field adjudication materialization failed closed.'
      echo
      echo '```text'
      echo "workflow_run: ${GITHUB_RUN_ID:-unknown}"
      echo "carrier_head: ${GITHUB_SHA:-unknown}"
      echo "bound_parent: ${BOUND_PARENT:-unbound}"
      echo "exit_code: $rc"
      echo "failed_line: ${FAILED_LINE:-unknown}"
      echo "failed_command: ${FAILED_COMMAND:-unknown}"
      echo '```'
      echo
      echo 'No unverified product ref is authorized.'
    } > "$body"
  fi
  if command -v gh >/dev/null 2>&1 && [[ -n "${GH_TOKEN:-}" ]]; then
    gh issue comment 1017 --repo "$GITHUB_REPOSITORY" --body-file "$body" || true
  fi
  exit "$rc"
}
trap finish EXIT

rm -rf "$OUT"
mkdir -p "$OUT/chunks" "$OUT/product"

gh issue comment 1017 --repo "$GITHUB_REPOSITORY" --body "RD-04 five-state source-field adjudication materialization started in run \`${GITHUB_RUN_ID}\` at exact carrier head \`${GITHUB_SHA}\`. Product archive SHA-256: \`${ARCHIVE_SHA256}\`."

fetch_blob() {
  local sha="$1" out="$2" bytes="$3" digest="$4"
  curl -fsSL \
    -H "Authorization: Bearer $GH_TOKEN" \
    -H 'Accept: application/vnd.github+json' \
    -H 'X-GitHub-Api-Version: 2022-11-28' \
    "https://api.github.com/repos/$GITHUB_REPOSITORY/git/blobs/$sha" > "$out.json"
  [[ "$(jq -r .encoding "$out.json")" == base64 ]]
  jq -r .content "$out.json" | tr -d '\n' | base64 -d > "$out"
  [[ "$(wc -c < "$out" | tr -d ' ')" == "$bytes" ]]
  [[ "$(sha256sum "$out" | awk '{print $1}')" == "$digest" ]]
  [[ "$(git hash-object "$out")" == "$sha" ]]
}

fetch_blob e439bc05590f36e476f4a5297ab1fae52d06f2a4 "$OUT/chunks/part-00" 4000 258bc8fd1497fc0792024bdf0b7dcaa5ae97abf1e0fb0c26c7e37d3c23eba196
fetch_blob 9c920d5f2b03a60a663e5997bfdf0db8a6d872f8 "$OUT/chunks/part-01" 4000 8232f3e3e01a094fb4602cb0d2f300ba67fa86dc8bea746c5776cecd76299417
fetch_blob d74478591bdb01a0cc9861f2645ec24c7f845ded "$OUT/chunks/part-02" 4000 a521b16cb51ef52095ff3938759b9302df94f7b3956b901f918e84325cad6070
fetch_blob 469a18d1a528670a92f1f98540d996d55e196ea9 "$OUT/chunks/part-03" 4000 6c027dc5b899055bf64c314910d7f12fb8065fe33f7bd5582208969fa34d83a6
fetch_blob a0f67afe8d1219ca564e490053de193e480ae4b1 "$OUT/chunks/part-04" 1004 782b9607474459b0dd72726ed7109b33c1fccedea8c137c50fe2439cfe33fd0f
cat "$OUT/chunks/part-00" "$OUT/chunks/part-01" "$OUT/chunks/part-02" "$OUT/chunks/part-03" "$OUT/chunks/part-04" > "$OUT/product.tar.xz"
[[ "$(wc -c < "$OUT/product.tar.xz" | tr -d ' ')" == 17004 ]]
[[ "$(sha256sum "$OUT/product.tar.xz" | awk '{print $1}')" == "$ARCHIVE_SHA256" ]]
tar -xJf "$OUT/product.tar.xz" -C "$OUT/product"
[[ -z "$(find "$OUT/product" -type l -print -quit)" ]]
find "$OUT/product" -type f -printf '%P\n' | sort > "$OUT/product-paths.txt"
[[ "$(wc -l < "$OUT/product-paths.txt" | tr -d ' ')" == 14 ]]
cat > "$OUT/expected-paths.txt" <<'PATHS'
.github/workflows/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.yml
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/capture-custody.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/field-adjudications.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/index.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/pdf-review-receipts.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/product-manifest.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/promotion-candidate-protocol.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/selected-followup-protocol.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/source-adjudications.json
docs/milestones/ssc-rd-wave03-rd04-five-state-source-field-adjudication.md
schemas/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.schema.json
test/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.test.js
tools/build-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
PATHS
diff -u "$OUT/expected-paths.txt" "$OUT/product-paths.txt"

python - <<'PY'
import hashlib, pathlib
root=pathlib.Path('/tmp/rd04-five-state-source-field-materializer/product')
expected={
'.github/workflows/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.yml':(5799,'9319247de4fbdc7237c258fef5f0d44d6451366b73a57eca8849c171b854e647'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/capture-custody.json':(2051,'4b62f1a251694996aed981c793609909f782d6e17c6d17cff42550bb993333e4'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/field-adjudications.json':(33838,'970435624b358361faf0b921ca9e5adbfced970bc0ee29780f00520602c20c19'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/index.json':(2992,'4fb5268d4c847fd992c6bf0f8bfccf8d963c8a59dbfbe9e2b1076fd55b859e1b'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/pdf-review-receipts.json':(2519,'ef09e6f58de4acb8826f47af8e2d1dbbc75c771a62f3a8bc30fa65891e8281f5'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/product-manifest.json':(1321,'3d99a1ec3b6a00635b14979aee3b304d983dfa6e10c6abc77750ac7c0e71156c'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/promotion-candidate-protocol.json':(5297,'4e0807ad813d3619b0ab4056813794f35db9ddcaca4c7c39882b29f8458fd3a7'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/selected-followup-protocol.json':(12233,'a27c057b36de0155463b2872b0e610500db2d7abca08de886e4661c8fc233834'),
'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication/source-adjudications.json':(38249,'84bdc0a364b937ec221b9ca8c8cf1741154f07b07f739f72fa3e6530482d21a9'),
'docs/milestones/ssc-rd-wave03-rd04-five-state-source-field-adjudication.md':(1826,'2b3fc6b3289bf596052c9520fcf1b890c97be3a71d76367c25063c862a6a635c'),
'schemas/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.schema.json':(10200,'7c7d3c6a990518f49a5e709e176015a61a2a7225e832945dd3e65402ff6c9147'),
'test/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.test.js':(3904,'a65fa82e482663ff3e0752dad47215e29f8c12a6a6b7e2229b2b2354bf762408'),
'tools/build-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs':(15981,'2b1dd96224ed7e89c962e2fab5825f1a7ffcf9c467c451a405b4b8d8c96975bd'),
'tools/validate-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs':(1321,'7f4d1dac50da3e8e152c41e6790136c24a20b74bdbd3d49d35494937c446b97a'),
}
combined=hashlib.sha256()
for path in sorted(expected):
    data=(root/path).read_bytes(); size,digest=expected[path]
    assert len(data)==size and hashlib.sha256(data).hexdigest()==digest, path
    combined.update(path.encode()+b'\0'+digest.encode()+b'\n')
assert combined.hexdigest()=='a3fbe2bbd6edab9079b1213b3fefa7d034657fb19e6a12ca84cd7f3c2dbe7426'
print('exact_archive_and_file_set=pass paths=14')
PY

git fetch origin main
BOUND_PARENT=$(git rev-parse origin/main)
for path in $(cat "$OUT/expected-paths.txt"); do
  if git cat-file -e "$BOUND_PARENT:$path" 2>/dev/null; then
    echo "target path already exists on live main: $path" >&2
    exit 1
  fi
done
[[ -z "$(git ls-remote --heads origin "refs/heads/$PRODUCT_BRANCH")" ]]
WT=/tmp/rd04-five-state-product-worktree
rm -rf "$WT"
git worktree add --detach "$WT" "$BOUND_PARENT"
cp -a "$OUT/product/." "$WT/"
(cd "$WT" && git diff --check)
(cd "$WT" && git status --porcelain=v1 --untracked-files=all | sed 's/^?? //' | sort > "$OUT/worktree-paths.txt")
diff -u "$OUT/expected-paths.txt" "$OUT/worktree-paths.txt"

cd "$WT"
node --check tools/build-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node --check tools/validate-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node --check test/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.test.js
node tools/build-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node tools/validate-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node test/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.test.js
python - <<'PY'
import json,pathlib
from jsonschema import Draft202012Validator
root=pathlib.Path('.')
schema=json.loads((root/'schemas/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.schema.json').read_text())
validator=Draft202012Validator(schema)
data=root/'data/intake/status-sovereignty-rd-wave03-rd04-fl-mt-nd-or-wi-source-field-adjudication'
names=['capture-custody.json','source-adjudications.json','field-adjudications.json','pdf-review-receipts.json','promotion-candidate-protocol.json','selected-followup-protocol.json','index.json','product-manifest.json']
for name in names: validator.validate(json.loads((data/name).read_text()))
print('closed_schema_validation=pass objects=8')
PY
node tools/validate-no-magic-human-gate.mjs
npm run release:check

git reset --hard "$BOUND_PARENT"
git clean -fdx
cp -a "$OUT/product/." "$WT/"
node tools/build-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node tools/validate-status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.mjs
node test/status-sovereignty-rd-wave03-rd04-five-state-source-field-adjudication.test.js
node tools/validate-no-magic-human-gate.mjs
git diff --check
git add --pathspec-from-file="$OUT/expected-paths.txt"
git diff --cached --name-only | sort > "$OUT/staged-paths.txt"
diff -u "$OUT/expected-paths.txt" "$OUT/staged-paths.txt"
[[ -z "$(git status --porcelain=v1 | grep -v '^A  ' || true)" ]]
git config user.name 'RD-04 bounded materializer'
git config user.email 'rd04-materializer@users.noreply.github.com'
git commit -m 'Adjudicate RD-04 five-state source fields and freeze follow-ups'
PRODUCT_HEAD=$(git rev-parse HEAD)
PRODUCT_TREE=$(git rev-parse HEAD^{tree})
[[ "$(git rev-parse HEAD^)" == "$BOUND_PARENT" ]]
[[ "$(git rev-list --count "$BOUND_PARENT"..HEAD)" == 1 ]]
git fetch origin main
[[ "$(git rev-parse origin/main)" == "$BOUND_PARENT" ]]
[[ -z "$(git ls-remote --heads origin "refs/heads/$PRODUCT_BRANCH")" ]]
git push origin "$PRODUCT_HEAD:refs/heads/$PRODUCT_BRANCH"

python - <<PY > "$OUT/receipt.json"
import json
print(json.dumps({
  'canonical_parent':'$BOUND_PARENT',
  'product_head':'$PRODUCT_HEAD',
  'product_tree':'$PRODUCT_TREE',
  'product_branch':'$PRODUCT_BRANCH',
  'permanent_paths':14,
  'archive_bytes':17004,
  'archive_sha256':'$ARCHIVE_SHA256',
  'file_set_combined_sha256':'$FILESET_SHA256',
  'source_decisions':27,
  'field_adjudications':20,
  'promotion_candidates':4,
  'selected_followup_routes':11,
  'matrix_updates':0,
  'terminal_cells_after':218,
  'open_substantive_cells_after':192,
  'class_closed':False,
  'outside_human_dependency':False,
  'publication_effect':'none',
  'adoption_effect':'none',
  'graph_effect':'none'
},indent=2))
PY
SUCCESS=true
