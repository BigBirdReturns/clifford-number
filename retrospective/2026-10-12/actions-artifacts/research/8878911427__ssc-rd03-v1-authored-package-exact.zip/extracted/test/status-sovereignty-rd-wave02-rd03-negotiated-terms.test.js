#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {
  ROOT,
  REQUIRED_FIELDS
} from '../tools/build-status-sovereignty-rd-wave02-rd03-negotiated-terms.mjs';
import {
  SCHEMA_PATH,
  readBundle,
  validateProduct,
  validateProductShape
} from '../tools/validate-status-sovereignty-rd-wave02-rd03-negotiated-terms.mjs';

const read = (rel) => JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8'));
const clone = (value) => structuredClone(value);

validateProduct(ROOT);
const bundle = readBundle(ROOT);
const schema = read(SCHEMA_PATH);

const mutations = [
  ['terminal schema', (b) => { b.terminal.schema_version = 'bad'; }],
  ['terminal wave', (b) => { b.terminal.wave_id = 'OTHER'; }],
  ['terminal class', (b) => { b.terminal.class_id = 'RD-02-C04'; }],
  ['terminal issue', (b) => { b.terminal.issue = 787; }],
  ['terminal cutoff', (b) => { b.terminal.as_of = '2026-08-03'; }],
  ['terminal status', (b) => { b.terminal.status = 'open'; }],
  ['research head', (b) => { b.terminal.source_product.research_head = '0'.repeat(40); }],
  ['matrix path', (b) => { b.terminal.source_product.historical_field_matrix_path = 'other'; }],
  ['matrix blob', (b) => { b.terminal.source_product.historical_field_matrix_git_blob_sha = '0'.repeat(40); }],
  ['matrix digest', (b) => { b.terminal.source_product.historical_field_matrix_sha256 = '0'.repeat(64); }],
  ['parent digest', (b) => { b.terminal.source_product.parent_sha256 = '0'.repeat(64); }],
  ['execution path', (b) => { b.terminal.source_product.execution_receipt_path = 'other'; }],
  ['census root', (b) => { b.terminal.source_product.census_root = 'other'; }],
  ['census artifact', (b) => { b.terminal.source_product.census_artifact_sha256 = '0'.repeat(64); }],
  ['census manifest', (b) => { b.terminal.source_product.census_manifest_combined_sha256 = '0'.repeat(64); }],
  ['census manifest count', (b) => { b.terminal.source_product.census_manifest_entry_count = 262; }],
  ['denominator count', (b) => { b.terminal.denominator_contract.instruments = 4; }],
  ['denominator order', (b) => { b.terminal.denominator_contract.instrument_ids.reverse(); }],
  ['executed count', (b) => { b.terminal.denominator_contract.executed_and_disbursed_instruments = 2; }],
  ['conditional count', (b) => { b.terminal.denominator_contract.conditional_pre_close_commitments = 3; }],
  ['row membership', (b) => { b.terminal.denominator_contract.row_membership_frozen = false; }],
  ['silent removal', (b) => { b.terminal.denominator_contract.silent_instrument_removal_allowed = true; }],
  ['outcome selection', (b) => { b.terminal.denominator_contract.outcome_based_selection_allowed = true; }],
  ['protocol denominator false', (b) => { b.terminal.denominator_contract.fixed_public_record_protocol_complete = false; }],
  ['required field removed', (b) => { b.terminal.required_fields.pop(); }],
  ['required field order', (b) => { b.terminal.required_fields.reverse(); }],
  ['state vocabulary removed', (b) => { b.terminal.permitted_field_states.pop(); }],
  ['remove instrument', (b) => { b.terminal.instruments.pop(); }],
  ['duplicate instrument', (b) => { b.terminal.instruments[4].instrument_id = b.terminal.instruments[3].instrument_id; }],
  ['instrument order', (b) => { b.terminal.instruments.reverse(); }],
  ['borrower changed', (b) => { b.terminal.instruments[0].borrower = 'Other'; }],
  ['parent state changed', (b) => { b.terminal.instruments[0].parent_state.executed_loan = false; }],
  ['remove field', (b) => { delete b.terminal.instruments[0].fields.pricing_and_cost_of_capital; }],
  ['extra field', (b) => { b.terminal.instruments[0].fields.extra = {}; }],
  ['field order', (b) => {
    const fields = b.terminal.instruments[0].fields;
    const reversed = {};
    for (const key of Object.keys(fields).reverse()) reversed[key] = fields[key];
    b.terminal.instruments[0].fields = reversed;
  }],
  ['legal borrower value', (b) => { b.terminal.instruments[0].fields.legal_borrower_and_material_affiliates.value.legal_borrower = 'Other'; }],
  ['affiliate absence', (b) => { b.terminal.instruments[0].fields.legal_borrower_and_material_affiliates.value.material_affiliates = []; }],
  ['affiliate state', (b) => { b.terminal.instruments[0].fields.legal_borrower_and_material_affiliates.value.material_affiliates_state = 'observed'; }],
  ['MP execution state', (b) => { b.terminal.instruments[0].fields.instrument_state_and_governing_date.value.executed_loan = false; }],
  ['MP cash state', (b) => { b.terminal.instruments[0].fields.instrument_state_and_governing_date.value.cash_proceeds_received = false; }],
  ['MP governing date invented', (b) => { b.terminal.instruments[0].fields.instrument_state_and_governing_date.value.governing_date = '2025-08-01'; }],
  ['MP principal', (b) => { b.terminal.instruments[0].fields.principal_or_ceiling.value.amount = 149000000; }],
  ['MP amount type', (b) => { b.terminal.instruments[0].fields.principal_or_ceiling.value.amount_type = 'ceiling'; }],
  ['MP interest', (b) => { b.terminal.instruments[0].fields.pricing_and_cost_of_capital.value.annual_interest_rate_percent = 5.39; }],
  ['MP frequency', (b) => { b.terminal.instruments[0].fields.pricing_and_cost_of_capital.value.interest_payment_frequency = 'annual'; }],
  ['MP maturity', (b) => { b.terminal.instruments[0].fields.maturity_and_amortization.value.maturity_date = '2037-08-02'; }],
  ['MP secured', (b) => { b.terminal.instruments[0].fields.security_and_collateral.value.instrument_form = 'secured_note'; }],
  ['MP seniority invented', (b) => { b.terminal.instruments[0].fields.seniority_and_subordination.value = 'senior'; }],
  ['MP companion right removed', (b) => { b.terminal.instruments[0].fields.warrant_or_other_public_rights.value.companion_transaction_rights_observed.pop(); }],
  ['MP complete right allocation', (b) => { b.terminal.instruments[0].fields.warrant_or_other_public_rights.value.loan_specific_right_allocation_complete = true; }],
  ['MP condition details invented', (b) => { b.terminal.instruments[0].fields.conditions_precedent_and_close_conditions.value.detailed_conditions_precedent = ['invented']; }],
  ['conditional promoted', (b) => { b.terminal.instruments[1].fields.instrument_state_and_governing_date.value.executed_loan = true; }],
  ['conditional cash promoted', (b) => { b.terminal.instruments[2].fields.instrument_state_and_governing_date.value.cash_proceeds_received = true; }],
  ['conditional amount state', (b) => { b.terminal.instruments[3].fields.principal_or_ceiling.state = 'observed'; }],
  ['conditional amount type', (b) => { b.terminal.instruments[4].fields.principal_or_ceiling.value.amount_type = 'executed_principal'; }],
  ['Vulcan amount', (b) => { b.terminal.instruments[1].fields.principal_or_ceiling.value.amount = 621000000; }],
  ['ReElement amount', (b) => { b.terminal.instruments[2].fields.principal_or_ceiling.value.amount = 81000000; }],
  ['Phoenix amount', (b) => { b.terminal.instruments[3].fields.principal_or_ceiling.value.amount = 501000000; }],
  ['Energy amount', (b) => { b.terminal.instruments[4].fields.principal_or_ceiling.value.amount = 726000000; }],
  ['Energy tenor promoted', (b) => { b.terminal.instruments[4].fields.maturity_and_amortization.state = 'observed'; }],
  ['Energy maturity invented', (b) => { b.terminal.instruments[4].fields.maturity_and_amortization.value.exact_maturity_date = '2046-01-01'; }],
  ['warrant issued', (b) => { b.terminal.instruments[1].fields.warrant_or_other_public_rights.value.issuance_observed = true; }],
  ['warrant exact terms', (b) => { b.terminal.instruments[2].fields.warrant_or_other_public_rights.value.exact_terms_state = 'observed'; }],
  ['unavailable value invented', (b) => { b.terminal.instruments[3].fields.security_and_collateral.value = { collateral: 'invented' }; }],
  ['unavailable source invented', (b) => { b.terminal.instruments[3].fields.security_and_collateral.source_ids.push('SSC-RD03-S007'); }],
  ['field state invalid', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.state = 'complete'; }],
  ['field route outside protocol', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.census_route_ids.push('RD03-CENSUS-R999'); }],
  ['field no routes', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.census_route_ids = []; }],
  ['field protocol false', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.fixed_protocol_complete = false; }],
  ['field terminal false', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.terminal_for_class_closure = false; }],
  ['field note empty', (b) => { b.terminal.instruments[0].fields.covenants_and_operating_restrictions.note = ''; }],
  ['custody head', (b) => { b.terminal.instruments[0].fields.source_identity_and_exact_custody.value.research_head = '0'.repeat(40); }],
  ['custody artifact', (b) => { b.terminal.instruments[1].fields.source_identity_and_exact_custody.value.census_artifact_sha256 = '0'.repeat(64); }],
  ['custody routes', (b) => { b.terminal.instruments[2].fields.source_identity_and_exact_custody.value.fixed_route_ids.pop(); }],
  ['result protocol false', (b) => { b.terminal.instruments[0].instrument_result.fixed_protocol_executed = false; }],
  ['result terminal fields', (b) => { b.terminal.instruments[1].instrument_result.terminal_fields = 13; }],
  ['result reopened', (b) => { b.terminal.instruments[2].instrument_result.instrument_closed = false; }],
  ['complete term stack promoted', (b) => { b.terminal.instruments[3].instrument_result.complete_negotiated_term_stack_observed = true; }],
  ['instrument terminal state', (b) => { b.terminal.instruments[4].instrument_result.terminal_state = 'complete'; }],
  ['counts instruments', (b) => { b.terminal.counts.instruments = 4; }],
  ['counts required fields', (b) => { b.terminal.counts.required_fields_total = 69; }],
  ['counts terminal fields', (b) => { b.terminal.counts.terminal_fields_total = 69; }],
  ['counts observed', (b) => { b.terminal.counts.observed_fields = 18; }],
  ['counts conditional', (b) => { b.terminal.counts.conditional_term_only_fields = 14; }],
  ['counts unavailable', (b) => { b.terminal.counts.source_unavailable_fields = 37; }],
  ['counts closed', (b) => { b.terminal.counts.closed_instruments = 4; }],
  ['counts complete stacks', (b) => { b.terminal.counts.complete_negotiated_term_stacks_observed = 1; }],
  ['counts routes', (b) => { b.terminal.counts.fixed_routes = 29; }],
  ['counts attempts', (b) => { b.terminal.counts.route_attempts = 31; }],
  ['counts direct success', (b) => { b.terminal.counts.exact_route_terminal_non_successes = 14; }],
  ['counts candidates', (b) => { b.terminal.counts.candidate_result_rows = 149; }],
  ['counts admitted', (b) => { b.terminal.counts.admitted_candidate_urls = 1; }],
  ['counts recursion', (b) => { b.terminal.counts.result_spawned_requests = 1; }],
  ['counts contact', (b) => { b.terminal.counts.external_contacts = 1; }],
  ['terminal class reopened', (b) => { b.terminal.current_result.class_closed = false; }],
  ['terminal state changed', (b) => { b.terminal.current_result.terminal_state = 'evidence_complete'; }],
  ['protocol incomplete', (b) => { b.terminal.current_result.fixed_protocol_complete = false; }],
  ['terminal instruments', (b) => { b.terminal.current_result.terminally_classified_instruments = 4; }],
  ['complete stacks result', (b) => { b.terminal.current_result.complete_negotiated_term_stacks_observed = true; }],
  ['state distinction weakened', (b) => { b.terminal.current_result.executed_and_conditional_state_distinction_preserved = false; }],
  ['source unavailability weakened', (b) => { b.terminal.current_result.source_unavailability_preserved = false; }],
  ['favoritism promoted', (b) => { b.terminal.current_result.favoritism_finding = true; }],
  ['extraction promoted', (b) => { b.terminal.current_result.extraction_finding = true; }],
  ['recovery promoted', (b) => { b.terminal.current_result.public_recovery_finding = true; }],
  ['coordination promoted', (b) => { b.terminal.current_result.coordination_finding = true; }],
  ['common purpose promoted', (b) => { b.terminal.current_result.common_purpose_finding = true; }],
  ['compact promoted', (b) => { b.terminal.current_result.complete_compact_finding = true; }],
  ['publication effect', (b) => { b.terminal.current_result.publication_effect = 'published'; }],
  ['conditional boundary', (b) => { b.terminal.boundaries.conditional_commitment_is_executed_loan = true; }],
  ['executed completeness boundary', (b) => { b.terminal.boundaries.executed_loan_is_complete_negotiated_term_stack = true; }],
  ['cash performance boundary', (b) => { b.terminal.boundaries.cash_disbursement_is_observed_performance_or_recovery = true; }],
  ['companion allocation boundary', (b) => { b.terminal.boundaries.companion_right_package_is_loan_specific_right_allocation = true; }],
  ['warrant issuance boundary', (b) => { b.terminal.boundaries.expected_warrant_is_issued_warrant = true; }],
  ['tenor boundary', (b) => { b.terminal.boundaries.advertised_tenor_is_final_maturity_schedule = true; }],
  ['access failure boundary', (b) => { b.terminal.boundaries.direct_route_access_failure_is_record_absence = true; }],
  ['search result boundary', (b) => { b.terminal.boundaries.search_result_is_governing_instrument = true; }],
  ['unrecovered absence boundary', (b) => { b.terminal.boundaries.unrecovered_term_is_zero_or_absent = true; }],
  ['parent false boundary', (b) => { b.terminal.boundaries.parent_false_boolean_is_contractual_nonexistence = true; }],
  ['cohort boundary', (b) => { b.terminal.boundaries.five_named_instruments_are_complete_OSC_cohort = true; }],
  ['favoritism boundary', (b) => { b.terminal.boundaries.strategic_financing_is_favoritism = true; }],
  ['extraction boundary', (b) => { b.terminal.boundaries.private_capacity_is_extraction = true; }],
  ['coordination boundary', (b) => { b.terminal.boundaries.functional_complementarity_is_coordination_or_common_purpose = true; }],
  ['matrix compact boundary', (b) => { b.terminal.boundaries.matrix_completion_is_complete_compact = true; }],
  ['human dependency', (b) => { b.terminal.boundaries.outside_human_dependency = true; }],
  ['boundary graph effect', (b) => { b.terminal.boundaries.graph_effect = 'changed'; }],
  ['receipt label', (b) => { b.receipt.class_label = 'partial terms'; }],
  ['receipt reopened', (b) => { b.receipt.class_closed = false; }],
  ['receipt terminal state', (b) => { b.receipt.terminal_state = 'open'; }],
  ['receipt basis removed', (b) => { b.receipt.closure_basis.pop(); }],
  ['receipt atlas arithmetic', (b) => { b.receipt.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06.open_after = 38; }],
  ['receipt artifact', (b) => { b.receipt.source_custody.census_artifact_sha256 = '0'.repeat(64); }],
  ['receipt contact', (b) => { b.receipt.authority.external_contacts = 1; }],
  ['receipt favoritism', (b) => { b.receipt.authority.favoritism_finding = true; }],
  ['summary counts', (b) => { b.summary.counts.instruments = 6; }],
  ['summary authority', (b) => { b.summary.authority.graph_effect = 'changed'; }],
  ['manifest entry removed', (b) => { b.manifest.entries.pop(); }],
  ['manifest path changed', (b) => { b.manifest.entries[0].path = 'other.json'; }],
  ['manifest digest changed', (b) => { b.manifest.entries[0].sha256 = '0'.repeat(64); }],
  ['manifest combined changed', (b) => { b.manifest.combined_sha256 = '0'.repeat(64); }],
  ['closure issue', (b) => { b.closure.child_issue = 787; }],
  ['closure PR', (b) => { b.closure.source_pr = 802; }],
  ['closure state', (b) => { b.closure.terminal_state = 'complete'; }],
  ['closure atlas', (b) => { b.closure.residual_atlas_effect_if_promoted_after_rd04_rd05_rd01_and_rd06.closed_after = 4; }],
  ['closure manifest', (b) => { b.closure.product.manifest_combined_sha256 = '0'.repeat(64); }],
  ['closure run', (b) => { b.closure.execution.workflow_run = 1; }],
  ['closure artifact', (b) => { b.closure.execution.artifact_zip_sha256 = '0'.repeat(64); }],
  ['closure authority', (b) => { b.closure.authority.extraction_finding = true; }],
  ['execution run', (b) => { b.execution.workflow_run = 1; }],
  ['execution digest', (b) => { b.execution.artifact_zip_sha256 = '0'.repeat(64); }],
  ['execution candidates', (b) => { b.execution.counts.candidate_result_rows = 151; }],
  ['execution adjudication', (b) => { b.execution.authority.substantive_adjudication_performed_by_census = true; }],
  ['census manifest entry', (b) => { b.censusManifest.entries[0].sha256 = '0'.repeat(64); }],
  ['census summary closure', (b) => { b.censusSummary.class_closed = true; }],
  ['candidate governing instrument', (b) => { b.candidateIndex.authority.candidate_hit_is_governing_instrument = true; }],
  ['candidate admission', (b) => { b.candidateUrls.admitted_sources = 1; }],
  ['evidence adjudication', (b) => { b.evidenceIndex.authority.substantive_adjudication_complete = true; }],
  ['protocol closure', (b) => { b.protocolLedger.class_closed = true; }],
  ['matrix pre-protocol state', (b) => { b.parentMatrix.current_result.class_closed = true; }],
  ['parent state split', (b) => { b.parent.counts.executed_loans = 2; }],
  ['seed label', (b) => { b.seed.closure_target = 'different'; }]
];

for (const fieldName of REQUIRED_FIELDS) {
  mutations.push([`field state mutation ${fieldName}`, (b) => {
    b.terminal.instruments[0].fields[fieldName].state = 'not_publicly_recovered';
  }]);
}

for (const [name, mutate] of mutations) {
  const candidate = clone(bundle);
  mutate(candidate);
  assert.throws(() => validateProductShape(candidate, schema, ROOT), undefined, name);
}

const schemaMutations = [
  ['schema root open', (s) => { s.additionalProperties = true; }],
  ['schema id changed', (s) => { s.$id = 'bad'; }],
  ['schema instruments min', (s) => { s.properties.instruments.minItems = 4; }],
  ['schema instruments max', (s) => { s.properties.instruments.maxItems = 6; }],
  ['schema instrument count', (s) => { s.properties.counts.properties.instruments.const = 4; }],
  ['schema required fields', (s) => { s.properties.counts.properties.required_fields_total.const = 69; }],
  ['schema terminal fields', (s) => { s.properties.counts.properties.terminal_fields_total.const = 69; }],
  ['schema unavailable fields', (s) => { s.properties.counts.properties.source_unavailable_fields.const = 37; }],
  ['schema terminal state', (s) => { s.properties.current_result.properties.terminal_state.const = 'complete'; }],
  ['schema closure', (s) => { s.properties.current_result.properties.class_closed.const = false; }],
  ['schema field open', (s) => { s.$defs.field.additionalProperties = true; }]
];

for (const [name, mutate] of schemaMutations) {
  const candidate = clone(schema);
  mutate(candidate);
  assert.throws(() => validateProductShape(bundle, candidate, ROOT), undefined, name);
}

console.log(`RD-03 terminal adversarial suite: ${mutations.length + schemaMutations.length} mutations refused`);
