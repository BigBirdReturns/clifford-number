# SSC RD‑03 Wave 02 — terminal negotiated-term closure

RD‑03‑C04 closes the bounded public acquisition obligation for:

```text
complete negotiated loan, warrant, security, covenant,
milestone, pricing, and seniority terms
```

The closure is `bounded_source_unavailable`. It is not a finding that all five instrument stacks are publicly observed, that every advertised commitment became final, or that unrecovered terms are zero or absent.

## Immutable denominator

```text
named instruments:                         5
executed and cash-disbursed parent state:  1
conditional pre-close parent states:       4
required fields per instrument:           14
required fields total:                    70
```

The five instruments remain:

```text
MP Materials              $150 million executed loan
Vulcan Elements           $620 million conditional commitment
ReElement Technologies     $80 million conditional commitment
Phoenix Tailings          $500 million conditional commitment
Energy Fuels              $725 million conditional commitment
```

The executed MP Materials note is not used to promote the four conditional commitments. A commitment amount is not executed principal, a proposed tenor is not a final maturity schedule, and an expected warrant is not an issued warrant.

## Fixed public-record protocol

The same frozen acquisition protocol was applied across the five-instrument universe:

```text
fixed routes:                           30
exact primary or index routes:          15
bounded discovery routes:               15
route attempts:                         30

exact-route terminal non-successes:     15
discovery-route successes:              15

candidate result rows:                 150
unique candidate URLs:                  60
official-host candidate URLs:            5
first-party candidate URLs:              1
admitted candidate URLs:                 0
result-spawned requests:                  0
```

All fifteen direct SEC, Defense, and War Department routes returned typed HTTP 403 access states from the execution environment. That is an access condition, not evidence that the filing, announcement, agreement, or instrument does not exist.

The five official-host discovery candidates were unrelated City of Phoenix or energy-agency pages. The one first-party candidate was the generic MP Materials homepage. None was admitted as a governing loan, warrant, security, covenant, milestone, pricing, or seniority instrument.

## Terminal field accounting

```text
observed fields:                         17
conditional-term-only fields:           15
source-unavailable fields:               38
terminal fields:                        70 / 70
closed instruments:                       5 / 5
complete negotiated-term stacks:          0 / 5
```

### MP Materials

The public parent record supports:

```text
executed loan and cash receipt:          observed
principal:                               $150 million
annual interest:                         5.38%
interest payment form:                   quarterly cash
maturity:                                August 1, 2037
instrument form:                         unsecured promissory note
companion public-right package:          preferred stock, warrant,
                                         price protection, offtake
```

The complete fee, amortization, seniority, covenant, milestone, reporting, default, cure, amendment, and enforcement schedules remain source unavailable. The companion right package remains separate from the loan and does not establish complete loan-specific right allocation.

### Four conditional commitments

The four announcements remain conditional pre-close states. Their published ceilings and bounded closing conditions are preserved, including the proposed twenty-year Energy Fuels tenor and the expected Vulcan/ReElement warrants. No final execution, financial close, cash disbursement, warrant issuance, final pricing, collateral, seniority, covenant, milestone, reporting, default, cure, or enforcement term is manufactured.

## Closure effect

```text
terminal state:                    bounded_source_unavailable
class closed:                      true

atlas before promotion:
38 open / 4 closed

atlas after promotion:
37 open / 5 closed
```

This closes only RD‑03‑C04’s bounded public negotiated-term acquisition. It does not close the broader OSC lifecycle, performance, repayment, loss, public recovery, counterfactual, or program-wide denominator classes.

## Authority ceiling

```text
outside-human dependency:         false
external contacts/reviews:        0 / 0

favoritism finding:               false
extraction finding:               false
public-recovery finding:          false
coordination finding:             false
common-purpose finding:           false
complete-compact finding:         false

graph/publication/adoption:       none / none / none
```

Strategic financing is not favoritism. Private capacity is not extraction. Functional complementarity is not coordination or common purpose. Cash disbursement is not observed performance, repayment, or public recovery. Five named instruments are not the complete OSC cohort.
