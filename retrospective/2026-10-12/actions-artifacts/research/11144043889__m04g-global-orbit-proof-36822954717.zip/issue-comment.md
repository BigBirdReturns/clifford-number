<!-- m04g-global-orbit-proof:36822954717 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/36822954717
- Head: `d8392cfb19b8fd870bc65e5a3dcf9a8ae4bcfb07`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `4/4`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `8/20` (`0.4`)
- Content success: `7/20` (`0.35`)
- Metadata only: `1`
- Failed: `12`
- Healthy basins: `0/4`
- Proof SHA-256: `d626f37121664fced2f3bcb4ab8008c8da048b668925dbf01f0b88184c73a819`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G09-SOUTH-ASIA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G10-EAST-ASIA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G11-SOUTHEAST-ASIA` | 5 | 2 | 2 | 0 | 3 | `false` |
| `G12-OCEANIA-PACIFIC` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
