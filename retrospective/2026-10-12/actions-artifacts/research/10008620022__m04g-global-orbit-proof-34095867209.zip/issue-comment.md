<!-- m04g-global-orbit-proof:34095867209 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/34095867209
- Head: `0b93ed2ab9741813b71e34b765bd17cd91533685`
- Event: `schedule`
- Classes: `ocean_discovery`
- Basin denominator: `12/12`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `20/24` (`0.8333`)
- Content success: `20/24` (`0.8333`)
- Metadata only: `0`
- Failed: `4`
- Healthy basins: `0/12`
- Proof SHA-256: `912cd7c6d8afac3954f9b80a49323de83d4f7d296024d631750ca107908317d9`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G01-GLOBAL-MULTILATERAL` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G02-NORTH-AMERICA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G03-LATIN-AMERICA-CARIBBEAN` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G04-EU-CONTINENTAL` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G05-UK-IRELAND-NORDICS` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G07-MENA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G09-SOUTH-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G10-EAST-ASIA` | 2 | 1 | 1 | 0 | 1 | `false` |
| `G11-SOUTHEAST-ASIA` | 2 | 2 | 2 | 0 | 0 | `false` |
| `G12-OCEANIA-PACIFIC` | 2 | 2 | 2 | 0 | 0 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
