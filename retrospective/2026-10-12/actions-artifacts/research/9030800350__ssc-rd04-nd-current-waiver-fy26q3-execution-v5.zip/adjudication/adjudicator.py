import hashlib
import json
import pathlib
import re
import sys
from html.parser import HTMLParser
from urllib.parse import urljoin

matrix_path = pathlib.Path(sys.argv[1])
execution = pathlib.Path(sys.argv[2])
out = pathlib.Path(sys.argv[3])

class SurfaceParser(HTMLParser):
    def __init__(self, base_url):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.text = []
        self.links = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {"script", "style", "noscript"}:
            self.skip += 1
        if tag == "a" and "href" in attrs:
            self.links.append({"href": urljoin(self.base_url, attrs["href"]), "text_parts": []})

    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript"} and self.skip:
            self.skip -= 1

    def handle_data(self, data):
        if self.skip:
            return
        value = " ".join(data.split())
        if not value:
            return
        self.text.append(value)
        if self.links:
            self.links[-1]["text_parts"].append(value)

    def result(self):
        text = "\n".join(self.text)
        links = [
            {"text": " ".join(item["text_parts"]).strip(), "href": item["href"]}
            for item in self.links
        ]
        return text, links

def canonical_sha(value):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()

matrix = json.loads(matrix_path.read_text())
counts = matrix["counts"]
assert (
    counts["materialized_cells"],
    counts["terminal_cells"],
    counts["still_open_cells"],
    counts["still_open_substantive_cells"],
    counts["terminal_units"],
) == (450, 227, 223, 183, 10)
assert matrix["current_result"]["class_closed"] is False
nd = next(row for row in matrix["rows"] if row["unit_id"] == "US-STATE-ND")
waiver_cell = next(
    cell for cell in nd["cells"]
    if cell["field_id"] == "abawd_or_work_requirement_waiver_state_and_governing_period"
)
assert nd["row_state"] == "still_open"
assert (nd["terminal_fields"], nd["open_fields"]) == (7, 2)
assert waiver_cell["state"] == "still_open" and waiver_cell["terminal"] is False
assert canonical_sha(waiver_cell) == "cbaabfa791f02aa4f17bc1b5b31e28775368b125a4b658cb216c22cd90a26dfe"

route_receipts = json.loads((execution / "route-receipts.json").read_text())
by_id = {row["route_id"]: row for row in route_receipts}
assert list(by_id) == [
    "RD04-ND-CURRENT-WAIVER-FNA-001",
    "RD04-ND-CURRENT-WAIVER-FNA-002",
    "RD04-ND-CURRENT-WAIVER-FNA-003",
    "RD04-ND-CURRENT-WAIVER-FNA-004",
]
expected = {
    "RD04-ND-CURRENT-WAIVER-FNA-001": (200, "300035d49923fcaf8dfcbd54a99388d7b67af58ebb0b713b49548ff824e9a7f3"),
    "RD04-ND-CURRENT-WAIVER-FNA-002": (404, "02fd72e7135514260a447c234944c325fa83bf248439296bd7a000740b01ea97"),
    "RD04-ND-CURRENT-WAIVER-FNA-003": (200, "2477832ad3dce9398dbe1e6158347175c729fbe8ef46fe261fbd12d338794f11"),
    "RD04-ND-CURRENT-WAIVER-FNA-004": (200, "aaec6c27abf3e25dc6e995b7dd74c6a16b24e18846dc896f404872ee7de42661"),
}

surfaces = {}
for route_id, row in by_id.items():
    status, body_sha = expected[route_id]
    assert row["http_status"] == status
    assert row["body_sha256"] == body_sha
    final_hop = row["hops"][-1]
    body_path = execution / final_hop["body_path"]
    body = body_path.read_bytes()
    assert hashlib.sha256(body).hexdigest() == body_sha
    parser = SurfaceParser(row["final_url"])
    parser.feed(body.decode("utf-8", errors="replace"))
    text, links = parser.result()
    surfaces[route_id] = {
        "route_id": route_id,
        "http_status": status,
        "final_url": row["final_url"],
        "body_bytes": len(body),
        "body_sha256": body_sha,
        "visible_text_bytes": len(text.encode()),
        "visible_text_sha256": hashlib.sha256(text.encode()).hexdigest(),
        "visible_text": text,
        "links": links,
    }

s1 = surfaces["RD04-ND-CURRENT-WAIVER-FNA-001"]
assert "Time Limit Waivers" in s1["visible_text"]
assert "This page also includes information on waiver status by state by fiscal quarter." in s1["visible_text"]
assert "Page updated: July 16, 2026" in s1["visible_text"]
q1 = "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-1-ABAWD-Waiver-Status.pdf"
q2 = "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-2-ABAWD-Waiver-Status.pdf"
q3 = "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-3-ABAWD-Waiver-Status.pdf"
hrefs1 = {link["href"] for link in s1["links"]}
assert {q1, q2, q3}.issubset(hrefs1)
assert "North Dakota" not in s1["visible_text"]

s2 = surfaces["RD04-ND-CURRENT-WAIVER-FNA-002"]
assert s2["http_status"] == 404
assert "Page or Content Not Found" in s2["visible_text"]

s3 = surfaces["RD04-ND-CURRENT-WAIVER-FNA-003"]
assert "SNAP Work Requirements" in s3["visible_text"]
assert "changes the work requirements for SNAP able-bodied adults without dependents" in s3["visible_text"]
assert "changes to the ABAWD exception criteria and ABAWD waiver criteria" in s3["visible_text"]
assert "We will update this page once the guidance is released." in s3["visible_text"]
assert "North Dakota" not in s3["visible_text"]

s4 = surfaces["RD04-ND-CURRENT-WAIVER-FNA-004"]
assert "SNAP Provisions of the One Big Beautiful Bill Act of 2025" in s4["visible_text"]
assert any(
    link["href"] == "https://www.usda.gov/guidance-documents/snap/fns/snap-provisions-one-big-beautiful-bill-act-2025-information-memorandum"
    for link in s4["links"]
)
assert "North Dakota" not in s4["visible_text"]

source_adjudication = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-source-adjudication@1",
    "object_type": "source_adjudication",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "source_admissions": 2,
    "decisions": [
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-001",
            "source_admitted_for_narrow_scope": True,
            "admitted_for": ["current_federal_time_limit_waiver_index_and_state_by_quarter_locator"],
            "not_admitted_for": ["north_dakota_waiver_geography", "north_dakota_governing_period"],
            "body_sha256": s1["body_sha256"],
            "visible_text_sha256": s1["visible_text_sha256"],
            "page_updated": "2026-07-16",
            "exact_fy2026_quarter_links": [q1, q2, q3],
            "substantive_weight_count": 1,
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-002",
            "source_admitted_for_narrow_scope": False,
            "disposition": "http_404_not_a_source",
            "body_sha256": s2["body_sha256"],
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-003",
            "source_admitted_for_narrow_scope": True,
            "admitted_for": ["current_federal_work_requirement_and_pending_waiver_guidance_context"],
            "not_admitted_for": ["north_dakota_waiver_geography", "north_dakota_governing_period"],
            "body_sha256": s3["body_sha256"],
            "visible_text_sha256": s3["visible_text_sha256"],
            "substantive_weight_count": 1,
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-004",
            "source_admitted_for_narrow_scope": False,
            "disposition": "locator_only_without_substantive_state_specific_body",
            "body_sha256": s4["body_sha256"],
        },
    ],
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
}

field_adjudication = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-field-adjudication@1",
    "object_type": "field_adjudication",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
    "current_cell_canonical_sha256": canonical_sha(waiver_cell),
    "disposition": "current_federal_index_and_policy_context_without_state_specific_status_hold_open",
    "promotion_candidate": False,
    "rationale": "The captured federal index proves a current state-by-quarter waiver-status series and exposes the FY2026 Quarter 3 PDF, but none of the captured HTML surfaces expressly states North Dakota waiver geography or a governing period.",
    "selected_next_source": q3,
    "q1_q2_disposition": "historical_quarter_context_not_selected_for_minimum_next_denominator",
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "prohibited_inferences": [
        "do_not_treat_index_presence_as_north_dakota_waiver_status",
        "do_not_treat_404_as_policy_absence",
        "do_not_treat_pending_guidance_as_waiver_approval_or_denial",
        "do_not_close_north_dakota_row",
        "do_not_close_rd04_c02",
    ],
}

protocol = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26q3-followup-protocol@1",
    "object_type": "selected_followup_protocol",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "target_field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
    "selection_basis": "latest FY2026 state-by-quarter status PDF directly linked by the captured current federal waiver index",
    "route_count": 1,
    "routes": [
        {
            "ordinal": 1,
            "route_id": "RD04-ND-CURRENT-WAIVER-FY26Q3-001",
            "route_category": "fy2026_quarter3_state_waiver_status_pdf",
            "url": q3,
            "allowed_hosts": ["fna.usda.gov", "www.fna.usda.gov"],
            "attempts": 1,
            "redirects": "manual_same_host_only",
            "maximum_body_bytes": 12_000_000,
            "expected_content_family": "application/pdf",
        }
    ],
    "source_requests_executed_here": 0,
    "result_spawned_requests": 0,
    "same_host_expansion": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "next_authorized_operation": "execute exactly the one FY2026 Quarter 3 PDF route once in a never-merge transport lane",
}

anchor_ledger = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-anchor-ledger@1",
    "execution_artifact": int(__import__("os").environ["EXECUTION_ARTIFACT_ID"]),
    "surfaces": [
        {
            "route_id": route_id,
            "final_url": surface["final_url"],
            "http_status": surface["http_status"],
            "body_sha256": surface["body_sha256"],
            "visible_text_sha256": surface["visible_text_sha256"],
            "links": surface["links"],
        }
        for route_id, surface in surfaces.items()
    ],
}

receipt = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-adjudication@1",
    "state": "complete",
    "failed_or_final_stage": "complete",
    "exit_code": 0,
    "canonical_parent": __import__("os").environ["CURRENT_MAIN"],
    "execution_artifact": int(__import__("os").environ["EXECUTION_ARTIFACT_ID"]),
    "execution_artifact_digest": __import__("os").environ["EXECUTION_ARTIFACT_DIGEST"],
    "source_admissions": 2,
    "field_decisions": 1,
    "promotion_candidates": 0,
    "held_open_fields": 1,
    "selected_followup_routes": 1,
    "source_requests": 0,
    "route_executions": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
    "next_authorized_operation": "execute the exact FY2026 Quarter 3 waiver-status PDF route once",
}

for name, value in {
    "source-adjudication.json": source_adjudication,
    "field-adjudication.json": field_adjudication,
    "selected-followup-protocol.json": protocol,
    "anchor-ledger.json": anchor_ledger,
    "receipt.json": receipt,
    "summary.json": {
        "schema_version": "ssc-rd04-nd-current-waiver-fna-adjudication-summary@1",
        "state": "complete",
        "source_admissions": 2,
        "field_decisions": 1,
        "promotion_candidates": 0,
        "held_open_fields": 1,
        "selected_followup_routes": 1,
        "source_requests": 0,
        "route_executions": 0,
        "field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
        "class_closed": False,
    },
}.items():
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

print(json.dumps(receipt, sort_keys=True))
