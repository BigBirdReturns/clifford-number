#!/usr/bin/env python3
"""Bounded one-route PDF transport executor for RD-04.

This program performs no source admission or field interpretation. It captures one
frozen HTTPS route, follows only manually validated same-host redirects, writes
per-hop byte custody, and emits a typed zero-effect execution receipt.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import ssl
import subprocess
import sys
import time
from typing import Any
import urllib.error
import urllib.parse
import urllib.request

SCHEMA = "ssc-rd04-nd-current-waiver-fy26q3-execution@1"
ALLOWED_HOSTS = {"fna.usda.gov", "www.fna.usda.gov"}
MAX_BODY_BYTES = 12_000_000
MAX_REQUESTS = 6


def required_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"missing required environment variable: {name}")
    return value


def stable_headers(headers: Any) -> list[dict[str, str]]:
    return [
        {"name": str(key).lower(), "value": str(value)}
        for key, value in sorted(
            headers.items(), key=lambda item: (str(item[0]).lower(), str(item[1]))
        )
    ]


def allowed_https_url(url: str) -> bool:
    parsed = urllib.parse.urlsplit(url)
    return (
        parsed.scheme == "https"
        and (parsed.hostname or "").lower().rstrip(".") in ALLOWED_HOSTS
    )


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[override]
        return None


def write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    if len(sys.argv) != 2:
        raise SystemExit("usage: rd04_fy26q3_executor_v4.py OUTPUT_DIR")

    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)

    current_main = required_env("CURRENT_MAIN")
    route_id = required_env("ROUTE_ID")
    initial_url = required_env("ROUTE_URL")
    adjudication_artifact = int(required_env("ADJUDICATION_ARTIFACT_ID"))
    adjudication_digest = required_env("ADJUDICATION_ARTIFACT_DIGEST")
    adjudication_receipt_sha = required_env("ADJUDICATION_RECEIPT_SHA256")
    protocol_sha = required_env("FOLLOWUP_PROTOCOL_SHA256")

    expected_route_id = "RD04-ND-CURRENT-WAIVER-FY26Q3-001"
    expected_url = (
        "https://www.fna.usda.gov/sites/default/files/resource-files/"
        "FY26-Quarter-3-ABAWD-Waiver-Status.pdf"
    )
    if route_id != expected_route_id or initial_url != expected_url:
        raise RuntimeError("frozen route identity mismatch")
    if not allowed_https_url(initial_url):
        raise RuntimeError("frozen route is outside HTTPS allowlist")

    opener = urllib.request.build_opener(
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),
        NoRedirect(),
    )

    current_url = initial_url
    hops: list[dict[str, Any]] = []
    physical_requests = 0
    terminal: dict[str, Any] | None = None

    for hop_index in range(MAX_REQUESTS):
        if not allowed_https_url(current_url):
            terminal = {
                "terminal_state": "refused_before_request",
                "reason": "scheme_or_host_outside_frozen_allowlist",
                "final_url": current_url,
                "http_status": None,
                "body_bytes": 0,
                "body_sha256": None,
                "content_type": None,
                "pdf_magic": False,
            }
            break

        request = urllib.request.Request(
            current_url,
            method="GET",
            headers={
                "User-Agent": "BigBirdReturns-RD04-bounded-pdf-capture/1.0",
                "Accept": "application/pdf,*/*;q=0.1",
                "Accept-Encoding": "identity",
                "Cache-Control": "no-cache",
            },
        )
        physical_requests += 1
        started = time.monotonic()

        try:
            response = opener.open(request, timeout=90)
            status = int(response.status)
            headers = response.headers
            body = response.read(MAX_BODY_BYTES + 1)
            effective_url = response.geturl()
        except urllib.error.HTTPError as exc:
            status = int(exc.code)
            headers = exc.headers
            body = exc.read(MAX_BODY_BYTES + 1)
            effective_url = exc.geturl()
        except Exception as exc:  # transport failures are terminal evidence
            hop = {
                "hop": hop_index,
                "requested_url": current_url,
                "transport_error": f"{type(exc).__name__}: {exc}",
                "elapsed_ms": round((time.monotonic() - started) * 1000),
            }
            hops.append(hop)
            terminal = {
                "terminal_state": "terminal_transport_without_http_status",
                "reason": hop["transport_error"],
                "final_url": current_url,
                "http_status": None,
                "body_bytes": 0,
                "body_sha256": None,
                "content_type": None,
                "pdf_magic": False,
            }
            break

        elapsed_ms = round((time.monotonic() - started) * 1000)
        body_sha = hashlib.sha256(body).hexdigest()
        content_type = (
            headers.get_content_type()
            if hasattr(headers, "get_content_type")
            else headers.get("Content-Type")
        )
        location = headers.get("Location")
        pdf_magic = body.startswith(b"%PDF-")
        body_limit_exceeded = len(body) > MAX_BODY_BYTES

        body_path = out / f"hop-{hop_index:02d}-body.bin"
        body_path.write_bytes(body)
        hop = {
            "hop": hop_index,
            "requested_url": current_url,
            "effective_url": effective_url,
            "http_status": status,
            "elapsed_ms": elapsed_ms,
            "location": location,
            "headers": stable_headers(headers),
            "body_path": body_path.name,
            "body_bytes": len(body),
            "body_sha256": body_sha,
            "content_type": content_type,
            "body_limit_exceeded": body_limit_exceeded,
            "pdf_magic": pdf_magic,
        }
        hops.append(hop)
        write_json(out / f"hop-{hop_index:02d}-receipt.json", hop)

        if body_limit_exceeded:
            terminal = {
                "terminal_state": "body_limit_exceeded_terminal",
                "reason": "maximum_body_bytes_exceeded",
                "final_url": effective_url,
                "http_status": status,
                "body_bytes": len(body),
                "body_sha256": body_sha,
                "content_type": content_type,
                "pdf_magic": pdf_magic,
            }
            break

        if 300 <= status <= 399:
            if not location:
                terminal = {
                    "terminal_state": "http_redirect_without_location_terminal",
                    "reason": "redirect_missing_location",
                    "final_url": effective_url,
                    "http_status": status,
                    "body_bytes": len(body),
                    "body_sha256": body_sha,
                    "content_type": content_type,
                    "pdf_magic": pdf_magic,
                }
                break
            next_url = urllib.parse.urljoin(effective_url, location)
            if not allowed_https_url(next_url):
                terminal = {
                    "terminal_state": "redirect_refused_terminal",
                    "reason": "redirect_target_outside_frozen_allowlist",
                    "final_url": effective_url,
                    "redirect_target": next_url,
                    "http_status": status,
                    "body_bytes": len(body),
                    "body_sha256": body_sha,
                    "content_type": content_type,
                    "pdf_magic": pdf_magic,
                }
                break
            if hop_index == MAX_REQUESTS - 1:
                terminal = {
                    "terminal_state": "redirect_hop_limit_terminal",
                    "reason": "manual_redirect_hop_limit",
                    "final_url": effective_url,
                    "redirect_target": next_url,
                    "http_status": status,
                    "body_bytes": len(body),
                    "body_sha256": body_sha,
                    "content_type": content_type,
                    "pdf_magic": pdf_magic,
                }
                break
            current_url = next_url
            continue

        if 200 <= status <= 299:
            terminal_state = (
                "http_success_pdf_captured"
                if pdf_magic
                else "http_success_non_pdf_body_captured"
            )
        else:
            terminal_state = "http_non_success_terminal"
        terminal = {
            "terminal_state": terminal_state,
            "reason": None,
            "final_url": effective_url,
            "http_status": status,
            "body_bytes": len(body),
            "body_sha256": body_sha,
            "content_type": content_type,
            "pdf_magic": pdf_magic,
        }
        break

    if terminal is None:
        raise RuntimeError("route did not reach a terminal state")

    route_receipt = {
        "route_id": route_id,
        "requested_url": initial_url,
        "allowed_hosts": sorted(ALLOWED_HOSTS),
        "attempts": 1,
        "redirect_policy": "manual_same_host_only",
        "maximum_body_bytes": MAX_BODY_BYTES,
        "hop_count": len(hops),
        "physical_request_count": physical_requests,
        "hops": hops,
        **terminal,
        "result_spawned_requests": 0,
        "automatic_source_admissions": 0,
        "automatic_field_classifications": 0,
        "automatic_row_terminalizations": 0,
        "automatic_class_closures": 0,
        "outside_human_dependency": False,
    }
    write_json(out / "route-receipt.json", route_receipt)

    execution_head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], text=True
    ).strip()
    receipt = {
        "schema_version": SCHEMA,
        "state": "complete",
        "failed_or_final_stage": "complete",
        "exit_code": 0,
        "issue": 1017,
        "lane_id": "RD-04",
        "class_id": "RD-04-C02",
        "execution_parent": current_main,
        "execution_head": execution_head,
        "adjudication_artifact": adjudication_artifact,
        "adjudication_artifact_digest": adjudication_digest,
        "adjudication_receipt_sha256": adjudication_receipt_sha,
        "followup_protocol_sha256": protocol_sha,
        "fixed_route_ids": [route_id],
        "fixed_route_count": 1,
        "terminal_route_count": 1,
        "physical_requests": physical_requests,
        "route": route_receipt,
        "result_spawned_requests": 0,
        "automatic_source_admissions": 0,
        "automatic_field_classifications": 0,
        "automatic_row_terminalizations": 0,
        "automatic_class_closures": 0,
        "source_admissions": 0,
        "field_terminalizations": 0,
        "matrix_updates": 0,
        "row_state_mutations": 0,
        "class_closed": False,
        "cumulative_ledger_effect": "none",
        "outside_human_dependency": False,
        "publication_effect": "none",
        "adoption_effect": "none",
        "graph_effect": "none",
        "additional_execution_authorized": False,
        "next_authorized_operation": (
            "offline PDF extraction, page-complete review, and field adjudication "
            "over this exact artifact"
        ),
    }
    write_json(out / "execution-receipt.json", receipt)
    print(json.dumps(receipt, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
