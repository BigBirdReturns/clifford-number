set -Eeuo pipefail
CARRIER_BASE='fdcbfbcd7e5a373444b25d3132d058669f8b3a71'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-regenerator-v11.yml'
TARGET='agent/schoolhouse-legal-identity-current-frontier-product-v1'
EXPORT_RUN='31223901158'
EXPORT_HEAD='bf374b46e3eff3d4936cc97e37e9bfdfec91bd6c'
EXPORT_ARTIFACT='9011399743'
EXPORT_BYTES='1918341'
EXPORT_DIGEST='sha256:0009dc40ae1c9be74e4b89c7fd4deb05e8eec3bc5f3fd8b2a88a7dc74e96c28e'
EXPORT_TAR='schoolhouse-legal-identity-frontier-46036c.tar.xz'
EXPORT_TAR_BYTES='706192'
EXPORT_TAR_SHA256='6d2d25325570c28648ca70cf30f9608622e95da078a9c8ec40d9f951eeeda3e2'
GENERATOR_BYTES='40028'
GENERATOR_SHA256='ba698903220655afe0512ebec90f9865ff84b4baa86c7c7d9612db119c7066a0'
GENERATOR_XZ_BYTES='8224'
GENERATOR_XZ_SHA256='25b0d26b58610606e90851536dc23fc4e27d035bb96240e1f1b56deb883e48af'
WORK="$RUNNER_TEMP/schoolhouse-current-frontier-regenerator-v11"
RECEIPT="$RUNNER_TEMP/schoolhouse-current-frontier-materialization-v11"
REPO="$WORK/product-repository"
EXPORT="$WORK/export"
GENERATOR_B64="$WORK/generator.py.xz.b64"
GENERATOR_XZ="$WORK/generator.py.xz"
GENERATOR="$WORK/generator.py"
rm -rf "$WORK" "$RECEIPT"
mkdir -p "$WORK" "$RECEIPT"
printf 'initializing-regeneration-v11\n' > "$RECEIPT/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\n' > "$RECEIPT/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  printf '%s\n' "$rc" > "$RECEIPT/SCRIPT_EXIT_CODE"
  (
    cd "$RECEIPT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-one-workflow-carrier-and-live-main-lease\n' > "$RECEIPT/STAGE"
git fetch --no-tags origin main
test "$(git rev-parse HEAD~4)" = "$CARRIER_BASE"
test "$(git rev-list --count "$CARRIER_BASE"..HEAD)" = '4'
cat > "$WORK/expected-carrier-paths.txt" <<'EOF_CARRIER_PATHS'
.github/materializers/schoolhouse-current-frontier-regenerator-v11/controller-00
.github/materializers/schoolhouse-current-frontier-regenerator-v11/controller-01
.github/materializers/schoolhouse-current-frontier-regenerator-v11/controller-02
.github/workflows/temp-schoolhouse-legal-identity-current-frontier-regenerator-v11.yml
EOF_CARRIER_PATHS
sort -o "$WORK/expected-carrier-paths.txt" "$WORK/expected-carrier-paths.txt"
git diff --name-only "$CARRIER_BASE"..HEAD | sort > "$RECEIPT/carrier-paths.txt"
diff -u "$WORK/expected-carrier-paths.txt" "$RECEIPT/carrier-paths.txt"
git diff --check "$CARRIER_BASE"..HEAD
test "$(git rev-parse origin/main)" = "$CARRIER_BASE"
set +e
git ls-remote --exit-code --heads origin "refs/heads/$TARGET" > "$RECEIPT/preexisting-target-ref.txt"
TARGET_RC="$?"
set -e
test "$TARGET_RC" -eq 2

printf 'reconstructing-authenticated-regenerator\n' > "$RECEIPT/STAGE"
cat > "$GENERATOR_B64" <<'EOF_GENERATOR_B64'
/Td6WFoAAArh+wyhAgAhARwAAAAQz1jM4JxbH8hdABGIQkeKIzPDdw8z/VWX7afH8OoqQzbKL4IkIXByCHUPi1h9BmwHBkSUI67y
v6IJVFPo/NDSTAT/hZVLrtXrStl9xX5E/5fA/fQjq3+/ePlH/+4/RKb3JmquM2czRYTFu5pNwh6JBbXTrdwFLZBydYQI0ObOk3me
uYCSnnn9/vhwQRugrOQNsRprqcc8Mf/YMNo4uF8t9cnw7N0f4fXROT3zRQEl2y8EQTLLf5MsrflGxTnd5IWBjAalJ4tpKIy992sq
T2SiIhCHxfA2okcrjzDrowcB+3skCcuWVhQFV2q0g8/FYwu8Fs8K5yFjs7+799o5K88sv9xAazxb3uAlRRDv1yruuUddzA1yawxB
JJkfsdlW+0tdngthm0oD7fcEB6KNx0s+Pe66qgFN7Q5hhpbO0hpwMKkx3TL6JwUwqZvfo9y1Hjz4c4SJZgdp+HRviWns4MZwurA7
mkajcU/sBYKn2cpEGDP5vMMDaYO3GhzMrdBx+j8+OE7iMEVnlOnz6mbYrT+6KDmKCggCQI4K0eoGIDJcR60SUEzkBgYoVxNcteeC
OyoHmeFn3nZ4l+JCzvfpA2boXB3AzuoYfCi6PD0b0ZUi3WU8RvTSklyAlpXbR5b46TRYp1YTMbjVxLunJ1Th1TV6tcPq9emX88ek
mE/jujTsDWXsw1A6lqbh9CFgPvQODpWi7CW5WJZidIjPXQbWIGjbnmYsSUIp1c8j1/l2RDcGSuxC8yd8x0eF5faK+0VUGa4Lz0r8
9RLw3tdNQYg5FDk5H4gj1IlDVMBYnu9dCPZW5YMuhdEsMxkDmkZ16KrAt3BL7RCOqD7Y1DpY7UJ7CEa/x4c4OCpdi025BW25IXET
ZgdfkeK++cFj8K+XSjBiRTKgkvH8kyaJgrVIt0dj5ReBTQS4Vx6QUqDR3cG/VQ6ksPPxCkuxy/6nh4K+h6y9JmWfL6CmNy3aLyqe
Wt3JTwFjGMHMSvskXReWckrysDpq/kbfoaXoiRc3U+1zkh4p4YPIX6DU8j7i8yIsCNRACcRmVyAI3+UzE/zE0NYQpz3FzA8rpH7I
Idv05eq7iwKT6Qyb6u7eX85vuVYxS3uxjs15XolslF4dBfyDGhq4AxjOy7lZpfldtwTx/MyCkzOMj3Wgunc8wAm9U6eAknDSA0Cg
zvOfD6QimiJ0d2+idFMY7wD4jiwqCUutJ3bPiyGP38W6VohprjU6KOI+KtGcMrytflHst4td5hviFTZC0wrG5riJeeEvMisn9CQt
UtHoWZlLAx0RvLmQlEzKvI0fsorTA2YMYo1qTjo+HHaNwKwJ2olgLME1QUv6ZT1um9VaVSPeGWcNaLYZvYdYR4lPJ1mA1zllAzgW
F6LO3w/Pr4QgjTODiU9QGUhFUFMjn2q3f2ponOKcNzpRPLQEgE/KBHujCiMRgaXEsM0bZ3mM5F7IeSlESbE8LiPoL0o/ejO7lsgC
SwbwbJNus7IHaqJKEQmNIxtRmwu13+7QmQQTFyAehMCQNTQkpt9U58NI9IUttAQFGhom2lMm6+PmirX/ZGaPBmljfRIwIY+xcflW
TereRGFBuBpX1PJq8zPzde54B+/flHn1uZjbRgGDTMQUqUkz1xuqvDNhLTZ+bX/LExy+Y+6qfat1tih7qJFhBj9RqzMO3nlcLXQO
dGMslBoi+x3YYUmwAz53Kw4uO5iPJYowIz0nZKrNk+tpOGzSqhWzow2bNia7l2TpyqL6VupqtWxiwPAHMyUOAp+3r6VGScogJYPi
dD8yjjKFgEgnLFj83dmk6i0PfxCub1VrtvYugpqD4wKa/lHvcY7K5PhoiC7ufyOJj5HivWMFavuYwA6vp6jtpwAyxZOurU+8swQR
CZtSXrpYGF2A2nNSAb2/VXdMtIrgzvtVWbnjtMIXSbAu6aeg0WEtFKHRFb6MomfuIhl1wezEa6E9Zgm1VVya5BVPntJmtvgdrAvF
hCu84E7vY/z56paKrF/YnISRah68Vd+5NDZaRchiqkIcf6ZchSZzktCsLmhTzaBzCXy5B6RkyuO2j/oRXEEw9AefMWCcgznQPcHR
c2WxlkJZ3/eKT3VASHyr7mTlIw1UDbXWtLKYMiz4aeFUHG6kZgcqR1/eLLH6ENuS+fVu/KaTlwERHFcHE0Pnn9VGphicE3pfNqjU
8T2coa/8lmKfm4lYrSv4vec7qQ73ddl8UxaxGcRXKNJxcM9W2rDRt6Hla1QmUmxYvEQm1wpcwvPPSbDIV3XlaqGYLbBcRiIL+rp4
JyhNaOWN2lo542gZq60O3PHoDtyyGbw9A1HIXiivJg4Na5cpfgBoePlEwpU+7hazBANufUbwf1ta5FLJD5SSFF9BOcHip+mD49Ie
xwQXKasVUB02przSL3Z9XUfQmD9hbZ/639gv1Bj0N4oaVjaDhrMJz3f4/UbrnBXc+gt8dkzo+BMs8nsogJOWRJPr0JmI8rIoAQeF
gDDK73ISbwI/yKGRtO8DFCyaI9XU3tmPf7RaR//flqGAWk09vF9C3W62fxG9noynNuKUzqUBNnwiIUw509CpZHF3h+jnBvOQtiMm
dcz6qAmnPkKbXQ2mgWjkyQmakxVj/ET/tpOqDEabKgjAqVOIiYscD+bSIM43U2yZhaLX9aRglBhDWvcx7BCSFe1cgnmGT2AmOpd2
0UZkoSxUi8mZyl+aWBoV/PgMsnkaP1ZbDHgvE5kTizPuThFCUS3leR1jGeahLMQt7kTT6XLfo/8EPK+jTmkEKM9r8+rT7IBA45dQ
15MBgXI29CboZxRdlsKAIf+OyMHn9PbZyTT4afDfR5MbDzJLDBd2lQmy3OwPQ0QorNUYXw+3a347TplIYmzYwgGOwppBbQ288WXH
/C4NGFj9IxV3BuVr1iRIcY5fpcSzkTd4cPmY9K2R+B7C/RFqBD91w0d40C25q1EeX38wkWer5OEZ3sTdp0gzOt1cN+AhLpapvdc0
mReReZw66R3IBZExBHc6zAY/MZGdaSAZKNGiirvKbQeH3vTNl44iIl0NUX7KjVMLoAKmEZO7G5pdgqEJ8IU+agZXv/2MkaHrT3D8
YrcAn6M71n61hgY/0KW8eZ8fQDHq3NWCzXIS2DG7wCrme0Hfk0bEmbtvtpUJRpac/V1lv/2PfOg+JE1FLto7JmrCEkyX4WU8AUS5
Yd+6Mzn7xrB4zFCnx0b2BLLXK3xf722O2OTinZA1V51PHXCiNKVpR1lp/MCOlYk1P/4er5nqOBbMjYWqu8k11wnKrg6vdkVWqTLu
Tg+jMTGfFYQQDUuhdFRAQvUS/0ftJ2BhEtHPMskXy5tQ6Oi//ii3w9J7CLA7i7toTQbZVu9jl5h0Xhlzsib1++3O0Q8d4TvGOjg/
/cHJl63EVZ9tpKS6+rf07T8U1YkdPPb8wfh5v/8uOl97yzO9vA80TaBQzFjw4WDCLjblPRjRQHgJzgXpexQWEb3BDP83SMPnb6uL
sGMHZg2TOAgyhe9ijB123+oRiGt5AWKD6w570bUoOzpv8ALu7Epl+6o7Tw2VLYdqObByCAz/P7HEDHbqy8zIdoZvX11lVXyks+Wb
KROq4QCVx2/9cuFGs0aW7hAPMNyXYtvwOaLExyEwakevMR5NsjBFhufGvBNkRu1sDDxxEqtuTIx3J+UgkcO/ymxqOATGDgmlVUwK
hAWBzXY+N+CZSoz1SV4aqhK4nGJugIJmrkvUDlST1hbNxzAW8CEL9VEXxvwaQar2LxF89io2o66XN34fVLM+Sprvr/BxPq+v10U6
dg1cQxxTJQ+VWMDGp9fL19ALGx42GX1rg3lQkxAjCWQGPtRHTEy4DMw+k4yyjHVRM/y9oLxeCZRQTPRJf8pYxMa8DRilX6fcGr+R
vlOsiVC/bzDjuUb3yP7mj57gWQS66pViGfPDeRMr6EfloIHaU25Rkx0WEP+Vm+mmMNUEdvWNFaXypAOEqKn98hVTb45iiSqqMQPV
FT0GvOi/5i6h4jRqi8yz0nXgLwD1ac5V/A5sOz6P8m179YQ5fTJZ4bPn3U01ilnedYvAMDKwJhMmwKIzvbnxNFfp1vOFvtlcymMg
Tpz/noz4XPgjxMq92bLUkqd6C7j6eNdAw04dpFn7wXGdG+5tl5vbtGF8Aa0sQYYfOi0am+E7IGOOw42g4xzKMKYYsQC7NmkZrvvk
7rqJbpOFTrGdWjLpolfu14ptvu754/Vyua59JxONPN9PqQVH8g0Zl+daSQhLcNQSAo4s5qynQsLNKxDmnRfOrptGMiOgAKNUFHAD
AzFp8a0gLmC1LZHncRv5yHbyEnDjUL7+5J/nUu+1ZVOvCkC93BiRzOxSs+72qag6P3lk4zNzFzFzBbJ+7/VzeUJDOk9pOihpbLdv
7GAsveChrjLyfJ6zXR/8Mg/+TruZsSIQ1u05xNHkAtH4VQoj7JRZz6PWgYQO2egT4hwb18rR+GZgYpP6kw7SwzZsP29hfy95DoQo
r6I7QQpfpMtdvIJuePp2BgBUjWSYGdQ61WeQjr7Y4IoPppIa+ie+bfh+MahFy1QIpaMkeEFtKyMC7G1G+yPGsOeEL56GWEFMfYJx
h8l73Gh8UVgJsa2ALg3qwTQczGhvn3ru2E7j9VpQk6pacNFA1be7+UTiIBIO2LAc6Rucr3KQTDzAkrsl/q+4djq6xhI5aiNpoPZ8
gC75129bOaJQuAL4iB01+/JvJjBXqjvjmRz4aSa8zKOc028MynhaM7hnehk9/hF+/DUlTrJTtsl+7yu/yxafGn5YVIrteIAk2+FV
QVqHzOeAm9sx/Le+Ru1e/pEYHo1SZKpT5g9i1/ucFdM3imREDMJQw+my7V+HTkBnhIwEKINetdPFxsGFZTSJieepDmk5LzXDyLRn
ki1SoW4mwjYRySV1+ExET34hSqi/q0grJYR61FcylowOzqWsKrQlPO5a3U4eKcm0jtMGNTqCdhNJ65+5kgnRKVM67NgCubnhCNjY
aLmoggZI5cveYyhSeFHySRO6Rt3T2AmL5t3aZ+b7HrJHde77N0YjO9GSVpKR9L7wIC1OuOibseb0qVnp+gxmuMThidSbNLYleVq2
dqGKo4eVsNnL2imKllLhuMb7lq6M1E+pFyYbrtmjNcY7efQwhxpnHoM8Z7H4d13A4ZxQh3nzKVpO/Q5nIOQTR45SEMLGFtImdD+2
PaL/OwqWq90A6cXbLqxhivo4kFpoRtzBaDnOzkHCARXejN5ZQXa5GxJgqbar4Vuk4znveSTB/sE7MV5t9VWlCSzCa3SptB5BlXMY
oawXRwlfa1TnW95a2FR6T7+IztN1hnchqmyQZNRoZ4aMT8mbf0mWzv8Ubwut8oI/MtADoitDmzOZJmD/bnBPzl3Ai11kULSy7noF
Eyw6QT4tmElfVYA48pa1C4x6DeQDmgMnShOpuN4evhbihO8RLkoKE4l7GjytzjqTkENiMBDKKE7DZiuMW+EInRYmYUE5Rn6EFrjl
r5aZ8N0739Esv/fK/ogdOof4CBTvUnG9Woiwz5sdYpPGWv7XTFK6ymzLChcCh4wxWkd3AXjd3PRgJA9ga77Rf9roVSaT+x/R+ETC
U1yG75aNdh2Aq9FyHEqIfQDcVLtW507o0FpKfi7xutCjraTXjmEDF5shyQub3NXagYLltInqBi0BRemn4rGeZrpCi/DNfzZgipLl
AqwsYvWgpA2oAv2I1zzKKe0QooOZqTV0cU+hCXypUutwo46Xg4C+8xW/hVH0EAS2tRW6ptn6KSo6bOcbp1domE1eOm+FCehvpAVA
I5IcVzV/InKMYRAvsRjSAXc5ig55jH8rYcR5BBn2C57dPsX3Ga91mJwzRw+3ZFwB5cqkDvdpSwWDyqvJqAA4N8D+KhCDI7Ley0eJ
m65H1beRsCtnjFe1NU9kjjkdkiMkAKMzaUcErU2cbbNQ4f1VOvUe8LwZMx8vAEB4rApw/5UUptzakTv1yEBmdaOIcDl5DjNBNGRn
IMTyOkL92cLeAR5kOP/gGnQreI4UGpRplptctIyy/UZYEYiOwGbICxBCROw1xbfWVYeXB98i1qCcCNMOf8BcEITW0LBCT0EmnwzP
R9Iv/KfWfkm1ZQYGaMqmzV9d5b8nxqruBjZ+oBmG/vH9Ih6FEFdt7qJUwReWu5pb21zLWsg0Jpx/oM1H6uV4NPDqpevY0OMucVls
Oa1eJmXkryn0m4rhmrOxKAhyNF+eAi14ZUBX8SRrYq2pQt/4krm9MZ4QucVJKnkXNGbyKxT59nugWYPryFA+DdHPklL7Rj6lW/AC
PsM3ooc3FwbIhliICbJ903uMj4/NBHJnRs0Be+qOEia0a4ksH5uPmOQ4SKaZxfPtoashfvDi8hOISuOj1M9XmgHWn7dCPo2tEeq9
t6av4YQ54IgXRI0qg7Opt9RaApYad4gpYISqWratami4FGBjnXCIRN7SL7FjLtQgWAngjAQOHA1+B8r3lU530vRdFzpaQxO0ETvI
ggNdrrU8Q2K/5Zw4iDC491eElbX+VkPOB8u79o96S8gy1VL3MtcLt5eB0oVpyZ3vX3yRmQ8sfC+gAJQKHiFmnxxVpYbMrAcD76Z6
wpYTD6Z/8Co3T7HoFEtz5nTkGizX9AeYJ94wFXM2J1n2B15P7bGvRWQMZyV/ul2UDDicsXw5u4j8ieKVWT6LjmF102AIyhpfnuIz
zP9nDbVqo04kuWycIScjEz8doFf6JH4tIqWEAGNogXxLkPRFOLEQa3pCW8U1aRSwfraePcgoRYi/+pxDDjnwFUAni60/1A9aBYPA
oM97w+R249q3QRjuwekVm0/Qurw0UFNCfrKKPpOhuc448ZlgPrJh8CbivQ+pEIc+OCkpnPOlsGEF9YTEEXpSWuu4t6kt8KwUluSe
WyUEEDfMJ0Ld0uRfgMWm04o+ago64TZsdSU5GkIPByp3OFC6w84+CTEWB2AywQS2hWMiO08SIiKnY0M1woYsPE2grcfVXe7x3tGp
wcqqy08vJekmGPlru546t6tm0BoyN54/uhRUq9Jh4Pfe8U/1TQUJUaUVJL3t2aFfkpi6/mepYVWYnM8nr/iEWA3FR3ly30F3E61Q
w8ecV0d4Rapesj1Bup51URjI5dpgGrrRYKKwyp5SzQwPhIBkDA0ZyIXWKPu/LZPRyLuxGICk4eFAZiU4BDrqmzhzuI2bn1+HwfTx
J2tL8BBfNmRsL53+iJi8POjIEEWtZkVHFXNFAZ4DHzu4OpgH/+SJHndsARdWeyiAYnMa2D0iJd4CR6zMUeSO5UzNrKpc3pqEv566
6eolRFXEqYRlUnDOfDJI//CXbIXKbHBP2F5kU7F5RlB1LutLP5cp4ssDnVfw0lk5yRdP9hdGbQrO228IxGLRpGITWRPjlC9aOBBu
DAo9bot/J65u++BAAd89+67nqNyIgvC2yA2eao1lXCOk2twgzu4yOWO7VKZL8LDMchPZLWu4/+BEpth61nX382duEHdLQIuLjTgQ
hd4YnF3YbUWH+5nWAgCmMNGch1q3B23d0qkAPf7mYTR9qbCW/X41fxmtxo6vTWBIXsOd18uXfw1B7PK7eozIOx/oVVxd4JYUNumj
UNS5s6Dcv/TaEmxTm/x5AhG5r6NB8p1/UQi/NP6VYmC1hGOvWac64cKdSvDq2/r+Q6f2QdC97cTxF+r6ax4RRhfuRBDArQGoUoKE
sKolLOc+x1nJ8iTZcpCrt0UFMhZeZL3hvN0tswHlDfeiAJoWErtZbohBjWSZfUVD0sGfmSWStwtZH2qTmsIjGPh2kyf+tYicKItu
5XOuX9UIaruWgbVnzJ6vyT8MrlTVQ6N6mzfJmV6iJL2nVSz1C9DYICo/A5jZpbSTPiH5pBNnu+/kmDhIsUi6DSsuOyhU9l7BznO2
h0whj9m/XBMap6zsU6YlFvvbAMux4+B+C0ShPugMVJVbkzprGIbZ454RANv3HjnwHrVyZbZc5Tws5ctWBH4enZDIYuA+fRgpjpi4
+NiiFpYFpU7gazZc0Wr1fKlbBkxlqUDeik74838xmus9MTyU/fA1wsWvevu4/cPC5/0KAyexwFsrWetZFi2yyc8Nskjea6QGqu3+
G9zjPZyo8WAQdXNQq+plwFN5ykZGcKEqfa2DbON+dFbNmmrd6dJycKpknnbUsjQ7PkF0rO/wYnfeT3NQA1Vpdxv0ov6oDEV3Q+Dd
ZibVN1H5r7vitB2ABvmvJqNOFZn2BeUlmWL91sxVzr6Rz/OLC1VEz+RFR0JyJZWPXxyMq91ZRS474FPnBMSVpfyqiyAY60aqfS8C
59nfVW/6lwosncaFTD+vHSfFa/uPpmuIXq6BThiMMZh3uXF3XEt4pwZX5cHvdrZfeBQkhGc6ATkug1zwHbESF+uO50JOLCNiss/x
xQBYt/VNC+C+HYYDV55LTECnBq7SD2NVOV968cuXAjCLYdpj1Mv9x03kUNgm7ITXRmpJaW1AIITr2d88fyH+167JhBPk8Fb1bZ/A
SUxx+P7u8Wti6/Gsl0WLQY5wYwCSCSdbaUKtX8omk3zOTugYQtVag5nwMiDjcay0fsHksA8j8y2zb3F8hTy0yV6eswHMh1lZRZhb
7Gv9EJRj/EJ9E61JGPL/N24yQYlaNhqIeOqtvZVkU7no7KzOMQaAEqZEaObmDVjZb6+EdjAgVIJ4qxCRdxva8/zPqCWqr8TbocbD
M8Yef6lU0zNY7kSjmmaKqpZe2b9MeuNuGn1HyoXNvNawhzMaSGg0Uv8az0KgduA5r0bru7oQG8gTNKALGav7rj0mtElzy2hvhOLd
R+RcZZQOtHye43pk0NQdVNfAGlWBXuHnLAxl7CO6OKtR6t0OfgEQHNUHdooUzGWfZuXO4bd4y8ycFe9cIsXemcudhHvU/sbONqRl
uDvBq9xaZqsGyFt3zvsioKz3U85cxlIB3pHPkBrd7ahiukdgQU7tCxKOe5tHcsA3rjl3NutkrmyKu6sIqntA1RSzff5hNQJrYbhi
kdnjAZ38IC2HnfcfmxEVxsa+CFiC7La8Lk2KYxqQ1AFSlJW7wGFY6V50CsSV8yu/jkJ62rgJluvPgTaiV//UjM1k9t1E1iKxdzdz
uzW3WafH/S28vG9CJFG8G3h6I/uKob+3p8HsUXorRGBW5KEumbeHNcOCdMmrUUBo0Qgs2yx17UBhJTwTBA7qOa9X+HhFCTOPOms0
jBpOZ62qNZ61KxzxblPvBfK0BD/lanzIsUozIjKMyCrd6norRiS4VY6gOlYSoXbcDDkV3Sck0XuAXAGxr7Hu0JoYxri1YRuYb52F
5C+uSnbzoOgryCM1OM1HJCx3VSPiQcBvTw3xHIM/Li2rxdLxD6AZ3BNHWKUttA9j11g7ORRcMzYFd7kdfA+F46JdCP5NLyCUUnnf
NHzSuTaeR16UxMifiHEUxBjSl/4Q3U8Woa4BqdOnyRCQqB6wFzlMRz3YqoGyA6WWr28RvzEmxkR5rrLjnIRbUrRu4XANdYUSmNQM
TzYQgUyWjs8fpvmfClOI5c6lm6NooJGjkTxgRzt12FSqwh0P7c9dQHk9EzAkC9I2Dz0fWK4B1MVVeThzP3xNpC+t71B0yq4QmHwO
eCD7sdIooLf4t6MqLijtswsSpaCi6UTFD+RNNqLrvY8cRGM1+j1ZvLhckEU+Yh+MgPpYc6URQE2P5i/k5DzrO5ImharMpfMqpHXv
2/QyfEwEltLLJ6XI5wGb0FY6pkeZqWKpZhnuMwKcIjuriUy7/SSh5AKua+wLwB+FUBTwpGQdOCnOJmucw9uZIXob5bY9ZeIRaE5s
JUJOyKK9TZpRgkQ2cIioeHN2HjIlACpTA/N3xSIrQzq8+r8oEyRAjJlBLamvwALzvJKbcfQ49BCE69IXZTwD3LaO3dWl39KBU699
dUXq8ntSEltrPOJrFPQLdmR5PpP1GJJIGiueEDuH18qiHkde4yiizbkAie0XwG2M2EbGw43Ro5occx2ePEJRxftI49XHRAoSdo37
90EIKRNJrCjfE4VEjc0auUMJiEmnL3xxhOqG93F8x8fk0cgXTEQ/94bRH5ItsijKSAtpuxPOSa+HNJH4WDAesc117nN7l+yUb/h9
GG+Epj26Tnyn8SJUc+v8xZsPw5gLs3kqy901sorOplESKulEEnNDuxaZMNgmaPMkNTIlTVWpj/mgB1n0qjiJWYJtrsYScWM4BOO9
+uFrgc9wIOGUy4dXZyMgISX9N5niW+nESVafvnup8Mp2PAWX0DCRYrFh3VI+Gvq23AS2wLXaIVu4948yeQqc/2Rh7FjtjSZfWcFE
v6dpbXNyt0A7li/4xNaKsoHvo1xpUeedqbulL3APO8bjsSviBa763Kl4CpJWZoidLXX1pVZ/kLj1x9TD9lwV1mXwlUHq6F4t61h2
WdoujHrvbcnk7D0ZDHuG3sA86PpaiGPQlmbg2AO2q3db/qpWtYBjiLIQ0+UjQeztMEeF5QHfgtaG741c5FWYNNxMvFBSHqEDUR/W
C3MQwSRzjB7UgYbz5+xzr+uQGmOBBozMXuTKf6ItKToi6vXCMwSxXypmrVMvnFKbKV5qbusfYpMX+2bA93onN0MHklscLtHRZBdh
pTz9AbaHvxicBs5MM6Hcjyh/AnJXPfUCnv0bjyHQScaSNzQehhc08smNIZtk3aJA/r6LO5lqNbct189cgUPijGvuzwHq+ir6t8At
z92EY6ZfU9qqGhUrvuoMoyVhw4GqmWFwtxgIITuSxfRghcz5U90LVhjPR61KvfGpkGsfvENEQOHmkyWy2TpVzUBXcemGqMZP2o/6
iNhSx/xvhvRSVCbosqExdfknyktNCOyBfvo9szoutAIny/UHg2WZUs/dK0VTMB/Q82IzxwvtPf7iDekMbVH0InJ8igC6aYkDIgZV
r+BRLr7JD5hl/4S0uqhsfH2WEtsRnHBmoAAB/D/cuAIA4+mNF7bp3xwCAAAAAApZWg==
EOF_GENERATOR_B64
base64 --decode "$GENERATOR_B64" > "$GENERATOR_XZ"
test "$(stat -c%s "$GENERATOR_XZ")" = "$GENERATOR_XZ_BYTES"
test "$(sha256sum "$GENERATOR_XZ" | cut -d' ' -f1)" = "$GENERATOR_XZ_SHA256"
xz --decompress --stdout "$GENERATOR_XZ" > "$GENERATOR"
test "$(stat -c%s "$GENERATOR")" = "$GENERATOR_BYTES"
test "$(sha256sum "$GENERATOR" | cut -d' ' -f1)" = "$GENERATOR_SHA256"
python -m py_compile "$GENERATOR"
chmod 0755 "$GENERATOR"

printf 'authenticating-read-only-233-file-export\n' > "$RECEIPT/STAGE"
gh api "repos/$GITHUB_REPOSITORY/actions/runs/$EXPORT_RUN" > "$RECEIPT/export-run.json"
test "$(jq -r .head_sha "$RECEIPT/export-run.json")" = "$EXPORT_HEAD"
test "$(jq -r .status "$RECEIPT/export-run.json")" = 'completed'
test "$(jq -r .conclusion "$RECEIPT/export-run.json")" = 'success'
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$EXPORT_ARTIFACT" > "$RECEIPT/export-artifact-metadata.json"
test "$(jq -r .size_in_bytes "$RECEIPT/export-artifact-metadata.json")" = "$EXPORT_BYTES"
test "$(jq -r .digest "$RECEIPT/export-artifact-metadata.json")" = "$EXPORT_DIGEST"
test "$(jq -r .workflow_run.id "$RECEIPT/export-artifact-metadata.json")" = "$EXPORT_RUN"
test "$(jq -r .expired "$RECEIPT/export-artifact-metadata.json")" = 'false'
gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$EXPORT_ARTIFACT/zip" > "$WORK/export.zip"
test "$(stat -c%s "$WORK/export.zip")" = "$EXPORT_BYTES"
test "sha256:$(sha256sum "$WORK/export.zip" | cut -d' ' -f1)" = "$EXPORT_DIGEST"
mkdir -p "$EXPORT" "$EXPORT/repo"
unzip -q "$WORK/export.zip" -d "$EXPORT"
(
  cd "$EXPORT"
  sha256sum -c SHA256SUMS > "$RECEIPT/export-internal-sha256.log"
)
test "$(stat -c%s "$EXPORT/$EXPORT_TAR")" = "$EXPORT_TAR_BYTES"
test "$(sha256sum "$EXPORT/$EXPORT_TAR" | cut -d' ' -f1)" = "$EXPORT_TAR_SHA256"
tar -xJf "$EXPORT/$EXPORT_TAR" -C "$EXPORT/repo"
test "$(find "$EXPORT/repo" -type f | wc -l | tr -d ' ')" = '233'

printf 'regenerating-eleven-path-product-on-live-parent\n' > "$RECEIPT/STAGE"
BASE="$CARRIER_BASE"
BASE_TREE="$(git rev-parse "$BASE^{tree}")"
git worktree add --detach "$REPO" "$BASE"
python "$GENERATOR" \
  --repo "$REPO" \
  --export "$EXPORT" \
  --parent "$BASE" \
  --parent-tree "$BASE_TREE" \
  --receipt "$RECEIPT/regeneration.json" \
  > "$RECEIPT/generated-product-manifest.json"

cat > "$WORK/expected-paths.txt" <<'EOF_EXPECTED_PATHS'
data/intake/bvvc-defense-capital/acquisition-frontier.json
data/intake/bvvc-defense-capital/manifest.json
data/intake/bvvc-defense-capital/schoolhouse.json
data/intake/schoolhouse-legal-identity-current-frontier-v1/canonical-slice-manifest.jsonl
data/intake/schoolhouse-legal-identity-current-frontier-v1/frontier-reconciliation.json
data/intake/schoolhouse-legal-identity-current-frontier-v1/next-source-gate.json
data/intake/schoolhouse-legal-identity-current-frontier-v1/product-manifest.json
data/intake/schoolhouse-legal-identity-current-frontier-v1/source-custody.json
data/intake/schoolhouse-legal-identity-current-frontier-v1/source-lanes.json
docs/milestones/schoolhouse-legal-identity-current-frontier-v1.md
tools/validate-schoolhouse-legal-identity-current-frontier.py
EOF_EXPECTED_PATHS
sed -i 's/^          //' "$WORK/expected-paths.txt"
sort -o "$WORK/expected-paths.txt" "$WORK/expected-paths.txt"
python - "$WORK/expected-status.txt" <<'PY_EXPECTED_STATUS'
from pathlib import Path
rows = [
    ('M', 'data/intake/bvvc-defense-capital/acquisition-frontier.json'),
    ('M', 'data/intake/bvvc-defense-capital/manifest.json'),
    ('M', 'data/intake/bvvc-defense-capital/schoolhouse.json'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/canonical-slice-manifest.jsonl'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/frontier-reconciliation.json'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/next-source-gate.json'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/product-manifest.json'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/source-custody.json'),
    ('A', 'data/intake/schoolhouse-legal-identity-current-frontier-v1/source-lanes.json'),
    ('A', 'docs/milestones/schoolhouse-legal-identity-current-frontier-v1.md'),
    ('A', 'tools/validate-schoolhouse-legal-identity-current-frontier.py'),
]
Path(__import__('sys').argv[1]).write_text(''.join(f'{state}\t{path}\n' for state, path in sorted(rows)))
PY_EXPECTED_STATUS

cd "$REPO"
chmod 0755 tools/validate-schoolhouse-legal-identity-current-frontier.py
git add --pathspec-from-file="$WORK/expected-paths.txt"
git diff --cached --name-only | sort > "$RECEIPT/product-paths.txt"
diff -u "$WORK/expected-paths.txt" "$RECEIPT/product-paths.txt"
git diff --cached --name-status | sort > "$RECEIPT/product-status.txt"
diff -u "$WORK/expected-status.txt" "$RECEIPT/product-status.txt"
git diff --cached --check
! git diff --cached --name-only | grep -q '^\.github/workflows/'

git config user.name 'School.House current-frontier regenerator'
git config user.email 'actions@users.noreply.github.com'
git config commit.gpgsign false
git commit \
  -m 'Reconcile the current School.House legal-identity frontier' \
  -m 'Bind the authenticated 233-file source snapshot, compose twenty-three terminal source lanes, repair the central projection, and install a changed-input gate with zero active source leases and no successor candidate. Preserve zero identity, relationship, absence, outside-human, publication, adoption, or graph authority.'
PRODUCT_COMMIT="$(git rev-parse HEAD)"
PRODUCT_TREE="$(git rev-parse 'HEAD^{tree}')"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
git diff --name-only "$BASE"..HEAD | sort > "$RECEIPT/product-commit-paths.txt"
diff -u "$WORK/expected-paths.txt" "$RECEIPT/product-commit-paths.txt"

printf 'running-focused-and-complete-gates\n' > "$RECEIPT/STAGE"
python -m py_compile tools/validate-schoolhouse-legal-identity-current-frontier.py
python tools/validate-schoolhouse-legal-identity-current-frontier.py --self-test | tee "$RECEIPT/focused-validator.log"
node tools/validate-bvvc-defense-capital.mjs | tee "$RECEIPT/bvvc-validator.log"
node tools/validate-no-magic-human-gate.mjs | tee "$RECEIPT/no-magic-human.log"
npm run release:check > "$RECEIPT/release-check.log" 2>&1

printf 'restoring-and-replaying-product\n' > "$RECEIPT/STAGE"
git reset --hard "$PRODUCT_COMMIT"
git clean -fd
python tools/validate-schoolhouse-legal-identity-current-frontier.py --self-test | tee "$RECEIPT/deterministic-replay.log"
node tools/validate-bvvc-defense-capital.mjs | tee "$RECEIPT/bvvc-validator-replay.log"
node tools/validate-no-magic-human-gate.mjs | tee "$RECEIPT/no-magic-human-replay.log"
test -z "$(git status --porcelain)"

printf 'leasing-and-pushing-workflow-free-product\n' > "$RECEIPT/STAGE"
git fetch --no-tags origin main
test "$(git rev-parse origin/main)" = "$BASE"
set +e
git ls-remote --exit-code --heads origin "refs/heads/$TARGET" > "$RECEIPT/prepush-target-ref.txt"
TARGET_RC="$?"
set -e
test "$TARGET_RC" -eq 2
git push origin "$PRODUCT_COMMIT:refs/heads/$TARGET" |& tee "$RECEIPT/push.log"
REMOTE_TARGET="$(git ls-remote --heads origin "refs/heads/$TARGET" | awk '{print $1}')"
test "$REMOTE_TARGET" = "$PRODUCT_COMMIT"
mapfile -t PRODUCT_PATHS < "$WORK/expected-paths.txt"
git ls-tree -r "$PRODUCT_COMMIT" -- "${PRODUCT_PATHS[@]}" > "$RECEIPT/product-ls-tree.txt"
test "$(wc -l < "$RECEIPT/product-ls-tree.txt" | tr -d ' ')" = '11'

python - "$RECEIPT/materialization.json" "$BASE" "$BASE_TREE" "$PRODUCT_COMMIT" "$PRODUCT_TREE" "$REMOTE_TARGET" <<'PY_RECEIPT'
from pathlib import Path
import json, sys
output, parent, parent_tree, product, product_tree, remote = sys.argv[1:]
value = {
    'schema_version': 'schoolhouse-legal-identity-current-frontier-materialization@2',
    'status': 'complete',
    'issue': 1421,
    'product_parent': parent,
    'product_parent_tree': parent_tree,
    'product_commit': product,
    'product_tree': product_tree,
    'remote_target': remote,
    'target_branch': 'agent/schoolhouse-legal-identity-current-frontier-product-v1',
    'product_commit_count': 1,
    'permanent_path_count': 11,
    'modified_path_count': 3,
    'addition_path_count': 8,
    'workflow_paths': 0,
    'source_canonical_main': '46036c01eaba31bdb18045307fe3ebcb67d576a6',
    'source_canonical_tree': '0ffec7018bcfc038a73cd280970f783d12a5c222',
    'export_workflow_run': 31223901158,
    'export_artifact_id': 9011399743,
    'export_artifact_digest': 'sha256:0009dc40ae1c9be74e4b89c7fd4deb05e8eec3bc5f3fd8b2a88a7dc74e96c28e',
    'source_slice_files': 233,
    'source_lanes': 23,
    'central_projection_lanes': 15,
    'post_cutoff_lanes': 8,
    'active_source_leases': 0,
    'candidate_successors': 0,
    'focused_validation': 'pass',
    'adversarial_refusals': 15,
    'bvvc_validation': 'pass',
    'no_magic_human_gate': 'pass',
    'complete_release_gate': 'pass',
    'deterministic_replay': 'pass',
    'post_restore_clean': True,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
    'public_schoolhouse_legal_identity': 'unresolved',
}
Path(output).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
PY_RECEIPT
{
  printf 'product_parent=%s\n' "$BASE"
  printf 'product_parent_tree=%s\n' "$BASE_TREE"
  printf 'product_commit=%s\n' "$PRODUCT_COMMIT"
  printf 'product_tree=%s\n' "$PRODUCT_TREE"
  printf 'target_branch=%s\n' "$TARGET"
  printf 'remote_target=%s\n' "$REMOTE_TARGET"
} > "$RECEIPT/product-proof.txt"
printf 'complete\n' > "$RECEIPT/STAGE"
cat "$RECEIPT/materialization.json"
