<!-- m04g-global-orbit-proof:31368749496 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31368749496
- Head: `283c5993cb2ac0bff173c72aba70088c67b2ac3c`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `16/25` (`0.64`)
- Content success: `14/25` (`0.56`)
- Metadata only: `2`
- Failed: `9`
- Healthy basins: `0/5`
- Proof SHA-256: `f796984f8bdf780d5092ccbefe441b8b82dd38c309ebe01f74198e9082b5eded`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 2 | 2 | 0 | 3 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
