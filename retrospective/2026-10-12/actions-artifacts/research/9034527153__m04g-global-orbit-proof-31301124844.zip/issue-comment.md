<!-- m04g-global-orbit-proof:31301124844 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/31301124844
- Head: `4ba77ed1364a6e331d18d3e9307189b74eed7fb7`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `18/25` (`0.72`)
- Content success: `16/25` (`0.64`)
- Metadata only: `2`
- Failed: `7`
- Healthy basins: `0/5`
- Proof SHA-256: `d1cfd0db14343460133c3ecd0bd6c04869e2651a8846b7971c19a57725ec0352`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 2 | 1 | 1 | 3 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
