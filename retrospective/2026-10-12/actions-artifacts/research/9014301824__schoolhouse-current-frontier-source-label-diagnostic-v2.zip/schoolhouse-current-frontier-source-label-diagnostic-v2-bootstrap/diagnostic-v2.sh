set -Eeuo pipefail
BASE='1e52a58be874538509d6c0d3c06adc12fc53cad7'
WORKFLOW='.github/workflows/temp-schoolhouse-legal-identity-current-frontier-materializer-v5.yml'
SOURCE_BRANCH='agent/schoolhouse-legal-identity-current-frontier-materializer-v1'
SOURCE_HEAD='901c16b0a8f32bfe2a83c4e0d619d3168cd668ff'
SOURCE_PAYLOAD='.github/materializers/schoolhouse-current-frontier-v1'
OUT="$RUNNER_TEMP/schoolhouse-current-frontier-source-label-diagnostic-v2"
RECOVERED="$RUNNER_TEMP/schoolhouse-current-frontier-source-label-diagnostic-v2-chunks"
rm -rf "$OUT" "$RECOVERED"
mkdir -p "$OUT" "$RECOVERED"
printf 'initializing\n' > "$OUT/STAGE"
printf 'source_requests=0\nregistry_queries=0\nform_submissions=0\ncontacts=0\npayments=0\nuploads=0\n' > "$OUT/BOUNDARY"

finalize() {
  rc="$?"
  trap - EXIT
  printf '%s\n' "$rc" > "$OUT/DIAGNOSTIC_EXIT_CODE"
  (
    cd "$OUT"
    find . -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > SHA256SUMS
  )
  exit "$rc"
}
trap finalize EXIT

printf 'proving-carrier-and-source-topology\n' > "$OUT/STAGE"
git fetch --no-tags origin main "$SOURCE_BRANCH"
test "$(git rev-parse HEAD^)" = "$BASE"
test "$(git rev-list --count "$BASE"..HEAD)" = '1'
mapfile -t paths < <(git diff --name-only "$BASE"..HEAD)
test "${#paths[@]}" -eq 1
test "${paths[0]}" = "$WORKFLOW"
git diff --check "$BASE"..HEAD
git merge-base --is-ancestor "$BASE" "$(git rev-parse origin/main)"
test "$(git rev-parse "origin/$SOURCE_BRANCH")" = "$SOURCE_HEAD"
test "$(git rev-list --count "$BASE".."$SOURCE_HEAD")" = '13'

cat > "$OUT/expected.tsv" <<'EOF_EXPECTED'
controller	0	controller-00	c38b28b1598f126d2727a4d9228f494e4c1079d5	5000	ec8b175c1473fd9f7f7c893a495269df2dfd440e4960f9d74487d706c14060f9	window
controller	1	controller-01	4b80357e74d23fe7edb0e7ce25052e1929f81db0	5000	8e69b377c4a4208bded118d4b8477a9ceac6ef35e66931455816ce786a1e54e2	window
controller	2	controller-02	9ceb01ab8c0f5efd09e26d66672a6dc9ceaf248d	5000	f764d261b300f0062345e7df8c5a6d530455560896094b405df87520f7be618f	window
controller	3	controller-03	9175ec1ad24346b9db9ab88722bb02ae1020414b	5000	79b2e68a76dc3ff0d13ec8c30cbedc8c41cbb8c5fc01cd95d94c2dbd513af2ee	window
controller	4	controller-04	22d3e5b938499d0b56df11ac1a9211e05712dc30	456	0bdb8068c48e536d5d6698be2bc58031af338bedd7cb2231148e959af4170f68	append_one_lf
payload	0	part-00	417dab959423065d8cbfbe9af183cde4b7c5fd25	10000	e932c87c3204e01fc208e6c2e3e46b86e255d42d57dadd1360e65f80269ae12b	window
payload	1	part-01	35607251fbb7fcf7370b710a0baf1e99f196577b	10000	f814e46666d96edaf076c6d8b992310e66baa62cc58622083955e38b7752e6d2	window
payload	2	part-02	ebd9841e850cef407c4d35191e234ec86a9da407	10000	a2c3a61652bde254bb66dd7e27546bfd2c3bc078220aae89aa7ebbca482fda89	window
payload	3	part-03	21971133a07421db3e3c219473c717d54e3479fb	10000	55b32a2d8c045e8cb2f2eebb565b70a5a3155b84746b05ac4895438487887f2f	window
payload	4	part-04	fc8dc1c4bb1cf991ae4a7f74f723569fa7307bf6	10000	ce1a3e3f3c19cd97215580d8f0fd1f7548c633828f468d0f0949a891fc8639c8	window
payload	5	part-05	5fb94d345a19f9b7df3fdc778ca2a89c03d18b57	10000	116a5d7864e3557b40ee4a4f35c466c6e0e82b13fc14d4326841dd86e2772a04	window
payload	6	part-06	70c0d173f6b887ebc5f488ac407b504ee2a95835	5880	22a59c63b9aeea9f8a27febcaf5a0b12d34a07fc7c5340c1142825e0ec53339d	window
EOF_EXPECTED
sed -i 's/^          //' "$OUT/expected.tsv"

printf 'recovering-and-adjudicating-all-twelve-chunks\n' > "$OUT/STAGE"
python - "$SOURCE_HEAD" "$SOURCE_PAYLOAD" "$OUT" "$RECOVERED" <<'PY'
from pathlib import Path
import hashlib
import json
import subprocess
import sys

head, root, out_raw, recovered_raw = sys.argv[1:]
out = Path(out_raw)
recovered = Path(recovered_raw)

expected = []
for line in (out / 'expected.tsv').read_text(encoding='utf-8').splitlines():
    kind, ordinal, name, old_blob, size, digest, mode = line.split('\t')
    expected.append(
        (kind, int(ordinal), name, old_blob, int(size), digest, mode)
    )

def git(*args: str) -> bytes:
    return subprocess.run(
        ['git', *args],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout

def blob_id(data: bytes) -> str:
    header = f'blob {len(data)}\0'.encode()
    return hashlib.sha1(header + data).hexdigest()

rows = []
for kind, ordinal, name, old_blob, size, digest, mode in expected:
    path = f'{root}/{name}'
    spec = f'{head}:{path}'
    source_blob = git('rev-parse', spec).decode().strip()
    source = git('cat-file', 'blob', spec)
    synthesized_suffix_hex = ''
    synthesized_bytes = 0

    if mode == 'window':
        offsets = [
            offset
            for offset in range(len(source) - size + 1)
            if hashlib.sha256(source[offset:offset + size]).hexdigest()
            == digest
        ]
        assert len(offsets) == 1, {
            'path': path,
            'mode': mode,
            'size': size,
            'sha256': digest,
            'source_bytes': len(source),
            'matching_offsets': offsets,
        }
        offset = offsets[0]
        chunk = source[offset:offset + size]
    elif mode == 'append_one_lf':
        assert name == 'controller-04'
        assert len(source) + 1 == size, {
            'path': path,
            'source_bytes': len(source),
            'expected_bytes': size,
        }
        assert source.endswith(b'\n')
        chunk = source + b'\n'
        assert hashlib.sha256(chunk).hexdigest() == digest
        offset = 0
        synthesized_suffix_hex = '0a'
        synthesized_bytes = 1
    else:
        raise AssertionError({'path': path, 'unsupported_mode': mode})

    assert len(chunk) == size
    assert hashlib.sha256(chunk).hexdigest() == digest
    reconstructed_blob = blob_id(chunk)
    (recovered / name).write_bytes(chunk)
    rows.append(
        {
            'kind': kind,
            'ordinal': ordinal,
            'name': name,
            'source_path': path,
            'source_blob': source_blob,
            'source_bytes': len(source),
            'source_sha256': hashlib.sha256(source).hexdigest(),
            'reconstruction_mode': mode,
            'window_offset': offset,
            'window_length': size,
            'window_sha256': digest,
            'synthesized_suffix_hex': synthesized_suffix_hex,
            'synthesized_bytes': synthesized_bytes,
            'historical_git_blob_label': old_blob,
            'reconstructed_git_blob': reconstructed_blob,
            'blob_label_match': reconstructed_blob == old_blob,
        }
    )

controller = b''.join(
    (recovered / f'controller-{index:02d}').read_bytes()
    for index in range(5)
)
payload = b''.join(
    (recovered / f'part-{index:02d}').read_bytes()
    for index in range(7)
)
assert len(controller) == 20456
assert hashlib.sha256(controller).hexdigest() == (
    '7f0cd764206a434841307110ff72d555580fea79215159786bdf96e1afe216bd'
)
assert len(payload) == 65880
assert hashlib.sha256(payload).hexdigest() == (
    '2ef3e418be0d06986d9825f7810e69e700884fc70a437c93bb381c40dd627aaa'
)

mismatches = [row for row in rows if not row['blob_label_match']]
synthesized = [row for row in rows if row['synthesized_bytes']]
receipt = {
    'schema_version': (
        'schoolhouse-current-frontier-source-label-diagnostic@2'
    ),
    'state': 'diagnostic_complete',
    'source_head': head,
    'source_path_count': len(rows),
    'recovered_chunk_count': len(rows),
    'unique_window_chunk_count': sum(
        row['reconstruction_mode'] == 'window' for row in rows
    ),
    'terminal_lf_repair_chunk_count': len(synthesized),
    'synthesized_byte_count': sum(
        row['synthesized_bytes'] for row in rows
    ),
    'historical_blob_label_mismatch_count': len(mismatches),
    'historical_blob_label_match_count': len(rows) - len(mismatches),
    'all_historical_blob_labels_match_reconstructed_bytes': (
        not mismatches
    ),
    'controller_bytes': len(controller),
    'controller_sha256': hashlib.sha256(controller).hexdigest(),
    'payload_b64_bytes': len(payload),
    'payload_b64_sha256': hashlib.sha256(payload).hexdigest(),
    'windows': rows,
    'source_requests': 0,
    'registry_queries': 0,
    'form_submissions': 0,
    'identity_admissions': 0,
    'relationship_admissions': 0,
    'negative_existence_claims': 0,
    'outside_human_dependency': False,
    'controller_executed': False,
    'product_written': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(out / 'diagnostic.json').write_text(
    json.dumps(receipt, indent=2, sort_keys=True) + '\n',
    encoding='utf-8',
)
with (out / 'diagnostic.tsv').open('w', encoding='utf-8') as handle:
    handle.write(
        'kind\tordinal\tname\tsource_blob\tsource_bytes\t'
        'reconstruction_mode\twindow_offset\twindow_length\t'
        'window_sha256\tsynthesized_suffix_hex\tsynthesized_bytes\t'
        'historical_git_blob_label\treconstructed_git_blob\t'
        'blob_label_match\n'
    )
    for row in rows:
        handle.write(
            f"{row['kind']}\t{row['ordinal']}\t{row['name']}\t"
            f"{row['source_blob']}\t{row['source_bytes']}\t"
            f"{row['reconstruction_mode']}\t"
            f"{row['window_offset']}\t{row['window_length']}\t"
            f"{row['window_sha256']}\t"
            f"{row['synthesized_suffix_hex']}\t"
            f"{row['synthesized_bytes']}\t"
            f"{row['historical_git_blob_label']}\t"
            f"{row['reconstructed_git_blob']}\t"
            f"{str(row['blob_label_match']).lower()}\n"
        )

print(
    'diagnostic_complete '
    f"chunks={len(rows)} "
    f"label_matches={len(rows) - len(mismatches)} "
    f"label_mismatches={len(mismatches)} "
    f"synthesized_bytes={sum(row['synthesized_bytes'] for row in rows)}"
)
if mismatches:
    raise SystemExit(42)
PY

printf 'unexpected-full-label-consistency\n' > "$OUT/STAGE"
exit 44

