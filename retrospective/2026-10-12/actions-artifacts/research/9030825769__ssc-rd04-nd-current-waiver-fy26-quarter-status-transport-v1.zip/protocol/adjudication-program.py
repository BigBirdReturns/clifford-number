from __future__ import annotations

import hashlib
import json
import os
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin

transport = Path(sys.argv[1])
out = Path(sys.argv[2])
matrix_path = Path(os.environ["MATRIX_PATH"])


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable(value):
    if isinstance(value, dict):
        return {key: stable(value[key]) for key in sorted(value)}
    if isinstance(value, list):
        return [stable(item) for item in value]
    return value


def object_digest(value) -> str:
    return sha256(json.dumps(stable(value), separators=(",", ":"), ensure_ascii=False).encode())


class LinkParser(HTMLParser):
    def __init__(self, base_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.stack: list[dict] = []
        self.links: list[dict] = []
        self.iframes: list[dict] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag.lower() == "a" and values.get("href"):
            self.stack.append({"href": urljoin(self.base_url, values["href"] or ""), "parts": []})
        elif tag.lower() == "iframe" and values.get("src"):
            self.iframes.append({
                "src": urljoin(self.base_url, values["src"] or ""),
                "title": values.get("title"),
            })

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self.stack:
            current = self.stack.pop()
            current["text"] = " ".join(" ".join(current["parts"]).split())
            current.pop("parts")
            self.links.append(current)

    def handle_data(self, data: str) -> None:
        if self.stack:
            self.stack[-1]["parts"].append(data)


execution_receipt = json.loads((transport / "execution-receipt.json").read_text())
assert execution_receipt["state"] == "transport_complete"
assert execution_receipt["canonical_parent"] == os.environ["TRANSPORT_CANONICAL_PARENT"]
assert execution_receipt["canonical_tree"] == os.environ["TRANSPORT_CANONICAL_TREE"]
assert execution_receipt["carrier_head"] == os.environ["TRANSPORT_HEAD"]
assert execution_receipt["fixed_routes"] == 4
assert execution_receipt["initiated_route_attempts"] == 4
assert execution_receipt["terminal_routes"] == 4
assert execution_receipt["physical_requests"] == 6
assert execution_receipt["http_success_routes"] == 3
assert execution_receipt["http_non_success_routes"] == 1
assert execution_receipt["transport_error_routes"] == 0
assert execution_receipt["followed_redirects"] == 2
assert execution_receipt["refused_redirects"] == 0
assert execution_receipt["result_spawned_requests"] == 0
assert execution_receipt["source_admissions"] == 0
assert execution_receipt["field_classifications"] == 0
assert execution_receipt["field_terminalizations"] == 0
assert execution_receipt["matrix_updates"] == 0
assert execution_receipt["row_state_mutations"] == 0
assert execution_receipt["class_closed"] is False
assert execution_receipt["additional_execution_authorized"] is False

assert sha256((transport / "execution-receipt.json").read_bytes()) == os.environ["TRANSPORT_RECEIPT_SHA256"]
assert sha256((transport / "route-receipts.jsonl").read_bytes()) == os.environ["ROUTE_RECEIPTS_SHA256"]
assert sha256((transport / "physical-requests.jsonl").read_bytes()) == os.environ["PHYSICAL_REQUESTS_SHA256"]
assert sha256((transport / "request-plan.json").read_bytes()) == os.environ["REQUEST_PLAN_SHA256"]
assert sha256((transport / "authority-boundary.json").read_bytes()) == os.environ["TRANSPORT_AUTHORITY_SHA256"]

route_rows = [json.loads(line) for line in (transport / "route-receipts.jsonl").read_text().splitlines() if line]
assert len(route_rows) == 4
routes = {row["route_id"]: row for row in route_rows}
expected = {
    "RD04-ND-CURRENT-WAIVER-FNA-001": {
        "status": 200,
        "final_url": "https://www.fna.usda.gov/snap/waivers/timelimit",
        "body_sha256": "300035d49923fcaf8dfcbd54a99388d7b67af58ebb0b713b49548ff824e9a7f3",
        "text_sha256": "3f95f0d5aa6c7727e3077b7ce0aa48d8c26a639d9915e2bace065892797a5e2b",
    },
    "RD04-ND-CURRENT-WAIVER-FNA-002": {
        "status": 404,
        "final_url": "https://www.fna.usda.gov/snap/statewide-able-bodied-adults-without-dependent-waivers-effective-immediately-eligible-states",
        "body_sha256": "02fd72e7135514260a447c234944c325fa83bf248439296bd7a000740b01ea97",
        "text_sha256": "a619bdab18ae23c2c2dfd1e1b357b76470b3d3efdd68a06a3439f8d7424ee30a",
    },
    "RD04-ND-CURRENT-WAIVER-FNA-003": {
        "status": 200,
        "final_url": "https://www.fna.usda.gov/snap/work-requirements",
        "body_sha256": "2477832ad3dce9398dbe1e6158347175c729fbe8ef46fe261fbd12d338794f11",
        "text_sha256": "a5b563abe3d50c37f8c5dd40a90bc894ab48d5da3881f115839375a83be7bfea",
    },
    "RD04-ND-CURRENT-WAIVER-FNA-004": {
        "status": 200,
        "final_url": "https://www.fna.usda.gov/snap/obbb-implementation",
        "body_sha256": "aaec6c27abf3e25dc6e995b7dd74c6a16b24e18846dc896f404872ee7de42661",
        "text_sha256": "939e7bf22b7cac72dd7570c47c96a8bab2430f05d23930cc5634e95da15ea1ce",
    },
}
for route_id, values in expected.items():
    row = routes[route_id]
    assert row["final_status_code"] == values["status"]
    assert row["final_url"] == values["final_url"]
    assert row["final_body_sha256"] == values["body_sha256"]
    assert row["visible_text_sha256"] == values["text_sha256"]
    assert row["attempts_authorized"] == 1 and row["attempts_initiated"] == 1
    assert row["result_spawned_requests"] == 0
    assert row["source_admissions"] == 0
    assert row["field_classifications"] == 0
    assert row["field_terminalizations"] == 0
    assert row["matrix_updates"] == 0
    assert row["row_state_mutations"] == 0
    assert row["class_closed"] is False
    assert sha256((transport / row["final_body_path"]).read_bytes()) == values["body_sha256"]
    assert sha256((transport / row["visible_text_path"]).read_bytes()) == values["text_sha256"]

text1 = (transport / routes["RD04-ND-CURRENT-WAIVER-FNA-001"]["visible_text_path"]).read_text()
text2 = (transport / routes["RD04-ND-CURRENT-WAIVER-FNA-002"]["visible_text_path"]).read_text()
text3 = (transport / routes["RD04-ND-CURRENT-WAIVER-FNA-003"]["visible_text_path"]).read_text()
text4 = (transport / routes["RD04-ND-CURRENT-WAIVER-FNA-004"]["visible_text_path"]).read_text()
for anchor in (
    "Time Limit Waivers",
    "states to ask us to temporarily waive the time limit",
    "This page also includes information on waiver status by state by fiscal quarter.",
    "FY 2026",
    "Quarter 1 (.pdf)",
    "Quarter 2 (.pdf)",
    "Quarter 3 (.pdf)",
    "Page updated: July 16, 2026",
):
    assert anchor in text1, anchor
assert "Page or Content Not Found" in text2 and "The page you are looking for is not available." in text2
for anchor in (
    "SNAP Work Requirements",
    "changes the work requirements for SNAP able-bodied adults without dependents",
    "changes to the ABAWD exception criteria and ABAWD waiver criteria",
    "We will update this page once the guidance is released.",
    "Page updated: July 16, 2026",
):
    assert anchor in text3, anchor
for anchor in (
    "SNAP Provisions of the One Big Beautiful Bill Act of 2025",
    "Information Memorandum",
    "USDA Guidance Portal",
    "Page updated: February 25, 2026",
):
    assert anchor in text4, anchor

page1_body = transport / routes["RD04-ND-CURRENT-WAIVER-FNA-001"]["final_body_path"]
parser1 = LinkParser(routes["RD04-ND-CURRENT-WAIVER-FNA-001"]["final_url"])
parser1.feed(page1_body.read_text(encoding="utf-8", errors="replace"))
quarter_specs = [
    (1, "FY26-Quarter-1-ABAWD-Waiver-Status.pdf", "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-1-ABAWD-Waiver-Status.pdf"),
    (2, "FY26-Quarter-2-ABAWD-Waiver-Status.pdf", "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-2-ABAWD-Waiver-Status.pdf"),
    (3, "FY26-Quarter-3-ABAWD-Waiver-Status.pdf", "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-3-ABAWD-Waiver-Status.pdf"),
]
locator_rows = []
for quarter, filename, url in quarter_specs:
    matches = [link for link in parser1.links if link["href"] == url]
    assert len(matches) == 1, (url, matches)
    anchor = matches[0]["text"]
    assert f"Quarter {quarter}" in anchor and ".pdf" in anchor
    locator_rows.append({
        "ordinal": quarter,
        "quarter": quarter,
        "anchor": anchor,
        "url": url,
        "filename": filename,
        "locator_route_id": "RD04-ND-CURRENT-WAIVER-FNA-001",
        "locator_body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-001"]["body_sha256"],
    })

page4_body = transport / routes["RD04-ND-CURRENT-WAIVER-FNA-004"]["final_body_path"]
parser4 = LinkParser(routes["RD04-ND-CURRENT-WAIVER-FNA-004"]["final_url"])
parser4.feed(page4_body.read_text(encoding="utf-8", errors="replace"))
assert any(item["src"] == "https://www.usda.gov/sites/default/files/guidance-documents/fns.snap-obbb-implementation.pdf" for item in parser4.iframes)

matrix = json.loads(matrix_path.read_text())
nd = next(row for row in matrix["rows"] if row["unit_id"] == "US-STATE-ND")
cell = next(item for item in nd["cells"] if item["field_id"] == "abawd_or_work_requirement_waiver_state_and_governing_period")
assert (nd["row_state"], nd["terminal_fields"], nd["open_fields"]) == ("still_open", 7, 2)
assert object_digest(nd) == os.environ["ND_ROW_SHA256"]
assert cell["state"] == "still_open" and cell["terminal"] is False
assert object_digest(cell) == os.environ["WAIVER_CELL_SHA256"]

authority = {
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
}
source_adjudication = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-transport-source-adjudication@1",
    "object_type": "source_adjudication",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "transport_artifact_id": int(os.environ["TRANSPORT_ARTIFACT_ID"]),
    "decisions": [
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-001",
            "disposition": "admitted_for_current_federal_time_limit_waiver_index_and_fy26_quarter_document_locator_role",
            "body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-001"]["body_sha256"],
            "visible_text_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-001"]["text_sha256"],
            "document_updated": "2026-07-16",
            "finding": "The current FNA page defines the time-limit waiver mechanism, states that it publishes waiver status by state by fiscal quarter, and links the FY 2026 Quarter 1 through Quarter 3 status documents.",
            "not_admitted_for": ["north_dakota_quarter_status", "north_dakota_waiver_geography", "north_dakota_governing_period"],
            "source_admission_count": 1,
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-002",
            "disposition": "rejected_current_404_surface",
            "body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-002"]["body_sha256"],
            "visible_text_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-002"]["text_sha256"],
            "finding": "The selected historical path returns the current FNA Page or Content Not Found surface.",
            "not_admitted_for": ["absence_of_waiver", "north_dakota_status", "historical_statewide_eligibility"],
            "source_admission_count": 0,
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-003",
            "disposition": "admitted_for_current_general_work_requirement_and_pending_guidance_context_only",
            "body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-003"]["body_sha256"],
            "visible_text_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-003"]["text_sha256"],
            "document_updated": "2026-07-16",
            "finding": "The current work-requirements page states that FNA is preparing guidance on the 2025 law's changes to ABAWD exception and waiver criteria and will update the page when guidance is released.",
            "not_admitted_for": ["north_dakota_waiver_status", "north_dakota_waiver_geography", "north_dakota_governing_period"],
            "source_admission_count": 1,
        },
        {
            "route_id": "RD04-ND-CURRENT-WAIVER-FNA-004",
            "disposition": "admitted_for_current_obbb_information_memorandum_locator_role_only",
            "body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-004"]["body_sha256"],
            "visible_text_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-004"]["text_sha256"],
            "document_updated": "2026-02-25",
            "finding": "The current FNA page identifies and embeds the federal SNAP OBBB information memorandum.",
            "not_admitted_for": ["north_dakota_waiver_status", "north_dakota_waiver_geography", "north_dakota_governing_period", "memorandum_content_not_captured_here"],
            "source_admission_count": 1,
        },
    ],
    "source_admissions": 3,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "authority_boundary": authority,
}
field_adjudication = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-transport-field-adjudication@1",
    "object_type": "field_adjudication",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
    "current_cell_canonical_sha256": os.environ["WAIVER_CELL_SHA256"],
    "disposition": "current_federal_status_index_and_exact_fy26_quarter_documents_located_but_state_documents_uncaptured_hold_open",
    "promotion_candidate": False,
    "rationale": "The transport establishes the current official status index and exact FY 2026 Quarter 1 through Quarter 3 document URLs, but the quarterly document bodies containing state-specific status have not been contacted or captured.",
    "prohibited_inferences": [
        "do_not_treat_the_404_route_as_absence_of_a_north_dakota_waiver",
        "do_not_treat_locator_links_as_quarter_document_content",
        "do_not_infer_north_dakota_status_from_general_waiver_criteria",
        "do_not_infer_current_status_from_the_hhs_implementation_page_alone",
        "do_not_close_the_north_dakota_row",
        "do_not_close_rd04_c02",
    ],
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "authority_boundary": authority,
}
locator_inventory = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-locator-inventory@1",
    "object_type": "artifact_derived_locator_inventory",
    "transport_artifact_id": int(os.environ["TRANSPORT_ARTIFACT_ID"]),
    "locator_route_id": "RD04-ND-CURRENT-WAIVER-FNA-001",
    "locator_final_url": routes["RD04-ND-CURRENT-WAIVER-FNA-001"]["final_url"],
    "locator_body_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-001"]["body_sha256"],
    "locator_visible_text_sha256": expected["RD04-ND-CURRENT-WAIVER-FNA-001"]["text_sha256"],
    "document_updated": "2026-07-16",
    "rows": locator_rows,
    "row_count": 3,
    "network_requests_executed_here": 0,
}
selected_protocol = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-status-followup-protocol@1",
    "object_type": "selected_followup_protocol",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "target_field_id": "abawd_or_work_requirement_waiver_state_and_governing_period",
    "selection_basis": "exact FY 2026 Quarter 1 through Quarter 3 PDF hrefs preserved in the admitted current FNA time-limit-waiver index body",
    "locator_inventory_sha256": object_digest(locator_inventory),
    "routes": [
        {
            "ordinal": row["ordinal"],
            "route_id": f"RD04-ND-CURRENT-WAIVER-FY26-Q{row['quarter']}-STATUS-PDF",
            "url": row["url"],
            "route_category": "current_federal_quarterly_state_waiver_status_pdf",
            "allowed_hosts": ["fna.usda.gov", "www.fna.usda.gov"],
            "attempts": 1,
            "redirects": "manual_same_host_only",
            "maximum_body_bytes": 12_000_000,
            "expected_media_type": "application/pdf",
        }
        for row in locator_rows
    ],
    "route_count": 3,
    "same_host_expansion": 0,
    "result_spawned_requests": 0,
    "source_requests_executed_here": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "next_authorized_operation": "execute exactly the three FY 2026 quarter status PDF routes once in a never-merge transport lane",
}
summary = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-transport-adjudication-summary@1",
    "state": "complete",
    "transport_artifact_id": int(os.environ["TRANSPORT_ARTIFACT_ID"]),
    "source_admissions": 3,
    "source_rejections": 1,
    "field_decisions": 1,
    "promotion_candidates": 0,
    "held_open_fields": 1,
    "selected_followup_routes": 3,
    "source_requests": 0,
    "route_executions": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
}
receipt = {
    "schema_version": "ssc-rd04-nd-current-waiver-fna-transport-adjudication@1",
    "state": "complete",
    "failed_or_final_stage": "complete",
    "exit_code": 0,
    "canonical_parent": os.environ["CANONICAL_PARENT"],
    "canonical_tree": os.environ["CURRENT_CANONICAL_TREE"],
    "transport_artifact_id": int(os.environ["TRANSPORT_ARTIFACT_ID"]),
    "transport_artifact_sha256": os.environ["TRANSPORT_ARTIFACT_SHA256"],
    "transport_receipt_sha256": os.environ["TRANSPORT_RECEIPT_SHA256"],
    "source_admissions": 3,
    "source_rejections": 1,
    "field_decisions": 1,
    "promotion_candidates": 0,
    "held_open_fields": 1,
    "selected_followup_routes": 3,
    "source_requests": 0,
    "route_executions": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
    "next_authorized_operation": "execute the exact FY 2026 Quarter 1 through Quarter 3 status PDFs once; do not rerun the four FNA page routes",
}

for name, value in (
    ("source-adjudication.json", source_adjudication),
    ("field-adjudication.json", field_adjudication),
    ("locator-inventory.json", locator_inventory),
    ("selected-followup-protocol.json", selected_protocol),
    ("summary.json", summary),
    ("receipt.json", receipt),
):
    (out / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

assert json.loads((out / "selected-followup-protocol.json").read_text())["route_count"] == 3
assert json.loads((out / "field-adjudication.json").read_text())["promotion_candidate"] is False
