from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit, urlunsplit

protocol_path = Path(sys.argv[1])
out = Path(sys.argv[2])
headers_dir = out / "headers"
bodies_dir = out / "bodies"
stderr_dir = out / "stderr"
for directory in (headers_dir, bodies_dir, stderr_dir):
    directory.mkdir(parents=True, exist_ok=True)

expected_routes = [
    {
        "ordinal": 1,
        "route_id": "RD04-ND-CURRENT-WAIVER-FY26-Q1-STATUS-PDF",
        "url": "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-1-ABAWD-Waiver-Status.pdf",
        "route_category": "current_federal_quarterly_state_waiver_status_pdf",
    },
    {
        "ordinal": 2,
        "route_id": "RD04-ND-CURRENT-WAIVER-FY26-Q2-STATUS-PDF",
        "url": "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-2-ABAWD-Waiver-Status.pdf",
        "route_category": "current_federal_quarterly_state_waiver_status_pdf",
    },
    {
        "ordinal": 3,
        "route_id": "RD04-ND-CURRENT-WAIVER-FY26-Q3-STATUS-PDF",
        "url": "https://www.fna.usda.gov/sites/default/files/resource-files/FY26-Quarter-3-ABAWD-Waiver-Status.pdf",
        "route_category": "current_federal_quarterly_state_waiver_status_pdf",
    },
]
redirect_codes = {301, 302, 303, 307, 308}
max_redirects = 5
user_agent = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0 Safari/537.36 "
    "ssc-rd04-nd-fy26-quarter-status-transport/1.0"
)


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def stable_json(value: object) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def canonical_redirect_url(raw: str, base: str) -> str:
    target = urljoin(base, raw)
    parts = urlsplit(target)
    if parts.scheme != "https":
        raise ValueError(f"redirect scheme is not https: {parts.scheme!r}")
    return urlunsplit(
        (
            "https",
            parts.netloc.lower(),
            re.sub(r"/{2,}", "/", parts.path or "/"),
            parts.query,
            "",
        )
    )


def parse_last_headers(raw: bytes) -> tuple[int | None, dict[str, list[str]]]:
    normalized = raw.replace(b"\r\n", b"\n")
    blocks = [block for block in normalized.split(b"\n\n") if block.strip()]
    selected: bytes | None = None
    for block in blocks:
        if block.lstrip().startswith(b"HTTP/"):
            selected = block
    if selected is None:
        return None, {}
    lines = selected.decode("iso-8859-1", errors="replace").splitlines()
    match = re.match(r"HTTP/\S+\s+(\d{3})", lines[0])
    status = int(match.group(1)) if match else None
    headers: dict[str, list[str]] = {}
    current_name: str | None = None
    for line in lines[1:]:
        if line.startswith((" ", "\t")) and current_name:
            headers[current_name][-1] += " " + line.strip()
            continue
        if ":" not in line:
            continue
        name, value = line.split(":", 1)
        current_name = name.strip().lower()
        headers.setdefault(current_name, []).append(value.strip())
    return status, headers


protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
assert protocol["schema_version"] == "ssc-rd04-nd-current-waiver-fy26-quarter-status-followup-protocol@1"
assert protocol["issue"] == 1017
assert protocol["class_id"] == "RD-04-C02"
assert protocol["unit_id"] == "US-STATE-ND"
assert protocol["target_field_id"] == "abawd_or_work_requirement_waiver_state_and_governing_period"
assert protocol["route_count"] == 3
assert protocol["same_host_expansion"] == 0
assert protocol["result_spawned_requests"] == 0
assert protocol["source_requests_executed_here"] == 0
assert protocol["field_terminalizations"] == 0
assert protocol["matrix_updates"] == 0
assert protocol["row_state_mutations"] == 0
assert protocol["class_closed"] is False
assert protocol["outside_human_dependency"] is False
assert protocol["next_authorized_operation"] == "execute exactly the three FY 2026 quarter status PDF routes once in a never-merge transport lane"
routes = protocol["routes"]
assert len(routes) == len(expected_routes)
for route, expected in zip(routes, expected_routes, strict=True):
    for key, value in expected.items():
        assert route[key] == value, (key, route[key], value)
    assert route["allowed_hosts"] == ["fna.usda.gov", "www.fna.usda.gov"]
    assert route["attempts"] == 1
    assert route["redirects"] == "manual_same_host_only"
    assert route["maximum_body_bytes"] == 12_000_000
    assert route["expected_media_type"] == "application/pdf"

plan = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-status-three-route-plan@1",
    "protocol_artifact_id": int(os.environ["PROTOCOL_ARTIFACT_ID"]),
    "protocol_sha256": os.environ["PROTOCOL_SHA256"],
    "canonical_parent": os.environ["CANONICAL_PARENT"],
    "canonical_tree": os.environ["CANONICAL_TREE"],
    "carrier_head": os.environ["HEAD_SHA"],
    "routes": routes,
    "fixed_routes": 3,
    "attempts_per_route": 1,
    "maximum_redirects_per_route_attempt": max_redirects,
    "same_host_expansion": 0,
    "result_spawned_requests": 0,
    "semantic_authority": "none",
}
(out / "request-plan.json").write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n", encoding="utf-8")

route_receipts: list[dict] = []
physical_requests: list[dict] = []
followed_redirects = 0
refused_redirects = 0

for route in routes:
    ordinal = route["ordinal"]
    route_id = route["route_id"]
    current_url = route["url"]
    allowed_hosts = set(route["allowed_hosts"])
    maximum_body_bytes = route["maximum_body_bytes"]
    expected_media_type = route["expected_media_type"]
    cookie_jar = out / f"cookies-{ordinal:02d}.txt"
    cookie_jar.touch()
    contacted_urls: list[str] = []
    contacted_hosts: list[str] = []
    redirect_chain: list[dict] = []
    terminal_error: str | None = None
    final_url: str | None = None
    final_status: int | None = None
    final_content_type: str | None = None
    final_media_type: str | None = None
    final_body_path: str | None = None
    final_body_sha256: str | None = None
    final_body_bytes = 0
    final_pdf_magic = False
    final_media_type_matches_expected = False
    outcome = "transport_error"

    for hop_index in range(max_redirects + 1):
        parts = urlsplit(current_url)
        host = (parts.hostname or "").lower()
        if parts.scheme != "https" or host not in allowed_hosts:
            terminal_error = f"contact refused before request: scheme={parts.scheme!r} host={host!r}"
            outcome = "refused_before_contact"
            break

        hop = hop_index + 1
        stem = f"{ordinal:02d}-{route_id}-hop-{hop:02d}"
        header_file = headers_dir / f"{stem}.headers"
        body_file = bodies_dir / f"{stem}.bin"
        stderr_file = stderr_dir / f"{stem}.stderr"
        started = time.monotonic()
        command = [
            "curl",
            "--silent",
            "--show-error",
            "--request", "GET",
            "--proto", "=https",
            "--tlsv1.2",
            "--connect-timeout", "15",
            "--max-time", "90",
            "--max-filesize", str(maximum_body_bytes),
            "--dump-header", str(header_file),
            "--output", str(body_file),
            "--write-out", "%{json}",
            "--user-agent", user_agent,
            "--header", "Accept: application/pdf,*/*;q=0.8",
            "--header", "Accept-Language: en-US,en;q=0.8",
            "--header", "Cache-Control: no-cache",
            "--cookie", str(cookie_jar),
            "--cookie-jar", str(cookie_jar),
            "--url", current_url,
        ]
        completed = subprocess.run(command, capture_output=True, text=True, check=False)
        elapsed_ms = int((time.monotonic() - started) * 1000)
        stderr_file.write_text(completed.stderr, encoding="utf-8")
        curl_meta: dict[str, object] = {}
        if completed.stdout.strip():
            try:
                curl_meta = json.loads(completed.stdout)
            except json.JSONDecodeError:
                curl_meta = {"unparsed_write_out": completed.stdout}
        raw_headers = header_file.read_bytes() if header_file.exists() else b""
        parsed_status, parsed_headers = parse_last_headers(raw_headers)
        body = body_file.read_bytes() if body_file.exists() else b""
        status = parsed_status
        if status is None and isinstance(curl_meta.get("http_code"), int):
            status = int(curl_meta["http_code"])
        content_type_values = parsed_headers.get("content-type", [])
        content_type = content_type_values[-1] if content_type_values else None
        media_type = (content_type or "").split(";", 1)[0].strip().lower()
        request_row = {
            "route_ordinal": ordinal,
            "route_id": route_id,
            "hop": hop,
            "request_url": current_url,
            "request_host": host,
            "curl_exit_code": completed.returncode,
            "elapsed_ms": elapsed_ms,
            "status_code": status,
            "content_type": content_type,
            "media_type": media_type or None,
            "raw_headers_path": str(header_file.relative_to(out)) if header_file.exists() else None,
            "raw_headers_bytes": len(raw_headers),
            "raw_headers_sha256": sha256(raw_headers),
            "body_path": str(body_file.relative_to(out)) if body_file.exists() else None,
            "body_bytes": len(body),
            "body_sha256": sha256(body),
            "pdf_magic": body.startswith(b"%PDF-"),
            "stderr_path": str(stderr_file.relative_to(out)),
            "curl_metadata": curl_meta,
        }
        physical_requests.append(request_row)
        contacted_urls.append(current_url)
        contacted_hosts.append(host)

        if completed.returncode != 0:
            outcome = "terminal_transport_error"
            terminal_error = f"curl exit {completed.returncode}: {completed.stderr.strip()}"
            final_url = current_url
            final_status = status
            final_content_type = content_type
            final_media_type = media_type or None
            final_body_path = request_row["body_path"]
            final_body_sha256 = request_row["body_sha256"]
            final_body_bytes = len(body)
            final_pdf_magic = request_row["pdf_magic"]
            final_media_type_matches_expected = media_type == expected_media_type
            break
        if len(body) > maximum_body_bytes:
            outcome = "terminal_body_size_refusal"
            terminal_error = f"captured body exceeds {maximum_body_bytes} bytes"
            final_url = current_url
            final_status = status
            final_content_type = content_type
            final_media_type = media_type or None
            final_body_path = request_row["body_path"]
            final_body_sha256 = request_row["body_sha256"]
            final_body_bytes = len(body)
            final_pdf_magic = request_row["pdf_magic"]
            final_media_type_matches_expected = media_type == expected_media_type
            break

        locations = parsed_headers.get("location", [])
        if status in redirect_codes and locations:
            location = locations[-1]
            try:
                target_url = canonical_redirect_url(location, current_url)
                target_host = (urlsplit(target_url).hostname or "").lower()
                target_allowed = target_host in allowed_hosts
            except Exception as exc:
                target_url = urljoin(current_url, location)
                target_host = (urlsplit(target_url).hostname or "").lower()
                target_allowed = False
                terminal_error = f"invalid redirect target: {type(exc).__name__}: {exc}"
            redirect_row = {
                "hop": hop,
                "from_url": current_url,
                "status_code": status,
                "location": location,
                "target_url": target_url,
                "target_host": target_host or None,
                "target_allowed": target_allowed,
                "action": "follow_frozen_host_redirect" if target_allowed and hop_index < max_redirects else "refuse_before_contact",
            }
            redirect_chain.append(redirect_row)
            if not target_allowed:
                refused_redirects += 1
                outcome = "terminal_redirect_refused_before_contact"
                terminal_error = terminal_error or f"redirect target outside frozen hosts: {target_host or '[missing]'}"
                final_url = current_url
                final_status = status
                final_content_type = content_type
                final_media_type = media_type or None
                final_body_path = request_row["body_path"]
                final_body_sha256 = request_row["body_sha256"]
                final_body_bytes = len(body)
                final_pdf_magic = request_row["pdf_magic"]
                final_media_type_matches_expected = media_type == expected_media_type
                break
            if hop_index >= max_redirects:
                refused_redirects += 1
                outcome = "terminal_redirect_ceiling_refusal"
                terminal_error = f"redirect ceiling exceeded: {max_redirects}"
                final_url = current_url
                final_status = status
                final_content_type = content_type
                final_media_type = media_type or None
                final_body_path = request_row["body_path"]
                final_body_sha256 = request_row["body_sha256"]
                final_body_bytes = len(body)
                final_pdf_magic = request_row["pdf_magic"]
                final_media_type_matches_expected = media_type == expected_media_type
                break
            followed_redirects += 1
            current_url = target_url
            continue

        final_url = current_url
        final_status = status
        final_content_type = content_type
        final_media_type = media_type or None
        final_body_path = request_row["body_path"]
        final_body_sha256 = request_row["body_sha256"]
        final_body_bytes = len(body)
        final_pdf_magic = request_row["pdf_magic"]
        final_media_type_matches_expected = media_type == expected_media_type
        outcome = "terminal_http_success_body_captured" if status is not None and 200 <= status < 300 else "terminal_http_non_success_body_captured"
        break

    cookie_jar.unlink(missing_ok=True)
    route_receipts.append(
        {
            "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-status-route-receipt@1",
            "ordinal": ordinal,
            "route_id": route_id,
            "route_category": route["route_category"],
            "target_field_id": protocol["target_field_id"],
            "requested_url": route["url"],
            "allowed_hosts": route["allowed_hosts"],
            "expected_media_type": expected_media_type,
            "attempts_authorized": 1,
            "attempts_initiated": 1,
            "physical_request_count": len(contacted_urls),
            "contacted_urls": contacted_urls,
            "contacted_hosts": contacted_hosts,
            "redirect_count": len(redirect_chain),
            "redirect_chain": redirect_chain,
            "final_url": final_url,
            "final_status_code": final_status,
            "final_content_type": final_content_type,
            "final_media_type": final_media_type,
            "final_media_type_matches_expected": final_media_type_matches_expected,
            "final_body_path": final_body_path,
            "final_body_bytes": final_body_bytes,
            "final_body_sha256": final_body_sha256,
            "final_pdf_magic": final_pdf_magic,
            "outcome": outcome,
            "error": terminal_error,
            "result_spawned_requests": 0,
            "source_admissions": 0,
            "field_classifications": 0,
            "field_terminalizations": 0,
            "matrix_updates": 0,
            "row_state_mutations": 0,
            "class_closed": False,
        }
    )

assert len(route_receipts) == 3
assert [row["route_id"] for row in route_receipts] == [row["route_id"] for row in expected_routes]
assert all(row["attempts_initiated"] == 1 for row in route_receipts)
assert all(row["result_spawned_requests"] == 0 for row in route_receipts)
assert len(physical_requests) <= 3 * (max_redirects + 1)

with (out / "route-receipts.jsonl").open("w", encoding="utf-8") as handle:
    for row in route_receipts:
        handle.write(stable_json(row) + "\n")
with (out / "physical-requests.jsonl").open("w", encoding="utf-8") as handle:
    for row in physical_requests:
        handle.write(stable_json(row) + "\n")

success_routes = sum(row["outcome"] == "terminal_http_success_body_captured" for row in route_receipts)
non_success_routes = sum(row["outcome"] == "terminal_http_non_success_body_captured" for row in route_receipts)
transport_error_routes = sum(row["outcome"] == "terminal_transport_error" for row in route_receipts)
pdf_magic_routes = sum(bool(row["final_pdf_magic"]) for row in route_receipts)
expected_media_type_routes = sum(bool(row["final_media_type_matches_expected"]) for row in route_receipts)
final_body_bytes = sum(row["final_body_bytes"] for row in route_receipts)
receipt = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-status-three-route-transport@1",
    "state": "transport_complete",
    "failed_or_final_stage": "complete",
    "exit_code": 0,
    "canonical_parent": os.environ["CANONICAL_PARENT"],
    "canonical_tree": os.environ["CANONICAL_TREE"],
    "carrier_head": os.environ["HEAD_SHA"],
    "protocol_artifact_id": int(os.environ["PROTOCOL_ARTIFACT_ID"]),
    "protocol_artifact_sha256": os.environ["PROTOCOL_ARTIFACT_SHA256"],
    "protocol_sha256": os.environ["PROTOCOL_SHA256"],
    "fixed_routes": 3,
    "initiated_route_attempts": 3,
    "terminal_routes": 3,
    "physical_requests": len(physical_requests),
    "followed_redirects": followed_redirects,
    "refused_redirects": refused_redirects,
    "http_success_routes": success_routes,
    "http_non_success_routes": non_success_routes,
    "transport_error_routes": transport_error_routes,
    "pdf_magic_routes": pdf_magic_routes,
    "expected_media_type_routes": expected_media_type_routes,
    "captured_final_body_bytes": final_body_bytes,
    "fresh_anonymous_route_sessions": 3,
    "same_host_expansion": 0,
    "result_spawned_requests": 0,
    "source_admissions": 0,
    "field_classifications": 0,
    "field_terminalizations": 0,
    "matrix_updates": 0,
    "row_state_mutations": 0,
    "class_closed": False,
    "cumulative_ledger_effect": "none",
    "outside_human_dependency": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
    "additional_execution_authorized": False,
    "next_authorized_operation": "offline artifact-only PDF source and field adjudication over this exact transport receipt",
}
(out / "execution-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
authority = {
    "schema_version": "ssc-rd04-nd-current-waiver-fy26-quarter-status-transport-authority@1",
    "object_type": "transport_only",
    "issue": 1017,
    "class_id": "RD-04-C02",
    "unit_id": "US-STATE-ND",
    "target_field_id": protocol["target_field_id"],
    "source_admission_authority": False,
    "field_classification_authority": False,
    "matrix_authority": False,
    "row_state_authority": False,
    "class_closure_authority": False,
    "publication_effect": "none",
    "adoption_effect": "none",
    "graph_effect": "none",
    "additional_execution_authorized": False,
}
(out / "authority-boundary.json").write_text(json.dumps(authority, indent=2, sort_keys=True) + "\n", encoding="utf-8")

lines = [
    "# RD-04 North Dakota FY 2026 quarterly status PDF transport",
    "",
    "Fixed routes: 3",
    f"Physical requests: {len(physical_requests)}",
    f"HTTP successes: {success_routes}",
    f"HTTP non-successes: {non_success_routes}",
    f"Transport errors: {transport_error_routes}",
    f"PDF magic routes: {pdf_magic_routes}",
    f"Expected media-type routes: {expected_media_type_routes}",
    f"Followed redirects: {followed_redirects}",
    f"Refused redirects: {refused_redirects}",
    f"Captured final body bytes: {final_body_bytes}",
    "",
    "Transport creates no source admission, field classification, matrix update, row transition, class closure, publication, adoption, or graph effect.",
]
(out / "transport-summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
