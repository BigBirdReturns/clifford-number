# RD-04 North Dakota FY 2026 quarterly status PDF transport

Fixed routes: 3
Physical requests: 3
HTTP successes: 0
HTTP non-successes: 0
Transport errors: 0
PDF magic routes: 0
Expected media-type routes: 0
Followed redirects: 0
Refused redirects: 3
Captured final body bytes: 0

Transport creates no source admission, field classification, matrix update, row transition, class closure, publication, adoption, or graph effect.
