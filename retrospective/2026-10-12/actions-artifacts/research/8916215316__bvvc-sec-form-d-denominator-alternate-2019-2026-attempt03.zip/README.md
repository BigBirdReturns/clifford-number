# BVVC SEC Form D alternate-route capture

This artifact preserves EDGAR full-text search, submissions API, quarterly company-index, and filing-folder route results separately. A failed route is not a no-match. A filing is not a portfolio transaction.
