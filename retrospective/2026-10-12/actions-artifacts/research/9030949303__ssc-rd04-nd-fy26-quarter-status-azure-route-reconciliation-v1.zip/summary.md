# RD-04 Azure target reconciliation

The checksum-valid three-route protocol was reconciled against terminal Q3 custody. Q3 is consumed. Only exact Q1 and Q2 targets retain one request each. No source request occurred here.
