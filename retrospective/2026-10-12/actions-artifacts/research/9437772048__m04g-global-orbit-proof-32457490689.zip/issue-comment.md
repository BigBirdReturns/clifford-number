<!-- m04g-global-orbit-proof:32457490689 -->
## M-04G global orbit proof

- Run: https://github.com/BigBirdReturns/clifford-number/actions/runs/32457490689
- Head: `9fa0827e2b9cbf6e105469b48128c58f1a30d532`
- Event: `schedule`
- Classes: `freshwater_authoritative`
- Basin denominator: `5/5`
- Orbit job: `success`
- Execution complete: `true`
- Coverage healthy: `false`
- Evidence sufficient: `false`
- Route success: `19/25` (`0.76`)
- Content success: `17/25` (`0.68`)
- Metadata only: `2`
- Failed: `6`
- Healthy basins: `0/5`
- Proof SHA-256: `dfe3c9c0c654debac43f993ee9a0f956a7d6396ddc7943beb6d49e031ebc0323`

| Basin | Selected | Route | Content | Metadata | Failed | Healthy |
|---|---:|---:|---:|---:|---:|---|
| `G04-EU-CONTINENTAL` | 5 | 4 | 4 | 0 | 1 | `false` |
| `G05-UK-IRELAND-NORDICS` | 5 | 5 | 5 | 0 | 0 | `false` |
| `G06-EASTERN-EUROPE-EURASIA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G07-MENA` | 5 | 3 | 2 | 1 | 2 | `false` |
| `G08-SUB-SAHARAN-AFRICA` | 5 | 4 | 4 | 0 | 1 | `false` |

```text
execution completeness ≠ coverage health
coverage health ≠ evidentiary sufficiency
metadata fingerprint ≠ content access

promotes_to: candidate_only
graph_effect: none
conclusion_generated: false
estate_completion_claimed: false
```
