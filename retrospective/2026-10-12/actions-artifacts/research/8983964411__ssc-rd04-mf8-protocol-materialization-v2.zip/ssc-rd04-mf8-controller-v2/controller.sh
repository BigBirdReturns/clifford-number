set -Eeuo pipefail
OUT=/tmp/ssc-rd04-mf8-protocol-materializer-v1
PKG="$OUT/package"
WT="$OUT/worktree"
rm -rf "$OUT"
mkdir -p "$OUT" "$PKG"
exec > >(tee "$OUT/run.log") 2>&1

trap 'rc=$?; failed=${BASH_COMMAND:-unknown}; trap - ERR; printf '{"exit_code":%s,"failed_command":%q,"workflow_run":"%s","carrier_head":"%s"}\n' "$rc" "$failed" "$GITHUB_RUN_ID" "$GITHUB_SHA" > "$OUT/failure.json"; exit "$rc"' ERR
echo "workflow_run=$GITHUB_RUN_ID"
echo "carrier_head=$GITHUB_SHA"
cat > "$OUT/shards.tsv" <<'EOF_SHARDS'
part-00.bin 707a58bc16a81da733862d8e16aa81191824b822 1536 185e9238a9b07735146cb7920dbed768ded4f31ba41ef5bd2ffea0867affce5b
part-01.bin 6ad1ad6c61d96f94f9daf7575bf482d326593b00 1536 e598c85d53d6ac21f8e63420a7c150f07f56b8facc7a90b248fb76341c0d4084
part-02.bin 8ea0720702cfb9080bd45e3b4149c6917599f5a7 1536 dce9cfe6761832852e00558f945f6adf460d7d57c01fe6f7c3d075807831da7b
part-03.bin d09d6fe4ed997db8f8a133d1eb3eced0901820e7 1536 3588d987764b11c72b78a9c07a114717e2ffdbe46283c54370524b6db75884ef
part-04.bin c8925cc188e5cd797940f9a3caa7356be02c70f3 1536 e223d1c3b6927c558c1a0574b8aa4c1fbd29eeede88caaf6c158150b495308f2
part-05.bin e6872f13db7e047ea9aab73aa0874875b9a1cfd6 1536 a61f522e3083ea6950efdf8d67885d22fa85f0818993301f8dca916dfc20ccf4
part-06.bin d610cb95a0ef4fe0b00355c55f6c1688d7cc1641 1536 a7782a38adc4f3e39a41b1fa014e82475ef7e6a0781d15fc13dd58cea87f53e1
part-07.bin 12c7fbf3d56bfdc9e90f5edb405e8d6699360269 1536 2ae72b895e4354effb037b52af72844138443a563722d6d8804b9f420b1d2dd4
part-08.bin 22f9b02214fd36f05af8ec1c963369cdc448bd91 1536 77b4a44b43e1a65788e7d1f38d01f3679169dfcd786a412a922d15408bf3973e
part-09.bin cea20bf613aa68d3049f839aa877922ed1eae1f9 1536 848082b00882debb7c24365105670e09f4dbe4c119133e5bef6d6992cae6bb3c
part-10.bin 41b6e9d1534a5e12018845d7b7e9d875a3aba117 1536 1064af2ce1edcacc2adc0f4f723a903c8dcd2454f562a57d5f936c62dd25d96f
part-11.bin b1629a3597b32a592f8e9a55cc70b297fc1a11d3 1536 3db71c5de71a4fc0fa33fa82e08c053b14fe9c42deb4f31e4d483b1689212d00
part-12.bin 6358423b4503b20795f5c911fda1131a8404a457 1536 edc4d06a6bcca7664e9d0ae4ca5f9be7ffa315dd2b1aaca7bff6d918775657d3
part-13.bin ee90de9e7e09491aba07d2591818bc6b106bdf01 780 60a0089c7a1a3e560df915c2971e00306e448eeb20c9a5aa79fad921c9b9d80c
EOF_SHARDS
: > "$OUT/product.tar.xz"
while read -r name blob bytes digest; do
  curl -fsSL \
    -H "Authorization: Bearer $GH_TOKEN" \
    -H 'Accept: application/vnd.github+json' \
    -H 'X-GitHub-Api-Version: 2022-11-28' \
    "https://api.github.com/repos/$GH_REPOSITORY/git/blobs/$blob" \
    > "$OUT/$name.json"
  test "$(jq -r .encoding "$OUT/$name.json")" = base64
  jq -r .content "$OUT/$name.json" | tr -d '\n' | base64 -d > "$OUT/$name"
  test "$(wc -c < "$OUT/$name" | tr -d ' ')" = "$bytes"
  test "$(sha256sum "$OUT/$name" | awk '{print $1}')" = "$digest"
  test "$(git hash-object "$OUT/$name")" = "$blob"
  cat "$OUT/$name" >> "$OUT/product.tar.xz"
done < "$OUT/shards.tsv"
test "$(wc -c < "$OUT/product.tar.xz" | tr -d ' ')" = "$ARCHIVE_BYTES"
test "$(sha256sum "$OUT/product.tar.xz" | awk '{print $1}')" = "$ARCHIVE_SHA256"
test "$(git hash-object "$OUT/product.tar.xz")" = "$ARCHIVE_GIT_BLOB"
echo 'archive_reconstruction=pass shards=14'
tar -xJf "$OUT/product.tar.xz" -C "$PKG"

cat > "$OUT/permanent-paths.txt" <<'EOF_PATHS'
.github/workflows/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.yml
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/authored-protocol.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/execution-receipt-template.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/index.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/product-manifest.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/route-ledger.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/source-interpretation-constraints.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/target-cell-ledger.json
docs/milestones/ssc-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.md
schemas/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.schema.json
test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py
tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
EOF_PATHS
cat > "$OUT/ordinary-paths.txt" <<'EOF_ORDINARY'
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/authored-protocol.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/execution-receipt-template.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/index.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/product-manifest.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/route-ledger.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/source-interpretation-constraints.json
data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/target-cell-ledger.json
docs/milestones/ssc-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.md
schemas/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.schema.json
test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py
tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
EOF_ORDINARY
cat > "$OUT/SHA256SUMS" <<'EOF_SUMS'
1b2a1fec3cd3ebeaa7a2c3b4bdc66f70b102ce87c5f8adb8498cbe99b71e2f90  .github/workflows/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.yml
1a2c94d8eae0ec6bbcc2e2fe038fee1953b44538ce4e05c9e821889233b8e3b3  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/authored-protocol.json
7e25609b263aa377e77718172356511df2f6ecc8553891830ee5391c89ecaffa  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/execution-receipt-template.json
95531be070d9982da8ec7bdb286555c6e8465a218a8ae01a4dcee7d21678a173  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/index.json
63098a3be6ae033abf37414898055b98d9121e516eae48fca6d228085da02c42  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/product-manifest.json
b878c79aeffbef4e35d6bfcce8382167acabe589fdcb69aec484a56db4059a68  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/route-ledger.json
71ab02a1c6d0e01a27ca70617024833863dc659b704044f55105476ee781059d  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/source-interpretation-constraints.json
00dee1be968d4fd986692b324847e6d37fc12be10e8dd2732a41ab07612aaa7d  data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol/target-cell-ledger.json
e80c440779237f8d4f27080553b4b2084fd3fee13e07b2f853b931e530df3775  docs/milestones/ssc-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.md
dff69db76e067d4ce0897c647a8255d49e3459e4d36f68e63c68962124530dac  schemas/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.schema.json
182bfd04b3033627689ac45cfd233ffe55f51cd8d7b35349e17338e4cddf863a  test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
a35373fed9c3d69d3adad3aa8dc7cb77e81490f0b7b490615df0056a41299a02  tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py
e10b358b624e1e9d18c8074cf0da9ec2b94f56909df126d76e669e8cb3fa1257  tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
c1c6808f9ac82143470d1511fdd503eae5ae4a3779e51c4af3760bb7fba61d43  tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
EOF_SUMS
(cd "$PKG" && sha256sum -c "$OUT/SHA256SUMS")
find "$PKG" -type f -printf '%P\n' | sort > "$OUT/extracted-paths.txt"
diff -u "$OUT/permanent-paths.txt" "$OUT/extracted-paths.txt"
test "$(wc -l < "$OUT/permanent-paths.txt" | tr -d ' ')" -eq 14
test "$(wc -l < "$OUT/ordinary-paths.txt" | tr -d ' ')" -eq 13
while IFS= read -r path; do test "$(stat -c '%a' "$PKG/$path")" = 644; done < "$OUT/permanent-paths.txt"

git fetch --force --no-tags origin main
LIVE_MAIN=$(git rev-parse origin/main)
LIVE_TREE=$(git rev-parse "${LIVE_MAIN}^{tree}")
git merge-base --is-ancestor "$EMPIRICAL_MERGE" "$LIVE_MAIN"
while IFS= read -r path; do
  if git cat-file -e "$LIVE_MAIN:$path" 2>/dev/null; then
    echo "target path already exists on live main: $path" >&2
    exit 1
  fi
done < "$OUT/permanent-paths.txt"
test "$(git rev-parse "$LIVE_MAIN:data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/summary.json")" = 14d34c2da3ef3bf1d40caf2f81a2af299ae1dd83
test "$(git rev-parse "$LIVE_MAIN:data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/index.json")" = babcaebc949f62271f3298ad76cd12ecd93e001b
test "$(git rev-parse "$LIVE_MAIN:data/intake/status-sovereignty-rd-wave03-rd04-ar-ga-md-nc-pa-ri-wv-row-state-adjudication/remaining-open-field-census.json")" = 89a6c85075299e9df00e387a21746a2747325d19
test -z "$(git ls-remote --heads origin "refs/heads/$TARGET_BRANCH")"

git worktree add --detach "$WT" "$LIVE_MAIN"
copy_ordinary() {
  while IFS= read -r path; do
    mkdir -p "$WT/$(dirname "$path")"
    cp -- "$PKG/$path" "$WT/$path"
  done < "$OUT/ordinary-paths.txt"
}
focused() {
  cd "$WT"
  node --check tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
  node --check tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
  node --check test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
  python -m py_compile tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py
  node tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs --check
  node tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
  python - <<'PY_SCHEMA'
import json
from pathlib import Path
import jsonschema
schema=json.loads(Path('schemas/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.schema.json').read_text())
files=sorted(Path('data/intake/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol').glob('*.json'))
assert len(files)==7, len(files)
validator=jsonschema.Draft202012Validator(schema)
for path in files: validator.validate(json.loads(path.read_text()))
print('closed_schema_validation=pass objects=7')
PY_SCHEMA
  node test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
  python tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py --validate-only
  node tools/validate-no-magic-human-gate.mjs
  git diff --check
}

copy_ordinary
focused
cd "$WT"
npm run release:check

git restore --staged --worktree .
git clean -fdx
copy_ordinary
focused
node tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs --write
node tools/build-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs --check
node tools/validate-status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.mjs
node test/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.test.js
python tools/acquisition/status-sovereignty-rd-wave03-rd04/run-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.py --validate-only
node tools/validate-no-magic-human-gate.mjs
git diff --check

git add --pathspec-from-file="$OUT/ordinary-paths.txt"
git diff --cached --name-only | sort > "$OUT/staged-paths.txt"
diff -u "$OUT/ordinary-paths.txt" "$OUT/staged-paths.txt"
test "$(git diff --cached --diff-filter=A --name-only | wc -l | tr -d ' ')" -eq 13
test -z "$(git status --porcelain=v1 --untracked-files=all | awk '$1 != "A" && $1 != "??" {print}')"

git fetch --force --no-tags origin main
test "$(git rev-parse origin/main)" = "$LIVE_MAIN"
git config user.name 'github-actions[bot]'
git config user.email '41898282+github-actions[bot]@users.noreply.github.com'
git commit -m 'Freeze RD-04 eight-state minimum-frontier protocol ordinary product'
ORDINARY_HEAD=$(git rev-parse HEAD)
ORDINARY_TREE=$(git rev-parse 'HEAD^{tree}')
test "$(git rev-parse HEAD^)" = "$LIVE_MAIN"
git push origin "$ORDINARY_HEAD:refs/heads/$TARGET_BRANCH"

STANDING_BLOB=$(git hash-object "$PKG/$STANDING_WORKFLOW")
python - "$LIVE_MAIN" "$LIVE_TREE" "$ORDINARY_HEAD" "$ORDINARY_TREE" "$STANDING_BLOB" <<'PY_RECEIPT'
import json,sys
from pathlib import Path
out=Path('/tmp/ssc-rd04-mf8-protocol-materializer-v1')
r={
  'schema_version':'ssc-rd04-mf8-protocol-materialization@1',
  'canonical_parent':sys.argv[1],
  'canonical_parent_tree':sys.argv[2],
  'ordinary_head':sys.argv[3],
  'ordinary_tree':sys.argv[4],
  'standing_workflow_blob':sys.argv[5],
  'standing_workflow_path':'.github/workflows/status-sovereignty-rd-wave03-rd04-fl-mo-mt-ne-nv-nd-or-wi-minimum-frontier-protocol.yml',
  'archive_git_blob':'f76674753c9e2e64183fcda0ff16bb8b948a1c81','transport_shards':14,
  'archive_bytes':20748,
  'archive_sha256':'3afa1a777dab75415cafc8a4b317a10771de0f5eb74ccbef5a18f6b4ae5c208f',
  'permanent_paths':14,'ordinary_paths':13,'fixed_routes':34,'target_states':8,'target_cells':32,
  'terminal_cells_before':218,'still_open_substantive_cells_before':192,'adversarial_refusals':884,
  'class_closed':False,'outside_human_dependency':False,
  'publication_effect':'none','adoption_effect':'none','graph_effect':'none'
}
out.joinpath('materialization-receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
PY_RECEIPT
