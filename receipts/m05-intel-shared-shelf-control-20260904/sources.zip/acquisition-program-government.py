import pathlib, json, ssl, http.client, hashlib, datetime, urllib.parse

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def hashes(body):
    return {'body_sha256':hashlib.sha256(body).hexdigest(),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest(),'body_length_bytes':len(body)}

def acquire(root, key, url, maximum=40000000):
    folder=pathlib.Path(root)/'sources'/key
    folder.mkdir(parents=True, exist_ok=False)
    current=url
    receipt={'schema':'bounded-public-source-acquisition@1','requested_url':url,'started_at_utc':utc(),'request_contains_credentials':False,'tls_verification_enabled':True,'method':'GET','hops':[],'complete':False,'repository_stage_admission':False}
    try:
        for n in range(5):
            p=urllib.parse.urlsplit(current)
            if p.scheme!='https' or p.username or p.password:
                raise ValueError('Only credential-free HTTPS source URLs are allowed')
            target=urllib.parse.urlunsplit(('', '',p.path or '/',p.query,''))
            headers={'User-Agent':'PublicRecordResearch/1.0','Accept':'*/*','Accept-Encoding':'identity','Connection':'close'}
            hop={'url':current,'request_headers':headers,'requested_at_utc':utc()}
            receipt['hops'].append(hop)
            conn=http.client.HTTPSConnection(p.hostname,p.port or 443,timeout=20,context=ssl.create_default_context())
            conn.connect()
            cert=conn.sock.getpeercert(binary_form=True)
            certname=f'tls-peer-{n}.der'
            (folder/certname).write_bytes(cert)
            hop['tls_peer_certificate']={'path':certname,**hashes(cert),'subject_issuer_and_validity':conn.sock.getpeercert(),'tls_version':conn.sock.version()}
            conn.request('GET',target,headers=headers)
            response=conn.getresponse()
            hop['response_status']=response.status
            hop['response_reason']=response.reason
            hop['response_headers']=response.getheaders()
            hop['response_at_utc']=utc()
            body=response.read(maximum+1)
            if len(body)>maximum:
                raise ValueError('Body exceeds declared acquisition bound')
            name=f'response-{n}.body'
            (folder/name).write_bytes(body)
            hop['body']={'path':name,**hashes(body),'content_type':response.getheader('Content-Type')}
            location=response.getheader('Location')
            conn.close()
            if response.status in (301,302,303,307,308) and location:
                current=urllib.parse.urljoin(current,location)
                continue
            receipt.update({'resolved_url':current,'response_status':response.status,'body':hop['body'],'complete':True,'http_success':response.status==200})
            break
        else:
            raise ValueError('Redirect bound exceeded')
    except Exception as e:
        receipt['error']={'type':type(e).__name__,'message':str(e)}
    receipt['finished_at_utc']=utc()
    (folder/'acquisition.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    print(key,json.dumps({k:receipt.get(k) for k in ('response_status','complete','body','error')},ensure_ascii=True),flush=True)
    return receipt
