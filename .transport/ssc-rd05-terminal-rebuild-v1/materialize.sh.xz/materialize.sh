#!/usr/bin/env bash
set -Eeuo pipefail
export GIT_AUTHOR_NAME='github-actions[bot]'
export GIT_AUTHOR_EMAIL='41898282+github-actions[bot]@users.noreply.github.com'
export GIT_COMMITTER_NAME="$GIT_AUTHOR_NAME"
export GIT_COMMITTER_EMAIL="$GIT_AUTHOR_EMAIL"

CARRIER_BRANCH='agent/ssc-rd05-wave03-terminal-rebuild-materializer-v1'
CARRIER_ROOT='.transport/ssc-rd05-terminal-rebuild-v1'
MANIFEST="$CARRIER_ROOT/manifest.json"
MAIN_LEASE='cf62a80b8628525b1eefc0ffcfae14696cbec700'
MAIN_TREE='7c5011f320fca192aa65400bffda29832dc8054b'
INPUT_BRANCH='agent/ssc-rd-wave03-rd05-member-participation'
INPUT_HEAD='bc9800dcd3a3768288a5dfeaf0f7144969994ffa'
PRODUCT_BRANCH='agent/ssc-rd05-wave03-terminal-rebuild-product-v1'
PRODUCT_LEASE='e6bd0e8202306b415f415eefaed917d4b23d9468'
SOURCE_PR='1227'
SOURCE_RUN='30989139364'
SOURCE_ARTIFACT='8923361634'
SOURCE_ARTIFACT_NAME='ssc-rd-wave03-rd05-source-census-v1'
SOURCE_ARTIFACT_DIGEST='sha256:0829f39c45dc5308c031dcde3efb6514a1f65ec5787ed19c9490bf49e6c1289b'
WORK="$RUNNER_TEMP/ssc-rd05-terminal-rebuild-v1"
BASE="$WORK/rebuild"
PRODUCT="$BASE/product-worktree"
PUBLISH="$WORK/publish"
RECEIPT="$WORK/receipt"
GENERATOR_XZ="$WORK/generate.py.xz"
GENERATOR="$WORK/generate_rd05_product.py"
rm -rf "$WORK"
mkdir -p "$BASE/main" "$BASE/intake" "$BASE/census" "$RECEIPT"
exec > >(tee "$RECEIPT/execution.log") 2>&1
STAGE=init
finish() {
  rc=$?
  printf 'status=%s\nstage=%s\nexit_code=%s\nutc=%s\n' \
    "$([[ $rc -eq 0 ]] && echo complete || echo failed_closed)" \
    "$STAGE" "$rc" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" > "$RECEIPT/checkpoint.txt"
  exit "$rc"
}
trap finish EXIT

STAGE=bind-carrier-and-leases
test "${GITHUB_HEAD_REF:-$CARRIER_BRANCH}" = "$CARRIER_BRANCH"
git fetch --no-tags origin main "$INPUT_BRANCH" "$PRODUCT_BRANCH"
test "$(git rev-parse origin/main)" = "$MAIN_LEASE"
test "$(git rev-parse "$MAIN_LEASE^{tree}")" = "$MAIN_TREE"
test "$(git rev-parse "origin/$INPUT_BRANCH")" = "$INPUT_HEAD"
test "$(git rev-parse "origin/$PRODUCT_BRANCH")" = "$PRODUCT_LEASE"
test "$(git rev-parse "$PRODUCT_LEASE^")" = "$MAIN_LEASE"

cat > "$RECEIPT/expected-carrier-paths.txt" <<'EOF'
.github/workflows/temp-ssc-rd05-terminal-rebuild-materializer-v1.yml
.transport/ssc-rd05-terminal-rebuild-v1/generate.py.xz
.transport/ssc-rd05-terminal-rebuild-v1/manifest.json
.transport/ssc-rd05-terminal-rebuild-v1/materialize.sh.xz
EOF
sed -i 's/^          //' "$RECEIPT/expected-carrier-paths.txt"
git diff --name-only "$MAIN_LEASE"..HEAD | sort > "$RECEIPT/carrier-paths.txt"
cmp "$RECEIPT/expected-carrier-paths.txt" "$RECEIPT/carrier-paths.txt"
test "$(git rev-list --count "$MAIN_LEASE"..HEAD)" = 1

STAGE=verify-generator-carrier
GENERATOR_CARRIER="$CARRIER_ROOT/generate.py.xz"
python - "$MANIFEST" "$GENERATOR_CARRIER" <<'PY'
from pathlib import Path
import hashlib, json, sys
manifest_path, generator_path = map(Path, sys.argv[1:])
manifest = json.loads(manifest_path.read_text())
assert manifest['schema_version'] == 'ssc-rd05-terminal-rebuild-materializer@2'
assert manifest['canonical_parent'] == 'cf62a80b8628525b1eefc0ffcfae14696cbec700'
assert manifest['canonical_parent_tree'] == '7c5011f320fca192aa65400bffda29832dc8054b'
assert manifest['input_head'] == 'bc9800dcd3a3768288a5dfeaf0f7144969994ffa'
assert manifest['source_pr'] == 1227
assert manifest['product_branch'] == 'agent/ssc-rd05-wave03-terminal-rebuild-product-v1'
assert manifest['product_lease'] == 'e6bd0e8202306b415f415eefaed917d4b23d9468'
assert manifest['product_files'] == 32 == len(manifest['files'])
assert manifest['generator_path'] == '.transport/ssc-rd05-terminal-rebuild-v1/generate.py.xz'
data = generator_path.read_bytes()
assert len(data) == manifest['generator_xz_bytes'] == 13672
assert hashlib.sha256(data).hexdigest() == manifest['generator_xz_sha256'] == '8f88e5de493775edcb29a958e8bca98c9e564c1152b5970e6438c4dec1a68c9b'
PY
cp "$GENERATOR_CARRIER" "$GENERATOR_XZ"
xz -dc "$GENERATOR_XZ" > "$GENERATOR"
test "$(stat -c '%s' "$GENERATOR")" = '69702'
test "$(sha256sum "$GENERATOR" | awk '{print $1}')" = '294a0c481967649e67cfa05f1c1b3f5e34aa4be66b1d0e8005fe91f3a233d2b6'
python -m py_compile "$GENERATOR"

STAGE=acquire-exact-inputs
git archive "$MAIN_LEASE" | tar -x -C "$BASE/main"
cat > "$RECEIPT/intake-paths.txt" <<'EOF'
.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation-intake.yml
data/intake/status-sovereignty-rd-wave03-rd05-member-participation/field-matrix-contract.json
data/intake/status-sovereignty-rd-wave03-rd05-member-participation/intake-product-manifest.json
data/intake/status-sovereignty-rd-wave03-rd05-member-participation/source-census-protocol.json
data/project/ssc-residual-wave03/seeds/RD-05-C02.json
docs/milestones/ssc-rd-wave03-rd05-member-participation-intake.md
schemas/status-sovereignty-rd-wave03-rd05-member-participation-intake.schema.json
test/status-sovereignty-rd-wave03-rd05-member-participation-intake.test.js
tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py
tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
tools/validate-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
EOF
sed -i 's/^          //' "$RECEIPT/intake-paths.txt"
git archive "$INPUT_HEAD" $(cat "$RECEIPT/intake-paths.txt") | tar -x -C "$BASE/intake"
test "$(gh api "repos/$GITHUB_REPOSITORY/actions/artifacts/$SOURCE_ARTIFACT" --jq .digest)" = "$SOURCE_ARTIFACT_DIGEST"
gh run download "$SOURCE_RUN" --repo "$GITHUB_REPOSITORY" --name "$SOURCE_ARTIFACT_NAME" --dir "$BASE/census"
python - "$BASE/census" <<'PYVERIFY'
from pathlib import Path
import hashlib, json, sys
root = Path(sys.argv[1])
package = root / 'artifact-package.json'
data = package.read_bytes()
assert len(data) == 172772
assert hashlib.sha256(data).hexdigest() == 'f8df87da1d5da337004a703c5f588cdbeea39f01863db876a43140c8517ffd1e'
obj = json.loads(data)
assert obj['schema_version'] == 'ssc-rd-wave03-rd05-source-census-artifact-package@1'
assert obj['combined_sha256'] == '50552148821397cef396eb7a7b884a2ddc3a534b57212aced70d7092a959e8d4'
for row in obj['entries']:
    path = root / row['path']
    payload = path.read_bytes()
    assert len(payload) == row['bytes'], row['path']
    assert hashlib.sha256(payload).hexdigest() == row['sha256'], row['path']
assert obj['raw_capture_is_permanent_git_content'] is False
assert obj['candidate_rows_are_admitted_sources'] is False
assert obj['class_closed'] is False
assert obj['graph_effect'] == 'none'
PYVERIFY

STAGE=deterministic-rebuild
RD05_REBUILD_ROOT="$BASE" RD05_SOURCE_PR="$SOURCE_PR" python "$GENERATOR"
node "$PRODUCT/tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs" --write
python - "$MANIFEST" "$PRODUCT" "$RECEIPT/product-paths.txt" <<'PY'
from pathlib import Path
import hashlib, json, os, stat, sys
manifest = json.loads(Path(sys.argv[1]).read_text())
root = Path(sys.argv[2])
paths_out = Path(sys.argv[3])
observed = []
for row in manifest['files']:
    path = root / row['path']
    data = path.read_bytes()
    mode = '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    assert mode == row['mode'], (row['path'], mode, row['mode'])
    observed.append(row['path'])
assert len(observed) == 32 and len(set(observed)) == 32
paths_out.write_text('\n'.join(observed) + '\n')
PY

STAGE=compose-exact-product
git worktree add --detach "$PUBLISH" "$MAIN_LEASE"
while IFS= read -r rel; do test ! -e "$PUBLISH/$rel"; done < "$RECEIPT/product-paths.txt"
while IFS= read -r rel; do
  mkdir -p "$PUBLISH/$(dirname "$rel")"
  cp -a "$PRODUCT/$rel" "$PUBLISH/$rel"
done < "$RECEIPT/product-paths.txt"
cd "$PUBLISH"
git add --pathspec-from-file="$RECEIPT/product-paths.txt"
git diff --cached --name-status > "$RECEIPT/name-status.txt"
test "$(wc -l < "$RECEIPT/name-status.txt" | tr -d ' ')" = 32
test "$(awk '$1 != "A" {n++} END {print n+0}' "$RECEIPT/name-status.txt")" = 0
! grep -F '.transport/' "$RECEIPT/name-status.txt"
! grep -F '.rd05-terminal-product-reservation' "$RECEIPT/name-status.txt"

run_focused() {
  node --check tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
  node --check tools/validate-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
  node --check test/status-sovereignty-rd-wave03-rd05-member-participation-intake.test.js
  python -m py_compile tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py
  node tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs --check
  node tools/validate-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
  node test/status-sovereignty-rd-wave03-rd05-member-participation-intake.test.js
  DRY="$RUNNER_TEMP/rd05-intake-dry-run"
  rm -rf "$DRY"
  python tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py --dry-run --output "$DRY"
  jq -e '.fixed_routes == 161 and .exact_official_routes == 25 and .candidate_census_routes == 136' "$DRY/plan.json"
  jq -e '.request_attempts == 0 and .terminal_route_receipts == 0 and .status == "protocol_validated_acquisition_not_executed"' "$DRY/execution-receipt.json"
  node --check tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs
  node --check tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs
  node --check test/status-sovereignty-rd-wave03-rd05-member-participation.test.js
  node tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs --check
  node tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs
  node test/status-sovereignty-rd-wave03-rd05-member-participation.test.js
  node tools/validate-no-magic-human-gate.mjs
  node test/no-magic-human-gate.test.js
}

STAGE=focused-gates
run_focused
git diff --check "$MAIN_LEASE"

STAGE=complete-release-gate
npm run release:check

STAGE=clean-replay
git reset --hard "$MAIN_LEASE"
git clean -fdx
while IFS= read -r rel; do
  mkdir -p "$(dirname "$rel")"
  cp -a "$PRODUCT/$rel" "$rel"
done < "$RECEIPT/product-paths.txt"
git add --pathspec-from-file="$RECEIPT/product-paths.txt"
run_focused
git diff --check "$MAIN_LEASE"
git diff --cached --name-status > "$RECEIPT/replay-name-status.txt"
cmp "$RECEIPT/name-status.txt" "$RECEIPT/replay-name-status.txt"
python - "$MANIFEST" . <<'PY'
from pathlib import Path
import hashlib, json, stat, sys
manifest = json.loads(Path(sys.argv[1]).read_text())
root = Path(sys.argv[2])
for row in manifest['files']:
    path = root / row['path']
    data = path.read_bytes()
    mode = '100755' if path.stat().st_mode & stat.S_IXUSR else '100644'
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    assert mode == row['mode']
PY

STAGE=commit
git commit -m 'Close RD-05 member-participation custody as bounded source unavailable' \
  -m 'Preserve all seventeen published ACES member rows across ten required fields each, terminally dispose all 1,351 candidate rows, bind twenty-five official-body observations, and close only the fixed public-record acquisition obligation. Missing public records remain source unavailability rather than evidence of nonparticipation, unanimity, silence, authorship, or event absence.'
PRODUCT_HEAD=$(git rev-parse HEAD)
PRODUCT_TREE=$(git rev-parse 'HEAD^{tree}')
test "$(git rev-parse HEAD^)" = "$MAIN_LEASE"
test "$(git rev-list --count "$MAIN_LEASE"..HEAD)" = 1
git diff --name-status "$MAIN_LEASE"..HEAD > "$RECEIPT/committed-name-status.txt"
cmp "$RECEIPT/name-status.txt" "$RECEIPT/committed-name-status.txt"

STAGE=publish
git fetch --no-tags origin main "$PRODUCT_BRANCH"
test "$(git rev-parse origin/main)" = "$MAIN_LEASE"
test "$(git rev-parse "origin/$PRODUCT_BRANCH")" = "$PRODUCT_LEASE"
git push origin "HEAD:refs/heads/$PRODUCT_BRANCH" \
  --force-with-lease="refs/heads/$PRODUCT_BRANCH:$PRODUCT_LEASE"
test "$(git ls-remote origin "refs/heads/$PRODUCT_BRANCH" | awk '{print $1}')" = "$PRODUCT_HEAD"

python - "$RECEIPT/final.json" "$PRODUCT_HEAD" "$PRODUCT_TREE" <<'PY'
from pathlib import Path
import json, sys
out, head, tree = sys.argv[1:]
Path(out).write_text(json.dumps({
    'schema_version': 'ssc-rd05-terminal-rebuild-materialization@1',
    'status': 'complete',
    'canonical_parent': 'cf62a80b8628525b1eefc0ffcfae14696cbec700',
    'canonical_parent_tree': '7c5011f320fca192aa65400bffda29832dc8054b',
    'source_pr': 1227,
    'product_branch': 'agent/ssc-rd05-wave03-terminal-rebuild-product-v1',
    'product_head': head,
    'product_tree': tree,
    'product_commits': 1,
    'permanent_paths': 32,
    'transport_paths': 0,
    'members': 17,
    'required_fields': 170,
    'terminal_fields': 170,
    'observed_fields': 71,
    'not_publicly_recovered_fields': 99,
    'candidate_rows': 1351,
    'terminal_candidate_dispositions': 1351,
    'official_body_observations': 25,
    'selected_candidate_followups': 0,
    'class_closed': True,
    'terminal_state': 'bounded_source_unavailable',
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}, indent=2, sort_keys=True) + '\n')
PY
cp "$MANIFEST" "$RECEIPT/materializer-manifest.json"
STAGE=complete
