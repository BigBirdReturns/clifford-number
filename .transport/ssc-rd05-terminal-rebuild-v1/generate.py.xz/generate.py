from __future__ import annotations

import copy
import hashlib
import json
import os
import pathlib
import re
import shutil
import unicodedata
from collections import Counter, defaultdict
from urllib.parse import urlparse

BASE = pathlib.Path(os.environ.get('RD05_REBUILD_ROOT', '/mnt/data/rd05-rebuild-work'))
MAIN = BASE / 'main'
INTAKE = BASE / 'intake'
CENSUS = BASE / 'census'
WORK = BASE / 'product-worktree'
SOURCE_PR = int(os.environ.get('RD05_SOURCE_PR', '0'))

if WORK.exists():
    shutil.rmtree(WORK)
# Hardlink current main so focused validation can run without another 509 MiB copy.
shutil.copytree(MAIN, WORK, copy_function=os.link)
for src in INTAKE.rglob('*'):
    if src.is_file():
        dst = WORK / src.relative_to(INTAKE)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

DATA_ROOT = WORK / 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation'
RESEARCH_ROOT = WORK / 'data/research/status-sovereignty-rd-wave03-rd05-member-participation'
CLOSURE_PATH = WORK / 'data/project/ssc-residual-wave03/closures/RD-05-C02.json'
DOC_PATH = WORK / 'docs/milestones/ssc-rd-wave03-rd05-member-participation.md'
SCHEMA_PATH = WORK / 'schemas/status-sovereignty-rd-wave03-rd05-member-participation.schema.json'
BUILDER_PATH = WORK / 'tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs'
VALIDATOR_PATH = WORK / 'tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs'
TEST_PATH = WORK / 'test/status-sovereignty-rd-wave03-rd05-member-participation.test.js'
WORKFLOW_PATH = WORK / '.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation.yml'
for p in [DATA_ROOT, RESEARCH_ROOT, CLOSURE_PATH.parent, DOC_PATH.parent, SCHEMA_PATH.parent, BUILDER_PATH.parent, VALIDATOR_PATH.parent, TEST_PATH.parent, WORKFLOW_PATH.parent]:
    p.mkdir(parents=True, exist_ok=True)

FIELD_CONTRACT_PATH = WORK / 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/field-matrix-contract.json'
field_contract = json.loads(FIELD_CONTRACT_PATH.read_text())
units = field_contract['units']
unit_by_id = {u['unit_id']: u for u in units}

source_execution = json.loads((CENSUS / 'execution-receipt.json').read_text())
source_plan = json.loads((CENSUS / 'plan.json').read_text())
source_protocol = json.loads((CENSUS / 'inputs/source-census-protocol.json').read_text())
source_manifest = json.loads((CENSUS / 'manifest.json').read_text())
source_artifact_package = json.loads((CENSUS / 'artifact-package.json').read_text())
candidates = json.loads((CENSUS / 'candidate-index.json').read_text())


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: pathlib.Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json(value) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, sort_keys=False) + '\n'


def normalize_text(value: str) -> str:
    value = unicodedata.normalize('NFKD', value)
    value = ''.join(ch for ch in value if not unicodedata.combining(ch))
    value = value.lower()
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    return ' '.join(value.split())

query_terms = {
    'attendance': ['attendance', 'attended', 'meeting'],
    'vote': ['vote', 'voted', 'roll call'],
    'dissent': ['dissent', 'dissented', 'minority statement', 'separate statement'],
    'subcommittee': ['subcommittee', 'working group'],
    'agenda_authority': ['agenda', 'chair', 'vice chair'],
    'information_access': ['briefing', 'materials', 'information access'],
    'authorship': ['author', 'drafted', 'recommendation'],
    'minutes_statement': ['minutes', 'statement', 'transcript'],
}

adjudicated = []
for row in sorted(candidates, key=lambda r: (r['route_ordinal'], r['result_rank'], r['candidate_id'])):
    combined = normalize_text(' '.join([row['canonical_name'], row['title'], row['description'], row['url']]))
    candidate_surface = normalize_text(' '.join([row['title'], row['description'], row['url']]))
    canonical_name = normalize_text(row['canonical_name'])
    exact_name_signal = canonical_name in candidate_surface
    aces_signal = 'aces' in candidate_surface or 'advisory committee on excellence in space' in candidate_surface
    event_signal = any(normalize_text(term) in candidate_surface for term in query_terms[row['query_class']])
    assert exact_name_signal is False, (row['candidate_id'], row['canonical_name'], row['title'])
    out = dict(row)
    out.update({
        'candidate_host': (urlparse(row['url']).hostname or '').lower(),
        'normalized_member_name': canonical_name,
        'exact_member_name_signal': exact_name_signal,
        'aces_context_signal': aces_signal,
        'query_event_signal': event_signal,
        'followup_eligibility': False,
        'terminal_disposition': 'terminal_no_exact_member_identity_signal',
        'terminal_disposition_reason': 'The fixed search-result row does not contain the exact normalized ACES member name in its title, description, or URL. Search-result text is not page-level evidence, so no candidate followup or admission is authorized.',
        'selected_for_followup': False,
        'admitted_evidence_source': False,
        'member_field_effect': 'none',
        'class_closure_effect': 'none',
        'publication_effect': 'none',
        'adoption_effect': 'none',
        'graph_effect': 'none',
    })
    adjudicated.append(out)
assert len(adjudicated) == 1351

candidate_dir = DATA_ROOT / 'candidate-adjudication'
candidate_dir.mkdir(parents=True, exist_ok=True)
part_sizes = [271, 270, 270, 270, 270]
assert sum(part_sizes) == len(adjudicated)
part_entries = []
offset = 0
for idx, size in enumerate(part_sizes):
    rows = adjudicated[offset:offset+size]
    offset += size
    path = candidate_dir / f'part-{idx:02d}.jsonl'
    path.write_text(''.join(json.dumps(r, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n' for r in rows))
    part_entries.append({
        'part': idx,
        'path': path.name,
        'rows': len(rows),
        'first_candidate_id': rows[0]['candidate_id'],
        'last_candidate_id': rows[-1]['candidate_id'],
        'bytes': path.stat().st_size,
        'sha256': sha256_file(path),
    })

query_counts = dict(sorted(Counter(r['query_class'] for r in adjudicated).items()))
hosts = sorted({r['candidate_host'] for r in adjudicated})
urls = sorted({r['url'] for r in adjudicated})
candidate_index = {
    'schema_version': 'ssc-rd05-wave03-candidate-adjudication-index@1',
    'wave_id': 'SSC-RD-W03',
    'lane_id': 'RD-05',
    'class_id': 'RD-05-C02',
    'issue': 1018,
    'source_census_receipt_path': '../source-census-execution-receipt.json',
    'candidate_parts': part_entries,
    'counts': {
        'candidate_rows': len(adjudicated),
        'terminal_candidate_dispositions': len(adjudicated),
        'selected_candidate_followups': 0,
        'admitted_candidate_sources': 0,
        'exact_member_name_signal_rows': 0,
        'aces_context_signal_rows': sum(r['aces_context_signal'] for r in adjudicated),
        'query_event_signal_rows': sum(r['query_event_signal'] for r in adjudicated),
        'unique_candidate_urls': len(urls),
        'unique_candidate_hosts': len(hosts),
        'query_class_counts': query_counts,
    },
    'adjudication_contract': {
        'exact_normalized_member_name_required_for_followup': True,
        'search_result_text_is_page_level_evidence': False,
        'official_or_first_party_host_is_substantive_support_by_itself': False,
        'result_rank_is_authority': False,
        'candidate_page_requests_executed': 0,
        'result_spawned_requests': 0,
        'automatic_evidence_admission': False,
    },
    'current_result': {
        'all_candidate_rows_terminally_disposed': True,
        'selected_candidate_followups': 0,
        'member_field_effect': 'none',
        'class_closed': False,
        'outside_human_dependency': False,
        'publication_effect': 'none',
        'adoption_effect': 'none',
        'graph_effect': 'none',
    },
}
(candidate_dir / 'index.json').write_text(canonical_json(candidate_index))

source_receipt = {
    'schema_version': 'ssc-rd05-wave03-source-census-custody@1',
    'wave_id': 'SSC-RD-W03',
    'lane_id': 'RD-05',
    'class_id': 'RD-05-C02',
    'issue': 1018,
    'workflow_run': 30989139364,
    'artifact_id': 8923361634,
    'artifact_zip_bytes': 2088436,
    'artifact_zip_sha256': '0829f39c45dc5308c031dcde3efb6514a1f65ec5787ed19c9490bf49e6c1289b',
    'artifact_package_entries': len(source_artifact_package['entries']),
    'artifact_package_combined_sha256': source_artifact_package['combined_sha256'],
    'protocol_path': 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/source-census-protocol.json',
    'protocol_sha256': sha256_file(CENSUS / 'inputs/source-census-protocol.json'),
    'capture_manifest_entries': len(source_manifest['entries']),
    'capture_manifest_combined_sha256': source_manifest['combined_sha256'],
    'fixed_routes': source_execution['fixed_routes'],
    'route_attempts': source_execution['request_attempts'],
    'terminal_route_receipts': source_execution['terminal_route_receipts'],
    'terminal_state_counts': source_execution['terminal_state_counts'],
    'exact_official_routes': source_plan['exact_official_routes'],
    'candidate_census_routes': source_plan['candidate_census_routes'],
    'candidate_rows': source_execution['candidate_rows'],
    'result_spawned_requests': 0,
    'candidate_followups': 0,
    'admitted_evidence_sources': 0,
    'record_absence_inferred': False,
    'member_event_absence_inferred': False,
    'raw_capture_committed_to_git': False,
    'outside_human_dependency': False,
    'publication_effect': 'none',
    'adoption_effect': 'none',
    'graph_effect': 'none',
}
(DATA_ROOT / 'source-census-execution-receipt.json').write_text(canonical_json(source_receipt))

# Exact observed member-specific structures from the eight shared official pages.
subcommittees = {
    'ACES-MEMBER-03': [{'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'}],
    'ACES-MEMBER-04': [{'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'chair', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'}],
    'ACES-MEMBER-05': [{'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'}],
    'ACES-MEMBER-06': [
        {'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-07': [
        {'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-08': [{'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'}],
    'ACES-MEMBER-09': [{'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'}],
    'ACES-MEMBER-10': [
        {'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'represented_member', 'representative': 'Amber Charlesworth', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'},
        {'subcommittee_id': 'space_sustainability', 'role': 'represented_member', 'representative': 'Josef Koller', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-11': [
        {'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-12': [
        {'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-13': [
        {'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-14': [
        {'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'},
        {'subcommittee_id': 'space_sustainability', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'},
    ],
    'ACES-MEMBER-15': [{'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'chair', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'}],
    'ACES-MEMBER-16': [{'subcommittee_id': 'space_sustainability', 'role': 'chair', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'}],
    'ACES-MEMBER-17': [
        {'subcommittee_id': 'private_remote_sensing_licensing', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING'},
        {'subcommittee_id': 'commercial_space_mission_authorization', 'role': 'member', 'source_route_id': 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION'},
    ],
}
chair_authorities = {
    'ACES-MEMBER-01': {'scope': 'committee', 'role': 'chair', 'source_route_ids': ['RD05-W03-SHARED-APPOINTMENT', 'RD05-W03-SHARED-ROSTER', 'RD05-W03-SHARED-MEETING-2024-10-03']},
    'ACES-MEMBER-02': {'scope': 'committee', 'role': 'vice_chair', 'source_route_ids': ['RD05-W03-SHARED-APPOINTMENT', 'RD05-W03-SHARED-ROSTER', 'RD05-W03-SHARED-MEETING-2024-10-03']},
    'ACES-MEMBER-04': {'scope': 'commercial_space_mission_authorization_subcommittee', 'role': 'chair', 'source_route_ids': ['RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION']},
    'ACES-MEMBER-15': {'scope': 'private_remote_sensing_licensing_subcommittee', 'role': 'chair', 'source_route_ids': ['RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING']},
    'ACES-MEMBER-16': {'scope': 'space_sustainability_subcommittee', 'role': 'chair', 'source_route_ids': ['RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY']},
}
assert len(subcommittees) == 15 and len(chair_authorities) == 5

route_by_id = {r['route_id']: r for r in source_plan['routes']}
exact_route_ids = [r['route_id'] for r in source_plan['routes'] if r['route_type'] == 'exact_official_get']
assert len(exact_route_ids) == 25
supported_cells = defaultdict(list)
for u in units:
    uid = u['unit_id']
    profile_route = f"RD05-W03-{u['unit_ordinal']:02d}-PROFILE"
    supported_cells['RD05-W03-SHARED-ROSTER'].append(f'{uid}:canonical_member_identity_and_affiliation')
    supported_cells[profile_route].extend([
        f'{uid}:canonical_member_identity_and_affiliation',
        f'{uid}:source_identities_and_exact_custody',
    ])
for uid, assignments in subcommittees.items():
    for assignment in assignments:
        supported_cells[assignment['source_route_id']].append(f'{uid}:subcommittee_assignment_and_role')
for uid, authority in chair_authorities.items():
    for rid in authority['source_route_ids']:
        supported_cells[rid].append(f'{uid}:agenda_setting_or_chair_authority')

observation_rows = []
for rid in exact_route_ids:
    route = route_by_id[rid]
    receipt = json.loads((CENSUS / f'routes/{rid}/receipt.json').read_text())
    row = {
        'schema_version': 'ssc-rd05-wave03-official-body-observation@1',
        'observation_id': f'RD05-OFFICIAL-{route["ordinal"]:03d}',
        'route_id': rid,
        'route_ordinal': route['ordinal'],
        'scope': receipt['scope'],
        'unit_id': receipt.get('unit_id'),
        'source_class': receipt['route_type'],
        'requested_url': receipt['requested_url'],
        'final_url': receipt['final_url'],
        'http_status': receipt['http_status'],
        'content_type': receipt['content_type'],
        'body_bytes': receipt['body_bytes'],
        'body_sha256': receipt['body_sha256'],
        'headers_bytes': receipt['headers_bytes'],
        'headers_sha256': receipt['headers_sha256'],
        'supported_member_field_cells': sorted(set(supported_cells.get(rid, []))),
        'member_event_negative_finding_authorized': False,
        'body_committed_to_git': False,
        'raw_visible_text_committed_to_git': False,
        'outside_human_dependency': False,
        'publication_effect': 'none',
        'adoption_effect': 'none',
        'graph_effect': 'none',
    }
    observation_rows.append(row)
obs_path = DATA_ROOT / 'official-body-observations.jsonl'
obs_path.write_text(''.join(json.dumps(r, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n' for r in observation_rows))

observation_protocol = {
    'schema_version': 'ssc-rd05-wave03-official-body-observation-protocol@1',
    'wave_id': 'SSC-RD-W03',
    'lane_id': 'RD-05',
    'class_id': 'RD-05-C02',
    'issue': 1018,
    'source_census_receipt_path': 'source-census-execution-receipt.json',
    'declared_official_body_rows': 25,
    'network_requests_authorized': 0,
    'route_ids': exact_route_ids,
    'field_observation_rules': {
        'canonical_member_identity_and_affiliation': 'Observed only from the exact official roster and member profile bodies.',
        'subcommittee_assignment_and_role': 'Observed only from the three exact official subcommittee membership lists; representation on behalf of a member is retained as represented_member, not direct personal attendance or authorship.',
        'agenda_setting_or_chair_authority': 'Observed only for the committee chair, committee vice chair, and the three published subcommittee chairs.',
        'source_identities_and_exact_custody': 'Observed only through exact route, body, header, artifact, and member-profile custody.',
        'meeting_attendance_state': 'No member-specific attendance is observed from a meeting agenda, roll-call agenda item, or generic statement that committee members met in person.',
        'recorded_vote_state_and_vote_identity': 'No recorded member vote is observed.',
        'dissent_concurrence_or_separate_statement_state': 'No member-specific dissent, concurrence, or separate statement is observed; silence is not unanimity.',
        'information_access_or_briefing_custody_where_public': 'Public webinar and presentation availability do not establish member-specific information access.',
        'recommendation_drafting_or_authorship_custody': 'A subcommittee mandate to research and draft recommendations and a member assignment do not establish individual authorship.',
    },
    'authority': {
        'automatic_field_promotion': False,
        'negative_event_finding': False,
        'candidate_page_followup': False,
        'outside_human_dependency': False,
        'publication_effect': 'none',
        'adoption_effect': 'none',
        'graph_effect': 'none',
    },
}
(DATA_ROOT / 'official-body-observation-protocol.json').write_text(canonical_json(observation_protocol))

# Builder and validator source are written below. The builder regenerates the six derived terminal objects.
builder = r'''#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const SOURCE_PR = __SOURCE_PR__;
export const PATHS = Object.freeze({
  fieldContract: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/field-matrix-contract.json',
  intakeManifest: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/intake-product-manifest.json',
  sourceProtocol: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/source-census-protocol.json',
  sourceReceipt: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/source-census-execution-receipt.json',
  candidateIndex: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/candidate-adjudication/index.json',
  candidateDir: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/candidate-adjudication',
  officialProtocol: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/official-body-observation-protocol.json',
  officialObservations: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/official-body-observations.jsonl',
  sourceManifest: 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/candidate-and-official-observation-manifest.json',
  matrix: 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/terminal-field-matrix.json',
  summary: 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/summary.json',
  classReceipt: 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/class-receipt.json',
  manifest: 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/manifest.json',
  closure: 'data/project/ssc-residual-wave03/closures/RD-05-C02.json',
});

export const REQUIRED_FIELDS = Object.freeze([
  'canonical_member_identity_and_affiliation',
  'meeting_attendance_state',
  'recorded_vote_state_and_vote_identity',
  'dissent_concurrence_or_separate_statement_state',
  'subcommittee_assignment_and_role',
  'agenda_setting_or_chair_authority',
  'information_access_or_briefing_custody_where_public',
  'recommendation_drafting_or_authorship_custody',
  'source_identities_and_exact_custody',
  'field_and_member_terminal_state',
]);

export const SUBCOMMITTEES = Object.freeze(__SUBCOMMITTEES__);
export const CHAIR_AUTHORITIES = Object.freeze(__CHAIR_AUTHORITIES__);

const readJson = rel => JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8'));
const readJsonl = rel => fs.readFileSync(path.join(ROOT, rel), 'utf8').split(/\n/).filter(Boolean).map(line => JSON.parse(line));
const canonical = value => `${JSON.stringify(value, null, 2)}\n`;
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const fileReceipt = (base, rel) => {
  const data = fs.readFileSync(path.join(base, rel));
  return { path: rel, bytes: data.length, sha256: sha256(data) };
};
const candidateRoute = (unitOrdinal, queryClass) => `RD05-W03-${String(unitOrdinal).padStart(2, '0')}-${({
  meeting_attendance_state: 'ATTENDANCE',
  recorded_vote_state_and_vote_identity: 'VOTE',
  dissent_concurrence_or_separate_statement_state: 'DISSENT',
  subcommittee_assignment_and_role: 'SUBCOMMITTEE',
  agenda_setting_or_chair_authority: 'AGENDA-AUTHORITY',
  information_access_or_briefing_custody_where_public: 'INFORMATION-ACCESS',
  recommendation_drafting_or_authorship_custody: 'AUTHORSHIP',
}[queryClass])}`;

function observed(value, sourceIds, note, custodyPaths = []) {
  return { state: 'observed', value, source_ids: sourceIds, custody_paths: custodyPaths, note, fixed_protocol_complete: true, terminal_for_class_closure: true };
}
function missing(field, unit, sourceIds, note) {
  return {
    state: 'not_publicly_recovered',
    value: {
      public_record_state: 'not_publicly_recovered_after_fixed_protocol',
      searched_candidate_route_id: candidateRoute(unit.unit_ordinal, field),
      event_absence_inferred: false,
      nonparticipation_inferred: false,
    },
    source_ids: sourceIds,
    custody_paths: [PATHS.sourceReceipt, PATHS.candidateIndex, PATHS.officialObservations],
    note,
    fixed_protocol_complete: true,
    terminal_for_class_closure: true,
  };
}

export function buildAll() {
  const contract = readJson(PATHS.fieldContract);
  const intakeManifest = readJson(PATHS.intakeManifest);
  const sourceProtocol = readJson(PATHS.sourceProtocol);
  const sourceReceipt = readJson(PATHS.sourceReceipt);
  const candidateIndex = readJson(PATHS.candidateIndex);
  const officialProtocol = readJson(PATHS.officialProtocol);
  const observations = readJsonl(PATHS.officialObservations);
  assert.deepEqual(contract.required_fields, REQUIRED_FIELDS);
  assert.equal(contract.units.length, 17);
  assert.equal(sourceReceipt.fixed_routes, 161);
  assert.equal(sourceReceipt.candidate_rows, 1351);
  assert.equal(candidateIndex.counts.terminal_candidate_dispositions, 1351);
  assert.equal(candidateIndex.counts.selected_candidate_followups, 0);
  assert.equal(officialProtocol.declared_official_body_rows, 25);
  assert.equal(observations.length, 25);

  const sourceBase = path.join(ROOT, 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation');
  const sourceEntries = [
    fileReceipt(sourceBase, 'source-census-execution-receipt.json'),
    fileReceipt(sourceBase, 'candidate-adjudication/index.json'),
    ...candidateIndex.candidate_parts.map(part => fileReceipt(sourceBase, `candidate-adjudication/${part.path}`)),
    fileReceipt(sourceBase, 'official-body-observation-protocol.json'),
    fileReceipt(sourceBase, 'official-body-observations.jsonl'),
  ];
  const sourceManifest = {
    schema_version: 'ssc-rd05-wave03-candidate-and-official-observation-manifest@1',
    entries: sourceEntries,
    entry_count: sourceEntries.length,
    combined_sha256: sha256(Buffer.from(sourceEntries.map(row => `${row.path}\0${row.bytes}\0${row.sha256}`).join('\n'))),
    candidate_rows: 1351,
    terminal_candidate_dispositions: 1351,
    selected_candidate_followups: 0,
    official_body_observations: 25,
    admitted_candidate_sources: 0,
    result_spawned_requests: 0,
    outside_human_dependency: false,
    publication_effect: 'none',
    adoption_effect: 'none',
    graph_effect: 'none',
  };

  const rows = contract.units.map(unit => {
    const profileRoute = `RD05-W03-${String(unit.unit_ordinal).padStart(2, '0')}-PROFILE`;
    const fields = {};
    fields.canonical_member_identity_and_affiliation = observed({
      unit_id: unit.unit_id,
      canonical_name: unit.canonical_name,
      display_name: unit.display_name,
      affiliation: unit.affiliation,
      appointment_capacity: unit.appointment_capacity,
      leadership_role: unit.leadership_role,
      term_end: unit.term_end,
      profile_url: unit.profile_url,
      identity_state: unit.identity_state,
    }, ['RD05-W03-SHARED-ROSTER', profileRoute], 'The exact official roster and member profile establish the published member identity, affiliation, capacity, term, and leadership label only.');
    fields.meeting_attendance_state = missing('meeting_attendance_state', unit, ['RD05-W03-SHARED-MEETING-2024-10-03', 'RD05-W03-SHARED-MEETING-2025-03'], 'A call-to-order or roll-call agenda item and a generic statement that committee members met in person do not establish this member’s attendance.');
    fields.recorded_vote_state_and_vote_identity = missing('recorded_vote_state_and_vote_identity', unit, [], 'No member-specific roll-call vote or vote identity was publicly recovered. Attendance would not establish a vote.');
    fields.dissent_concurrence_or_separate_statement_state = missing('dissent_concurrence_or_separate_statement_state', unit, [], 'No member-specific dissent, concurrence, or separate statement was publicly recovered. No recorded dissent is not unanimity.');
    if (SUBCOMMITTEES[unit.unit_id]) {
      const assignments = SUBCOMMITTEES[unit.unit_id];
      fields.subcommittee_assignment_and_role = observed({ assignments }, [...new Set(assignments.map(row => row.source_route_id))], 'The exact official subcommittee membership lists establish assignment and published role only; assignment does not establish attendance, vote, or recommendation authorship.');
    } else {
      fields.subcommittee_assignment_and_role = missing('subcommittee_assignment_and_role', unit, ['RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING', 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION', 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'], 'The three exact official subcommittee lists do not publicly recover a member-specific assignment for this unit; this is not proof that no informal work occurred.');
    }
    if (CHAIR_AUTHORITIES[unit.unit_id]) {
      fields.agenda_setting_or_chair_authority = observed(CHAIR_AUTHORITIES[unit.unit_id], CHAIR_AUTHORITIES[unit.unit_id].source_route_ids, 'The published committee or subcommittee chair label establishes the bounded chair-authority surface only; it does not establish unilateral agenda control, adoption, or authorship.');
    } else {
      fields.agenda_setting_or_chair_authority = missing('agenda_setting_or_chair_authority', unit, ['RD05-W03-SHARED-MEETING-2024-10-03'], 'No member-specific chair or agenda-setting authority was publicly recovered. An agenda item does not identify who authored or controlled it.');
    }
    fields.information_access_or_briefing_custody_where_public = missing('information_access_or_briefing_custody_where_public', unit, ['RD05-W03-SHARED-MEETING-2024-10-03', 'RD05-W03-SHARED-MEETING-2025-03'], 'Public webinar access, presentation links, or a planned briefing do not establish this member’s receipt of equal or particular information.');
    fields.recommendation_drafting_or_authorship_custody = missing('recommendation_drafting_or_authorship_custody', unit, ['RD05-W03-SHARED-SUBCOMMITTEE-REMOTE-SENSING', 'RD05-W03-SHARED-SUBCOMMITTEE-MISSION-AUTHORIZATION', 'RD05-W03-SHARED-SUBCOMMITTEE-SUSTAINABILITY'], 'A subcommittee mandate to research and draft recommendations and a member assignment do not establish individual drafting or authorship.');
    fields.source_identities_and_exact_custody = observed({
      source_census_workflow_run: sourceReceipt.workflow_run,
      source_census_artifact_id: sourceReceipt.artifact_id,
      source_census_artifact_zip_sha256: sourceReceipt.artifact_zip_sha256,
      profile_route_id: profileRoute,
      profile_url: unit.profile_url,
      fixed_routes: sourceReceipt.fixed_routes,
      candidate_rows: sourceReceipt.candidate_rows,
      selected_candidate_followups: 0,
    }, [profileRoute], 'Exact route, body, header, artifact, candidate-disposition, and official-observation custody is retained without committing raw bodies or admitting search-result rows.', [PATHS.sourceReceipt, PATHS.sourceManifest]);
    const preTerminalStates = Object.values(fields).map(field => field.state);
    const preObserved = preTerminalStates.filter(state => state === 'observed').length;
    const preMissing = preTerminalStates.filter(state => state === 'not_publicly_recovered').length;
    assert.equal(preObserved + preMissing, 9);
    fields.field_and_member_terminal_state = observed({
      required_fields: 10,
      terminal_fields: 10,
      observed_fields: preObserved + 1,
      not_publicly_recovered_fields: preMissing,
      member_terminal_state: 'bounded_source_unavailable',
      member_closed: true,
      class_terminal_state: 'bounded_source_unavailable',
    }, [], 'All ten required fields are explicitly typed. Member closure records the fixed public-record acquisition boundary and does not assert event nonoccurrence.', [PATHS.fieldContract, PATHS.sourceManifest]);
    const stateCounts = Object.values(fields).reduce((acc, field) => ((acc[field.state] = (acc[field.state] ?? 0) + 1), acc), {});
    return {
      unit_id: unit.unit_id,
      unit_ordinal: unit.unit_ordinal,
      canonical_name: unit.canonical_name,
      fields,
      member_result: {
        fixed_protocol_executed: true,
        required_fields: 10,
        terminal_fields: 10,
        state_counts: stateCounts,
        member_terminal_state: 'bounded_source_unavailable',
        member_closed: true,
      },
    };
  });
  const states = rows.flatMap(row => Object.values(row.fields).map(field => field.state));
  const observedFields = states.filter(state => state === 'observed').length;
  const missingFields = states.filter(state => state === 'not_publicly_recovered').length;
  assert.equal(rows.length, 17);
  assert.equal(states.length, 170);
  assert.equal(observedFields, 71);
  assert.equal(missingFields, 99);

  const counts = {
    member_rows: 17,
    required_fields_per_member: 10,
    required_fields: 170,
    terminal_fields: 170,
    observed_fields: 71,
    not_publicly_recovered_fields: 99,
    closed_members: 17,
    fixed_routes: 161,
    route_attempts: 161,
    http_success_routes: 161,
    exact_official_routes: 25,
    official_body_observations: 25,
    candidate_census_routes: 136,
    candidate_rows: 1351,
    terminal_candidate_dispositions: 1351,
    selected_candidate_followups: 0,
    admitted_candidate_sources: 0,
    observed_identity_fields: 17,
    observed_subcommittee_fields: 15,
    observed_chair_authority_fields: 5,
    observed_source_custody_fields: 17,
    observed_terminal_state_fields: 17,
    observed_attendance_fields: 0,
    observed_vote_fields: 0,
    observed_dissent_fields: 0,
    observed_information_access_fields: 0,
    observed_authorship_fields: 0,
    external_contacts: 0,
    external_reviews: 0,
  };
  const currentResult = {
    terminal_state: 'bounded_source_unavailable',
    fixed_protocol_complete: true,
    class_closed: true,
    all_seventeen_members_preserved: true,
    all_one_hundred_seventy_fields_terminal: true,
    candidate_results_admitted: 0,
    missing_records_are_event_absence: false,
    roster_membership_is_attendance: false,
    attendance_is_vote: false,
    subcommittee_assignment_is_authorship: false,
    no_recorded_dissent_is_unanimity: false,
    reviewed_disposition_changed: false,
    outside_human_dependency: false,
    project_blocking: false,
    publication_effect: 'none',
    adoption_effect: 'none',
    graph_effect: 'none',
  };
  const authority = {
    outside_human_dependency: false,
    external_contacts: 0,
    external_reviews: 0,
    denominator_widened: false,
    reviewed_disposition_changed: false,
    participation_finding: false,
    vote_finding: false,
    dissent_or_unanimity_finding: false,
    information_asymmetry_finding: false,
    recommendation_authorship_finding: false,
    coordination_finding: false,
    common_purpose_finding: false,
    publication_effect: 'none',
    adoption_effect: 'none',
    graph_effect: 'none',
  };
  const matrix = {
    schema_version: 'ssc-rd05-wave03-member-participation-terminal-matrix@1',
    wave_id: 'SSC-RD-W03', lane_id: 'RD-05', class_id: 'RD-05-C02', issue: 1018,
    class_label: 'member-specific votes, dissents, subcommittee assignments, agenda control, information access, and recommendation authorship',
    status: 'seventeen_member_one_hundred_seventy_cell_matrix_terminal_bounded_source_unavailable',
    as_of: '2026-08-05',
    source_product: {
      constitution_merge: contract.constitution_merge,
      wave03_current_ledger_merge_at_design: contract.wave03_current_ledger_merge_at_design,
      intake_head: 'bc9800dcd3a3768288a5dfeaf0f7144969994ffa',
      field_matrix_contract_path: PATHS.fieldContract,
      intake_manifest_path: PATHS.intakeManifest,
      source_protocol_path: PATHS.sourceProtocol,
      source_census_receipt_path: PATHS.sourceReceipt,
      source_census_artifact_zip_sha256: sourceReceipt.artifact_zip_sha256,
      candidate_and_observation_manifest_path: PATHS.sourceManifest,
      candidate_and_observation_manifest_combined_sha256: sourceManifest.combined_sha256,
    },
    permitted_field_states: ['observed', 'not_publicly_recovered'],
    required_fields: REQUIRED_FIELDS,
    members: rows,
    counts,
    current_result: currentResult,
    boundaries: {
      roster_membership_is_meeting_attendance: false,
      attendance_is_recorded_vote: false,
      agenda_item_is_adopted_recommendation: false,
      subcommittee_assignment_is_recommendation_authorship: false,
      no_recorded_dissent_is_unanimity: false,
      public_webinar_is_equal_information_access: false,
      committee_termination_is_suppression: false,
      representation_is_neutrality_tokenism_or_effective_counterpower: false,
      missing_public_record_is_nonoccurrence: false,
      search_result_is_evidence: false,
      class_closure_is_lane_or_wave_completion: false,
      publication_effect: 'none', adoption_effect: 'none', graph_effect: 'none',
    },
    authority,
  };
  const summary = {
    schema_version: 'ssc-rd05-wave03-member-participation-summary@1',
    wave_id: 'SSC-RD-W03', lane_id: 'RD-05', class_id: 'RD-05-C02', issue: 1018,
    terminal_state: 'bounded_source_unavailable', class_closed: true, counts, current_result: currentResult, authority,
  };
  const classReceipt = {
    schema_version: 'ssc-rd05-wave03-class-receipt@1',
    wave_id: 'SSC-RD-W03', lane_id: 'RD-05', class_id: 'RD-05-C02', issue: 1018,
    source_pr: SOURCE_PR,
    class_label: 'member-specific votes, dissents, subcommittee assignments, agenda control, information access, and recommendation authorship',
    terminal_state: 'bounded_source_unavailable', class_closed: true,
    closure_basis: [
      'the immutable denominator preserves all seventeen published ACES member rows and ten non-collapsible required fields per member',
      'the fixed 161-route source census completed once, preserving 1,351 candidate rows and twenty-five exact official bodies with zero result-spawned requests',
      'all 1,351 search-result candidates are terminally disposed because none contains the exact normalized member name in title, description, or URL; no candidate page was requested or admitted',
      'the exact official roster, profiles, and subcommittee lists support seventy-one bounded observed cells: seventeen identity, fifteen subcommittee-assignment, five chair-authority, seventeen source-custody, and seventeen terminal-state cells',
      'the remaining ninety-nine cells are explicitly not publicly recovered rather than converted into nonparticipation, no vote, no dissent, equal access, or no authorship findings',
      'all one hundred seventy cells are terminally typed and all seventeen members are closed only for the declared fixed public-record acquisition obligation',
    ],
    counts,
    source_custody: {
      intake_head: 'bc9800dcd3a3768288a5dfeaf0f7144969994ffa',
      source_census_workflow_run: sourceReceipt.workflow_run,
      source_census_artifact_id: sourceReceipt.artifact_id,
      source_census_artifact_zip_sha256: sourceReceipt.artifact_zip_sha256,
      source_census_capture_manifest_sha256: sourceReceipt.capture_manifest_combined_sha256,
      candidate_and_observation_manifest_path: PATHS.sourceManifest,
      candidate_and_observation_manifest_combined_sha256: sourceManifest.combined_sha256,
    },
    unresolved_limit: {
      not_publicly_recovered_fields: 99,
      selected_candidate_followups: 0,
      candidate_page_requests: 0,
      missing_records_are_not_event_absence: true,
      no_recorded_dissent_is_not_unanimity: true,
      subcommittee_assignment_is_not_authorship: true,
      automatic_additional_search_pass_authorized: false,
    },
    authority,
  };
  const researchBase = path.join(ROOT, 'data/research/status-sovereignty-rd-wave03-rd05-member-participation');
  const matrixBytes = Buffer.from(canonical(matrix));
  const summaryBytes = Buffer.from(canonical(summary));
  const receiptBytes = Buffer.from(canonical(classReceipt));
  const manifestEntries = [
    { path: 'terminal-field-matrix.json', bytes: matrixBytes.length, sha256: sha256(matrixBytes) },
    { path: 'summary.json', bytes: summaryBytes.length, sha256: sha256(summaryBytes) },
    { path: 'class-receipt.json', bytes: receiptBytes.length, sha256: sha256(receiptBytes) },
  ];
  const manifest = {
    schema_version: 'ssc-rd05-wave03-terminal-product-manifest@1',
    entries: manifestEntries,
    entry_count: manifestEntries.length,
    combined_sha256: sha256(Buffer.from(manifestEntries.map(row => `${row.path}\0${row.bytes}\0${row.sha256}`).join('\n'))),
  };
  const closure = {
    schema_version: 'ssc-residual-denominator-wave03-class-closure-reference@1',
    wave_issue: 1013, child_issue: 1018, source_pr: SOURCE_PR,
    lane_id: 'RD-05', class_id: 'RD-05-C02',
    exact_label: 'member-specific votes, dissents, subcommittee assignments, agenda control, information access, and recommendation authorship',
    terminal_state: 'bounded_source_unavailable', class_closed: true,
    product: {
      root: 'data/research/status-sovereignty-rd-wave03-rd05-member-participation',
      manifest_path: PATHS.manifest,
      manifest_combined_sha256: manifest.combined_sha256,
      class_receipt_path: PATHS.classReceipt,
    },
    source_custody: {
      source_census_receipt_path: PATHS.sourceReceipt,
      source_census_artifact_id: sourceReceipt.artifact_id,
      source_census_artifact_zip_sha256: sourceReceipt.artifact_zip_sha256,
      candidate_and_observation_manifest_path: PATHS.sourceManifest,
      candidate_and_observation_manifest_combined_sha256: sourceManifest.combined_sha256,
      fixed_routes: 161, candidate_rows: 1351, official_body_observations: 25,
    },
    authority,
    residual_atlas_effect_if_promoted: {
      canonical_classes: 42, open_before: 33, closed_before: 9, open_after: 32, closed_after: 10,
      wave03_selected_attempts_terminal_after_promotion: 4, wave_complete: false,
    },
  };
  return { sourceManifest, matrix, summary, classReceipt, manifest, closure };
}

const OUTPUTS = {
  sourceManifest: PATHS.sourceManifest,
  matrix: PATHS.matrix,
  summary: PATHS.summary,
  classReceipt: PATHS.classReceipt,
  manifest: PATHS.manifest,
  closure: PATHS.closure,
};
export function writeAll() {
  const built = buildAll();
  for (const [key, rel] of Object.entries(OUTPUTS)) {
    const target = path.join(ROOT, rel);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, canonical(built[key]));
  }
}
export function checkAll() {
  const built = buildAll();
  for (const [key, rel] of Object.entries(OUTPUTS)) {
    assert.equal(fs.readFileSync(path.join(ROOT, rel), 'utf8'), canonical(built[key]), `${rel}: deterministic drift`);
  }
  return built;
}
if (process.argv.includes('--write')) writeAll();
else if (process.argv.includes('--check')) checkAll();
else console.log(JSON.stringify(buildAll().summary, null, 2));
'''
builder = builder.replace('__SOURCE_PR__', str(SOURCE_PR)).replace('__SUBCOMMITTEES__', json.dumps(subcommittees, ensure_ascii=False, sort_keys=True)).replace('__CHAIR_AUTHORITIES__', json.dumps(chair_authorities, ensure_ascii=False, sort_keys=True))
BUILDER_PATH.write_text(builder)
BUILDER_PATH.chmod(0o755)

validator = r'''#!/usr/bin/env node
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ROOT as DEFAULT_ROOT, PATHS, REQUIRED_FIELDS, SUBCOMMITTEES, CHAIR_AUTHORITIES, checkAll } from './build-status-sovereignty-rd-wave03-rd05-member-participation.mjs';

const canonical = value => `${JSON.stringify(value, null, 2)}\n`;
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const normalize = value => value.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim().replace(/\s+/g, ' ');
const readJson = (root, rel) => JSON.parse(fs.readFileSync(path.join(root, rel), 'utf8'));
const readJsonl = (root, rel) => fs.readFileSync(path.join(root, rel), 'utf8').split(/\n/).filter(Boolean).map(line => JSON.parse(line));
const fileReceipt = (root, rel) => { const data = fs.readFileSync(path.join(root, rel)); return { path: rel, bytes: data.length, sha256: sha256(data) }; };

export function validateRD05(root = DEFAULT_ROOT, { deterministic = root === DEFAULT_ROOT } = {}) {
  if (deterministic) checkAll();
  const contract = readJson(root, PATHS.fieldContract);
  const sourceReceipt = readJson(root, PATHS.sourceReceipt);
  const candidateIndex = readJson(root, PATHS.candidateIndex);
  const officialProtocol = readJson(root, PATHS.officialProtocol);
  const observations = readJsonl(root, PATHS.officialObservations);
  const sourceManifest = readJson(root, PATHS.sourceManifest);
  const matrix = readJson(root, PATHS.matrix);
  const summary = readJson(root, PATHS.summary);
  const classReceipt = readJson(root, PATHS.classReceipt);
  const manifest = readJson(root, PATHS.manifest);
  const closure = readJson(root, PATHS.closure);

  assert.equal(contract.class_id, 'RD-05-C02');
  assert.equal(contract.units.length, 17);
  assert.deepEqual(contract.required_fields, REQUIRED_FIELDS);
  assert.equal(new Set(contract.units.map(row => row.unit_id)).size, 17);
  assert.equal(sourceReceipt.artifact_zip_sha256, '0829f39c45dc5308c031dcde3efb6514a1f65ec5787ed19c9490bf49e6c1289b');
  assert.equal(sourceReceipt.fixed_routes, 161);
  assert.equal(sourceReceipt.route_attempts, 161);
  assert.deepEqual(sourceReceipt.terminal_state_counts, { http_success: 161 });
  assert.equal(sourceReceipt.exact_official_routes, 25);
  assert.equal(sourceReceipt.candidate_census_routes, 136);
  assert.equal(sourceReceipt.candidate_rows, 1351);
  assert.equal(sourceReceipt.candidate_followups, 0);
  assert.equal(sourceReceipt.record_absence_inferred, false);
  assert.equal(sourceReceipt.member_event_absence_inferred, false);

  assert.equal(candidateIndex.candidate_parts.length, 5);
  assert.equal(candidateIndex.counts.candidate_rows, 1351);
  assert.equal(candidateIndex.counts.terminal_candidate_dispositions, 1351);
  assert.equal(candidateIndex.counts.selected_candidate_followups, 0);
  assert.equal(candidateIndex.counts.exact_member_name_signal_rows, 0);
  const candidates = candidateIndex.candidate_parts.flatMap(part => readJsonl(root, `${PATHS.candidateDir}/${part.path}`));
  assert.equal(candidates.length, 1351);
  assert.equal(new Set(candidates.map(row => row.candidate_id)).size, 1351);
  assert.deepEqual(candidates.map(row => row.candidate_id), [...candidates].sort((a, b) => a.route_ordinal - b.route_ordinal || a.result_rank - b.result_rank || a.candidate_id.localeCompare(b.candidate_id)).map(row => row.candidate_id));
  for (const row of candidates) {
    const surface = normalize(`${row.title} ${row.description} ${row.url}`);
    assert.equal(surface.includes(normalize(row.canonical_name)), false, `${row.candidate_id}: exact member signal drift`);
    assert.equal(row.exact_member_name_signal, false);
    assert.equal(row.followup_eligibility, false);
    assert.equal(row.terminal_disposition, 'terminal_no_exact_member_identity_signal');
    assert.equal(row.selected_for_followup, false);
    assert.equal(row.followup_requested, false);
    assert.equal(row.admitted_evidence_source, false);
    assert.equal(row.member_field_effect, 'none');
    assert.equal(row.graph_effect, 'none');
  }

  assert.equal(officialProtocol.declared_official_body_rows, 25);
  assert.equal(officialProtocol.network_requests_authorized, 0);
  assert.equal(observations.length, 25);
  assert.equal(new Set(observations.map(row => row.route_id)).size, 25);
  assert.deepEqual(observations.map(row => row.route_id), officialProtocol.route_ids);
  for (const row of observations) {
    assert.equal(row.http_status, 200);
    assert.equal(row.content_type, 'text/html');
    assert.match(row.body_sha256, /^[0-9a-f]{64}$/);
    assert.match(row.headers_sha256, /^[0-9a-f]{64}$/);
    assert.equal(row.member_event_negative_finding_authorized, false);
    assert.equal(row.body_committed_to_git, false);
    assert.equal(row.graph_effect, 'none');
  }

  const sourceBase = 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation';
  const expectedSourceEntries = [
    fileReceipt(root, `${sourceBase}/source-census-execution-receipt.json`).path ? fileReceipt(root, `${sourceBase}/source-census-execution-receipt.json`) : null,
  ];
  const sourceEntryPaths = [
    'source-census-execution-receipt.json', 'candidate-adjudication/index.json',
    ...candidateIndex.candidate_parts.map(part => `candidate-adjudication/${part.path}`),
    'official-body-observation-protocol.json', 'official-body-observations.jsonl',
  ];
  const recomputedSourceEntries = sourceEntryPaths.map(rel => {
    const receipt = fileReceipt(root, `${sourceBase}/${rel}`);
    return { path: rel, bytes: receipt.bytes, sha256: receipt.sha256 };
  });
  assert.deepEqual(sourceManifest.entries, recomputedSourceEntries);
  assert.equal(sourceManifest.entry_count, 9);
  assert.equal(sourceManifest.combined_sha256, sha256(Buffer.from(recomputedSourceEntries.map(row => `${row.path}\0${row.bytes}\0${row.sha256}`).join('\n'))));
  assert.equal(sourceManifest.candidate_rows, 1351);
  assert.equal(sourceManifest.terminal_candidate_dispositions, 1351);
  assert.equal(sourceManifest.selected_candidate_followups, 0);
  assert.equal(sourceManifest.official_body_observations, 25);
  assert.equal(sourceManifest.admitted_candidate_sources, 0);
  assert.equal(sourceManifest.result_spawned_requests, 0);
  assert.equal(sourceManifest.outside_human_dependency, false);
  assert.equal(sourceManifest.publication_effect, 'none');
  assert.equal(sourceManifest.adoption_effect, 'none');
  assert.equal(sourceManifest.graph_effect, 'none');

  assert.equal(matrix.schema_version, 'ssc-rd05-wave03-member-participation-terminal-matrix@1');
  assert.equal(matrix.members.length, 17);
  assert.deepEqual(matrix.required_fields, REQUIRED_FIELDS);
  const memberIds = contract.units.map(row => row.unit_id);
  assert.deepEqual(matrix.members.map(row => row.unit_id), memberIds);
  const allFields = [];
  for (const member of matrix.members) {
    assert.deepEqual(Object.keys(member.fields), REQUIRED_FIELDS);
    assert.equal(member.member_result.required_fields, 10);
    assert.equal(member.member_result.terminal_fields, 10);
    assert.equal(member.member_result.member_closed, true);
    assert.equal(member.member_result.member_terminal_state, 'bounded_source_unavailable');
    for (const [fieldName, field] of Object.entries(member.fields)) {
      assert.ok(['observed', 'not_publicly_recovered'].includes(field.state));
      assert.equal(field.fixed_protocol_complete, true);
      assert.equal(field.terminal_for_class_closure, true);
      allFields.push({ unit_id: member.unit_id, field_name: fieldName, ...field });
    }
  }
  assert.equal(allFields.length, 170);
  assert.equal(allFields.filter(row => row.state === 'observed').length, 71);
  assert.equal(allFields.filter(row => row.state === 'not_publicly_recovered').length, 99);
  const observedByField = Object.fromEntries(REQUIRED_FIELDS.map(field => [field, allFields.filter(row => row.field_name === field && row.state === 'observed').map(row => row.unit_id).sort()]));
  assert.deepEqual(observedByField.canonical_member_identity_and_affiliation, memberIds.slice().sort());
  assert.deepEqual(observedByField.subcommittee_assignment_and_role, Object.keys(SUBCOMMITTEES).sort());
  assert.deepEqual(observedByField.agenda_setting_or_chair_authority, Object.keys(CHAIR_AUTHORITIES).sort());
  assert.deepEqual(observedByField.source_identities_and_exact_custody, memberIds.slice().sort());
  assert.deepEqual(observedByField.field_and_member_terminal_state, memberIds.slice().sort());
  for (const field of ['meeting_attendance_state', 'recorded_vote_state_and_vote_identity', 'dissent_concurrence_or_separate_statement_state', 'information_access_or_briefing_custody_where_public', 'recommendation_drafting_or_authorship_custody']) assert.deepEqual(observedByField[field], []);

  const counts = matrix.counts;
  assert.deepEqual(counts, summary.counts);
  assert.deepEqual(counts, classReceipt.counts);
  assert.equal(counts.required_fields, 170);
  assert.equal(counts.terminal_fields, 170);
  assert.equal(counts.observed_fields, 71);
  assert.equal(counts.not_publicly_recovered_fields, 99);
  assert.equal(counts.observed_identity_fields, 17);
  assert.equal(counts.observed_subcommittee_fields, 15);
  assert.equal(counts.observed_chair_authority_fields, 5);
  assert.equal(counts.observed_source_custody_fields, 17);
  assert.equal(counts.observed_terminal_state_fields, 17);
  assert.equal(counts.selected_candidate_followups, 0);
  assert.equal(counts.admitted_candidate_sources, 0);
  assert.equal(summary.terminal_state, 'bounded_source_unavailable');
  assert.equal(summary.class_closed, true);
  assert.equal(classReceipt.terminal_state, 'bounded_source_unavailable');
  assert.equal(classReceipt.class_closed, true);
  assert.equal(classReceipt.unresolved_limit.missing_records_are_not_event_absence, true);
  assert.equal(classReceipt.unresolved_limit.no_recorded_dissent_is_not_unanimity, true);
  assert.equal(classReceipt.unresolved_limit.subcommittee_assignment_is_not_authorship, true);
  assert.equal(closure.class_closed, true);
  assert.equal(closure.terminal_state, 'bounded_source_unavailable');
  assert.equal(closure.product.manifest_combined_sha256, manifest.combined_sha256);
  assert.deepEqual(closure.residual_atlas_effect_if_promoted, { canonical_classes: 42, open_before: 33, closed_before: 9, open_after: 32, closed_after: 10, wave03_selected_attempts_terminal_after_promotion: 4, wave_complete: false });

  for (const object of [matrix.current_result, matrix.authority, summary.current_result, summary.authority, classReceipt.authority, closure.authority]) {
    assert.equal(object.outside_human_dependency, false);
    assert.equal(object.publication_effect, 'none');
    assert.equal(object.adoption_effect, 'none');
    assert.equal(object.graph_effect, 'none');
  }
  for (const [key, value] of Object.entries(matrix.boundaries)) if (key.endsWith('_is_meeting_attendance') || key.includes('_is_') || key.includes('_is_nonoccurrence')) assert.equal(value, false, key);

  const researchBase = 'data/research/status-sovereignty-rd-wave03-rd05-member-participation';
  const researchEntries = ['terminal-field-matrix.json', 'summary.json', 'class-receipt.json'].map(rel => {
    const receipt = fileReceipt(root, `${researchBase}/${rel}`);
    return { path: rel, bytes: receipt.bytes, sha256: receipt.sha256 };
  });
  assert.deepEqual(manifest.entries, researchEntries);
  assert.equal(manifest.entry_count, 3);
  assert.equal(manifest.combined_sha256, sha256(Buffer.from(researchEntries.map(row => `${row.path}\0${row.bytes}\0${row.sha256}`).join('\n'))));
  return { members: 17, terminal_fields: 170, observed_fields: 71, not_publicly_recovered_fields: 99, candidate_rows: 1351, official_body_observations: 25, class_closed: true };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) console.log(JSON.stringify(validateRD05(), null, 2));
'''
VALIDATOR_PATH.write_text(validator)
VALIDATOR_PATH.chmod(0o755)

# The test mutates each of the 170 terminal cells plus source, candidate, count, and authority controls.
test_source = r'''#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ROOT, PATHS } from '../tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs';
import { validateRD05 } from '../tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs';

const relevant = [
  'data/intake/status-sovereignty-rd-wave03-rd05-member-participation',
  'data/research/status-sovereignty-rd-wave03-rd05-member-participation',
  'data/project/ssc-residual-wave03/closures/RD-05-C02.json',
  'schemas/status-sovereignty-rd-wave03-rd05-member-participation.schema.json',
];
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'rd05-terminal-test-'));
for (const rel of relevant) fs.cpSync(path.join(ROOT, rel), path.join(temp, rel), { recursive: true });
let mutations = 0;
function expectFailure(rel, mutator) {
  const target = path.join(temp, rel);
  const original = fs.readFileSync(target, 'utf8');
  mutator(target, original);
  assert.throws(() => validateRD05(temp, { deterministic: false }));
  fs.writeFileSync(target, original);
  mutations += 1;
}
function mutateJson(rel, mutator) { expectFailure(rel, (target, original) => { const value = JSON.parse(original); mutator(value); fs.writeFileSync(target, `${JSON.stringify(value, null, 2)}\n`); }); }

assert.deepEqual(validateRD05(), { members: 17, terminal_fields: 170, observed_fields: 71, not_publicly_recovered_fields: 99, candidate_rows: 1351, official_body_observations: 25, class_closed: true });
const matrixRel = PATHS.matrix;
const matrix = JSON.parse(fs.readFileSync(path.join(temp, matrixRel), 'utf8'));
for (let memberIndex = 0; memberIndex < matrix.members.length; memberIndex += 1) {
  for (const fieldName of Object.keys(matrix.members[memberIndex].fields)) {
    mutateJson(matrixRel, value => { const field = value.members[memberIndex].fields[fieldName]; field.state = field.state === 'observed' ? 'not_publicly_recovered' : 'observed'; });
  }
}
for (const [rel, mutate] of [
  [PATHS.summary, value => { value.counts.observed_fields = 72; }],
  [PATHS.summary, value => { value.class_closed = false; }],
  [PATHS.classReceipt, value => { value.unresolved_limit.missing_records_are_not_event_absence = false; }],
  [PATHS.classReceipt, value => { value.authority.outside_human_dependency = true; }],
  [PATHS.closure, value => { value.residual_atlas_effect_if_promoted.open_after = 31; }],
  [PATHS.closure, value => { value.terminal_state = 'complete_participation_history'; }],
  [PATHS.sourceReceipt, value => { value.candidate_rows = 1350; }],
  [PATHS.sourceReceipt, value => { value.artifact_zip_sha256 = '0'.repeat(64); }],
  [PATHS.candidateIndex, value => { value.counts.selected_candidate_followups = 1; }],
  [PATHS.officialProtocol, value => { value.network_requests_authorized = 1; }],
  [PATHS.sourceManifest, value => { value.graph_effect = 'edge'; }],
]) mutateJson(rel, mutate);

const firstPart = JSON.parse(fs.readFileSync(path.join(temp, `${PATHS.candidateDir}/part-00.jsonl`), 'utf8').split('\n')[0]);
expectFailure(`${PATHS.candidateDir}/part-00.jsonl`, (target, original) => {
  const lines = original.split('\n'); const row = JSON.parse(lines[0]); row.selected_for_followup = true; lines[0] = JSON.stringify(row); fs.writeFileSync(target, lines.join('\n'));
});
expectFailure(PATHS.officialObservations, (target, original) => {
  const lines = original.split('\n'); const row = JSON.parse(lines[0]); row.body_sha256 = '0'.repeat(64); lines[0] = JSON.stringify(row); fs.writeFileSync(target, lines.join('\n'));
});
assert.equal(mutations, 183);
console.log(`RD-05 terminal adversarial mutations refused: ${mutations}`);
'''
TEST_PATH.write_text(test_source)
TEST_PATH.chmod(0o755)

schema = {
    '$schema': 'https://json-schema.org/draft/2020-12/schema',
    '$id': 'https://example.invalid/schemas/status-sovereignty-rd-wave03-rd05-member-participation.schema.json',
    'title': 'SSC RD-05 Wave-03 member participation terminal product',
    'type': 'object',
    'additionalProperties': False,
    'required': ['schema_version', 'wave_id', 'lane_id', 'class_id', 'issue'],
    'properties': {
        'schema_version': {'type': 'string', 'pattern': '^ssc-rd05-wave03-'},
        'wave_id': {'const': 'SSC-RD-W03'},
        'lane_id': {'const': 'RD-05'},
        'class_id': {'const': 'RD-05-C02'},
        'issue': {'const': 1018},
    },
    '$defs': {
        'field_state': {'enum': ['observed', 'not_publicly_recovered']},
        'terminal_counts': {
            'type': 'object', 'additionalProperties': True,
            'required': ['member_rows', 'required_fields', 'terminal_fields', 'observed_fields', 'not_publicly_recovered_fields'],
            'properties': {
                'member_rows': {'const': 17}, 'required_fields': {'const': 170}, 'terminal_fields': {'const': 170},
                'observed_fields': {'const': 71}, 'not_publicly_recovered_fields': {'const': 99},
            },
        },
        'authority': {
            'type': 'object', 'additionalProperties': True,
            'required': ['outside_human_dependency', 'publication_effect', 'adoption_effect', 'graph_effect'],
            'properties': {
                'outside_human_dependency': {'const': False}, 'publication_effect': {'const': 'none'},
                'adoption_effect': {'const': 'none'}, 'graph_effect': {'const': 'none'},
            },
        },
    },
    'x-closed-product-contract': {
        'member_rows': 17, 'required_fields_per_member': 10, 'required_cells': 170,
        'observed_fields': 71, 'not_publicly_recovered_fields': 99,
        'candidate_rows': 1351, 'terminal_candidate_dispositions': 1351,
        'official_body_observations': 25, 'selected_candidate_followups': 0,
        'terminal_state': 'bounded_source_unavailable', 'class_closed': True,
    },
}
SCHEMA_PATH.write_text(canonical_json(schema))

DOC_PATH.write_text(f'''# SSC RD Wave 03 — RD-05-C02 terminal member-participation custody\n\nThis product closes the declared **RD-05-C02** public-record acquisition obligation while preserving the difference between member identity, assignment, attendance, vote, dissent, access, and authorship.\n\n```text\npublished ACES member rows                 17\nrequired fields per member                 10\nrequired member-field cells               170\nterminal member-field cells           170 / 170\nobserved fields                             71\nnot-publicly-recovered fields               99\nfixed source routes                        161\nterminal route receipts                    161\nsearch-result candidate rows             1,351\nterminal candidate dispositions          1,351\nselected candidate followups                 0\nexact official-body observations            25\nterminal state          bounded_source_unavailable\nclass closed                              true\n```\n\nThe 71 observed cells are exactly 17 published identity/affiliation cells, 15 subcommittee-assignment cells, 5 bounded chair-authority cells, 17 source-custody cells, and 17 terminal-state cells. The remaining 99 cells are typed as `not_publicly_recovered`: 17 attendance, 17 vote, 17 dissent/concurrence, 17 information-access, 17 authorship, 2 subcommittee-assignment, and 12 agenda/chair-authority cells.\n\nAll 1,351 search-result rows failed the predeclared exact normalized member-name gate. No candidate URL was requested, selected, or admitted. Search-result text, rank, domain, and lexical similarity remain non-evidence.\n\n```text\nroster membership           ≠ attendance\nattendance                  ≠ vote\nagenda item                 ≠ adopted recommendation\nsubcommittee assignment     ≠ authorship\nno recorded dissent         ≠ unanimity\npublic webinar              ≠ member-specific information access\ncommittee termination       ≠ suppression\nbounded public corpus       ≠ complete participation history\n```\n\nClass closure records exhaustion of this fixed public-source denominator. It does not establish participation or nonparticipation, a vote, unanimity, equal information access, authorship, coordination, common purpose, publication, adoption, or a graph edge. Outside-human dependency remains false.\n\nThe cumulative ledger must be promoted separately after this class receipt is canonical. The expected promotion is `33 open / 9 closed → 32 open / 10 closed`; this product does not perform that accounting transaction.\n''')

workflow = r'''name: Status sovereignty RD Wave 03 RD-05 terminal member participation

on:
  pull_request:
    branches: [main]
    paths:
      - '.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation.yml'
      - '.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation-intake.yml'
      - 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/**'
      - 'data/project/ssc-residual-wave03/seeds/RD-05-C02.json'
      - 'data/project/ssc-residual-wave03/closures/RD-05-C02.json'
      - 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/**'
      - 'docs/milestones/ssc-rd-wave03-rd05-member-participation*.md'
      - 'schemas/status-sovereignty-rd-wave03-rd05-member-participation*.schema.json'
      - 'tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py'
      - 'tools/build-status-sovereignty-rd-wave03-rd05-member-participation*.mjs'
      - 'tools/validate-status-sovereignty-rd-wave03-rd05-member-participation*.mjs'
      - 'test/status-sovereignty-rd-wave03-rd05-member-participation*.test.js'
  push:
    branches: [main]
    paths:
      - '.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation.yml'
      - '.github/workflows/status-sovereignty-rd-wave03-rd05-member-participation-intake.yml'
      - 'data/intake/status-sovereignty-rd-wave03-rd05-member-participation/**'
      - 'data/project/ssc-residual-wave03/seeds/RD-05-C02.json'
      - 'data/project/ssc-residual-wave03/closures/RD-05-C02.json'
      - 'data/research/status-sovereignty-rd-wave03-rd05-member-participation/**'
      - 'docs/milestones/ssc-rd-wave03-rd05-member-participation*.md'
      - 'schemas/status-sovereignty-rd-wave03-rd05-member-participation*.schema.json'
      - 'tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py'
      - 'tools/build-status-sovereignty-rd-wave03-rd05-member-participation*.mjs'
      - 'tools/validate-status-sovereignty-rd-wave03-rd05-member-participation*.mjs'
      - 'test/status-sovereignty-rd-wave03-rd05-member-participation*.test.js'
  workflow_dispatch:

permissions:
  contents: read

jobs:
  validate:
    runs-on: ubuntu-24.04
    timeout-minutes: 180
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
      - uses: actions/setup-node@v4
        with:
          node-version: '24'
      - uses: actions/setup-python@v5
        with:
          python-version: '3.13'
      - name: Validate exact terminal product
        run: |
          set -Eeuo pipefail
          node --check tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
          node --check tools/validate-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
          node --check test/status-sovereignty-rd-wave03-rd05-member-participation-intake.test.js
          python -m py_compile tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs --check
          node tools/validate-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs
          node test/status-sovereignty-rd-wave03-rd05-member-participation-intake.test.js
          OUT="$RUNNER_TEMP/rd05-intake-dry-run"
          python tools/acquisition/status-sovereignty-rd-wave03-rd05/run-source-census.py --dry-run --output "$OUT"
          node --check tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs
          node --check tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs
          node --check test/status-sovereignty-rd-wave03-rd05-member-participation.test.js
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs --check
          node tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs
          node test/status-sovereignty-rd-wave03-rd05-member-participation.test.js
          node tools/validate-no-magic-human-gate.mjs
          node test/no-magic-human-gate.test.js
      - name: Run complete repository release gate
        run: npm run release:check
      - name: Prove clean deterministic replay
        run: |
          set -Eeuo pipefail
          git restore --staged --worktree .
          git clean -fdx
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs --write
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs --write
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation-intake.mjs --check
          node tools/build-status-sovereignty-rd-wave03-rd05-member-participation.mjs --check
          node tools/validate-status-sovereignty-rd-wave03-rd05-member-participation.mjs
          node test/status-sovereignty-rd-wave03-rd05-member-participation.test.js
          node tools/validate-no-magic-human-gate.mjs
          git diff --check
          git diff --exit-code
          test -z "$(git status --porcelain=v1 --untracked-files=all)"
      - name: Preserve exact terminal custody
        uses: actions/upload-artifact@v4
        with:
          name: ssc-rd05-wave03-terminal-member-participation
          path: |
            data/intake/status-sovereignty-rd-wave03-rd05-member-participation
            data/research/status-sovereignty-rd-wave03-rd05-member-participation
            data/project/ssc-residual-wave03/closures/RD-05-C02.json
            docs/milestones/ssc-rd-wave03-rd05-member-participation.md
            schemas/status-sovereignty-rd-wave03-rd05-member-participation.schema.json
          if-no-files-found: error
          retention-days: 90
'''
WORKFLOW_PATH.write_text(workflow)

# Generate the six derived objects through the committed Node builder itself.
print(WORK)
